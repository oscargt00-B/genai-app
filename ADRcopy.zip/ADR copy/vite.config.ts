import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  // Deployed at https://<domain>/portfolio/adr/ on shared hosting (not the
  // domain root), so every built asset URL needs this prefix baked in.
  base: "/portfolio/adr/",
  // Static source assets (favicon, .htaccess) live in ./static, and the
  // built site is emitted to ./Public. They can't share the name "public":
  // macOS's case-insensitive filesystem treats Public/ and public/ as the
  // same folder, which would have Vite copy its own output into itself.
  publicDir: "static",
  build: { outDir: "Public" },
})
