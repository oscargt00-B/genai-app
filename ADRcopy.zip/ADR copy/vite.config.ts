import react from '@vitejs/plugin-react'
import { defineConfig, type Plugin } from 'vite'

/**
 * The built site has to open straight from disk (double-clicking
 * Public/index.html, file://) as well as from any web folder. Browsers block
 * `type="module"` scripts and `crossorigin` requests on file://, so the
 * bundle is emitted as a classic IIFE and index.html's tags are rewritten to
 * plain `<script defer>` / `<link rel="stylesheet">`.
 */
function classicScriptTags(): Plugin {
  return {
    name: 'classic-script-tags',
    enforce: 'post',
    transformIndexHtml(html) {
      return html
        .replace(/<script type="module" crossorigin /g, '<script defer ')
        .replace(/<link rel="stylesheet" crossorigin /g, '<link rel="stylesheet" ')
    },
  }
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), classicScriptTags()],
  // Relative asset URLs, so the site works from whichever folder it's
  // placed in (file://, a subfolder, or the domain root).
  base: './',
  // Static source assets (favicon) live in ./static, and the built site is
  // emitted to ./Public. They can't share the name "public": macOS's
  // case-insensitive filesystem treats Public/ and public/ as the same
  // folder, which would have Vite copy its own output into itself.
  publicDir: 'static',
  build: {
    outDir: 'Public',
    rolldownOptions: { output: { format: 'iife', inlineDynamicImports: true } },
  },
})
