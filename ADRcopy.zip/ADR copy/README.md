# ADR — Agent Data Repository

A responsive web app for Plymouth Rock Assurance to search and manage its
agency / producer hierarchy records, built to match the **PRAC-ADR** Figma
file (Home Search 1 / Home Search A / Home Search R 1).

## Stack

- React 19 + TypeScript + Vite + React Router (client-side routing between
  the search page and the Agency/Producer detail pages)
- MUI (Material UI) v9 + `@mui/x-data-grid` — the actual design system used
  in the Figma file (component docs in the file link straight to
  `mui.com/api/...`, and the results grid's toolbar is literally MUI X's
  `GridToolbarQuickFilter`/`GridToolbarColumnsButton`/`GridToolbarExport`).
- Theme tokens pulled from the file's **"PR New"** variable mode via
  `get_variable_defs`: primary `#0078d6`, secondary/orange `#ff7826`, Open
  Sans, the 4/8/12px radius scale, and the exact elevation-4/6 shadow
  strings. `src/theme.ts` exports both the MUI `theme` and a `prPrimitives`
  object (color ramps, radius, spacing, elevations) so components can cite
  the same primitives directly instead of hardcoding values.
- Icons: the local **Font Awesome Pro 6.6.0** kit in `src/assets/` (the same
  icon font referenced throughout the Figma file), loaded via
  `src/assets/fontawesome-fonts.css` (`@font-face`, pointing at
  `src/assets/webfonts/`) + `fontawesome.min.css` (icon-to-glyph classes),
  and rendered through the [FaIcon](src/components/FaIcon.tsx) wrapper —
  not `@mui/icons-material`.

All data is local mock data (`src/data/agencies.ts`, 25 records across 5
branches — 1 Level 1 branch + 1 Level 2 agency + 3 Level 3 producers each)
— there is no backend. Swap `src/lib/searchAgencies.ts` for real API calls
when one is available; the rest of the UI is already decoupled from the
data source.

## Getting started

```bash
npm install
npm run dev
```

Then open the printed local URL (Vite's dev server, e.g. http://localhost:5173)
— since the app is configured to deploy under a subpath (see Deployment
below), the dev server serves it at that same subpath too, e.g.
`http://localhost:5173/portfolio/adr/`.

```bash
npm run build    # production build (also type-checks)
npm run preview  # preview the production build locally
npm run lint      # oxlint
```

## Deployment

This app is 100% static once built — no Node process or backend needed at
runtime — so it's built to be dropped straight into shared/cPanel-style
hosting at **`public_html/portfolio/adr/`**:

- `vite.config.ts` sets `base: "/portfolio/adr/"`, so every built asset URL
  in `Public/index.html` is prefixed correctly for that subfolder rather than
  the domain root.
- `App.tsx`'s router passes `basename: import.meta.env.BASE_URL` to
  `createBrowserRouter`, reading that same value back from Vite rather than
  duplicating it, so in-app links/breadcrumbs and the router never drift out
  of sync with the build config above.
- [static/.htaccess](static/.htaccess) (copied into `Public/` on every build,
  since `publicDir: "static"` in `vite.config.ts` makes Vite copy that folder
  verbatim) rewrites any request that isn't a
  real file/folder back to `index.html`, so a direct load or refresh of a
  deep link like `/portfolio/adr/branch/1012345` doesn't 404 on Apache —
  React Router takes over from `index.html` and renders that route
  client-side.

The build output goes to **`Public/`** (`build.outDir` in `vite.config.ts`),
not Vite's default `dist/`. Vite's source static-asset folder is therefore
`static/` rather than the conventional `public/` — on macOS's
case-insensitive filesystem `Public/` and `public/` are the same folder, so
sharing the name would have Vite copy its own output into itself.

To deploy: `npm run build`, then upload everything **inside** `Public/`
(including the hidden `.htaccess`) into `public_html/portfolio/adr/` via
your host's file manager or SFTP. Re-deploys are just repeating those two
steps — asset filenames are content-hashed, so overwriting the folder each
time is safe.

If this ever needs to move to a different path (or the domain root), update
`base` in `vite.config.ts` and `RewriteBase` in `static/.htaccess` to match,
then rebuild — the router's `basename` follows `base` automatically.

## Screens

One page with progressive disclosure, matching the three Figma frames:

| Figma frame | In this app |
| --- | --- |
| **Home Search 1** | Default state: a combined "Level Code Search" field + Search button (the unique record identifier), with a tune icon inside the field that opens Advanced Search. |
| **Home Search A** | Advanced search ("PRAC - Search Advanced"): L1 Branch Name (select), L2 Agency Code, L3 Producer Code, Agency Group Key, L2 Agency Name (multi-select autocomplete with chips), L3 Producer Name, NPN, Tax ID — with Search / Hide. |
| **Home Search R 1** | Once a search runs, an MUI X DataGrid appears below the (now-expanded) search form with a Reset button, a toolbar (Bulk Edit, Filters, Columns, Export), and native pagination — 25 mock records so pagination has more than one page. |
| **Home Search R 2** | Clicking **Hide** on the advanced form (when at least one field is filled) collapses it into a chip summary — "Clear All", up to 3 value chips (each with its own delete ×), a "+N Terms" overflow count, and a "Show Search" button to re-expand. Deleting a chip re-runs the search with that field cleared; clearing every field (or "Clear All") drops back to the plain quick-search bar. |
| **Side Nav — Collapsed Main** | Clicking the chevron toggle collapses the side nav to a 56px icon-only rail (labels removed, not just clipped) — each icon gets a right-side tooltip, the active item keeps its white pill, and Admin sits below a divider at the bottom. The toggle FAB shows a double-chevron (`angles-left` / `angles-right`) and always straddles the rail's right edge. |

The persistent chrome (top AppBar with the Plymouth Rock logo, permanent —
collapsible — side nav with Home/All Licenses/All Authority (Contracts)/All
Contacts/All Addresses + Admin) matches all three frames and stays across
every state. Every side nav item except **Admin** is a real route (the
active item is derived from the current URL, not a hardcoded flag). The
AppBar's own logo is also a link back to **Home** — not itself part of any
linked Figma frame, but standard behavior for a persistent header logo.

Leaving the Level Code field blank (quick search) or every field blank
(advanced search) and pressing **Search** browses the full 25-record
repository — useful for exercising pagination immediately.

### Results grid columns

The grid's default-visible columns match the mockup exactly: Level, AG Key,
Branch, Level Code, Agency/Producer Name, Main Address 1, City, State,
Actions. The remaining columns from the written spec (Main Address 2, Zip
Code, Legacy Level Code, Heir Status, Heir ID, Heir Type, Channel, Main
Phone Number, NPN, Tax ID, Last Update, Last Update by) are wired into the
same grid and one click away via the native **Columns** toolbar button —
mirroring the DataGrid's built-in column-visibility panel referenced in the
design's component names.

## Licenses (`/licenses`)

Clicking **All Licenses** in the side nav (matching the "Licenses Search R 2"
Figma frame, `node-id=14314-228423`) opens its own quick/advanced search +
results grid, at the same URL a bookmark or shared link would use, following
the exact same pattern as the Home agency search page above —
[LicensesSearchPage.tsx](src/pages/LicensesSearchPage.tsx) mirrors
[AgencySearchPage.tsx](src/pages/AgencySearchPage.tsx) (quick search, an
advanced form, the chip summary, and the unsaved-Bulk-Edit-changes
confirmation dialog on navigation-away or a new search) and
[LicenseDataGrid.tsx](src/components/LicenseDataGrid.tsx) mirrors
[AgencyDataGrid.tsx](src/components/AgencyDataGrid.tsx) (Bulk Edit /
Cancel / Duplicate / Save, the pinned edit row, and the same
edited/selected/pending color states), scoped to `License` records instead
of `Agency` ones.

The grid's default-visible columns match the mockup exactly: Level, Level
Code, Agency/Producer name, License Type, Status, SLN (State License
Number), NPN, License Name, State, Expiration, Actions. The remaining
columns (Branch, Legacy Level Code, Sync Status, License Effective Date,
Person/Firm Indicator, Underwriting Company, Residence Indicator, Line of
Authority, Last Update, Last Update by) come straight from the "Column Menu
- Licenses" Figma frame (`node-id=14314-228810`, the DataGrid's Columns
panel) and are one click away via the native **Columns** toolbar button, same
as the Agency grid. The Actions column's arrow routes by the row's
**Level** to that owner's **Licenses** section (see below), opened with
that specific license's drawer already showing — Level 2 rows go to
`/agency/:levelCode/licenses/...`, Level 3 to
`/producer/:levelCode/licenses/...`.

A license is uniquely identified by **(owner, License State, License Type,
Underwriting Company)** — never by `levelCode` alone, since one
agency/producer can hold several licenses (same `levelCode`, different
State/Type/Underwriting Company). [LicenseDataGrid.tsx](src/components/LicenseDataGrid.tsx)'s
`rowKey()` composite key (mirroring `AuthorityDataGrid.tsx`'s own) is used
everywhere a single identity is needed — `getRowId`, Bulk Edit overrides,
selection, and Duplicate — so editing or selecting one of an owner's
licenses never leaks onto a sibling. [licenses.ts](src/data/licenses.ts)'s
mock data is generated from the real agency/producer roster in
[agencies.ts](src/data/agencies.ts) (excluding its synthetic Level 1 branch
rows), the same "every row resolves to a real record" fix applied to
`authorities.ts` — every L2/L3 record has at least one license, a handful
have several.

The advanced search fields (Level Code, License Type, Status, State,
License Name, NPN, SLN) aren't backed by a linked Figma frame — only the
already-collapsed results screen was — so they're inferred from the grid's
own filterable columns, following the same field-per-column convention as
the Home page's own advanced search.

## All Authority (Contracts) (`/authority`)

Clicking **All Authority (Contracts)** in the side nav matches three linked
Figma frames: "Authority Search 1" (`node-id=14314-227185`, the
quick-search bar — pixel-identical to the Home page's own search field, so
[AuthoritySearchPage.tsx](src/pages/AuthoritySearchPage.tsx) reuses
[QuickSearchBar.tsx](src/components/QuickSearchBar.tsx) verbatim for it),
"Authority Search R 1" (`node-id=14314-228070`, the 16-field advanced
search form + 9-column results grid), and "Column Menu - Contracts"
(`node-id=14314-228869`, the full 35-field Columns panel).

[AuthorityAdvancedSearchForm.tsx](src/components/AuthorityAdvancedSearchForm.tsx)
matches the design's 16 fields exactly, in the same layout order: L1 Branch
Name, L2 Agency Code, L3 Producer Code, Contract State, L2 Agency Name (the
same multi-select-with-chips Autocomplete as the Home page's own field),
L3 Producer Name, LOB, Underwriting Company, Contract Type, Contract
Status, Contract Number, Appointment Date, New Business Indicator, Service
Center Indicator, Underwriting Group, Marketing Group.

[AuthorityDataGrid.tsx](src/components/AuthorityDataGrid.tsx)'s
default-visible columns match the results grid exactly: Level, Level Code,
Agency/Producer Name, State, LOB, Underwriting Company, Contract Type,
Status, Appointment Date, Actions. Every other field from the "Column Menu
- Contracts" panel — Branch, Legacy Level Code, Contract Effective Date,
Contract Number, NBI, Exp/Letter Term Date, NB Termination Date, Renewal
Term Date, Commission Group, Esales Eligible, Super Agent, Profit Sharing,
PSR Profit Sharing Rollup Code, Underwriting Group, Marketing Group,
Service Center Indicator, Service Center Percent Fee, Report Order Group,
Remove Comp Rater Access, Prevent Low BI/CSL, Prevent No Prio Ins, Prevent
Lapse of Coverage, Default VHS Score Value, eSales Only, Sales Channel,
Last Update, Last Update by — is wired into the grid and one click away via
the native **Columns** toolbar button (35 fields total, matching the Figma
panel one-for-one). The long tail of contract-administration fields isn't
meaningfully differentiated by anything in the linked frames, so their mock
values are derived deterministically per record in
[authorities.ts](src/data/authorities.ts) rather than hand-authored —
same pattern `agencyDetails.ts` already uses for its own derived fields.

Every L2 Agency and L3 Producer actually defined in
[agencies.ts](src/data/agencies.ts) (all 20) has at least one contract here
— `authorities.ts` generates one per owner from a roster mirrored from
agencies.ts's own records, cycling through the option lists by index so
each differs a bit, plus a second contract (a different State/LOB/
Underwriting Company) for four owners to keep the "one or many contracts"
case exercised. Earlier mock rows referenced levelCodes that didn't exist
anywhere in agencies.ts and 404'd when clicked through — fixed by
generating strictly from the real roster instead of hand-authoring
arbitrary ones.

Because an owner can now legitimately appear more than once (same
`levelCode`, different contract), `AuthorityDataGrid.tsx` identifies a row
by a `rowKey()` composite of `levelCode|State|LOB|Underwriting Company` —
for `getRowId`, Bulk Edit's override map, and row selection — everywhere
the grid used to key off `levelCode` alone (which would have collided two
of an owner's contracts into one row and let editing one leak into the
other). Verified live: selecting and bulk-editing one of an owner's two
contracts leaves the sibling contract's values untouched.

This follows the same quick/advanced/chips + results-grid pattern already
established by the Home and Licenses pages, including Bulk Edit and the
unsaved-changes confirmation dialog. The Actions column's arrow routes by
the row's **Level**, same as the Agency grid — Level 2 rows open that
contract on its L2 Agency's Contract Details page
(`/agency/:levelCode/contracts/:state/:lob/:company`), Level 3 rows open
it on the L3 Producer's equivalent page — see "Authority (Contracts) —
per-agency/producer" below.

## All Contacts (`/contacts`)

Clicking **All Contacts** in the side nav (now a real link, matching
"Contacts Search 1" `node-id=14314-227191`) follows the exact same
quick/advanced/chips + results-grid pattern as Licenses and Authority:
[ContactsSearchPage.tsx](src/pages/ContactsSearchPage.tsx) mirrors
[LicensesSearchPage.tsx](src/pages/LicensesSearchPage.tsx), and
[ContactDataGrid.tsx](src/components/ContactDataGrid.tsx) mirrors
[LicenseDataGrid.tsx](src/components/LicenseDataGrid.tsx) (Bulk Edit /
Cancel / Duplicate / Save, the pinned edit row, and the same
edited/selected/pending color states), scoped to `Contact` records.

[ContactAdvancedSearchForm.tsx](src/components/ContactAdvancedSearchForm.tsx)
matches "Contacts Search R 1" (`node-id=14314-228183`)'s 11 fields exactly:
L1 Branch Name, L2 Agency Code, L3 Producer Code, Contact Type, L2 Agency
Name (the same multi-select-with-chips Autocomplete as the Home page's own
field), L3 Producer Name, First Name, Last Name, Image Right ID, Phone,
Email. The grid's default-visible columns match the same frame's results
table: Level, Level Code, Agency/Producer name, Contact Type, First Name,
Last Name, Phone, Email, Image Right ID, Actions. The remaining columns
(Contact ID, Branch, Legacy Level Code, UW Company Name, Prefix, Middle
Name, Suffix, Cell Phone, Last Update, Last Update by) come from "Contacts
Menu 1" (`node-id=14314-228837`) and are one click away via **Columns**.
The Actions column's arrow routes by the row's **Level** to its owning
Agency/Producer's Details page — Level 2 rows go to `/agency/:levelCode`,
Level 3 to `/producer/:levelCode` — since a contact doesn't have its own
detail page in the linked Figma frames.

A contact's "Contact Type" can hold several roles at once — the design's
own sample row shows a truncated "CSR, HPM, Commis..." — so
[contacts.ts](src/data/contacts.ts) stores it as a comma-joined string
rather than a single enum value; the advanced search's Contact Type filter
and Bulk Edit's own field editor still treat it as a plain text/select
value, matching how the linked frames themselves only ever show one
dropdown-style field (not a multi-select). Unlike Authority and Licenses,
a Contact record already carries its own unique `contactId` (the "Contact
ID" column from the Figma Columns panel), so it's used directly as
`getRowId`/Bulk Edit's identity — no `rowKey()` composite is needed here,
since one owner's several contacts are never confused with one another in
the first place. [contacts.ts](src/data/contacts.ts)'s mock data is
generated from the real agency/producer roster in
[agencies.ts](src/data/agencies.ts) (the same "every row resolves to a
real record" fix already applied to `authorities.ts`/`licenses.ts`) —
every L2/L3 has at least one contact, a handful have two.

## All Addresses (`/addresses`)

Clicking **All Addresses** in the side nav (now a real link, matching
"Address Search 1" `node-id=14314-227197`) follows the same pattern:
[AddressesSearchPage.tsx](src/pages/AddressesSearchPage.tsx) mirrors
[LicensesSearchPage.tsx](src/pages/LicensesSearchPage.tsx), and
[AddressDataGrid.tsx](src/components/AddressDataGrid.tsx) mirrors
[LicenseDataGrid.tsx](src/components/LicenseDataGrid.tsx), scoped to
`Address` records.

[AddressAdvancedSearchForm.tsx](src/components/AddressAdvancedSearchForm.tsx)
matches "Address Search R 1" (`node-id=14314-228915`)'s 8 fields exactly:
L1 Branch Name, L2 Agency Code, L3 Producer Code, Address Type, Agency Name
(Autocomplete w/ chips), Address, State, Zip Code. The grid's
default-visible columns match the same frame's results table: Level, Level
Code, Agency/Producer Name, Address Type, Address 1, Address 2, City,
State, Zip, Actions. The remaining columns (Address ID, Branch, County,
Phone, Fax, Last Update, Last Update by) come from "Address Menu 1"
(`node-id=14314-228835`) and are one click away via **Columns**. Like
Contacts, an Address record already carries its own unique `addressId`, so
no `rowKey()` composite is needed for `getRowId`/Bulk Edit identity. The
Actions column's arrow routes the same way Contacts' does, by the row's
**Level**, to its owning Agency/Producer's Details page.

[addresses.ts](src/data/addresses.ts) doesn't invent separate mock data —
it's generated directly from the exact same Main/Mailing/(Private Office)
addresses already shown on each owner's own Agency/Producer Details page
("Addresses" card, from `getDetailExtra` in
[agencyDetails.ts](src/data/agencyDetails.ts)), so the two stay consistent
with each other. The L2-only placeholder "Address Type" template row
(blank "Address Line 1"/"City, State Zip"/etc., itself a design template
rather than real data) is excluded. Every L2 Agency and L3 Producer has at
least one address (Main); most have two or three.

## Responsive behavior

- **≥ md**: permanent side nav (collapsible via the chevron toggle at its
  bottom edge), full-width AppBar, and the advanced search grid at 4
  columns.
- **< md**: the side nav becomes an off-canvas drawer opened from a menu
  icon in the AppBar; the quick-search field/button flex to fit; advanced
  search fields stack to a single column; the results grid scrolls
  horizontally within its own container.

## Project structure

```
src/
  components/     TopBar, SideNav, DetailSideNav, DetailShell, QuickSearchBar,
                   AdvancedSearchForm, AgencyDataGrid, LicenseAdvancedSearchForm,
                   LicenseDataGrid, AuthorityAdvancedSearchForm, AuthorityDataGrid,
                   ContractsDataGrid, ContractBreadcrumbs, ContractDetailContent,
                   SearchChipsBar, DetailBreadcrumbs, BranchDetailContent,
                   AgencyDetailContent, ShellMain
  pages/          AgencySearchPage, LicensesSearchPage, AuthoritySearchPage,
                   BranchDetailPage (L1), AgencyDetailPage (L2), ProducerDetailPage (L3),
                   Agency/ProducerContractsPage, Agency/ProducerContractDetailPage
  hooks/          useSidebarShell — shared responsive/collapse state for every side nav
  data/           Mock agency/license/authority records + agencyDetails.ts (derived
                   detail-page fields) + derived option lists
  lib/            Search/filter logic (agencies, licenses & authorities), contracts.ts
                   (per-owner contract lookups), date formatting
  types/          Agency/AdvancedSearchCriteria, License/LicenseAdvancedSearchCriteria &
                   Authority/AuthorityAdvancedSearchCriteria types
  theme.ts        MUI theme tokens pulled from the Figma file
  assets/         Plymouth Rock logo + the Font Awesome Pro kit (css/, webfonts/)
```

## Detail pages (Branch / Agency / Producer View)

The Actions column's arrow routes by the row's **Level**: Level 1 rows go
to `/branch/:levelCode` ("Branch Details"), Level 2 to `/agency/:levelCode`
("Agency Details"), Level 3 to `/producer/:levelCode` ("Producer Details")
— all three built from the Figma detail frames. The mock data now includes
one Level 1 branch record per branch group (25 rows total), generated
alongside its L2/L3 rows in [agencies.ts](src/data/agencies.ts) so the flow
is exercisable straight from the search results grid.

All three share a breadcrumb trail (`Home / {branch} / {L2 agency} /
{L3 producer}`, trimmed to whichever levels exist above the current page)
in [DetailBreadcrumbs.tsx](src/components/DetailBreadcrumbs.tsx) — every
ancestor segment is a real link, the current level renders as plain text
showing its own full, untruncated name, and the trailing segment is a
**functional dropdown** ("Select L2 Agency"
on the branch page, "Select L3" on the agency page, or the other producers
under the same agency on a producer page), all driven by the real
`agencyGroupKey` grouping (`getAgencyGroup` in agencies.ts). Every
*ancestor* segment above the current level — Branch, and L2 when on an L3
page — collapses to a plain `fa-ellipsis` icon instead of its name, to keep
the breadcrumb compact regardless of how deep the hierarchy is; hovering it
shows the full "{code} {name}" in a tooltip, and clicking it still navigates
there exactly as the full link did before.

L2 and L3 share one dark side nav with an expandable Details section
(Contacts/Options/360 Codes sub-items, then Licenses/Authority
(Contracts)/Agency Tier/[QMAs on L3 only]/Commission Rates); L1's is
simpler — a single non-expanding "Branch Details" item, no sub-items or
extra rows, matching its simpler content (one "Branch Information" card,
no Addresses section, no Individual Information). **Agency/Producer
Details**, **Authority (Contracts)**, and **Licenses** are real,
separately-routed sections — see the next two sections below; Agency Tier,
QMAs, and Commission Rates remain visual-only, matching the design's tabs,
since no page exists behind them yet. Each level uses a
**different accent color**, per the Figma frames' own variable bindings
(confirmed by sampling pixels from each screenshot): L1 is `primary/main`
`#0078d6` (the same blue as the main app shell), L2 is `primary/dark`
`#004884`, L3 is a separate `neutral/dark` token, `#2e3845`.
`accentColorFor(level)` in [DetailSideNav.tsx](src/components/DetailSideNav.tsx)
picks the right one (rail background, the active item's icon/text, and the
collapse-toggle FAB all follow it) — except the avatar circle's own text,
which the Figma frames bind to `primary/dark` on every level, regardless of
the rail's own color.

Fields beyond what the results grid already carries (individual name,
Circle of Excl, Dist Channel, eSales Only, the Mailing/Private-Office
addresses, the admin Hier/Entity ids and update timestamps) are derived
deterministically per record by [agencyDetails.ts](src/data/agencyDetails.ts)
(seeded from `levelCode`, not hand-authored) so every row has a
distinct-but-consistent detail page. [AgencyDetailContent.tsx](src/components/AgencyDetailContent.tsx)
is one shared component parameterized per level for L2 vs. L3 (headline,
the "L2/L3 ... Name" field label, whether eSales Only and the New-Producer
button show, and whether the admin bar's "last update" fields are split
into two or combined into one); L1's simpler layout is its own
[BranchDetailContent.tsx](src/components/BranchDetailContent.tsx).

## Authority (Contracts) — per-agency/producer (`/agency/:levelCode/contracts`, `/producer/:levelCode/contracts`)

An L2 Agency or L3 Producer can hold one or many carrier contracts, each
uniquely identified by its **(Contract State, Line of Business,
Underwriting Company)** combination — never by a single id. Clicking
**Authority (Contracts)** in the L2/L3 side nav (now a real link, matching
`node-id=14314-176865` for L2 / `14314-182655` for L3) opens
[ContractsDataGrid.tsx](src/components/ContractsDataGrid.tsx): a results
table scoped to that one owner's contracts (via
[`getContractsForOwner`](src/lib/contracts.ts)), with L2 and L3 using
slightly different columns/widths per their own Figma frames — L3 adds a
leading Contract ID column L2 doesn't have, and abbreviates "Contract
Number" to "Contract N." to fit narrower columns. [DetailSideNav.tsx](src/components/DetailSideNav.tsx)
highlights whichever section is active (`activeItem: "details" |
"contracts"`) and hides the Details section's Contacts/Options/360 Codes
sub-items while on the Contracts section, matching the design.

Clicking a contract row's Actions arrow navigates to that contract's own
page (`.../contracts/:state/:lob/:company`, matching `node-id=14314-179329`
for an L2 contract / `14314-182968` for an L3 one) —
[ContractDetailContent.tsx](src/components/ContractDetailContent.tsx) shows
a "Contract Details" card (22 fields across two columns — Contract
State/Line of Business/Underwriting Company render dimmed, since they're
the contract's own identity, not editable fields) plus a 6-field admin
info bar, and is identical for L2 and L3 (confirmed structurally identical
between the two Figma frames — only the surrounding chrome, side nav
accent and breadcrumb depth, differs). [ContractBreadcrumbs.tsx](src/components/ContractBreadcrumbs.tsx)
extends the usual Home/Branch/Agency(/Producer) chain with one more
segment identifying the contract, itself a **functional dropdown** to any
sibling contract of the same owner. Since the contract is the current
level here, every ancestor above it — Branch, L2 (on an L3 contract page),
and the owning Agency/Producer — collapses to the same ellipsis-icon
treatment DetailBreadcrumbs uses for its own ancestor segments.

The `Authority` type in [types/authority.ts](src/types/authority.ts) is
shared with the standalone `/authority` search page from the section
above — the same real-world entity, just a narrower set of columns shown
in each context. Several fields only matter here, not on the standalone
page (Web Display Name, Aggregation Group, RC1 Use Default, the admin
bar's Bus Entity Id/Polstar Config/Authority Pro Config/Last Pol. Sys.
Push, and L3's extra "Comp Rater Details" / "Agency Transfer Data" /
"Legacy" field groups from its own Columns-menu frame,
`node-id=14314-187738`) — those extra fields exist on every mock record
regardless of level, but this section's own results grid doesn't expose
them as toggleable columns (unlike the standalone page's Columns button,
which does list its own full field set) since that wasn't asked for this
round; only the columns actually shown in the linked Figma frames are
wired up here.

This section's own results grid doesn't offer **Bulk Edit** — contracts
are already fully editable at the record level via the standalone
`/authority` page, and duplicating that machinery for this narrower,
per-owner view wasn't requested.

## Licenses — per-agency/producer (`/agency/:levelCode/licenses`, `/producer/:levelCode/licenses`)

An L2 Agency or L3 Producer can hold one or many licenses, each uniquely
identified by its **(License State, License Type, Underwriting Company)**
combination — never by a single id, the same convention Authority
(Contracts) uses. Clicking **Licenses** in the L2/L3 side nav (now a real
link, matching `node-id=14314-176571` for L2 / `14314-181766` for L3 — the
two frames are structurally identical: same columns, same row data in the
mock) opens [LicensesDataGrid.tsx](src/components/LicensesDataGrid.tsx): a
results table scoped to that one owner's licenses (via
[`getLicensesForOwner`](src/lib/licenses.ts)), with columns State, License
Type, Status, SLN, NPN, License Name, UW Company, P/F Ind, Res Ind,
Effective, Actions — the abbreviated headers the Figma frame itself uses.
[DetailSideNav.tsx](src/components/DetailSideNav.tsx) highlights whichever
section is active (`activeItem: "details" | "contracts" | "licenses"`) and
hides the Details section's Contacts/Options/360 Codes sub-items while on
the Licenses section, matching the design.

Clicking a row's pencil action opens [LicenseDrawer.tsx](src/components/LicenseDrawer.tsx),
a right-side panel matching `node-id=14314-189548` (L2) /
`14314-187937` (L3) — the same drawer design in both Figma frames, differing
only in the mock values filled into each field. The drawer is also
reachable by URL: `.../licenses/:state/:licenseType/:company` opens the
section with that license's drawer already showing, via
[`findLicense`](src/lib/licenses.ts) — this is how the standalone
`/licenses` search page's own Actions column links here (see the Licenses
section above), and it's exactly what "navigate to the License section of
the L2 or L3 with the drawer of that license opened" means in practice.
Closing the drawer (the X, Cancel, or Save) routes back to the bare
`.../licenses` URL when it was opened via a deep link. Delete/Save aren't
wired to any backend, mirroring `ContractDetailContent`'s own "not wired"
precedent — the drawer only displays the record.

Like `ContractsDataGrid`, this embedded table doesn't offer **Bulk Edit**
even though the Figma toolbar itself shows a "Bulk Edit" button — licenses
are already fully editable at the record level via the standalone
`/licenses` search page's own Bulk Edit, and duplicating that machinery for
this narrower, per-owner view wasn't requested.

## Bulk Edit (results grid)

Clicking **Bulk Edit** on the search results grid turns on row checkboxes
and a pinned input row right below the column headers (a synthetic row
injected into the DataGrid's own `rows`, so it scrolls/aligns with the real
columns for free) — one input per bulk-editable column: a text field for
free-text columns, a select for State/Heir Status/Heir Type/Channel. The
toolbar swaps to **Bulk Edit** (now the active toggle) / **Cancel** /
**Duplicate** / **Save**, matching the design.

Once you've selected rows and typed or picked a new value in a column's
input, a **green apply button** appears next to that input — clicking it
pushes that value onto every selected row for that column immediately
(this is the "replace the value on the selected rows" control). You can
apply several columns in sequence before deciding what to do next:

- **Save** commits the session's changes and exits Bulk Edit mode.
- **Cancel** (or clicking **Bulk Edit** again to toggle off) discards
  everything applied since Bulk Edit mode was last turned on — changes from
  an earlier, already-saved session are untouched.
- **Duplicate** clones the selected rows (with a `-COPY` suffixed Level
  Code so they stay unique) and appends them to the grid.

All of this is local component state in [AgencyDataGrid.tsx](src/components/AgencyDataGrid.tsx)
(an `overrides` map keyed by Level Code, plus a `duplicatedRows` array) —
there's no backend, so edits live only for the current browser session and
reset the next time a new search runs.

### Edited/selected color states

While in Bulk Edit mode, three colors — pulled exactly from this Figma
frame via `get_variable_defs` and cross-checked by pixel-sampling its
screenshot — mark what's going on, via `prPrimitives` in [theme.ts](src/theme.ts):

- **A cell edited but not yet saved** ("warning/light" `#fff3ba`): any cell
  whose value differs from what it was when Bulk Edit mode was last turned
  on — i.e. applied via the green button this session but not yet Saved.
- **A selected row** ("primary/paper 1" `#f5faff`) — overriding MUI X
  DataGrid's own default `.Mui-selected` tint, which turned out to be baked
  into its generated styles at definition time rather than read from a
  live CSS variable, so the fix is a directly-targeted `!important` rule on
  the `DataGrid`'s own `sx` (an ancestor-level override was silently
  shadowed).
- **An unselected row with a pending edit** ("warning/paper 1" `#fffef0`) —
  wins only when the row isn't also selected; selection takes priority,
  matching the design.

A cell/row's "pending" state is computed by diffing the current
`overrides` (and, for **Duplicate**, the current `duplicatedRows`) against
a snapshot taken when Bulk Edit mode was last turned on
(`isPendingField`/`rowHasPendingEdit`), so a value — or a whole duplicated
row — saved in an earlier session doesn't re-highlight as unsaved just
because you re-enter Bulk Edit mode later. A row Duplicated this session
gets the unselected-pending row tint even though none of its individual
cells carry an override — the row itself is the unsaved change.

### Guarding against lost changes

While Bulk Edit mode has unsaved changes, three things are locked down:

- **Row Actions are hidden.** The Actions column's arrow (which would
  navigate to a detail page — see below) renders nothing for every row,
  including the pinned edit row, so a click can't jump away from the page
  and silently strand an in-progress edit session.
- **In-app navigation is blocked**, via React Router's `useBlocker` — any
  route change, including the browser Back/Forward buttons — which
  requires `App.tsx` to use a **data router** (`createBrowserRouter` /
  `RouterProvider`) rather than a plain `<BrowserRouter>`, since `useBlocker`
  only works with the former.
- **Starting a new search is held back.** Quick Search and Advanced Search
  both route through `runSearch()` in
  [AgencySearchPage.tsx](src/pages/AgencySearchPage.tsx), which queues the
  search instead of running it immediately whenever Bulk Edit has unsaved
  changes.

Either case opens the same confirmation dialog — **Save changes**,
**Discard changes**, or **Cancel** (stay put, changes untouched) — after
which the save/discard runs against the grid and, if the user chose to
proceed, the navigation completes or the queued search finally runs.
`AgencyDataGrid` exposes `hasUnsavedChanges` / `saveChanges` /
`discardChanges` to its parent via `forwardRef` + `useImperativeHandle`
(the `AgencyDataGridHandle` type) so the search page can drive Save/Discard
without owning the grid's internal edit state itself, and reports its dirty
status upward through an `onDirtyChange` callback.

A real tab close, refresh, or address-bar navigation isn't something
`useBlocker` can intercept, so a `beforeunload` listener covers that case
too — the browser shows its own generic "leave site?" prompt there; the
message text isn't customizable.

### Sorting during Bulk Edit

Clicking a column header still sorts the grid while Bulk Edit mode is on,
exactly like the default grid state — the one difference is the pinned
edit row always stays pinned first, in either sort direction. Each
sortable column supplies a `getSortComparator` (rather than a plain
`sortComparator`) so the comparator can see the current sort direction
itself: for a descending sort, the DataGrid doesn't re-invoke a plain
`sortComparator` with swapped arguments, it just negates whatever it
returned for ascending — which would flip an "always sort first" rule for
the edit row into "always sort last". Handling the direction explicitly
inside the comparator keeps the edit row pinned first correctly both ways.

## Note on scope

Column pinning for the Actions column (shown in Figma) isn't available in
the free `@mui/x-data-grid` Community edition used here — it's a
`@mui/x-data-grid-pro` feature — so the Actions column scrolls with the
rest of the grid instead of staying pinned right.

On the detail pages, the pencil (edit) icons, "+ Address", "New L3
Producer", and the flat nav items below Details (Contacts, Licenses,
Authority (Contracts), Agency Tier, QMAs, Commission Rates) are visually
present to match the design but aren't wired to real edit/detail screens,
since none of those were in the linked Figma frames.
