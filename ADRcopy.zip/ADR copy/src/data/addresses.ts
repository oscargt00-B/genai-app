import type { Address } from "../types/address";
import { agencies } from "./agencies";
import { getDetailExtra } from "./agencyDetails";

/** `agencies` also contains one synthetic "Level 1" branch roll-up row per group (levelNumber "001") — not a real owner of its own addresses, so it's excluded here the same way licenses.ts's own owner roster excludes it. */
const owners = agencies.filter((a) => a.levelNumber !== "001");

function parseCityStateZip(cityStateZip: string): { city: string; state: string; zipCode: string } {
  const [city, rest] = cityStateZip.split(", ");
  const [state, zipCode] = rest.split(" ");
  return { city, state, zipCode };
}

let counter = 0;

/**
 * Mock address records for the Agent Data Repository, matching the
 * "Address Search R 1" / "Address Menu 1" Figma frames' field set. Reuses
 * the exact same Main/Mailing/(Private Office) addresses already shown on
 * each owner's own Agency/Producer Details page ("Addresses" card, from
 * `getDetailExtra` in agencyDetails.ts) rather than inventing separate mock
 * data, so the two stay consistent. The L2-only placeholder "Address Type"
 * template row (blank "Address Line 1"/"City, State Zip"/etc., shown as a
 * design template rather than real data) is skipped here. Every L2 Agency
 * and L3 Producer has at least one address (Main); most have two or three.
 */
export const addresses: Address[] = owners.flatMap((owner) => {
  const extra = getDetailExtra(owner);
  return extra.addresses
    .filter((a) => a.type !== "Address Type")
    .map((a) => {
      const { city, state, zipCode } = parseCityStateZip(a.cityStateZip);
      return {
        addressId: `ADR-${100000 + counter++}`,
        levelNumber: owner.levelNumber,
        levelCode: owner.levelCode,
        branch: owner.branch,
        agencyProducerName: owner.name,
        addressType: a.type,
        address1: a.line1,
        address2: a.line2 ?? "",
        city,
        state,
        zipCode,
        county: a.county,
        phone: a.phone ?? "",
        fax: a.fax ?? "",
        lastUpdate: owner.lastUpdate,
        lastUpdateBy: owner.lastUpdateBy,
      };
    });
});
