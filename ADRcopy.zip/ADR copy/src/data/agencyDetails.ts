import type { Agency } from "../types/agency";

export interface AddressDetail {
  type: string;
  line1: string;
  line2?: string;
  cityStateZip: string;
  county: string;
  fax?: string;
  phone?: string;
}

export interface AgencyDetailExtra {
  firstName: string;
  middleName: string;
  lastName: string;
  circleOfExcl: "Yes" | "No";
  distChannelCode: string;
  eSalesOnly: "Yes" | "No";
  addresses: AddressDetail[];
  agentHierId: string;
  busEntityId: string;
  agentHierType: string;
  lastEntityUpdate: string;
  lastAddressUpdate: string;
  lastPolSysPush: string;
  updatedBy: string;
}

const FIRST_NAMES = ["John", "Maria", "David", "Priya", "James", "Linda", "Robert", "Susan"];
const LAST_NAMES = ["Doe", "Santos", "Kim", "Patel", "Reyes", "Nguyen", "Torres", "Walsh"];
const COUNTIES = ["Manhattan", "Cook", "Fulton", "Maricopa", "King", "Suffolk", "Middlesex", "Denver"];
const DIST_CHANNELS = ["AI", "BR", "DI", "BA"];
const HIER_TYPES = ["Location", "Individual", "Entity"];

/** Simple deterministic hash so the same levelCode always derives the same mock values. */
function hash(input: string): number {
  let h = 0;
  for (let i = 0; i < input.length; i++) h = (h * 31 + input.charCodeAt(i)) >>> 0;
  return h;
}

function pick<T>(pool: T[], seed: number, offset = 0): T {
  return pool[(seed + offset) % pool.length];
}

/** Derives the fields the Agency/Producer Details pages show beyond the search-results columns. */
export function getDetailExtra(agency: Agency): AgencyDetailExtra {
  const seed = hash(agency.levelCode);
  const isL2 = agency.levelNumber === "002";

  const mailingLine1 = `${200 + (seed % 700)} Central Ave`;
  const mailingUnit = String(100 + (seed % 200));

  return {
    firstName: pick(FIRST_NAMES, seed),
    middleName: "",
    lastName: pick(LAST_NAMES, seed, 3),
    circleOfExcl: seed % 3 === 0 ? "No" : "Yes",
    distChannelCode: pick(DIST_CHANNELS, seed, 1),
    eSalesOnly: seed % 2 === 0 ? "Yes" : "No",
    addresses: [
      {
        type: "Main",
        line1: agency.mainAddress1,
        line2: agency.mainAddress2 || undefined,
        cityStateZip: `${agency.mainCity}, ${agency.mainState} ${agency.zipCode}`,
        county: pick(COUNTIES, seed),
        fax: agency.mainPhoneNumber.replace(/\d{4}$/, String(1000 + (seed % 9000)).slice(0, 4)),
        phone: agency.mainPhoneNumber,
      },
      {
        type: "Mailing",
        line1: mailingLine1,
        line2: mailingUnit,
        cityStateZip: `${agency.mainCity}, ${agency.mainState} ${String(Number(agency.zipCode) + 2).padStart(5, "0")}`,
        county: pick(COUNTIES, seed),
        fax: agency.mainPhoneNumber.replace(/\d{4}$/, String(1200 + (seed % 9000)).slice(0, 4)),
        phone: agency.mainPhoneNumber.replace(/\d{4}$/, String(1100 + (seed % 9000)).slice(0, 4)),
      },
      // L2 (Agency) records show a blank "Address Type" template column in the
      // design; L3 (Producer) records show a filled third address instead.
      isL2
        ? { type: "Address Type", line1: "Address Line 1", line2: "Address Line 2", cityStateZip: "City, State Zip", county: "County", fax: "Fax Number", phone: "Phone Number" }
        : {
            type: "Private Office",
            line1: agency.mainAddress1,
            line2: "1st Fl",
            cityStateZip: `${agency.mainCity}, ${agency.mainState} ${agency.zipCode}`,
            county: pick(COUNTIES, seed),
            phone: agency.mainPhoneNumber,
          },
    ],
    agentHierId: String(10000 + (seed % 90000)).slice(0, 5),
    busEntityId: String(20000 + (seed % 80000)).slice(0, 5),
    agentHierType: pick(HIER_TYPES, seed, 2),
    lastEntityUpdate: agency.lastUpdate,
    lastAddressUpdate: agency.lastUpdate,
    lastPolSysPush: agency.lastUpdate,
    updatedBy: agency.lastUpdateBy,
  };
}
