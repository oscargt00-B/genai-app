import type { AuthorityStatus } from "../types/authority";

export const AUTHORITY_STATUSES: AuthorityStatus[] = ["Active", "In-Active"];

/** "LOB" — reuses the same line-of-business values as License Type; both describe the same real-world coverage lines. */
export const LOB_OPTIONS: string[] = [
  "Personal Auto",
  "Homeowners",
  "Umbrella",
  "Commercial Auto",
  "General Liability",
  "Life",
  "Health",
];

export const CONTRACT_TYPES: string[] = ["Full", "Servicing", "Brokerage"];

export const SERVICE_CENTER_INDICATORS: string[] = ["Yes", "No", "Opt-Out"];

export const YES_NO: string[] = ["Yes", "No"];

export const UNDERWRITING_COMPANIES: string[] = [
  "Plymouth Rock Assurance Corporation",
  "Palisades Insurance Company",
  "High Point Property & Casualty",
  "Bunker Hill Insurance Company",
];
