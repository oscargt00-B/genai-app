import type { Authority } from "../types/authority";
import { CONTRACT_TYPES, LOB_OPTIONS, UNDERWRITING_COMPANIES } from "./authorityOptions";

interface AuthorityCore {
  levelCode: string;
  levelNumber: string;
  branch: string;
  legacyLevelCode: string;
  agencyProducerName: string;
  contractState: string;
  lob: string;
  underwritingCompany: string;
  contractType: string;
  contractStatus: Authority["contractStatus"];
  contractEffectiveDate: string;
  contractNumber: string;
  contractAppointmentDate: string;
}

/**
 * The long tail of contract-administration fields (NBI, term/renewal dates,
 * commission/profit-sharing flags, service-center settings, etc.) isn't
 * meaningfully differentiated by any UI shown in the linked Figma frames —
 * only their presence in the "Column Menu - Contracts" panel matters, so
 * they're derived deterministically per record instead of hand-authored,
 * the same pattern agencyDetails.ts uses for its own derived fields.
 */
function deriveExtras(seed: number): Omit<Authority, keyof AuthorityCore> {
  const yn = (n: number) => (n % 3 === 0 ? "No" : "Yes");
  const dateFrom = (daysOffset: number) => {
    const d = new Date("2026-08-25T00:00:00");
    d.setDate(d.getDate() + daysOffset);
    return d.toISOString().slice(0, 10);
  };
  return {
    newBusinessIndicator: yn(seed),
    expLetterTermDate: dateFrom(seed * 37 + 400),
    nbTerminationDate: dateFrom(seed * 41 + 900),
    renewalTermDate: dateFrom(seed * 29 + 365),
    commissionGroup: `CG-${100 + (seed % 6)}`,
    esalesEligible: yn(seed + 1),
    superAgent: yn(seed + 2),
    profitSharing: yn(seed + 1),
    psrProfitSharingRollupCode: `PSR-${200 + (seed % 4)}`,
    underwritingGroup: `UG-${(seed % 5) + 1}`,
    marketingGroup: `MG-${(seed % 3) + 1}`,
    serviceCenterIndicator: seed % 3 === 0 ? "Opt-Out" : seed % 2 === 0 ? "Yes" : "No",
    serviceCenterPercentFee: `${(seed % 5) + 1}%`,
    reportOrderGroup: `RG-${(seed % 4) + 1}`,
    removeCompRaterAccess: yn(seed + 2),
    preventLowBiCsl: yn(seed),
    preventNoPrioIns: yn(seed + 1),
    preventLapseOfCoverage: yn(seed + 2),
    defaultVhsScoreValue: String(600 + ((seed * 13) % 200)),
    esalesOnly: yn(seed),
    salesChannel: seed % 2 === 0 ? "Independent" : "Direct",
    lastUpdate: dateFrom(seed % 10),
    lastUpdateBy: seed % 2 === 0 ? "m.torres" : "j.nguyen",

    contractId: String(12300 + seed),
    webDisplayName: seed % 4 === 0 ? "-" : `WD-${seed}`,
    aggregationGroup: String.fromCharCode(65 + (seed % 4)), // "A".."D"
    rc1UseDefault: seed % 2 === 0 ? "-" : "Yes",
    groupName: `GRP-${(seed % 5) + 1}`,
    secondRateAgentGroup: seed % 3 === 0 ? "-" : `RAG-${(seed % 3) + 1}`,
    preventUnder6MosContCoverage: yn(seed + 1),
    defaultFrTierScore: String(1 + (seed % 5)),
    transferedNewAgent: seed % 4 === 0 ? `AGT-${seed}` : "-",
    transferedNewProducer: seed % 4 === 0 ? `PRD-${seed}` : "-",
    transferedAcqnTranDate: seed % 4 === 0 ? dateFrom(seed * 17 + 200) : "-",
    bookTransfer: yn(seed + 2),
    btPremiumDollars: seed % 3 === 0 ? "-" : `$${(seed + 1) * 1000}`,
    tip: yn(seed),
    charitable: yn(seed + 1),
    payrollDeduct: yn(seed + 2),
    busEntityId: String(3012300 + seed),
    polstarConfig: yn(seed),
    authorityProConfig: yn(seed + 1),
    lastPolSysPush: `${dateFrom(seed % 10)}T12:24:00`,
  };
}

interface OwnerRef {
  levelCode: string;
  levelNumber: string;
  branch: string;
  legacyLevelCode: string;
  name: string;
  /** The owner's own `mainState` from agencies.ts — used as the primary contract's Contract State. */
  state: string;
}

/**
 * Every L2 Agency and L3 Producer actually defined in agencies.ts (all 20 —
 * `node -e` cross-checked against agencies.ts's own levelCodes), so every
 * row on the "All Authority (Contracts)" page links to a real, resolvable
 * Agency/Producer Details page and Authority (Contracts) section — earlier
 * mock rows referenced levelCodes (2022101, 3031501, 2012345, etc.) that
 * didn't exist anywhere in agencies.ts and 404'd via `getAgencyByLevelCode`.
 */
const owners: OwnerRef[] = [
  { levelCode: "2010001", levelNumber: "002", branch: "Palisades Corporate Group", legacyLevelCode: "LEG-10001", name: "Harborview Insurance Co. MA", state: "MA" },
  { levelCode: "3010001", levelNumber: "003", branch: "Palisades Corporate Group", legacyLevelCode: "LEG-10002", name: "Harborview Insurance Co. NY", state: "NY" },
  { levelCode: "3010002", levelNumber: "003", branch: "Palisades Corporate Group", legacyLevelCode: "LEG-10003", name: "Harborview Insurance Co. NJ", state: "NJ" },
  { levelCode: "3010003", levelNumber: "003", branch: "Palisades Corporate Group", legacyLevelCode: "LEG-10004", name: "Harborview Insurance Co. PA", state: "PA" },
  { levelCode: "2010004", levelNumber: "002", branch: "Northeast Regional Partners", legacyLevelCode: "LEG-20940", name: "Cornerstone Producers CT", state: "CT" },
  { levelCode: "3010005", levelNumber: "003", branch: "Northeast Regional Partners", legacyLevelCode: "LEG-20941", name: "Cornerstone Producers RI", state: "RI" },
  { levelCode: "3010006", levelNumber: "003", branch: "Northeast Regional Partners", legacyLevelCode: "LEG-20942", name: "Cornerstone Producers NH", state: "NH" },
  { levelCode: "3010007", levelNumber: "003", branch: "Northeast Regional Partners", legacyLevelCode: "LEG-20943", name: "Cornerstone Producers VT", state: "VT" },
  { levelCode: "2010008", levelNumber: "002", branch: "Summit Atlantic Holdings", legacyLevelCode: "LEG-40219", name: "Magnolia State Producers GA", state: "GA" },
  { levelCode: "3010009", levelNumber: "003", branch: "Summit Atlantic Holdings", legacyLevelCode: "LEG-40220", name: "Magnolia State Producers FL", state: "FL" },
  { levelCode: "3010010", levelNumber: "003", branch: "Summit Atlantic Holdings", legacyLevelCode: "LEG-40221", name: "Magnolia State Producers SC", state: "SC" },
  { levelCode: "3010011", levelNumber: "003", branch: "Summit Atlantic Holdings", legacyLevelCode: "LEG-40222", name: "Magnolia State Producers NC", state: "NC" },
  { levelCode: "2010012", levelNumber: "002", branch: "Bayview Insurance Alliance", legacyLevelCode: "LEG-91820", name: "Golden Gate Producers CA", state: "CA" },
  { levelCode: "3010013", levelNumber: "003", branch: "Bayview Insurance Alliance", legacyLevelCode: "LEG-91821", name: "Golden Gate Producers OR", state: "OR" },
  { levelCode: "3010014", levelNumber: "003", branch: "Bayview Insurance Alliance", legacyLevelCode: "LEG-91822", name: "Golden Gate Producers WA", state: "WA" },
  { levelCode: "3010015", levelNumber: "003", branch: "Bayview Insurance Alliance", legacyLevelCode: "LEG-91823", name: "Golden Gate Producers NV", state: "NV" },
  { levelCode: "2010016", levelNumber: "002", branch: "Continental Producers Group", legacyLevelCode: "LEG-30280", name: "Lonestar Alliance TX", state: "TX" },
  { levelCode: "3010017", levelNumber: "003", branch: "Continental Producers Group", legacyLevelCode: "LEG-30281", name: "Lonestar Alliance IL", state: "IL" },
  { levelCode: "3010018", levelNumber: "003", branch: "Continental Producers Group", legacyLevelCode: "LEG-30282", name: "Lonestar Alliance CO", state: "CO" },
  { levelCode: "3010019", levelNumber: "003", branch: "Continental Producers Group", legacyLevelCode: "LEG-30283", name: "Lonestar Alliance AZ", state: "AZ" },
];

/** One contract for an owner, cycling through the option lists by index so every record differs a bit. */
function primaryContract(owner: OwnerRef, index: number): AuthorityCore {
  return {
    levelCode: owner.levelCode,
    levelNumber: owner.levelNumber,
    branch: owner.branch,
    legacyLevelCode: owner.legacyLevelCode,
    agencyProducerName: owner.name,
    contractState: owner.state,
    lob: LOB_OPTIONS[index % LOB_OPTIONS.length],
    underwritingCompany: UNDERWRITING_COMPANIES[index % UNDERWRITING_COMPANIES.length],
    contractType: CONTRACT_TYPES[index % CONTRACT_TYPES.length],
    contractStatus: index % 6 === 5 ? "In-Active" : "Active",
    contractEffectiveDate: "2022-01-15",
    contractNumber: `CTR-${100000 + index}`,
    contractAppointmentDate: "2018-11-22",
  };
}

/** A second contract for the same owner, in a different state — demonstrates the "one or many contracts" case for a handful of owners. */
function secondContract(owner: OwnerRef, index: number, state: string): AuthorityCore {
  return {
    levelCode: owner.levelCode,
    levelNumber: owner.levelNumber,
    branch: owner.branch,
    legacyLevelCode: owner.legacyLevelCode,
    agencyProducerName: owner.name,
    contractState: state,
    lob: LOB_OPTIONS[(index + 2) % LOB_OPTIONS.length],
    underwritingCompany: UNDERWRITING_COMPANIES[(index + 1) % UNDERWRITING_COMPANIES.length],
    contractType: CONTRACT_TYPES[(index + 1) % CONTRACT_TYPES.length],
    contractStatus: "Active",
    contractEffectiveDate: "2023-10-23",
    contractNumber: `CTR-${200000 + index}`,
    contractAppointmentDate: index % 4 === 0 ? "" : "2019-01-10",
  };
}

/** Owners (by index into `owners` above) that get a second contract, for the "many contracts" demo. */
const MULTI_CONTRACT_OWNER_INDEXES: [ownerIndex: number, secondState: string][] = [
  [0, "NY"], // Harborview Insurance Co. MA -> also appointed in NY
  [1, "CT"], // Harborview Insurance Co. NY -> also appointed in CT
  [4, "RI"], // Cornerstone Producers CT -> also appointed in RI
  [12, "NV"], // Golden Gate Producers CA -> also appointed in NV
];

const core: AuthorityCore[] = [
  ...owners.map((owner, i) => primaryContract(owner, i)),
  ...MULTI_CONTRACT_OWNER_INDEXES.map(([ownerIndex, state], i) => secondContract(owners[ownerIndex], i, state)),
];

/**
 * Mock carrier authority/contract records for the Agent Data Repository,
 * matching the "Authority Search R 1" / "Column Menu - Contracts" Figma
 * frames' full field set. Every L2 Agency and L3 Producer in agencies.ts
 * has at least one contract here (a handful have two or three) — see
 * `owners` above — so every row's Actions link and every "Authority
 * (Contracts)" section reachable from an Agency/Producer Details page
 * resolves to a real record instead of 404ing.
 */
export const authorities: Authority[] = core.map((c, i) => ({ ...c, ...deriveExtras(i) }));
