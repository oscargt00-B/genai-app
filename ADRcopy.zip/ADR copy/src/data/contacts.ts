import type { Contact } from "../types/contact";
import { agencies } from "./agencies";
import { CONTACT_TYPES, PREFIXES, SUFFIXES } from "./contactOptions";
import { UNDERWRITING_COMPANIES } from "./licenseOptions";

/** `agencies` also contains one synthetic "Level 1" branch roll-up row per group (levelNumber "001") — not a real owner of its own contacts, so it's excluded here the same way licenses.ts's own owner roster excludes it. */
const owners = agencies.filter((a) => a.levelNumber !== "001");

const FIRST_NAMES = ["Johnathan", "Maria", "David", "Priya", "James", "Linda", "Robert", "Susan"];
const LAST_NAMES = ["Doe", "Santos", "Kim", "Patel", "Reyes", "Nguyen", "Torres", "Walsh"];

/** Simple deterministic hash so the same levelCode always derives the same mock values. */
function hash(input: string): number {
  let h = 0;
  for (let i = 0; i < input.length; i++) h = (h * 31 + input.charCodeAt(i)) >>> 0;
  return h;
}

function pick<T>(pool: T[], seed: number, offset = 0): T {
  return pool[(seed + offset) % pool.length];
}

/** 1-3 "Contact Type" roles joined with a comma, matching the design's own truncated sample ("CSR, HPM, Commis..."). */
function contactTypesFor(seed: number): string {
  const count = 1 + (seed % 3);
  const types = Array.from({ length: count }, (_, i) => pick(CONTACT_TYPES, seed, i * 2));
  return [...new Set(types)].join(", ");
}

function phoneFor(mainPhoneNumber: string, offset: number): string {
  return mainPhoneNumber.replace(/\d{4}$/, String(1000 + offset).slice(0, 4));
}

interface ContactSeed {
  firstNameOffset: number;
  lastNameOffset: number;
}

/**
 * Every L2 Agency / L3 Producer in agencies.ts gets at least one contact
 * here; a handful get a second, matching the "one or many" relationship
 * Authority (Contracts) and Licenses both have.
 */
function seedsFor(ownerIndex: number): ContactSeed[] {
  if (ownerIndex % 4 === 0) {
    return [
      { firstNameOffset: 0, lastNameOffset: 3 },
      { firstNameOffset: 1, lastNameOffset: 5 },
    ];
  }
  return [{ firstNameOffset: 0, lastNameOffset: 3 }];
}

function buildContact(owner: (typeof agencies)[number], seed: ContactSeed, index: number): Contact {
  const h = hash(owner.levelCode) + index * 97;
  return {
    contactId: `CNT-${100000 + index}`,
    levelNumber: owner.levelNumber,
    branch: owner.branch,
    legacyLevelCode: owner.legacyLevelCode,
    levelCode: owner.levelCode,
    agencyProducerName: owner.name,
    uwCompanyName: pick(UNDERWRITING_COMPANIES, h),
    contactType: contactTypesFor(h),
    prefix: pick(PREFIXES, h),
    firstName: pick(FIRST_NAMES, hash(owner.levelCode), seed.firstNameOffset),
    middleName: "",
    lastName: pick(LAST_NAMES, hash(owner.levelCode), seed.lastNameOffset),
    suffix: pick(SUFFIXES, h, 1),
    phone: phoneFor(owner.mainPhoneNumber, h % 9000),
    cellPhone: phoneFor(owner.mainPhoneNumber, (h + 500) % 9000),
    email: `${pick(FIRST_NAMES, hash(owner.levelCode), seed.firstNameOffset)[0].toLowerCase()}${pick(LAST_NAMES, hash(owner.levelCode), seed.lastNameOffset).toLowerCase()}@email.com`,
    imageRightId: `${pick(FIRST_NAMES, hash(owner.levelCode), seed.firstNameOffset)[0]}${pick(LAST_NAMES, hash(owner.levelCode), seed.lastNameOffset).slice(0, 3).toUpperCase()}`,
    lastUpdate: owner.lastUpdate,
    lastUpdateBy: owner.lastUpdateBy,
  };
}

let counter = 0;

/**
 * Mock contact records for the Agent Data Repository, matching the
 * "Contacts Search R 1" / "Contacts Menu 1" Figma frames' field set. Every
 * L2 Agency and L3 Producer in agencies.ts has at least one contact here (a
 * handful have two) — mirrors licenses.ts's own fix for the same "orphaned
 * mock data" defect (rows whose levelCode didn't match any real
 * agency/producer).
 */
export const contacts: Contact[] = owners.flatMap((owner, ownerIndex) =>
  seedsFor(ownerIndex).map((seed) => buildContact(owner, seed, counter++)),
);
