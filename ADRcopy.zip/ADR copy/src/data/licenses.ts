import type { License } from "../types/license";
import { agencies } from "./agencies";
import {
  LICENSE_TYPES,
  LINES_OF_AUTHORITY,
  PERSON_FIRM_INDICATORS,
  SYNC_STATUSES,
  UNDERWRITING_COMPANIES,
} from "./licenseOptions";

function dateFrom(daysOffset: number): string {
  const d = new Date("2026-08-25T00:00:00");
  d.setDate(d.getDate() + daysOffset);
  return d.toISOString().slice(0, 10);
}

interface LicenseSeed {
  state: string;
  licenseType: string;
  status: License["licenseStatus"];
  underwritingCompany: string;
}

/**
 * Every L2 Agency / L3 Producer in agencies.ts gets at least one license
 * here; a handful get several, matching the "Licenses" section mock
 * (node-id=14314-176571 for L2, 14314-181766 for L3), which shows 5 rows
 * for a single owner — i.e. one owner can hold one or many licenses, the
 * same "one or many" relationship Authority (Contracts) has.
 */
function seedsFor(ownerIndex: number, mainState: string): LicenseSeed[] {
  if (ownerIndex === 0) {
    // Matches the Figma mock's own 5-row sample (state/type/status) exactly.
    return [
      { state: "MA", licenseType: "Personal Auto", status: "Active", underwritingCompany: UNDERWRITING_COMPANIES[0] },
      { state: "NY", licenseType: "Personal Auto", status: "Active", underwritingCompany: UNDERWRITING_COMPANIES[1] },
      { state: "MA", licenseType: "Umbrella", status: "Active", underwritingCompany: UNDERWRITING_COMPANIES[2] },
      { state: "NJ", licenseType: "Personal Auto", status: "Active", underwritingCompany: UNDERWRITING_COMPANIES[3] },
      { state: "PA", licenseType: "Personal Auto", status: "In-Active", underwritingCompany: UNDERWRITING_COMPANIES[0] },
    ];
  }
  if (ownerIndex % 5 === 0) {
    // A couple more "many licenses" owners, to keep the rowKey composite-identity path exercised beyond just owner 0.
    return [
      {
        state: mainState,
        licenseType: LICENSE_TYPES[ownerIndex % LICENSE_TYPES.length],
        status: "Active",
        underwritingCompany: UNDERWRITING_COMPANIES[ownerIndex % UNDERWRITING_COMPANIES.length],
      },
      {
        state: mainState,
        licenseType: LICENSE_TYPES[(ownerIndex + 2) % LICENSE_TYPES.length],
        status: "Active",
        underwritingCompany: UNDERWRITING_COMPANIES[(ownerIndex + 1) % UNDERWRITING_COMPANIES.length],
      },
    ];
  }
  return [
    {
      state: mainState,
      licenseType: LICENSE_TYPES[ownerIndex % LICENSE_TYPES.length],
      status: ownerIndex % 7 === 6 ? "In-Active" : "Active",
      underwritingCompany: UNDERWRITING_COMPANIES[ownerIndex % UNDERWRITING_COMPANIES.length],
    },
  ];
}

function buildLicense(owner: (typeof agencies)[number], seed: LicenseSeed, index: number): License {
  return {
    levelCode: owner.levelCode,
    levelNumber: owner.levelNumber,
    branch: owner.branch,
    legacyLevelCode: owner.legacyLevelCode,
    agencyProducerName: owner.name,
    licenseType: seed.licenseType,
    licenseStatus: seed.status,
    stateLicenseNumber: `SLN-${100000 + index}`,
    npn: String(1000000 + index),
    syncStatus: SYNC_STATUSES[index % SYNC_STATUSES.length],
    licenseName: owner.name,
    licenseState: seed.state,
    licenseEffectiveDate: dateFrom(index * 11),
    licenseExpirationDate: dateFrom(index * 11 + 730),
    personFirmIndicator: PERSON_FIRM_INDICATORS[index % PERSON_FIRM_INDICATORS.length],
    underwritingCompany: seed.underwritingCompany,
    residenceIndicator: seed.state === owner.mainState ? "Resident" : "Non-Resident",
    lineOfAuthority: LINES_OF_AUTHORITY[index % LINES_OF_AUTHORITY.length],
    lastUpdate: dateFrom(index % 10),
    lastUpdateBy: index % 2 === 0 ? "m.torres" : "j.nguyen",
  };
}

/** `agencies` also contains one synthetic "Level 1" branch roll-up row per group (levelNumber "001") — not a real licensable Agency/Producer, so it's excluded here the same way authorities.ts's own owner roster excludes it. */
const owners = agencies.filter((a) => a.levelNumber !== "001");

let counter = 0;

/**
 * Mock license records for the Agent Data Repository, matching the
 * "Licenses Search R 2" / "Column Menu - Licenses" Figma frames' field set.
 * Every L2 Agency and L3 Producer in agencies.ts has at least one license
 * here (a handful have several) — mirrors authorities.ts's own fix for the
 * same "orphaned mock data" defect (rows whose levelCode didn't match any
 * real agency/producer, 404ing via `getAgencyByLevelCode`).
 */
export const licenses: License[] = owners.flatMap((owner, ownerIndex) =>
  seedsFor(ownerIndex, owner.mainState).map((seed) => buildLicense(owner, seed, counter++)),
);
