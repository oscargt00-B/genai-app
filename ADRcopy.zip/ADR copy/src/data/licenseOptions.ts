import type { LicenseStatus, PersonFirmIndicator, ResidenceIndicator, SyncStatus } from "../types/license";

export const LICENSE_TYPES: string[] = [
  "Personal Auto",
  "Homeowners",
  "Umbrella",
  "Commercial Auto",
  "General Liability",
  "Life",
  "Health",
];

export const LICENSE_STATUSES: LicenseStatus[] = ["Active", "In-Active"];

export const PERSON_FIRM_INDICATORS: PersonFirmIndicator[] = ["Person", "Firm"];

export const RESIDENCE_INDICATORS: ResidenceIndicator[] = ["Resident", "Non-Resident"];

export const SYNC_STATUSES: SyncStatus[] = ["Synced", "Pending", "Failed"];

export const LINES_OF_AUTHORITY: string[] = [
  "Property & Casualty",
  "Life & Health",
  "Personal Lines",
  "Surplus Lines",
];

export const UNDERWRITING_COMPANIES: string[] = [
  "Plymouth Rock Assurance Corporation",
  "Palisades Insurance Company",
  "High Point Property & Casualty",
  "Bunker Hill Insurance Company",
];
