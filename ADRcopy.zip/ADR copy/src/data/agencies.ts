import type { Agency } from "../types/agency";

interface BranchDef {
  branch: string;
  agencyGroupKey: string;
  rows: Array<{
    levelNumber: string;
    levelCode: string;
    legacyLevelCode: string;
    name: string;
    mainAddress1: string;
    mainAddress2: string;
    mainCity: string;
    mainState: string;
    zipCode: string;
    heirStatus: Agency["heirStatus"];
    heirId: string;
    heirType: Agency["heirType"];
    channel: Agency["channel"];
    mainPhoneNumber: string;
    npn: string;
    taxId: string;
    lastUpdate: string;
    lastUpdateBy: string;
  }>;
}

/**
 * Mock agency/producer records for the Agent Data Repository, grouped by the
 * L1 Branch they roll up to (matching the "AG Key" / "Branch" columns and the
 * L1 Branch Name filter in the advanced search). 5 branches x 4 records = 20
 * rows total, so the results grid's pagination has more than one page.
 */
const branches: BranchDef[] = [
  {
    branch: "Palisades Corporate Group",
    agencyGroupKey: "1012345GK",
    rows: [
      {
        levelNumber: "002", levelCode: "2010001", legacyLevelCode: "LEG-10001",
        name: "Harborview Insurance Co. MA", mainAddress1: "123 Main St.", mainAddress2: "",
        mainCity: "Boston", mainState: "MA", zipCode: "02109",
        heirStatus: "Active", heirId: "H-100234", heirType: "Entity", channel: "Independent",
        mainPhoneNumber: "(617) 555-0148", npn: "8823741", taxId: "82-4471203",
        lastUpdate: "2026-08-28", lastUpdateBy: "m.torres",
      },
      {
        levelNumber: "003", levelCode: "3010001", legacyLevelCode: "LEG-10002",
        name: "Harborview Insurance Co. NY", mainAddress1: "123 Main St.", mainAddress2: "Suite 200",
        mainCity: "New York", mainState: "NY", zipCode: "10005",
        heirStatus: "Active", heirId: "H-100891", heirType: "Entity", channel: "Broker/IMO",
        mainPhoneNumber: "(212) 555-0192", npn: "7745902", taxId: "83-1029457",
        lastUpdate: "2026-08-25", lastUpdateBy: "j.nguyen",
      },
      {
        levelNumber: "003", levelCode: "3010002", legacyLevelCode: "LEG-10003",
        name: "Harborview Insurance Co. NJ", mainAddress1: "123 Main St.", mainAddress2: "",
        mainCity: "Newark", mainState: "NJ", zipCode: "07102",
        heirStatus: "Pending", heirId: "H-101045", heirType: "Entity", channel: "Captive",
        mainPhoneNumber: "(973) 555-0110", npn: "6602198", taxId: "58-2201194",
        lastUpdate: "2026-08-30", lastUpdateBy: "a.reyes",
      },
      {
        levelNumber: "003", levelCode: "3010003", legacyLevelCode: "LEG-10004",
        name: "Harborview Insurance Co. PA", mainAddress1: "123 Main St.", mainAddress2: "",
        mainCity: "Scranton", mainState: "PA", zipCode: "18503",
        heirStatus: "Active", heirId: "H-101332", heirType: "Entity", channel: "Independent",
        mainPhoneNumber: "(570) 555-0173", npn: "5514832", taxId: "43-0987621",
        lastUpdate: "2026-08-19", lastUpdateBy: "m.torres",
      },
    ],
  },
  {
    branch: "Northeast Regional Partners",
    agencyGroupKey: "1022846GK",
    rows: [
      {
        levelNumber: "002", levelCode: "2010004", legacyLevelCode: "LEG-20940",
        name: "Cornerstone Producers CT", mainAddress1: "482 Congress Street", mainAddress2: "Suite 300",
        mainCity: "Hartford", mainState: "CT", zipCode: "06103",
        heirStatus: "Active", heirId: "H-101567", heirType: "Entity", channel: "Broker/IMO",
        mainPhoneNumber: "(860) 555-0129", npn: "4498210", taxId: "86-1120044",
        lastUpdate: "2026-08-22", lastUpdateBy: "d.kim",
      },
      {
        levelNumber: "003", levelCode: "3010005", legacyLevelCode: "LEG-20941",
        name: "Cornerstone Producers RI", mainAddress1: "482 Congress Street", mainAddress2: "",
        mainCity: "Providence", mainState: "RI", zipCode: "02903",
        heirStatus: "Active", heirId: "H-101789", heirType: "Entity", channel: "Direct",
        mainPhoneNumber: "(401) 555-0165", npn: "3390127", taxId: "13-3789021",
        lastUpdate: "2026-08-31", lastUpdateBy: "a.reyes",
      },
      {
        levelNumber: "003", levelCode: "3010006", legacyLevelCode: "LEG-20942",
        name: "Cornerstone Producers NH", mainAddress1: "482 Congress Street", mainAddress2: "",
        mainCity: "Manchester", mainState: "NH", zipCode: "03101",
        heirStatus: "Inactive", heirId: "H-102013", heirType: "Entity", channel: "Independent",
        mainPhoneNumber: "(603) 555-0187", npn: "2287410", taxId: "57-2245108",
        lastUpdate: "2026-07-30", lastUpdateBy: "j.nguyen",
      },
      {
        levelNumber: "003", levelCode: "3010007", legacyLevelCode: "LEG-20943",
        name: "Cornerstone Producers VT", mainAddress1: "482 Congress Street", mainAddress2: "",
        mainCity: "Burlington", mainState: "VT", zipCode: "05401",
        heirStatus: "Active", heirId: "H-102244", heirType: "Individual", channel: "Captive",
        mainPhoneNumber: "(802) 555-0141", npn: "1187452", taxId: "75-1123409",
        lastUpdate: "2026-08-27", lastUpdateBy: "s.patel",
      },
    ],
  },
  {
    branch: "Summit Atlantic Holdings",
    agencyGroupKey: "1034127GK",
    rows: [
      {
        levelNumber: "002", levelCode: "2010008", legacyLevelCode: "LEG-40219",
        name: "Magnolia State Producers GA", mainAddress1: "1200 Peachtree St NE", mainAddress2: "Floor 14",
        mainCity: "Atlanta", mainState: "GA", zipCode: "30309",
        heirStatus: "Active", heirId: "H-102456", heirType: "Entity", channel: "Broker/IMO",
        mainPhoneNumber: "(404) 555-0119", npn: "9987320", taxId: "36-3345012",
        lastUpdate: "2026-08-15", lastUpdateBy: "d.kim",
      },
      {
        levelNumber: "003", levelCode: "3010009", legacyLevelCode: "LEG-40220",
        name: "Magnolia State Producers FL", mainAddress1: "1200 Peachtree St NE", mainAddress2: "",
        mainCity: "Tampa", mainState: "FL", zipCode: "33602",
        heirStatus: "Active", heirId: "H-102689", heirType: "Entity", channel: "Bancassurance",
        mainPhoneNumber: "(813) 555-0176", npn: "8871209", taxId: "91-2245701",
        lastUpdate: "2026-08-29", lastUpdateBy: "m.torres",
      },
      {
        levelNumber: "003", levelCode: "3010010", legacyLevelCode: "LEG-40221",
        name: "Magnolia State Producers SC", mainAddress1: "1200 Peachtree St NE", mainAddress2: "",
        mainCity: "Charleston", mainState: "SC", zipCode: "29401",
        heirStatus: "Pending", heirId: "H-102901", heirType: "Individual", channel: "Independent",
        mainPhoneNumber: "(843) 555-0154", npn: "7765402", taxId: "61-1198734",
        lastUpdate: "2026-08-10", lastUpdateBy: "s.patel",
      },
      {
        levelNumber: "003", levelCode: "3010011", legacyLevelCode: "LEG-40222",
        name: "Magnolia State Producers NC", mainAddress1: "1200 Peachtree St NE", mainAddress2: "",
        mainCity: "Charlotte", mainState: "NC", zipCode: "28202",
        heirStatus: "Active", heirId: "H-103122", heirType: "Entity", channel: "Direct",
        mainPhoneNumber: "(704) 555-0138", npn: "6654893", taxId: "84-2298761",
        lastUpdate: "2026-08-24", lastUpdateBy: "a.reyes",
      },
    ],
  },
  {
    branch: "Bayview Insurance Alliance",
    agencyGroupKey: "1045608GK",
    rows: [
      {
        levelNumber: "002", levelCode: "2010012", legacyLevelCode: "LEG-91820",
        name: "Golden Gate Producers CA", mainAddress1: "555 California St", mainAddress2: "Floor 22",
        mainCity: "San Francisco", mainState: "CA", zipCode: "94104",
        heirStatus: "Active", heirId: "H-103355", heirType: "Entity", channel: "Independent",
        mainPhoneNumber: "(415) 555-0122", npn: "5543210", taxId: "64-2287103",
        lastUpdate: "2026-06-02", lastUpdateBy: "j.nguyen",
      },
      {
        levelNumber: "003", levelCode: "3010013", legacyLevelCode: "LEG-91821",
        name: "Golden Gate Producers OR", mainAddress1: "555 California St", mainAddress2: "",
        mainCity: "Portland", mainState: "OR", zipCode: "97201",
        heirStatus: "Active", heirId: "H-103578", heirType: "Entity", channel: "Broker/IMO",
        mainPhoneNumber: "(503) 555-0163", npn: "4432198", taxId: "41-1276430",
        lastUpdate: "2026-08-26", lastUpdateBy: "d.kim",
      },
      {
        levelNumber: "003", levelCode: "3010014", legacyLevelCode: "LEG-91822",
        name: "Golden Gate Producers WA", mainAddress1: "555 California St", mainAddress2: "",
        mainCity: "Seattle", mainState: "WA", zipCode: "98101",
        heirStatus: "Active", heirId: "H-103812", heirType: "Entity", channel: "Direct",
        mainPhoneNumber: "(206) 555-0191", npn: "3321087", taxId: "94-3312087",
        lastUpdate: "2026-09-01", lastUpdateBy: "s.patel",
      },
      {
        levelNumber: "003", levelCode: "3010015", legacyLevelCode: "LEG-91823",
        name: "Golden Gate Producers NV", mainAddress1: "555 California St", mainAddress2: "",
        mainCity: "Las Vegas", mainState: "NV", zipCode: "89101",
        heirStatus: "Terminated", heirId: "H-104034", heirType: "Individual", channel: "Independent",
        mainPhoneNumber: "(702) 555-0157", npn: "2298743", taxId: "23-2298871",
        lastUpdate: "2026-08-21", lastUpdateBy: "m.torres",
      },
    ],
  },
  {
    branch: "Continental Producers Group",
    agencyGroupKey: "1056789GK",
    rows: [
      {
        levelNumber: "002", levelCode: "2010016", legacyLevelCode: "LEG-30280",
        name: "Lonestar Alliance TX", mainAddress1: "5215 N O'Connor Blvd", mainAddress2: "Suite 900",
        mainCity: "Irving", mainState: "TX", zipCode: "75039",
        heirStatus: "Active", heirId: "H-104267", heirType: "Entity", channel: "Captive",
        mainPhoneNumber: "(972) 555-0144", npn: "1187630", taxId: "59-1287340",
        lastUpdate: "2026-08-18", lastUpdateBy: "a.reyes",
      },
      {
        levelNumber: "003", levelCode: "3010017", legacyLevelCode: "LEG-30281",
        name: "Lonestar Alliance IL", mainAddress1: "233 S Wacker Dr", mainAddress2: "Suite 4200",
        mainCity: "Chicago", mainState: "IL", zipCode: "60606",
        heirStatus: "Pending", heirId: "H-104489", heirType: "Individual", channel: "Independent",
        mainPhoneNumber: "(312) 555-0136", npn: "9954321", taxId: "68-1129873",
        lastUpdate: "2026-08-12", lastUpdateBy: "j.nguyen",
      },
      {
        levelNumber: "003", levelCode: "3010018", legacyLevelCode: "LEG-30282",
        name: "Lonestar Alliance CO", mainAddress1: "1550 Market St", mainAddress2: "Suite 350",
        mainCity: "Denver", mainState: "CO", zipCode: "80202",
        heirStatus: "Active", heirId: "H-104701", heirType: "Entity", channel: "Broker/IMO",
        mainPhoneNumber: "(303) 555-0182", npn: "8843201", taxId: "04-2298761",
        lastUpdate: "2026-08-23", lastUpdateBy: "d.kim",
      },
      {
        levelNumber: "003", levelCode: "3010019", legacyLevelCode: "LEG-30283",
        name: "Lonestar Alliance AZ", mainAddress1: "2398 E Camelback Rd", mainAddress2: "",
        mainCity: "Phoenix", mainState: "AZ", zipCode: "85016",
        heirStatus: "Inactive", heirId: "H-104933", heirType: "Entity", channel: "Independent",
        mainPhoneNumber: "(602) 555-0169", npn: "7732105", taxId: "87-2298104",
        lastUpdate: "2026-07-14", lastUpdateBy: "s.patel",
      },
    ],
  },
];

/** The branch's own AG Key without the trailing "GK" suffix, e.g. "1012345" — also the L1 row's levelCode. */
export function branchCode(agencyGroupKey: string): string {
  return agencyGroupKey.replace(/GK$/, "");
}

export const agencies: Agency[] = branches.flatMap((b) => {
  const rows = b.rows.map((row) => ({ branch: b.branch, agencyGroupKey: b.agencyGroupKey, ...row }));
  const l2 = rows.find((r) => r.levelNumber === "002");

  // One "Level 1" branch record per group, rolled up from its L2 agency —
  // matches the "Branch Details" screen (Branch Information + admin bar only).
  const branchRow: Agency | null = l2
    ? {
        branch: b.branch,
        agencyGroupKey: b.agencyGroupKey,
        levelNumber: "001",
        levelCode: branchCode(b.agencyGroupKey),
        legacyLevelCode: "",
        name: b.branch,
        mainAddress1: l2.mainAddress1,
        mainAddress2: l2.mainAddress2,
        mainCity: l2.mainCity,
        mainState: l2.mainState,
        zipCode: l2.zipCode,
        heirStatus: l2.heirStatus,
        heirId: l2.heirId,
        heirType: "Entity",
        channel: l2.channel,
        mainPhoneNumber: l2.mainPhoneNumber,
        npn: "",
        taxId: "",
        lastUpdate: l2.lastUpdate,
        lastUpdateBy: l2.lastUpdateBy,
      }
    : null;

  return branchRow ? [branchRow, ...rows] : rows;
});

/** Distinct L1 branch names, for the advanced search's "L1 Branch Name" select. */
export const branchNames: string[] = branches.map((b) => b.branch);

export function getAgencyByLevelCode(levelCode: string): Agency | undefined {
  return agencies.find((a) => a.levelCode === levelCode);
}

/**
 * The hierarchy siblings for a record's branch/agency group: the L1 Branch
 * record, the single L2 "Agency" record it rolls up to, and every L3
 * "Producer" record under it — used to build breadcrumbs and the L3-switcher
 * dropdown on the detail pages.
 */
export function getAgencyGroup(
  agencyGroupKey: string,
): { l1: Agency | undefined; l2: Agency | undefined; l3s: Agency[] } {
  const group = agencies.filter((a) => a.agencyGroupKey === agencyGroupKey);
  return {
    l1: group.find((a) => a.levelNumber === "001"),
    l2: group.find((a) => a.levelNumber === "002"),
    l3s: group.filter((a) => a.levelNumber === "003"),
  };
}
