export const ADDRESS_TYPES: string[] = ["Main", "Mailing", "Private Office", "Billing"];
