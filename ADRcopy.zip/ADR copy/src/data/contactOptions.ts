/** "Contact Type" options — a contact can hold several at once (e.g. "CSR, HPM, Commissions"), matching the design's own truncated sample ("CSR, HPM, Commis..."). */
export const CONTACT_TYPES: string[] = [
  "CSR",
  "HPM",
  "Commissions",
  "Principal",
  "Accounting",
  "Claims",
];

export const PREFIXES: string[] = ["Mr.", "Mrs.", "Ms.", "Dr."];

export const SUFFIXES: string[] = ["-", "Jr.", "Sr.", "II", "III"];
