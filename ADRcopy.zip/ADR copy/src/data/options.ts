import type { Channel, HeirStatus, HeirType } from "../types/agency";

export const US_STATES: string[] = [
  "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA",
  "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD",
  "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ",
  "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC",
  "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY",
];

export const HEIR_STATUSES: HeirStatus[] = ["Active", "Inactive", "Pending", "Terminated"];

export const HEIR_TYPES: HeirType[] = ["Individual", "Entity"];

export const CHANNELS: Channel[] = ["Captive", "Independent", "Broker/IMO", "Direct", "Bancassurance"];
