import { useState } from "react";
import { useTheme } from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";
import { SIDENAV_WIDTH, SIDENAV_WIDTH_COLLAPSED } from "../components/SideNav";

/**
 * Shared responsive/collapse state for the app shell's side nav — used by
 * both the main search layout and the Agency/Producer detail pages so they
 * stay in sync (permanent + collapsible on desktop, off-canvas drawer on
 * mobile).
 */
export function useSidebarShell() {
  const muiTheme = useTheme();
  const isMobile = useMediaQuery(muiTheme.breakpoints.down("md"));
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const navWidth = collapsed ? SIDENAV_WIDTH_COLLAPSED : SIDENAV_WIDTH;

  return {
    isMobile,
    collapsed,
    toggleCollapsed: () => setCollapsed((c) => !c),
    mobileOpen,
    openMobile: () => setMobileOpen(true),
    closeMobile: () => setMobileOpen(false),
    navWidth,
  };
}
