import { useEffect, useMemo, useRef, useState } from "react";
import { useBlocker } from "react-router-dom";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import { FaIcon } from "../components/FaIcon";
import { QuickSearchBar } from "../components/QuickSearchBar";
import { AdvancedSearchForm } from "../components/AdvancedSearchForm";
import { SearchChipsBar } from "../components/SearchChipsBar";
import { AgencyDataGrid, type AgencyDataGridHandle } from "../components/AgencyDataGrid";
import { agencies } from "../data/agencies";
import { searchAdvanced, searchByLevelCode } from "../lib/searchAgencies";
import { activeCriteriaEntries, clearCriteriaField } from "../lib/criteria";
import type { AdvancedSearchCriteria, Agency } from "../types/agency";
import { emptyAdvancedSearch } from "../types/agency";

const agencyNameOptions = [...new Set(agencies.map((a) => a.name))].sort();

type Mode = "simple" | "advanced" | "chips";

export function AgencySearchPage() {
  const [mode, setMode] = useState<Mode>("simple");
  const [criteria, setCriteria] = useState<AdvancedSearchCriteria>(emptyAdvancedSearch);
  const [results, setResults] = useState<Agency[] | null>(null);

  const gridRef = useRef<AgencyDataGridHandle>(null);
  const [bulkEditDirty, setBulkEditDirty] = useState(false);
  const [pendingSearch, setPendingSearch] = useState<(() => void) | null>(null);

  // Blocks in-app navigation (any route change, including the browser back/forward
  // buttons) while there are unsaved Bulk Edit changes; requires the data-router
  // set up in App.tsx.
  const blocker = useBlocker(bulkEditDirty);

  // Covers the case react-router's blocker can't: closing the tab, refreshing, or
  // navigating via the address bar. Browsers show their own generic prompt here —
  // the message text itself isn't customizable.
  useEffect(() => {
    if (!bulkEditDirty) return;
    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [bulkEditDirty]);

  const activeEntries = useMemo(() => activeCriteriaEntries(criteria), [criteria]);

  /** Runs a search immediately, unless there are unsaved Bulk Edit changes — then it waits behind the confirm dialog. */
  const runSearch = (search: () => void) => {
    if (bulkEditDirty) {
      setPendingSearch(() => search);
    } else {
      search();
    }
  };

  const handleQuickSearch = (levelCode: string) => {
    runSearch(() => setResults(searchByLevelCode(agencies, levelCode)));
  };

  const handleAdvancedSearch = () => {
    runSearch(() => setResults(searchAdvanced(agencies, criteria)));
  };

  const handleReset = () => {
    setCriteria(emptyAdvancedSearch);
    setResults(null);
  };

  /** "Hide" collapses the form — into the chip summary if any filters are active, otherwise all the way back to quick search. */
  const handleHide = () => {
    setMode(activeEntries.length > 0 ? "chips" : "simple");
  };

  const handleClearAllChips = () => {
    setCriteria(emptyAdvancedSearch);
    setResults(null);
    setMode("simple");
  };

  const handleRemoveChip = (key: keyof AdvancedSearchCriteria) => {
    const next = clearCriteriaField(criteria, key);
    setCriteria(next);
    const remaining = activeCriteriaEntries(next);
    if (remaining.length === 0) {
      setResults(null);
      setMode("simple");
    } else {
      setResults(searchAdvanced(agencies, next));
    }
  };

  const showReset = useMemo(
    () => results !== null && mode === "advanced",
    [results, mode],
  );

  const confirmOpen = pendingSearch !== null || blocker.state === "blocked";

  const closeConfirm = () => {
    setPendingSearch(null);
    if (blocker.state === "blocked") blocker.reset();
  };

  const proceed = () => {
    const search = pendingSearch;
    setPendingSearch(null);
    search?.();
    if (blocker.state === "blocked") blocker.proceed();
  };

  const handleDiscardAndContinue = () => {
    gridRef.current?.discardChanges();
    proceed();
  };

  const handleSaveAndContinue = () => {
    gridRef.current?.saveChanges();
    proceed();
  };

  return (
    <Box sx={{ p: 2, display: "flex", flexDirection: "column", gap: 2 }}>
      {mode === "simple" && (
        <QuickSearchBar onSearch={handleQuickSearch} onOpenAdvanced={() => setMode("advanced")} />
      )}

      {mode === "advanced" && (
        <AdvancedSearchForm
          criteria={criteria}
          onChange={setCriteria}
          onSubmit={handleAdvancedSearch}
          onReset={handleReset}
          onHide={handleHide}
          showReset={showReset}
          agencyNameOptions={agencyNameOptions}
        />
      )}

      {mode === "chips" && (
        <SearchChipsBar
          entries={activeEntries}
          onClearAll={handleClearAllChips}
          onRemove={handleRemoveChip}
          onShowSearch={() => setMode("advanced")}
        />
      )}

      {results === null ? null : results.length === 0 ? (
        <Paper
          variant="outlined"
          sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 1,
            py: 8,
            borderStyle: "dashed",
          }}
        >
          <FaIcon icon="magnifying-glass-minus" sx={{ fontSize: 28, color: "text.disabled" }} />
          <Typography variant="body2" sx={{ fontWeight: 600, color: "text.secondary" }}>
            No agencies found
          </Typography>
          <Typography variant="caption" sx={{ color: "text.disabled", maxWidth: 360, textAlign: "center" }}>
            Try a different Level Code, or adjust your advanced search criteria.
          </Typography>
        </Paper>
      ) : (
        <Box sx={{ mt: 2 }}>
          <AgencyDataGrid ref={gridRef} rows={results} onDirtyChange={setBulkEditDirty} />
        </Box>
      )}

      <Dialog open={confirmOpen} onClose={closeConfirm} maxWidth="xs" fullWidth>
        <DialogTitle>Unsaved Bulk Edit changes</DialogTitle>
        <DialogContent>
          <DialogContentText>
            You have changes in Bulk Edit mode that haven't been saved yet. Save them before
            continuing, or discard them?
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={closeConfirm} color="inherit">
            Cancel
          </Button>
          <Button onClick={handleDiscardAndContinue} color="error">
            Discard changes
          </Button>
          <Button onClick={handleSaveAndContinue} variant="contained">
            Save changes
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
