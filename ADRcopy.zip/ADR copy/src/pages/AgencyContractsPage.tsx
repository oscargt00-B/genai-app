import { useParams } from "react-router-dom";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { DetailShell } from "../components/DetailShell";
import { DetailBreadcrumbs } from "../components/DetailBreadcrumbs";
import { ContractsDataGrid } from "../components/ContractsDataGrid";
import { getAgencyByLevelCode } from "../data/agencies";
import { getContractsForOwner } from "../lib/contracts";

/** The L2 Agency's "Authority (Contracts)" section — matches `node-id=14314-176865`. */
export function AgencyContractsPage() {
  const { levelCode = "" } = useParams();
  const agency = getAgencyByLevelCode(levelCode);
  const contracts = getContractsForOwner(levelCode);

  const navConfig = {
    level: "L2" as const,
    code: agency?.levelCode ?? "",
    name: agency?.name ?? "",
    sectionLabel: "Agency Details",
    optionsLabel: "Agency Options",
    detailsPath: `/agency/${levelCode}`,
    contractsPath: `/agency/${levelCode}/contracts`,
    licensesPath: `/agency/${levelCode}/licenses`,
    activeItem: "contracts" as const,
  };

  return (
    <DetailShell navConfig={navConfig} found={!!agency} levelCode={levelCode}>
      {agency && (
        <Box sx={{ p: 2, display: "flex", flexDirection: "column", gap: 2 }}>
          <DetailBreadcrumbs agency={agency} />
          <Typography sx={{ fontSize: 24, letterSpacing: "0.25px", color: "text.primary" }}>
            Authority (Contracts)
          </Typography>
          <ContractsDataGrid level="L2" contracts={contracts} basePath={`/agency/${levelCode}/contracts`} />
        </Box>
      )}
    </DetailShell>
  );
}
