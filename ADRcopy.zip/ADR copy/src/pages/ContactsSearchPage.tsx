import { useEffect, useMemo, useRef, useState } from "react";
import { useBlocker } from "react-router-dom";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import { FaIcon } from "../components/FaIcon";
import { QuickSearchBar } from "../components/QuickSearchBar";
import { ContactAdvancedSearchForm } from "../components/ContactAdvancedSearchForm";
import { SearchChipsBar } from "../components/SearchChipsBar";
import { ContactDataGrid, type ContactDataGridHandle } from "../components/ContactDataGrid";
import { contacts } from "../data/contacts";
import { searchContactsAdvanced, searchContactsByLevelCode } from "../lib/searchContacts";
import { activeContactCriteriaEntries, clearContactCriteriaField } from "../lib/contactCriteria";
import type { ContactAdvancedSearchCriteria, Contact } from "../types/contact";
import { emptyContactAdvancedSearch } from "../types/contact";

const agencyNameOptions = [...new Set(contacts.map((c) => c.agencyProducerName))].sort();

type Mode = "simple" | "advanced" | "chips";

/**
 * "All Contacts" — matches the Figma "Contacts Search 1" / "Contacts Search
 * R 1" screens: the same quick/advanced search + chips-summary +
 * results-grid pattern as the Home agency search page (AgencySearchPage),
 * scoped to contact fields, including the same unsaved-Bulk-Edit-changes
 * guard (in-app navigation via `useBlocker`, plus starting a new search).
 */
export function ContactsSearchPage() {
  const [mode, setMode] = useState<Mode>("simple");
  const [criteria, setCriteria] = useState<ContactAdvancedSearchCriteria>(emptyContactAdvancedSearch);
  const [results, setResults] = useState<Contact[] | null>(null);

  const gridRef = useRef<ContactDataGridHandle>(null);
  const [bulkEditDirty, setBulkEditDirty] = useState(false);
  const [pendingSearch, setPendingSearch] = useState<(() => void) | null>(null);

  const blocker = useBlocker(bulkEditDirty);

  useEffect(() => {
    if (!bulkEditDirty) return;
    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [bulkEditDirty]);

  const activeEntries = useMemo(() => activeContactCriteriaEntries(criteria), [criteria]);

  /** Runs a search immediately, unless there are unsaved Bulk Edit changes — then it waits behind the confirm dialog. */
  const runSearch = (search: () => void) => {
    if (bulkEditDirty) {
      setPendingSearch(() => search);
    } else {
      search();
    }
  };

  const handleQuickSearch = (levelCode: string) => {
    runSearch(() => setResults(searchContactsByLevelCode(contacts, levelCode)));
  };

  const handleAdvancedSearch = () => {
    runSearch(() => setResults(searchContactsAdvanced(contacts, criteria)));
  };

  const handleReset = () => {
    setCriteria(emptyContactAdvancedSearch);
    setResults(null);
  };

  const handleHide = () => {
    setMode(activeEntries.length > 0 ? "chips" : "simple");
  };

  const handleClearAllChips = () => {
    setCriteria(emptyContactAdvancedSearch);
    setResults(null);
    setMode("simple");
  };

  const handleRemoveChip = (key: keyof ContactAdvancedSearchCriteria) => {
    const next = clearContactCriteriaField(criteria, key);
    setCriteria(next);
    const remaining = activeContactCriteriaEntries(next);
    if (remaining.length === 0) {
      setResults(null);
      setMode("simple");
    } else {
      setResults(searchContactsAdvanced(contacts, next));
    }
  };

  const showReset = useMemo(() => results !== null && mode === "advanced", [results, mode]);

  const confirmOpen = pendingSearch !== null || blocker.state === "blocked";

  const closeConfirm = () => {
    setPendingSearch(null);
    if (blocker.state === "blocked") blocker.reset();
  };

  const proceed = () => {
    const search = pendingSearch;
    setPendingSearch(null);
    search?.();
    if (blocker.state === "blocked") blocker.proceed();
  };

  const handleDiscardAndContinue = () => {
    gridRef.current?.discardChanges();
    proceed();
  };

  const handleSaveAndContinue = () => {
    gridRef.current?.saveChanges();
    proceed();
  };

  return (
    <Box sx={{ p: 2, display: "flex", flexDirection: "column", gap: 2 }}>
      {mode === "simple" && (
        <QuickSearchBar onSearch={handleQuickSearch} onOpenAdvanced={() => setMode("advanced")} />
      )}

      {mode === "advanced" && (
        <ContactAdvancedSearchForm
          criteria={criteria}
          onChange={setCriteria}
          onSubmit={handleAdvancedSearch}
          onReset={handleReset}
          onHide={handleHide}
          showReset={showReset}
          agencyNameOptions={agencyNameOptions}
        />
      )}

      {mode === "chips" && (
        <SearchChipsBar
          entries={activeEntries}
          onClearAll={handleClearAllChips}
          onRemove={handleRemoveChip}
          onShowSearch={() => setMode("advanced")}
        />
      )}

      {results === null ? null : results.length === 0 ? (
        <Paper
          variant="outlined"
          sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 1,
            py: 8,
            borderStyle: "dashed",
          }}
        >
          <FaIcon icon="magnifying-glass-minus" sx={{ fontSize: 28, color: "text.disabled" }} />
          <Typography variant="body2" sx={{ fontWeight: 600, color: "text.secondary" }}>
            No contacts found
          </Typography>
          <Typography variant="caption" sx={{ color: "text.disabled", maxWidth: 360, textAlign: "center" }}>
            Try a different Level Code, or adjust your advanced search criteria.
          </Typography>
        </Paper>
      ) : (
        <Box sx={{ mt: 2 }}>
          <ContactDataGrid ref={gridRef} rows={results} onDirtyChange={setBulkEditDirty} />
        </Box>
      )}

      <Dialog open={confirmOpen} onClose={closeConfirm} maxWidth="xs" fullWidth>
        <DialogTitle>Unsaved Bulk Edit changes</DialogTitle>
        <DialogContent>
          <DialogContentText>
            You have changes in Bulk Edit mode that haven't been saved yet. Save them before
            continuing, or discard them?
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={closeConfirm} color="inherit">
            Cancel
          </Button>
          <Button onClick={handleDiscardAndContinue} color="error">
            Discard changes
          </Button>
          <Button onClick={handleSaveAndContinue} variant="contained">
            Save changes
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
