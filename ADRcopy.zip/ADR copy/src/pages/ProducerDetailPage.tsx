import { useParams } from "react-router-dom";
import Box from "@mui/material/Box";
import { DetailShell } from "../components/DetailShell";
import { DetailBreadcrumbs } from "../components/DetailBreadcrumbs";
import { AgencyDetailContent } from "../components/AgencyDetailContent";
import { getAgencyByLevelCode } from "../data/agencies";
import { getDetailExtra } from "../data/agencyDetails";

/** "Level" 3 rows — the "Producer View" detail screen. */
export function ProducerDetailPage() {
  const { levelCode = "" } = useParams();
  const agency = getAgencyByLevelCode(levelCode);

  const navConfig = {
    level: "L3" as const,
    code: agency?.levelCode ?? "",
    name: agency?.name ?? "",
    sectionLabel: "Producer Details",
    optionsLabel: "Producer Options",
    showQmas: true,
    detailsPath: `/producer/${levelCode}`,
    contractsPath: `/producer/${levelCode}/contracts`,
    licensesPath: `/producer/${levelCode}/licenses`,
    activeItem: "details" as const,
  };

  return (
    <DetailShell navConfig={navConfig} found={!!agency} levelCode={levelCode}>
      {agency && (
        <Box sx={{ p: 2, display: "flex", flexDirection: "column", flex: 1, minHeight: "calc(100vh - 64px)" }}>
          <DetailBreadcrumbs agency={agency} />
          <AgencyDetailContent
            agency={agency}
            extra={getDetailExtra(agency)}
            headline="Producer Details"
            companyNameLabel="L3 Producer Name"
            showESalesOnly
            adminUpdateStyle="combined"
          />
        </Box>
      )}
    </DetailShell>
  );
}
