import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { DetailShell } from "../components/DetailShell";
import { DetailBreadcrumbs } from "../components/DetailBreadcrumbs";
import { LicensesDataGrid } from "../components/LicensesDataGrid";
import { LicenseDrawer } from "../components/LicenseDrawer";
import { getAgencyByLevelCode } from "../data/agencies";
import { findLicense, getLicensesForOwner, licensePath } from "../lib/licenses";
import type { License } from "../types/license";

/**
 * The L3 Producer's "Licenses" section — matches `node-id=14314-181766`.
 * See AgencyLicensesPage for the deep-linking rationale (shared verbatim).
 */
export function ProducerLicensesPage() {
  const { levelCode = "", state, licenseType, company } = useParams();
  const navigate = useNavigate();
  const agency = getAgencyByLevelCode(levelCode);
  const ownerLicenses = getLicensesForOwner(levelCode);
  const basePath = `/producer/${levelCode}/licenses`;

  const deepLinked = state && licenseType && company ? findLicense(levelCode, state, licenseType, company) : undefined;
  const [openLicense, setOpenLicense] = useState<License | null>(deepLinked ?? null);

  useEffect(() => {
    setOpenLicense(deepLinked ?? null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [levelCode, state, licenseType, company]);

  const navConfig = {
    level: "L3" as const,
    code: agency?.levelCode ?? "",
    name: agency?.name ?? "",
    sectionLabel: "Producer Details",
    optionsLabel: "Producer Options",
    showQmas: true,
    detailsPath: `/producer/${levelCode}`,
    contractsPath: `/producer/${levelCode}/contracts`,
    licensesPath: basePath,
    activeItem: "licenses" as const,
  };

  const handleClose = () => {
    setOpenLicense(null);
    if (state && licenseType && company) navigate(basePath);
  };

  return (
    <DetailShell navConfig={navConfig} found={!!agency} levelCode={levelCode}>
      {agency && (
        <Box sx={{ p: 2, display: "flex", flexDirection: "column", gap: 2 }}>
          <DetailBreadcrumbs agency={agency} />
          <Typography sx={{ fontSize: 24, letterSpacing: "0.25px", color: "text.primary" }}>Licenses</Typography>
          <LicensesDataGrid
            licenses={ownerLicenses}
            onEditLicense={(license) => navigate(licensePath(basePath, license))}
          />
          <LicenseDrawer license={openLicense} open={!!openLicense} onClose={handleClose} />
        </Box>
      )}
    </DetailShell>
  );
}
