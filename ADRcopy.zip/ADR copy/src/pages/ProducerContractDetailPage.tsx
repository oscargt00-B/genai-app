import { useParams } from "react-router-dom";
import Box from "@mui/material/Box";
import { DetailShell } from "../components/DetailShell";
import { ContractBreadcrumbs } from "../components/ContractBreadcrumbs";
import { ContractDetailContent } from "../components/ContractDetailContent";
import { NotFoundDetail } from "../components/NotFoundDetail";
import { getAgencyByLevelCode } from "../data/agencies";
import { findContract, getContractsForOwner } from "../lib/contracts";

/** One L3 Producer contract's detail page — matches `node-id=14314-182968` ("Producer Contract"). */
export function ProducerContractDetailPage() {
  const { levelCode = "", state = "", lob = "", company = "" } = useParams();
  const agency = getAgencyByLevelCode(levelCode);
  const contract = agency ? findContract(levelCode, state, lob, company) : undefined;

  const navConfig = {
    level: "L3" as const,
    code: agency?.levelCode ?? "",
    name: agency?.name ?? "",
    sectionLabel: "Producer Details",
    optionsLabel: "Producer Options",
    showQmas: true,
    detailsPath: `/producer/${levelCode}`,
    contractsPath: `/producer/${levelCode}/contracts`,
    licensesPath: `/producer/${levelCode}/licenses`,
    activeItem: "contracts" as const,
  };

  return (
    <DetailShell navConfig={navConfig} found={!!agency} levelCode={levelCode}>
      {agency &&
        (contract ? (
          <Box sx={{ p: 2, display: "flex", flexDirection: "column", flex: 1, minHeight: "calc(100vh - 64px)" }}>
            <ContractBreadcrumbs agency={agency} contract={contract} siblingContracts={getContractsForOwner(levelCode)} />
            <ContractDetailContent contract={contract} />
          </Box>
        ) : (
          <NotFoundDetail levelCode={`${state}, ${lob}, ${company}`} />
        ))}
    </DetailShell>
  );
}
