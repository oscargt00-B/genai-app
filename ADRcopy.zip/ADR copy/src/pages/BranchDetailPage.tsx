import { useParams } from "react-router-dom";
import Box from "@mui/material/Box";
import { TopBar } from "../components/TopBar";
import { DetailSideNav } from "../components/DetailSideNav";
import { ShellMain } from "../components/ShellMain";
import { DetailBreadcrumbs } from "../components/DetailBreadcrumbs";
import { BranchDetailContent } from "../components/BranchDetailContent";
import { NotFoundDetail } from "../components/NotFoundDetail";
import { useSidebarShell } from "../hooks/useSidebarShell";
import { getAgencyByLevelCode } from "../data/agencies";
import { getDetailExtra } from "../data/agencyDetails";

/** "Level" 1 rows — the "Branch View" detail screen. */
export function BranchDetailPage() {
  const { levelCode = "" } = useParams();
  const shell = useSidebarShell();
  const branch = getAgencyByLevelCode(levelCode);

  const navConfig = {
    level: "L1" as const,
    code: branch?.levelCode ?? "",
    name: branch?.name ?? "",
    sectionLabel: "Branch Details",
  };

  return (
    <>
      <TopBar onMenuClick={shell.isMobile ? shell.openMobile : undefined} />
      {shell.isMobile ? (
        <DetailSideNav variant="temporary" open={shell.mobileOpen} onClose={shell.closeMobile} {...navConfig} />
      ) : (
        <DetailSideNav
          variant="permanent"
          collapsed={shell.collapsed}
          onToggleCollapsed={shell.toggleCollapsed}
          {...navConfig}
        />
      )}
      <ShellMain navWidth={shell.navWidth}>
        {branch ? (
          <Box sx={{ p: 2, display: "flex", flexDirection: "column", flex: 1, minHeight: "calc(100vh - 64px)" }}>
            <DetailBreadcrumbs agency={branch} />
            <BranchDetailContent branch={branch} extra={getDetailExtra(branch)} />
          </Box>
        ) : (
          <NotFoundDetail levelCode={levelCode} />
        )}
      </ShellMain>
    </>
  );
}
