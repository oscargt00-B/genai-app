import { useEffect, useMemo, useRef, useState } from "react";
import { useBlocker } from "react-router-dom";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import { FaIcon } from "../components/FaIcon";
import { QuickSearchBar } from "../components/QuickSearchBar";
import { LicenseAdvancedSearchForm } from "../components/LicenseAdvancedSearchForm";
import { SearchChipsBar } from "../components/SearchChipsBar";
import { LicenseDataGrid, type LicenseDataGridHandle } from "../components/LicenseDataGrid";
import { licenses } from "../data/licenses";
import { searchLicensesAdvanced, searchLicensesByLevelCode } from "../lib/searchLicenses";
import { activeLicenseCriteriaEntries, clearLicenseCriteriaField } from "../lib/licenseCriteria";
import type { LicenseAdvancedSearchCriteria, License } from "../types/license";
import { emptyLicenseAdvancedSearch } from "../types/license";

type Mode = "simple" | "advanced" | "chips";

/**
 * "All Licenses" — matches the Figma "Licenses Search R 2" screen: the same
 * quick/advanced search + chips-summary + results-grid pattern as the Home
 * agency search page (AgencySearchPage), scoped to license fields, including
 * the same unsaved-Bulk-Edit-changes guard (in-app navigation via
 * `useBlocker`, plus starting a new search).
 */
export function LicensesSearchPage() {
  const [mode, setMode] = useState<Mode>("simple");
  const [criteria, setCriteria] = useState<LicenseAdvancedSearchCriteria>(emptyLicenseAdvancedSearch);
  const [results, setResults] = useState<License[] | null>(null);

  const gridRef = useRef<LicenseDataGridHandle>(null);
  const [bulkEditDirty, setBulkEditDirty] = useState(false);
  const [pendingSearch, setPendingSearch] = useState<(() => void) | null>(null);

  const blocker = useBlocker(bulkEditDirty);

  useEffect(() => {
    if (!bulkEditDirty) return;
    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [bulkEditDirty]);

  const activeEntries = useMemo(() => activeLicenseCriteriaEntries(criteria), [criteria]);

  /** Runs a search immediately, unless there are unsaved Bulk Edit changes — then it waits behind the confirm dialog. */
  const runSearch = (search: () => void) => {
    if (bulkEditDirty) {
      setPendingSearch(() => search);
    } else {
      search();
    }
  };

  const handleQuickSearch = (levelCode: string) => {
    runSearch(() => setResults(searchLicensesByLevelCode(licenses, levelCode)));
  };

  const handleAdvancedSearch = () => {
    runSearch(() => setResults(searchLicensesAdvanced(licenses, criteria)));
  };

  const handleReset = () => {
    setCriteria(emptyLicenseAdvancedSearch);
    setResults(null);
  };

  const handleHide = () => {
    setMode(activeEntries.length > 0 ? "chips" : "simple");
  };

  const handleClearAllChips = () => {
    setCriteria(emptyLicenseAdvancedSearch);
    setResults(null);
    setMode("simple");
  };

  const handleRemoveChip = (key: keyof LicenseAdvancedSearchCriteria) => {
    const next = clearLicenseCriteriaField(criteria, key);
    setCriteria(next);
    const remaining = activeLicenseCriteriaEntries(next);
    if (remaining.length === 0) {
      setResults(null);
      setMode("simple");
    } else {
      setResults(searchLicensesAdvanced(licenses, next));
    }
  };

  const showReset = useMemo(() => results !== null && mode === "advanced", [results, mode]);

  const confirmOpen = pendingSearch !== null || blocker.state === "blocked";

  const closeConfirm = () => {
    setPendingSearch(null);
    if (blocker.state === "blocked") blocker.reset();
  };

  const proceed = () => {
    const search = pendingSearch;
    setPendingSearch(null);
    search?.();
    if (blocker.state === "blocked") blocker.proceed();
  };

  const handleDiscardAndContinue = () => {
    gridRef.current?.discardChanges();
    proceed();
  };

  const handleSaveAndContinue = () => {
    gridRef.current?.saveChanges();
    proceed();
  };

  return (
    <Box sx={{ p: 2, display: "flex", flexDirection: "column", gap: 2 }}>
      {mode === "simple" && (
        <QuickSearchBar onSearch={handleQuickSearch} onOpenAdvanced={() => setMode("advanced")} />
      )}

      {mode === "advanced" && (
        <LicenseAdvancedSearchForm
          criteria={criteria}
          onChange={setCriteria}
          onSubmit={handleAdvancedSearch}
          onReset={handleReset}
          onHide={handleHide}
          showReset={showReset}
        />
      )}

      {mode === "chips" && (
        <SearchChipsBar
          entries={activeEntries}
          onClearAll={handleClearAllChips}
          onRemove={handleRemoveChip}
          onShowSearch={() => setMode("advanced")}
        />
      )}

      {results === null ? null : results.length === 0 ? (
        <Paper
          variant="outlined"
          sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 1,
            py: 8,
            borderStyle: "dashed",
          }}
        >
          <FaIcon icon="magnifying-glass-minus" sx={{ fontSize: 28, color: "text.disabled" }} />
          <Typography variant="body2" sx={{ fontWeight: 600, color: "text.secondary" }}>
            No licenses found
          </Typography>
          <Typography variant="caption" sx={{ color: "text.disabled", maxWidth: 360, textAlign: "center" }}>
            Try a different Level Code, or adjust your advanced search criteria.
          </Typography>
        </Paper>
      ) : (
        <Box sx={{ mt: 2 }}>
          <LicenseDataGrid ref={gridRef} rows={results} onDirtyChange={setBulkEditDirty} />
        </Box>
      )}

      <Dialog open={confirmOpen} onClose={closeConfirm} maxWidth="xs" fullWidth>
        <DialogTitle>Unsaved Bulk Edit changes</DialogTitle>
        <DialogContent>
          <DialogContentText>
            You have changes in Bulk Edit mode that haven't been saved yet. Save them before
            continuing, or discard them?
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={closeConfirm} color="inherit">
            Cancel
          </Button>
          <Button onClick={handleDiscardAndContinue} color="error">
            Discard changes
          </Button>
          <Button onClick={handleSaveAndContinue} variant="contained">
            Save changes
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
