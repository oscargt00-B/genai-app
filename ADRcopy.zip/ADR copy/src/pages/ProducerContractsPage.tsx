import { useParams } from "react-router-dom";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { DetailShell } from "../components/DetailShell";
import { DetailBreadcrumbs } from "../components/DetailBreadcrumbs";
import { ContractsDataGrid } from "../components/ContractsDataGrid";
import { getAgencyByLevelCode } from "../data/agencies";
import { getContractsForOwner } from "../lib/contracts";

/** The L3 Producer's "Authority (Contracts)" section — matches `node-id=14314-182655`. */
export function ProducerContractsPage() {
  const { levelCode = "" } = useParams();
  const agency = getAgencyByLevelCode(levelCode);
  const contracts = getContractsForOwner(levelCode);

  const navConfig = {
    level: "L3" as const,
    code: agency?.levelCode ?? "",
    name: agency?.name ?? "",
    sectionLabel: "Producer Details",
    optionsLabel: "Producer Options",
    showQmas: true,
    detailsPath: `/producer/${levelCode}`,
    contractsPath: `/producer/${levelCode}/contracts`,
    licensesPath: `/producer/${levelCode}/licenses`,
    activeItem: "contracts" as const,
  };

  return (
    <DetailShell navConfig={navConfig} found={!!agency} levelCode={levelCode}>
      {agency && (
        <Box sx={{ p: 2, display: "flex", flexDirection: "column", gap: 2 }}>
          <DetailBreadcrumbs agency={agency} />
          <Typography sx={{ fontSize: 24, letterSpacing: "0.25px", color: "text.primary" }}>
            Authority (Contracts)
          </Typography>
          <ContractsDataGrid level="L3" contracts={contracts} basePath={`/producer/${levelCode}/contracts`} />
        </Box>
      )}
    </DetailShell>
  );
}
