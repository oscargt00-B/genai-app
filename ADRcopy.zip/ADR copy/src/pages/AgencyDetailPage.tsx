import { useParams } from "react-router-dom";
import Box from "@mui/material/Box";
import { DetailShell } from "../components/DetailShell";
import { DetailBreadcrumbs } from "../components/DetailBreadcrumbs";
import { AgencyDetailContent } from "../components/AgencyDetailContent";
import { getAgencyByLevelCode } from "../data/agencies";
import { getDetailExtra } from "../data/agencyDetails";

/** "Level" 2 rows — the "Agency View" detail screen. */
export function AgencyDetailPage() {
  const { levelCode = "" } = useParams();
  const agency = getAgencyByLevelCode(levelCode);

  const navConfig = {
    level: "L2" as const,
    code: agency?.levelCode ?? "",
    name: agency?.name ?? "",
    sectionLabel: "Agency Details",
    optionsLabel: "Agency Options",
    detailsPath: `/agency/${levelCode}`,
    contractsPath: `/agency/${levelCode}/contracts`,
    licensesPath: `/agency/${levelCode}/licenses`,
    activeItem: "details" as const,
  };

  return (
    <DetailShell navConfig={navConfig} found={!!agency} levelCode={levelCode}>
      {agency && (
        <Box sx={{ p: 2, display: "flex", flexDirection: "column", flex: 1, minHeight: "calc(100vh - 64px)" }}>
          <DetailBreadcrumbs agency={agency} />
          <AgencyDetailContent
            agency={agency}
            extra={getDetailExtra(agency)}
            headline="Agency Details"
            companyNameLabel="L2 Agency Name"
            newButtonLabel="New L3 Producer"
            showESalesOnly={false}
            adminUpdateStyle="split"
          />
        </Box>
      )}
    </DetailShell>
  );
}
