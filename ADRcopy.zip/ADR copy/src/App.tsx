import type { ReactNode } from "react";
import CssBaseline from "@mui/material/CssBaseline";
import { ThemeProvider } from "@mui/material/styles";
import { createHashRouter, RouterProvider } from "react-router-dom";
import { theme } from "./theme";
import { TopBar } from "./components/TopBar";
import { SideNav } from "./components/SideNav";
import { ShellMain } from "./components/ShellMain";
import { useSidebarShell } from "./hooks/useSidebarShell";
import { AgencySearchPage } from "./pages/AgencySearchPage";
import { LicensesSearchPage } from "./pages/LicensesSearchPage";
import { AuthoritySearchPage } from "./pages/AuthoritySearchPage";
import { ContactsSearchPage } from "./pages/ContactsSearchPage";
import { AddressesSearchPage } from "./pages/AddressesSearchPage";
import { BranchDetailPage } from "./pages/BranchDetailPage";
import { AgencyDetailPage } from "./pages/AgencyDetailPage";
import { ProducerDetailPage } from "./pages/ProducerDetailPage";
import { AgencyContractsPage } from "./pages/AgencyContractsPage";
import { ProducerContractsPage } from "./pages/ProducerContractsPage";
import { AgencyContractDetailPage } from "./pages/AgencyContractDetailPage";
import { ProducerContractDetailPage } from "./pages/ProducerContractDetailPage";
import { AgencyLicensesPage } from "./pages/AgencyLicensesPage";
import { ProducerLicensesPage } from "./pages/ProducerLicensesPage";

/** The persistent chrome (AppBar + side nav) shared by every top-level page reachable from the side nav. */
function MainLayout({ children }: { children: ReactNode }) {
  const shell = useSidebarShell();

  return (
    <>
      <TopBar onMenuClick={shell.isMobile ? shell.openMobile : undefined} />
      {shell.isMobile ? (
        <SideNav variant="temporary" open={shell.mobileOpen} onClose={shell.closeMobile} />
      ) : (
        <SideNav variant="permanent" collapsed={shell.collapsed} onToggleCollapsed={shell.toggleCollapsed} />
      )}
      <ShellMain navWidth={shell.navWidth}>{children}</ShellMain>
    </>
  );
}

// A data router (rather than plain <BrowserRouter>) is required for useBlocker,
// which AgencySearchPage/LicensesSearchPage/AuthoritySearchPage use to confirm
// before navigating away with unsaved Bulk Edit changes.
//
// A *hash* router (URLs like index.html#/licenses) keeps the built site fully
// static and relocatable: it opens straight from disk (file://) and from any
// folder on any web server, with no rewrite rules, because the route lives
// after the "#" and never reaches the server.
const router = createHashRouter(
  [
    { path: "/", element: <MainLayout><AgencySearchPage /></MainLayout> },
    { path: "/licenses", element: <MainLayout><LicensesSearchPage /></MainLayout> },
    { path: "/authority", element: <MainLayout><AuthoritySearchPage /></MainLayout> },
    { path: "/contacts", element: <MainLayout><ContactsSearchPage /></MainLayout> },
    { path: "/addresses", element: <MainLayout><AddressesSearchPage /></MainLayout> },
    { path: "/branch/:levelCode", element: <BranchDetailPage /> },
    { path: "/agency/:levelCode", element: <AgencyDetailPage /> },
    { path: "/agency/:levelCode/contracts", element: <AgencyContractsPage /> },
    { path: "/agency/:levelCode/contracts/:state/:lob/:company", element: <AgencyContractDetailPage /> },
    { path: "/agency/:levelCode/licenses", element: <AgencyLicensesPage /> },
    { path: "/agency/:levelCode/licenses/:state/:licenseType/:company", element: <AgencyLicensesPage /> },
    { path: "/producer/:levelCode", element: <ProducerDetailPage /> },
    { path: "/producer/:levelCode/contracts", element: <ProducerContractsPage /> },
    { path: "/producer/:levelCode/contracts/:state/:lob/:company", element: <ProducerContractDetailPage /> },
    { path: "/producer/:levelCode/licenses", element: <ProducerLicensesPage /> },
    { path: "/producer/:levelCode/licenses/:state/:licenseType/:company", element: <ProducerLicensesPage /> },
  ],
);

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <RouterProvider router={router} />
    </ThemeProvider>
  );
}

export default App;
