import type { ContactAdvancedSearchCriteria } from "../types/contact";

export interface ContactCriteriaEntry {
  key: keyof ContactAdvancedSearchCriteria;
  label: string;
  /** Display text for the chip — joined for multi-value fields. */
  value: string;
}

const FIELD_LABELS: Record<keyof ContactAdvancedSearchCriteria, string> = {
  l1BranchName: "L1 Branch Name",
  l2AgencyCode: "L2 Agency Code",
  l3ProducerCode: "L3 Producer Code",
  contactType: "Contact Type",
  l2AgencyName: "L2 Agency Name",
  l3ProducerName: "L3 Producer Name",
  firstName: "First Name",
  lastName: "Last Name",
  imageRightId: "Image Right ID",
  phone: "Phone",
  email: "Email",
};

/** Field order matches the form layout, top-left to bottom-right. */
const FIELD_ORDER: (keyof ContactAdvancedSearchCriteria)[] = [
  "l1BranchName",
  "l2AgencyCode",
  "l3ProducerCode",
  "contactType",
  "l2AgencyName",
  "l3ProducerName",
  "firstName",
  "lastName",
  "imageRightId",
  "phone",
  "email",
];

/** Non-empty criteria fields, in form order, as chip-ready {key, label, value} entries. */
export function activeContactCriteriaEntries(
  criteria: ContactAdvancedSearchCriteria,
): ContactCriteriaEntry[] {
  return FIELD_ORDER.flatMap((key) => {
    const raw = criteria[key];
    const value = Array.isArray(raw) ? raw.join(", ") : raw;
    if (!value || !value.trim()) return [];
    return [{ key, label: FIELD_LABELS[key], value }];
  });
}

/** Clears a single field, preserving the type (string vs. string[]) of the rest. */
export function clearContactCriteriaField(
  criteria: ContactAdvancedSearchCriteria,
  key: keyof ContactAdvancedSearchCriteria,
): ContactAdvancedSearchCriteria {
  return { ...criteria, [key]: Array.isArray(criteria[key]) ? [] : "" };
}
