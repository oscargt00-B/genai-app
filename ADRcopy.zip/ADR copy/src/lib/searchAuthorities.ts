import type { Authority, AuthorityAdvancedSearchCriteria } from "../types/authority";

const norm = (v: string) => v.trim().toLowerCase();

const includesText = (haystack: string, needle: string) =>
  norm(haystack).includes(norm(needle));

/**
 * Quick search: match the unique Level Code (exact or partial, case-insensitive).
 * A blank query browses the full repository — handy for exercising pagination.
 */
export function searchAuthoritiesByLevelCode(authorities: Authority[], levelCode: string): Authority[] {
  const q = norm(levelCode);
  if (!q) return authorities;
  return authorities.filter((a) => includesText(a.levelCode, q));
}

/**
 * Advanced search: AND-combine every non-empty criterion. With every field
 * left blank, returns the full repository.
 */
export function searchAuthoritiesAdvanced(
  authorities: Authority[],
  criteria: AuthorityAdvancedSearchCriteria,
): Authority[] {
  return authorities.filter((a) => {
    if (criteria.l1BranchName && a.branch !== criteria.l1BranchName) return false;
    if (criteria.l2AgencyCode && !includesText(a.levelCode, criteria.l2AgencyCode)) return false;
    if (criteria.l3ProducerCode && !includesText(a.levelCode, criteria.l3ProducerCode)) return false;
    if (criteria.contractState && a.contractState !== criteria.contractState) return false;
    if (
      criteria.l2AgencyName.length > 0 &&
      !criteria.l2AgencyName.some((n) => includesText(a.agencyProducerName, n))
    )
      return false;
    if (criteria.l3ProducerName && !includesText(a.agencyProducerName, criteria.l3ProducerName)) return false;
    if (criteria.lob && a.lob !== criteria.lob) return false;
    if (criteria.underwritingCompany && !includesText(a.underwritingCompany, criteria.underwritingCompany))
      return false;
    if (criteria.contractType && a.contractType !== criteria.contractType) return false;
    if (criteria.contractStatus && a.contractStatus !== criteria.contractStatus) return false;
    if (criteria.contractNumber && !includesText(a.contractNumber, criteria.contractNumber)) return false;
    if (criteria.appointmentDate && !includesText(a.contractAppointmentDate, criteria.appointmentDate))
      return false;
    if (
      criteria.newBusinessIndicator &&
      !includesText(a.newBusinessIndicator, criteria.newBusinessIndicator)
    )
      return false;
    if (criteria.serviceCenterIndicator && a.serviceCenterIndicator !== criteria.serviceCenterIndicator)
      return false;
    if (criteria.underwritingGroup && !includesText(a.underwritingGroup, criteria.underwritingGroup))
      return false;
    if (criteria.marketingGroup && !includesText(a.marketingGroup, criteria.marketingGroup)) return false;
    return true;
  });
}
