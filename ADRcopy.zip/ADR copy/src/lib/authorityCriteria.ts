import type { AuthorityAdvancedSearchCriteria } from "../types/authority";

export interface AuthorityCriteriaEntry {
  key: keyof AuthorityAdvancedSearchCriteria;
  label: string;
  /** Display text for the chip — joined for multi-value fields. */
  value: string;
}

const FIELD_LABELS: Record<keyof AuthorityAdvancedSearchCriteria, string> = {
  l1BranchName: "L1 Branch Name",
  l2AgencyCode: "L2 Agency Code",
  l3ProducerCode: "L3 Producer Code",
  contractState: "Contract State",
  l2AgencyName: "L2 Agency Name",
  l3ProducerName: "L3 Producer Name",
  lob: "LOB",
  underwritingCompany: "Underwriting Company",
  contractType: "Contract Type",
  contractStatus: "Contract Status",
  contractNumber: "Contract Number",
  appointmentDate: "Appointment Date",
  newBusinessIndicator: "New Business Indicator",
  serviceCenterIndicator: "Service Center Indicator",
  underwritingGroup: "Underwriting Group",
  marketingGroup: "Marketing Group",
};

/** Field order matches the form layout, top-left to bottom-right. */
const FIELD_ORDER: (keyof AuthorityAdvancedSearchCriteria)[] = [
  "l1BranchName",
  "l2AgencyCode",
  "l3ProducerCode",
  "contractState",
  "l2AgencyName",
  "l3ProducerName",
  "lob",
  "underwritingCompany",
  "contractType",
  "contractStatus",
  "contractNumber",
  "appointmentDate",
  "newBusinessIndicator",
  "serviceCenterIndicator",
  "underwritingGroup",
  "marketingGroup",
];

/** Non-empty criteria fields, in form order, as chip-ready {key, label, value} entries. */
export function activeAuthorityCriteriaEntries(
  criteria: AuthorityAdvancedSearchCriteria,
): AuthorityCriteriaEntry[] {
  return FIELD_ORDER.flatMap((key) => {
    const raw = criteria[key];
    const value = Array.isArray(raw) ? raw.join(", ") : raw;
    if (!value || !value.trim()) return [];
    return [{ key, label: FIELD_LABELS[key], value }];
  });
}

/** Clears a single field, preserving the type (string vs. string[]) of the rest. */
export function clearAuthorityCriteriaField(
  criteria: AuthorityAdvancedSearchCriteria,
  key: keyof AuthorityAdvancedSearchCriteria,
): AuthorityAdvancedSearchCriteria {
  return { ...criteria, [key]: Array.isArray(criteria[key]) ? [] : "" };
}
