import type { AddressAdvancedSearchCriteria } from "../types/address";

export interface AddressCriteriaEntry {
  key: keyof AddressAdvancedSearchCriteria;
  label: string;
  /** Display text for the chip — joined for multi-value fields. */
  value: string;
}

const FIELD_LABELS: Record<keyof AddressAdvancedSearchCriteria, string> = {
  l1BranchName: "L1 Branch Name",
  l2AgencyCode: "L2 Agency Code",
  l3ProducerCode: "L3 Producer Code",
  addressType: "Address Type",
  agencyName: "Agency Name",
  address: "Address",
  state: "State",
  zipCode: "Zip Code",
};

/** Field order matches the form layout, top-left to bottom-right. */
const FIELD_ORDER: (keyof AddressAdvancedSearchCriteria)[] = [
  "l1BranchName",
  "l2AgencyCode",
  "l3ProducerCode",
  "addressType",
  "agencyName",
  "address",
  "state",
  "zipCode",
];

/** Non-empty criteria fields, in form order, as chip-ready {key, label, value} entries. */
export function activeAddressCriteriaEntries(
  criteria: AddressAdvancedSearchCriteria,
): AddressCriteriaEntry[] {
  return FIELD_ORDER.flatMap((key) => {
    const raw = criteria[key];
    const value = Array.isArray(raw) ? raw.join(", ") : raw;
    if (!value || !value.trim()) return [];
    return [{ key, label: FIELD_LABELS[key], value }];
  });
}

/** Clears a single field, preserving the type (string vs. string[]) of the rest. */
export function clearAddressCriteriaField(
  criteria: AddressAdvancedSearchCriteria,
  key: keyof AddressAdvancedSearchCriteria,
): AddressAdvancedSearchCriteria {
  return { ...criteria, [key]: Array.isArray(criteria[key]) ? [] : "" };
}
