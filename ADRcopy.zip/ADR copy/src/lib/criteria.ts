import type { AdvancedSearchCriteria } from "../types/agency";

export interface CriteriaEntry {
  key: keyof AdvancedSearchCriteria;
  label: string;
  /** Display text for the chip — joined for multi-value fields. */
  value: string;
}

const FIELD_LABELS: Record<keyof AdvancedSearchCriteria, string> = {
  l1BranchName: "L1 Branch Name",
  l2AgencyCode: "L2 Agency Code",
  l3ProducerCode: "L3 Producer Code",
  agencyGroupKey: "Agency Group Key",
  l2AgencyName: "L2 Agency Name",
  l3ProducerName: "L3 Producer Name",
  npn: "NPN",
  taxId: "Tax ID",
};

/** Field order matches the form layout, top-left to bottom-right. */
const FIELD_ORDER: (keyof AdvancedSearchCriteria)[] = [
  "l1BranchName",
  "l2AgencyCode",
  "l3ProducerCode",
  "agencyGroupKey",
  "l2AgencyName",
  "l3ProducerName",
  "npn",
  "taxId",
];

/** Non-empty criteria fields, in form order, as chip-ready {key, label, value} entries. */
export function activeCriteriaEntries(criteria: AdvancedSearchCriteria): CriteriaEntry[] {
  return FIELD_ORDER.flatMap((key) => {
    const raw = criteria[key];
    const value = Array.isArray(raw) ? raw.join(", ") : raw;
    if (!value || !value.trim()) return [];
    return [{ key, label: FIELD_LABELS[key], value }];
  });
}

/** Clears a single field, preserving the type (string vs. string[]) of the rest. */
export function clearCriteriaField(
  criteria: AdvancedSearchCriteria,
  key: keyof AdvancedSearchCriteria,
): AdvancedSearchCriteria {
  return { ...criteria, [key]: Array.isArray(criteria[key]) ? [] : "" };
}
