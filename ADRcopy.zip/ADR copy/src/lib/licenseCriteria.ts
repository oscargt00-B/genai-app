import type { LicenseAdvancedSearchCriteria } from "../types/license";

export interface LicenseCriteriaEntry {
  key: keyof LicenseAdvancedSearchCriteria;
  label: string;
  value: string;
}

const FIELD_LABELS: Record<keyof LicenseAdvancedSearchCriteria, string> = {
  levelCode: "Level Code",
  licenseType: "License Type",
  licenseStatus: "Status",
  licenseState: "State",
  licenseName: "License Name",
  npn: "NPN",
  stateLicenseNumber: "SLN",
};

/** Field order matches the form layout, top-left to bottom-right. */
const FIELD_ORDER: (keyof LicenseAdvancedSearchCriteria)[] = [
  "levelCode",
  "licenseType",
  "licenseStatus",
  "licenseState",
  "licenseName",
  "npn",
  "stateLicenseNumber",
];

/** Non-empty criteria fields, in form order, as chip-ready {key, label, value} entries. */
export function activeLicenseCriteriaEntries(criteria: LicenseAdvancedSearchCriteria): LicenseCriteriaEntry[] {
  return FIELD_ORDER.flatMap((key) => {
    const value = criteria[key];
    if (!value || !value.trim()) return [];
    return [{ key, label: FIELD_LABELS[key], value }];
  });
}

/** Clears a single field. */
export function clearLicenseCriteriaField(
  criteria: LicenseAdvancedSearchCriteria,
  key: keyof LicenseAdvancedSearchCriteria,
): LicenseAdvancedSearchCriteria {
  return { ...criteria, [key]: "" };
}
