import type { License, LicenseAdvancedSearchCriteria } from "../types/license";

const norm = (v: string) => v.trim().toLowerCase();

const includesText = (haystack: string, needle: string) =>
  norm(haystack).includes(norm(needle));

/**
 * Quick search: match the unique Level Code (exact or partial, case-insensitive).
 * A blank query browses the full repository — handy for exercising pagination.
 */
export function searchLicensesByLevelCode(licenses: License[], levelCode: string): License[] {
  const q = norm(levelCode);
  if (!q) return licenses;
  return licenses.filter((l) => includesText(l.levelCode, q));
}

/**
 * Advanced search: AND-combine every non-empty criterion. With every field
 * left blank, returns the full repository.
 */
export function searchLicensesAdvanced(
  licenses: License[],
  criteria: LicenseAdvancedSearchCriteria,
): License[] {
  return licenses.filter((l) => {
    if (criteria.levelCode && !includesText(l.levelCode, criteria.levelCode)) return false;
    if (criteria.licenseType && l.licenseType !== criteria.licenseType) return false;
    if (criteria.licenseStatus && l.licenseStatus !== criteria.licenseStatus) return false;
    if (criteria.licenseState && l.licenseState !== criteria.licenseState) return false;
    if (criteria.licenseName && !includesText(l.licenseName, criteria.licenseName)) return false;
    if (criteria.npn && !includesText(l.npn, criteria.npn)) return false;
    if (criteria.stateLicenseNumber && !includesText(l.stateLicenseNumber, criteria.stateLicenseNumber))
      return false;
    return true;
  });
}
