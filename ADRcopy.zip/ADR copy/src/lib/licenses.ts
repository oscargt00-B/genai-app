import { licenses } from "../data/licenses";
import type { License } from "../types/license";

/** Every license held by one L2 Agency or L3 Producer — an owner can have one or many. */
export function getLicensesForOwner(levelCode: string): License[] {
  return licenses.filter((l) => l.levelCode === levelCode);
}

/** A license is uniquely identified by (owner, License State, License Type, Underwriting Company) — never by a single id, mirroring how a Contract is identified. */
export function findLicense(
  levelCode: string,
  licenseState: string,
  licenseType: string,
  underwritingCompany: string,
): License | undefined {
  return licenses.find(
    (l) =>
      l.levelCode === levelCode &&
      l.licenseState === licenseState &&
      l.licenseType === licenseType &&
      l.underwritingCompany === underwritingCompany,
  );
}

/** Builds the URL for one license, nested under its owner's Agency/Producer Licenses route — opens that section with the license's drawer open. */
export function licensePath(
  ownerBasePath: string,
  license: Pick<License, "licenseState" | "licenseType" | "underwritingCompany">,
): string {
  return [
    ownerBasePath,
    encodeURIComponent(license.licenseState),
    encodeURIComponent(license.licenseType),
    encodeURIComponent(license.underwritingCompany),
  ].join("/");
}

/**
 * `levelCode` alone is NOT a unique row identity — an owner can hold one or
 * many licenses (same levelCode, different State/Type/Underwriting Company),
 * so every place that identifies a row for selection, Bulk Edit overrides,
 * or a DataGrid's own `getRowId` needs this full composite key instead, the
 * same convention AuthorityDataGrid.tsx uses for its own rows.
 */
export function licenseRowKey(license: Pick<License, "levelCode" | "licenseState" | "licenseType" | "underwritingCompany">): string {
  return `${license.levelCode}|${license.licenseState}|${license.licenseType}|${license.underwritingCompany}`;
}
