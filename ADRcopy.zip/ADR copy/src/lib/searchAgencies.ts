import type { Agency, AdvancedSearchCriteria } from "../types/agency";

const norm = (v: string) => v.trim().toLowerCase();

const includesText = (haystack: string, needle: string) =>
  norm(haystack).includes(norm(needle));

/**
 * Quick search: match the unique Level Code (exact or partial, case-insensitive).
 * A blank query browses the full repository — handy for exercising pagination.
 */
export function searchByLevelCode(agencies: Agency[], levelCode: string): Agency[] {
  const q = norm(levelCode);
  if (!q) return agencies;
  return agencies.filter((a) => includesText(a.levelCode, q));
}

/**
 * Advanced search ("PRAC - Search Advanced"): AND-combine every non-empty
 * criterion. L2 Agency Code and Agency Group Key both narrow the AG Key
 * column; L2/L3 Name both narrow the Agency/Producer Name column — mirroring
 * how the design offers several ways into the same underlying identifiers.
 * With every field left blank, returns the full repository.
 */
export function searchAdvanced(
  agencies: Agency[],
  criteria: AdvancedSearchCriteria,
): Agency[] {
  return agencies.filter((a) => {
    if (criteria.l1BranchName && a.branch !== criteria.l1BranchName) return false;
    if (criteria.l2AgencyCode && !includesText(a.agencyGroupKey, criteria.l2AgencyCode))
      return false;
    if (criteria.l3ProducerCode && !includesText(a.levelCode, criteria.l3ProducerCode))
      return false;
    if (criteria.agencyGroupKey && !includesText(a.agencyGroupKey, criteria.agencyGroupKey))
      return false;
    if (
      criteria.l2AgencyName.length > 0 &&
      !criteria.l2AgencyName.some((n) => includesText(a.name, n))
    )
      return false;
    if (criteria.l3ProducerName && !includesText(a.name, criteria.l3ProducerName))
      return false;
    if (criteria.npn && !includesText(a.npn, criteria.npn)) return false;
    if (criteria.taxId && !includesText(a.taxId, criteria.taxId)) return false;
    return true;
  });
}
