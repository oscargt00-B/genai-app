import type { Contact, ContactAdvancedSearchCriteria } from "../types/contact";

const norm = (v: string) => v.trim().toLowerCase();

const includesText = (haystack: string, needle: string) => norm(haystack).includes(norm(needle));

/**
 * Quick search: match the unique Level Code (exact or partial, case-insensitive).
 * A blank query browses the full repository — handy for exercising pagination.
 */
export function searchContactsByLevelCode(contacts: Contact[], levelCode: string): Contact[] {
  const q = norm(levelCode);
  if (!q) return contacts;
  return contacts.filter((c) => includesText(c.levelCode, q));
}

/**
 * Advanced search: AND-combine every non-empty criterion. L2 Agency Code
 * and L3 Producer Code both narrow the same Level Code field — Contact
 * records don't carry a separate "AG Key", so (like Licenses' own advanced
 * search) both boxes are just different entry points into the one
 * identifier. With every field left blank, returns the full repository.
 */
export function searchContactsAdvanced(
  contacts: Contact[],
  criteria: ContactAdvancedSearchCriteria,
): Contact[] {
  return contacts.filter((c) => {
    if (criteria.l1BranchName && c.branch !== criteria.l1BranchName) return false;
    if (criteria.l2AgencyCode && !includesText(c.levelCode, criteria.l2AgencyCode)) return false;
    if (criteria.l3ProducerCode && !includesText(c.levelCode, criteria.l3ProducerCode)) return false;
    if (criteria.contactType && !includesText(c.contactType, criteria.contactType)) return false;
    if (
      criteria.l2AgencyName.length > 0 &&
      !criteria.l2AgencyName.some((n) => includesText(c.agencyProducerName, n))
    )
      return false;
    if (criteria.l3ProducerName && !includesText(c.agencyProducerName, criteria.l3ProducerName))
      return false;
    if (criteria.firstName && !includesText(c.firstName, criteria.firstName)) return false;
    if (criteria.lastName && !includesText(c.lastName, criteria.lastName)) return false;
    if (criteria.imageRightId && !includesText(c.imageRightId, criteria.imageRightId)) return false;
    if (criteria.phone && !includesText(c.phone, criteria.phone) && !includesText(c.cellPhone, criteria.phone))
      return false;
    if (criteria.email && !includesText(c.email, criteria.email)) return false;
    return true;
  });
}
