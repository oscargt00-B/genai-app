import type { Address, AddressAdvancedSearchCriteria } from "../types/address";

const norm = (v: string) => v.trim().toLowerCase();

const includesText = (haystack: string, needle: string) => norm(haystack).includes(norm(needle));

/**
 * Quick search: match the unique Level Code (exact or partial, case-insensitive).
 * A blank query browses the full repository — handy for exercising pagination.
 */
export function searchAddressesByLevelCode(addresses: Address[], levelCode: string): Address[] {
  const q = norm(levelCode);
  if (!q) return addresses;
  return addresses.filter((a) => includesText(a.levelCode, q));
}

/**
 * Advanced search: AND-combine every non-empty criterion. L2 Agency Code
 * and L3 Producer Code both narrow the same Level Code field — Address
 * records don't carry a separate "AG Key", so (like Contacts' own advanced
 * search) both boxes are just different entry points into the one
 * identifier. With every field left blank, returns the full repository.
 */
export function searchAddressesAdvanced(
  addresses: Address[],
  criteria: AddressAdvancedSearchCriteria,
): Address[] {
  return addresses.filter((a) => {
    if (criteria.l1BranchName && a.branch !== criteria.l1BranchName) return false;
    if (criteria.l2AgencyCode && !includesText(a.levelCode, criteria.l2AgencyCode)) return false;
    if (criteria.l3ProducerCode && !includesText(a.levelCode, criteria.l3ProducerCode)) return false;
    if (criteria.addressType && a.addressType !== criteria.addressType) return false;
    if (
      criteria.agencyName.length > 0 &&
      !criteria.agencyName.some((n) => includesText(a.agencyProducerName, n))
    )
      return false;
    if (
      criteria.address &&
      !includesText(a.address1, criteria.address) &&
      !includesText(a.address2, criteria.address)
    )
      return false;
    if (criteria.state && a.state !== criteria.state) return false;
    if (criteria.zipCode && !includesText(a.zipCode, criteria.zipCode)) return false;
    return true;
  });
}
