import { authorities } from "../data/authorities";
import type { Authority } from "../types/authority";

/** Every contract held by one L2 Agency or L3 Producer — an owner can have one or many. */
export function getContractsForOwner(levelCode: string): Authority[] {
  return authorities.filter((a) => a.levelCode === levelCode);
}

/** A contract is uniquely identified by (owner, State, LOB, Underwriting Company) — never by a single id. */
export function findContract(
  levelCode: string,
  contractState: string,
  lob: string,
  underwritingCompany: string,
): Authority | undefined {
  return authorities.find(
    (a) =>
      a.levelCode === levelCode &&
      a.contractState === contractState &&
      a.lob === lob &&
      a.underwritingCompany === underwritingCompany,
  );
}

/** Builds the URL for one contract's detail page, nested under its owner's Agency/Producer route. */
export function contractPath(ownerBasePath: string, contract: Pick<Authority, "contractState" | "lob" | "underwritingCompany">): string {
  return [
    ownerBasePath,
    encodeURIComponent(contract.contractState),
    encodeURIComponent(contract.lob),
    encodeURIComponent(contract.underwritingCompany),
  ].join("/");
}
