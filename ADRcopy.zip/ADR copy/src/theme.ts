import { createTheme } from "@mui/material/styles";

/**
 * Primitive values from the PRAC-ADR Figma file's "PR New" variable mode
 * (resolved via get_variable_defs against several frames in that mode).
 * Anything not exposed as a first-class MUI palette key (the orange/blue
 * ramps, the paper tones, precise spacing/radius steps) lives here so
 * components can reference the same source of truth as theme.ts.
 */
export const prPrimitives = {
  color: {
    primaryMain: "#0078d6",
    primaryDark: "#004884",
    primaryLight: "#d3e5f9",
    primaryContrast: "#ffffff",
    secondaryMain: "#ff7826", // orange/500
    orange200: "#febfa2",
    orange400: "#f38d50",
    orange500: "#ff7826",
    orange700: "#db5809",
    orange800: "#80390d",
    blue600: "#126ea9",
    blue900: "#074064",
    /** "neutral/dark" — the L3 (Producer) detail side nav's background; L2 (Agency) uses primary/dark instead. */
    neutralDark: "#2e3845",
    paperPlain: "#ffffff",
    paperGrayLight: "#bec7d1",
    /** "paper/paper-3" — the light-gray card fill behind the advanced search form. */
    paper3: "#f8f8f8",
    /** "primary/paper 1" — a selected row's background in the bulk-edit grid. */
    primaryPaper1: "#f5faff",
    /** "warning/paper 1" — an unselected row's background when it has a pending bulk edit. */
    warningPaper1: "#fffef0",
    /** "warning/light" — a cell's background when its value was bulk-edited but not yet saved. */
    warningLight: "#fff3ba",
    /** "warning/main" — a stronger amber, paired with warning/light for hover/emphasis states. */
    warningMain: "#ffe565",
    textPrimary: "rgba(0,0,0,0.9)",
    textSecondary: "#00000099",
    textInverted: "#ffffff",
    textFocus: "#0000001f",
    actionActive: "#0000008f",
    inputOutlinedBorder: "#0000003b",
    whiteOutlinedBorder: "#ffffff80",
  },
  radius: {
    none: 0,
    m: 4,
    l: 8,
    xl: 12,
  },
  spacing: {
    medium: 8,
    large: 12,
    xlarge: 16,
    componentsMd: 24,
    componentsLg: 28,
  },
  elevation: {
    4: "0px 2px 4px -1px rgba(0,0,0,0.2), 0px 4px 5px 0px rgba(0,0,0,0.14), 0px 1px 10px 0px rgba(0,0,0,0.12)",
    6: "0px 3px 5px -1px rgba(0,0,0,0.2), 0px 6px 10px 0px rgba(0,0,0,0.14), 0px 1px 18px 0px rgba(0,0,0,0.12)",
  },
} as const;

const c = prPrimitives.color;

// MUI's default Material elevation scale already closely matches indices 4 and
// 6 here; pin them to the design's exact shadow values for those two levels.
const baseShadows = createTheme().shadows;
const shadows = [...baseShadows] as typeof baseShadows;
shadows[4] = prPrimitives.elevation[4];
shadows[6] = prPrimitives.elevation[6];

/**
 * Theme tokens pulled from the PRAC-ADR Figma file's "PR New" variable mode:
 * primary/main #0078d6, secondary/main #ff7826, Open Sans typography, and
 * the radius/spacing scale used across the TextField, Button, and Paper specs.
 */
export const theme = createTheme({
  palette: {
    primary: {
      main: c.primaryMain,
      dark: c.primaryDark,
      light: c.primaryLight,
      contrastText: c.primaryContrast,
    },
    secondary: {
      main: c.secondaryMain,
    },
    background: {
      default: c.paperPlain,
      paper: c.paperPlain,
    },
    text: {
      primary: c.textPrimary,
      secondary: c.textSecondary,
    },
    divider: "rgba(0,0,0,0.12)",
  },
  shape: {
    borderRadius: prPrimitives.radius.m,
  },
  typography: {
    fontFamily: '"Open Sans", "Helvetica", "Arial", sans-serif',
    subtitle1: {
      fontFamily: '"Open Sans", sans-serif',
      fontWeight: 700,
      fontSize: 18,
      letterSpacing: 0.15,
    },
    button: {
      textTransform: "none",
      fontWeight: 400,
      fontSize: 16,
      letterSpacing: 0.4,
    },
    body2: {
      fontSize: 16,
      letterSpacing: 0.17,
    },
  },
  shadows,
  components: {
    MuiButton: {
      styleOverrides: {
        root: { borderRadius: prPrimitives.radius.m },
        sizeLarge: { fontSize: 18, letterSpacing: 0.46, lineHeight: "26px" },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: { backgroundImage: "none" },
      },
    },
  },
});
