/** A license record's Active/In-Active state — labels match the "Status" column exactly as designed. */
export type LicenseStatus = "Active" | "In-Active";

/** Whether the license is held by an individual producer or a business entity. */
export type PersonFirmIndicator = "Person" | "Firm";

/** Whether the licensee resides in the licensing state. */
export type ResidenceIndicator = "Resident" | "Non-Resident";

/** Whether this record's last edit has synced to the policy system yet. */
export type SyncStatus = "Synced" | "Pending" | "Failed";

/**
 * A single insurance license record in the Agent Data Repository. Field
 * names map to the "Licenses Search R 2" DataGrid columns (both the
 * default-visible set and the additional columns available from the
 * DataGrid's Columns panel / "Column Menu - Licenses").
 */
export interface License {
  /** Unique, searchable identifier for the record — the "Level Code" quick search key. */
  levelCode: string;
  /** Short hierarchy level number shown in the grid's "Level" column, e.g. "002". */
  levelNumber: string;
  /** "Branch" column — the L1 branch this record rolls up to. */
  branch: string;
  legacyLevelCode: string;
  /** "Agency/Producer name" column. */
  agencyProducerName: string;
  licenseType: string;
  /** "Status" column. */
  licenseStatus: LicenseStatus;
  /** "SLN" column — State License Number. */
  stateLicenseNumber: string;
  /** "NPN" column — National Producer Number. */
  npn: string;
  syncStatus: SyncStatus;
  /** "License Name" column — the licensed individual or firm's name. */
  licenseName: string;
  /** "State" column — License State. */
  licenseState: string;
  licenseEffectiveDate: string; // ISO date string
  /** "Expiration" column — License Expiration Date. */
  licenseExpirationDate: string; // ISO date string
  personFirmIndicator: PersonFirmIndicator;
  underwritingCompany: string;
  residenceIndicator: ResidenceIndicator;
  lineOfAuthority: string;
  lastUpdate: string; // ISO date string
  lastUpdateBy: string;
}

/** Fields the Licenses advanced search form filters on. */
export interface LicenseAdvancedSearchCriteria {
  levelCode: string;
  licenseType: string;
  licenseStatus: string;
  licenseState: string;
  licenseName: string;
  npn: string;
  stateLicenseNumber: string;
}

export const emptyLicenseAdvancedSearch: LicenseAdvancedSearchCriteria = {
  levelCode: "",
  licenseType: "",
  licenseStatus: "",
  licenseState: "",
  licenseName: "",
  npn: "",
  stateLicenseNumber: "",
};
