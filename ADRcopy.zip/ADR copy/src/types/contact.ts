/**
 * A single contact record in the Agent Data Repository. Field names map to
 * the "Contacts Search R 1" DataGrid columns (both the default-visible set
 * and the additional columns available from the DataGrid's Columns panel /
 * "Contacts Menu 1").
 */
export interface Contact {
  /** "Contact ID" column — unique identifier for this record (an owner can have one or many contacts). */
  contactId: string;
  /** Short hierarchy level number shown in the grid's "Level" column, e.g. "002". */
  levelNumber: string;
  /** "Branch" column — the L1 branch this record rolls up to. */
  branch: string;
  legacyLevelCode: string;
  /** Unique, searchable identifier for the owning Agency/Producer — the "Level Code" quick search key. */
  levelCode: string;
  /** "Agency/Producer name" column. */
  agencyProducerName: string;
  uwCompanyName: string;
  /** "Contact Type" column — may hold several comma-separated roles, e.g. "CSR, HPM, Commissions". */
  contactType: string;
  prefix: string;
  firstName: string;
  middleName: string;
  lastName: string;
  suffix: string;
  phone: string;
  cellPhone: string;
  /** "Email" column. */
  email: string;
  imageRightId: string;
  lastUpdate: string; // ISO date string
  lastUpdateBy: string;
}

/** Fields the Contacts advanced search form filters on ("PRAC - Search Advanced" for Contacts). */
export interface ContactAdvancedSearchCriteria {
  l1BranchName: string;
  l2AgencyCode: string;
  l3ProducerCode: string;
  contactType: string;
  /** Autocomplete w/ chips in the design — one or more agency names selected from suggestions. */
  l2AgencyName: string[];
  l3ProducerName: string;
  firstName: string;
  lastName: string;
  imageRightId: string;
  phone: string;
  email: string;
}

export const emptyContactAdvancedSearch: ContactAdvancedSearchCriteria = {
  l1BranchName: "",
  l2AgencyCode: "",
  l3ProducerCode: "",
  contactType: "",
  l2AgencyName: [],
  l3ProducerName: "",
  firstName: "",
  lastName: "",
  imageRightId: "",
  phone: "",
  email: "",
};
