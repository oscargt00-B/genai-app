/**
 * A single address record in the Agent Data Repository. Field names map to
 * the "Address Search R 1" DataGrid columns (both the default-visible set
 * and the additional columns available from the DataGrid's Columns panel /
 * "Address Menu 1").
 */
export interface Address {
  /** "Address ID" column — unique identifier for this record (an owner can have one or many addresses). */
  addressId: string;
  /** Short hierarchy level number shown in the grid's "Level" column, e.g. "002". */
  levelNumber: string;
  /** Unique, searchable identifier for the owning Agency/Producer — the "Level Code" quick search key. */
  levelCode: string;
  /** "Branch" column — the L1 branch this record rolls up to. */
  branch: string;
  /** "Agency/Producer Name" column. */
  agencyProducerName: string;
  addressType: string;
  address1: string;
  address2: string;
  city: string;
  state: string;
  zipCode: string;
  county: string;
  phone: string;
  fax: string;
  lastUpdate: string; // ISO date string
  lastUpdateBy: string;
}

/** Fields the Addresses advanced search form filters on ("PRAC - Search Advanced" for Addresses). */
export interface AddressAdvancedSearchCriteria {
  l1BranchName: string;
  l2AgencyCode: string;
  l3ProducerCode: string;
  addressType: string;
  /** Autocomplete w/ chips in the design — one or more agency names selected from suggestions. */
  agencyName: string[];
  address: string;
  state: string;
  zipCode: string;
}

export const emptyAddressAdvancedSearch: AddressAdvancedSearchCriteria = {
  l1BranchName: "",
  l2AgencyCode: "",
  l3ProducerCode: "",
  addressType: "",
  agencyName: [],
  address: "",
  state: "",
  zipCode: "",
};
