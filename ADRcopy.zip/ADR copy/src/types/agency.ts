/** Heir status of an agency/producer hierarchy record. */
export type HeirStatus = "Active" | "Inactive" | "Pending" | "Terminated";

/** Heir relationship type. */
export type HeirType = "Individual" | "Entity";

/** Distribution channel the agency/producer writes business through. */
export type Channel =
  | "Captive"
  | "Independent"
  | "Broker/IMO"
  | "Direct"
  | "Bancassurance";

/**
 * A single agency/producer level record in the Agent Data Repository.
 * Field names map to the "Home Search R 1" DataGrid columns (both the
 * default-visible set and the additional columns available from the
 * DataGrid's Columns panel).
 */
export interface Agency {
  /** Unique, searchable identifier for the record — the "Level Code" quick search key. */
  levelCode: string;
  /** Short hierarchy level number shown in the grid's "Level" column, e.g. "002". */
  levelNumber: string;
  /** "AG Key" column. */
  agencyGroupKey: string;
  /** "Branch" column — the L1 branch this record rolls up to. */
  branch: string;
  legacyLevelCode: string;
  /** "Agency/Producer Name" column. */
  name: string;
  mainAddress1: string;
  mainAddress2: string;
  mainCity: string;
  mainState: string;
  zipCode: string;
  heirStatus: HeirStatus;
  heirId: string;
  heirType: HeirType;
  channel: Channel;
  mainPhoneNumber: string;
  npn: string;
  taxId: string;
  lastUpdate: string; // ISO date string
  lastUpdateBy: string;
}

/** Fields the "Home Search A" advanced search form filters on (PRAC - Search Advanced). */
export interface AdvancedSearchCriteria {
  l1BranchName: string;
  l2AgencyCode: string;
  l3ProducerCode: string;
  agencyGroupKey: string;
  /** Autocomplete w/ chips in the design — one or more agency names selected from suggestions. */
  l2AgencyName: string[];
  l3ProducerName: string;
  npn: string;
  taxId: string;
}

export const emptyAdvancedSearch: AdvancedSearchCriteria = {
  l1BranchName: "",
  l2AgencyCode: "",
  l3ProducerCode: "",
  agencyGroupKey: "",
  l2AgencyName: [],
  l3ProducerName: "",
  npn: "",
  taxId: "",
};
