/** A contract/authority record's Active/In-Active state — same convention as License. */
export type AuthorityStatus = "Active" | "In-Active";

/**
 * A single carrier authority/contract record in the Agent Data Repository —
 * which underwriting company, line of business, and contract terms an
 * agency/producer is appointed under. Field set matches the "Authority
 * Search R 1" results grid and the "Column Menu - Contracts" Figma frames
 * exactly (`node-id=14314-228070` / `14314-228869`): Level/Branch/Legacy
 * Level Code/Level Code/Agency-Producer Name, then every contract-specific
 * field, then Last Update/Last Update by.
 */
export interface Authority {
  /** Unique, searchable identifier for the record — the "Level Code" quick search key. */
  levelCode: string;
  /** "Level" column, e.g. "002". */
  levelNumber: string;
  branch: string;
  legacyLevelCode: string;
  /** "Agency/Producer Name" column. */
  agencyProducerName: string;
  /** "State" column — Contract State. */
  contractState: string;
  /** "LOB" column — Line of Business. */
  lob: string;
  underwritingCompany: string;
  contractType: string;
  /** "Status" column — Contract Status. */
  contractStatus: AuthorityStatus;
  contractEffectiveDate: string; // ISO date string
  contractNumber: string;
  /** "Appointment Date" column — Contract Appointment Date. */
  contractAppointmentDate: string; // ISO date string
  /** "NBI" — New Business Indicator. */
  newBusinessIndicator: string;
  expLetterTermDate: string; // ISO date string
  nbTerminationDate: string; // ISO date string
  renewalTermDate: string; // ISO date string
  commissionGroup: string;
  esalesEligible: string;
  superAgent: string;
  profitSharing: string;
  psrProfitSharingRollupCode: string;
  underwritingGroup: string;
  marketingGroup: string;
  serviceCenterIndicator: string;
  serviceCenterPercentFee: string;
  reportOrderGroup: string;
  removeCompRaterAccess: string;
  preventLowBiCsl: string;
  preventNoPrioIns: string;
  preventLapseOfCoverage: string;
  defaultVhsScoreValue: string;
  esalesOnly: string;
  salesChannel: string;
  lastUpdate: string; // ISO date string
  lastUpdateBy: string;

  // The fields below don't appear on the standalone "All Authority
  // (Contracts)" search page, but are needed by the per-agency Contract
  // Details section/page embedded in the L2 Agency and L3 Producer detail
  // pages (`node-id=14314-176865` / `14314-182655` for the section,
  // `14314-179329` / `14314-182968` for the contract detail page) — see
  // the "Authority (Contracts) section" README entry.
  /** Short display id shown in the L3 contracts table and the contract detail page's admin bar — distinct from `contractNumber`. */
  contractId: string;
  webDisplayName: string;
  aggregationGroup: string;
  rc1UseDefault: string;
  /** L3 (Producer) contracts only — not shown on L2 agency contracts. */
  groupName: string;
  /** L3 (Producer) contracts only — "2nd Rate Agent Group". */
  secondRateAgentGroup: string;
  // `removeCompRaterAccess`/`preventLowBiCsl`/`preventNoPrioIns`/`preventLapseOfCoverage`/
  // `defaultVhsScoreValue` above already cover 5 of L3's 7 "Comp Rater Details" fields —
  // only these two are new:
  preventUnder6MosContCoverage: string;
  defaultFrTierScore: string;
  /** L3-only "Agency Transfer Data" field group. */
  transferedNewAgent: string;
  transferedNewProducer: string;
  transferedAcqnTranDate: string; // ISO date string
  /** L3-only "Legacy" field group. */
  bookTransfer: string;
  btPremiumDollars: string;
  tip: string;
  charitable: string;
  payrollDeduct: string;
  /** Contract detail page admin bar only. */
  busEntityId: string;
  polstarConfig: string;
  authorityProConfig: string;
  lastPolSysPush: string; // ISO datetime string
}

/** Fields the Authority advanced search form filters on — matches "Authority Search R 1"'s form fields exactly. */
export interface AuthorityAdvancedSearchCriteria {
  l1BranchName: string;
  l2AgencyCode: string;
  l3ProducerCode: string;
  contractState: string;
  /** Autocomplete w/ chips in the design — same pattern as the Home page's own L2 Agency Name field. */
  l2AgencyName: string[];
  l3ProducerName: string;
  lob: string;
  underwritingCompany: string;
  contractType: string;
  contractStatus: string;
  contractNumber: string;
  appointmentDate: string;
  newBusinessIndicator: string;
  serviceCenterIndicator: string;
  underwritingGroup: string;
  marketingGroup: string;
}

export const emptyAuthorityAdvancedSearch: AuthorityAdvancedSearchCriteria = {
  l1BranchName: "",
  l2AgencyCode: "",
  l3ProducerCode: "",
  contractState: "",
  l2AgencyName: [],
  l3ProducerName: "",
  lob: "",
  underwritingCompany: "",
  contractType: "",
  contractStatus: "",
  contractNumber: "",
  appointmentDate: "",
  newBusinessIndicator: "",
  serviceCenterIndicator: "",
  underwritingGroup: "",
  marketingGroup: "",
};
