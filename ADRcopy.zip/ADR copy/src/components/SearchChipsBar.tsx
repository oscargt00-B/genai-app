import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Chip from "@mui/material/Chip";
import Typography from "@mui/material/Typography";
import { FaIcon } from "./FaIcon";

const MAX_VISIBLE_CHIPS = 3;

/** Generic over the criteria key type so both Agency and License search pages can reuse this bar. */
interface Entry<K extends string> {
  key: K;
  label: string;
  value: string;
}

interface Props<K extends string> {
  entries: Entry<K>[];
  onClearAll: () => void;
  onRemove: (key: K) => void;
  onShowSearch: () => void;
}

export function SearchChipsBar<K extends string>({ entries, onClearAll, onRemove, onShowSearch }: Props<K>) {
  const visible = entries.slice(0, MAX_VISIBLE_CHIPS);
  const overflowCount = entries.length - visible.length;

  return (
    <Box
      sx={{
        bgcolor: "#f0f0f0",
        borderRadius: "12px",
        px: 2,
        py: 1.5,
        display: "flex",
        alignItems: "center",
        flexWrap: "wrap",
        gap: 1,
      }}
    >
      <Chip label="Clear All" size="small" onClick={onClearAll} sx={{ bgcolor: "#e0e0e0" }} />

      {visible.map((entry) => (
        <Chip
          key={entry.key}
          label={entry.value}
          size="small"
          onDelete={() => onRemove(entry.key)}
          deleteIcon={<FaIcon icon="circle-xmark" sx={{ fontSize: "1rem !important" }} />}
          sx={{ bgcolor: "#e0e0e0", maxWidth: 220 }}
        />
      ))}

      {overflowCount > 0 && (
        <Typography
          variant="caption"
          onClick={onShowSearch}
          sx={{ color: "text.secondary", cursor: "pointer", whiteSpace: "nowrap" }}
        >
          +{overflowCount} Terms
        </Typography>
      )}

      <Box sx={{ flex: 1 }} />

      <Button
        variant="outlined"
        size="small"
        endIcon={<FaIcon icon="chevron-down" sx={{ fontSize: "0.875rem" }} />}
        onClick={onShowSearch}
        sx={{ whiteSpace: "nowrap", flexShrink: 0 }}
      >
        Show Search
      </Button>
    </Box>
  );
}
