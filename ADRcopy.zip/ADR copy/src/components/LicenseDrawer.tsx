import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Drawer from "@mui/material/Drawer";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import Tooltip from "@mui/material/Tooltip";
import Typography from "@mui/material/Typography";
import { FaIcon } from "./FaIcon";
import { formatDate } from "../lib/format";
import type { License } from "../types/license";

const dash = (v: string) => (v && v.trim() ? v : "-");
const dashDate = (v: string) => (v ? formatDate(v) : "-");

function ReadOnlyField({ label, value, endIcon }: { label: string; value: string; endIcon?: "calendar" | "chevron-down" }) {
  return (
    <TextField
      label={label}
      value={value}
      size="small"
      fullWidth
      slotProps={{
        input: {
          readOnly: true,
          endAdornment: endIcon ? <FaIcon icon={endIcon} sx={{ fontSize: "1rem", color: "action.active" }} /> : undefined,
        },
      }}
    />
  );
}

interface Props {
  license: License | null;
  open: boolean;
  onClose: () => void;
}

/**
 * The right-side "License Details" panel shown when a row's pencil action
 * is clicked, matching `node-id=14314-189548` (L2) / `14314-187937` (L3) —
 * the two Figma frames are the same drawer design (same fields, same
 * layout), differing only in the mock values filled into each field.
 *
 * Delete/Save aren't wired to any backend, mirroring ContractDetailContent's
 * own "not wired" precedent; the close icon, Cancel, and Save all just
 * close the drawer.
 */
export function LicenseDrawer({ license, open, onClose }: Props) {
  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={onClose}
      // TopBar sets its own zIndex to `zIndex.drawer + 1` (see TopBar.tsx) so it stays above the
      // permanent DetailSideNav; a plain Drawer defaults to `zIndex.drawer`, which is *below*
      // that, so without this override TopBar would paint over this drawer's own header.
      sx={{ zIndex: (t) => t.zIndex.drawer + 2 }}
      slotProps={{ paper: { sx: { width: 480, maxWidth: "100%" } } }}
    >
      {license && (
        <Box sx={{ display: "flex", flexDirection: "column", height: "100%" }}>
          <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", p: 2 }}>
            <Typography sx={{ fontSize: 18, fontWeight: 700, color: "text.primary" }}>License Details</Typography>
            <IconButton size="small" onClick={onClose}>
              <FaIcon icon="xmark" sx={{ fontSize: "1.1rem" }} />
            </IconButton>
          </Box>

          <Box sx={{ display: "flex", flexDirection: "column", gap: "16px", p: 2, flex: 1, overflowY: "auto" }}>
            <ReadOnlyField label="Person/Firm Indicator" value={dash(license.personFirmIndicator)} endIcon="chevron-down" />
            <ReadOnlyField label="License State" value={dash(license.licenseState)} endIcon="chevron-down" />
            <ReadOnlyField label="License Type" value={dash(license.licenseType)} endIcon="chevron-down" />
            <ReadOnlyField label="Underwriting Company Name" value={dash(license.underwritingCompany)} endIcon="chevron-down" />
            <ReadOnlyField label="License Status" value={dash(license.licenseStatus)} endIcon="chevron-down" />
            <ReadOnlyField label="State License Number" value={dash(license.stateLicenseNumber)} />
            <ReadOnlyField label="National Producer Number" value={dash(license.npn)} />
            <ReadOnlyField label="License Name" value={dash(license.licenseName)} />
            <ReadOnlyField label="Residence Indicator" value={dash(license.residenceIndicator)} endIcon="chevron-down" />
            <ReadOnlyField label="License Effective Date" value={dashDate(license.licenseEffectiveDate)} endIcon="calendar" />
            <ReadOnlyField label="License Expiration Date" value={dashDate(license.licenseExpirationDate)} endIcon="calendar" />
          </Box>

          <Box
            sx={{
              display: "flex",
              justifyContent: "flex-end",
              alignItems: "center",
              gap: "12px",
              p: 2,
              borderTop: "1px solid",
              borderColor: "divider",
            }}
          >
            <Tooltip title="Delete (not wired — no backend to delete against)">
              <span>
                <IconButton disabled sx={{ border: "1px solid", borderColor: "primary.main", borderRadius: `8px` }}>
                  <FaIcon icon="trash" sx={{ fontSize: "1rem" }} />
                </IconButton>
              </span>
            </Tooltip>
            <Button variant="outlined" onClick={onClose}>
              Cancel
            </Button>
            <Button variant="contained" onClick={onClose}>
              Save
            </Button>
          </Box>
        </Box>
      )}
    </Drawer>
  );
}
