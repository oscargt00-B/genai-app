import { useState, type FormEvent } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import InputAdornment from "@mui/material/InputAdornment";
import TextField from "@mui/material/TextField";
import Tooltip from "@mui/material/Tooltip";
import { FaIcon } from "./FaIcon";

interface Props {
  onSearch: (levelCode: string) => void;
  onOpenAdvanced: () => void;
}

export function QuickSearchBar({ onSearch, onOpenAdvanced }: Props) {
  const [levelCode, setLevelCode] = useState("");

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    onSearch(levelCode);
  };

  return (
    <Box
      component="form"
      onSubmit={handleSubmit}
      sx={{ display: "flex", width: "100%", maxWidth: 449 }}
    >
      <TextField
        value={levelCode}
        onChange={(e) => setLevelCode(e.target.value)}
        placeholder="Level Code Search"
        aria-label="Level Code Search"
        size="medium"
        sx={{
          flex: 1,
          minWidth: 0,
          "& .MuiOutlinedInput-root": {
            borderTopRightRadius: 0,
            borderBottomRightRadius: 0,
            bgcolor: "background.paper",
          },
        }}
        slotProps={{
          input: {
            endAdornment: (
              <InputAdornment position="end">
                <Tooltip title="Advanced search">
                  <IconButton onClick={onOpenAdvanced} edge="end" size="small">
                    <FaIcon icon="sliders" sx={{ fontSize: "1rem" }} />
                  </IconButton>
                </Tooltip>
              </InputAdornment>
            ),
          },
        }}
      />
      <Button
        type="submit"
        variant="contained"
        size="large"
        sx={{
          flexShrink: 0,
          width: { xs: 96, sm: 108 },
          minWidth: 0,
          px: { xs: 1.5, sm: 2 },
          borderTopLeftRadius: 0,
          borderBottomLeftRadius: 0,
          borderTopRightRadius: "8px",
          borderBottomRightRadius: "8px",
        }}
      >
        Search
      </Button>
    </Box>
  );
}
