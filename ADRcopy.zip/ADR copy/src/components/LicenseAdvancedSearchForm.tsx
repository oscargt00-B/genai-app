import type { FormEvent } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import MenuItem from "@mui/material/MenuItem";
import TextField from "@mui/material/TextField";
import { FaIcon } from "./FaIcon";
import type { LicenseAdvancedSearchCriteria } from "../types/license";
import { LICENSE_STATUSES, LICENSE_TYPES } from "../data/licenseOptions";
import { US_STATES } from "../data/options";
import { prPrimitives } from "../theme";

const FIELD_WIDTH = { xs: "100%", sm: 260 };

interface Props {
  criteria: LicenseAdvancedSearchCriteria;
  onChange: (next: LicenseAdvancedSearchCriteria) => void;
  onSubmit: () => void;
  onReset: () => void;
  onHide: () => void;
  /** Show the Reset button — only present once a search has produced results. */
  showReset: boolean;
}

export function LicenseAdvancedSearchForm({ criteria, onChange, onSubmit, onReset, onHide, showReset }: Props) {
  const set = <K extends keyof LicenseAdvancedSearchCriteria>(key: K, value: LicenseAdvancedSearchCriteria[K]) =>
    onChange({ ...criteria, [key]: value });

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    onSubmit();
  };

  return (
    <Box
      component="form"
      onSubmit={handleSubmit}
      sx={{
        bgcolor: prPrimitives.color.paper3,
        borderRadius: `${prPrimitives.radius.xl}px`,
        px: `${prPrimitives.spacing.large}px`,
        py: 2,
      }}
    >
      <Box sx={{ display: "flex", flexWrap: "wrap", gap: "12px 16px" }}>
        <TextField
          label="Level Code"
          placeholder="Level Code"
          value={criteria.levelCode}
          onChange={(e) => set("levelCode", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <TextField
          select
          label="License Type"
          value={criteria.licenseType}
          onChange={(e) => set("licenseType", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        >
          <MenuItem value="">
            <em>Any type</em>
          </MenuItem>
          {LICENSE_TYPES.map((t) => (
            <MenuItem key={t} value={t}>
              {t}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          select
          label="Status"
          value={criteria.licenseStatus}
          onChange={(e) => set("licenseStatus", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        >
          <MenuItem value="">
            <em>Any status</em>
          </MenuItem>
          {LICENSE_STATUSES.map((s) => (
            <MenuItem key={s} value={s}>
              {s}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          select
          label="State"
          value={criteria.licenseState}
          onChange={(e) => set("licenseState", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        >
          <MenuItem value="">
            <em>Any state</em>
          </MenuItem>
          {US_STATES.map((s) => (
            <MenuItem key={s} value={s}>
              {s}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          label="License Name"
          placeholder="License Name"
          value={criteria.licenseName}
          onChange={(e) => set("licenseName", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <TextField
          label="NPN"
          placeholder="NPN"
          value={criteria.npn}
          onChange={(e) => set("npn", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <TextField
          label="SLN"
          placeholder="State License Number"
          value={criteria.stateLicenseNumber}
          onChange={(e) => set("stateLicenseNumber", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />
      </Box>

      <Box sx={{ display: "flex", alignItems: "center", gap: 3, mt: 2 }}>
        <Button type="submit" variant="contained" sx={{ width: 162 }}>
          Search
        </Button>
        {showReset && (
          <Button variant="outlined" onClick={onReset}>
            Reset
          </Button>
        )}
        <Box sx={{ flex: 1 }} />
        <Button
          variant="outlined"
          endIcon={<FaIcon icon="chevron-up" variant="regular" sx={{ fontSize: "0.875rem" }} />}
          onClick={onHide}
        >
          Hide
        </Button>
      </Box>
    </Box>
  );
}
