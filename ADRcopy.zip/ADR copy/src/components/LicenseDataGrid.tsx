import { forwardRef, useEffect, useImperativeHandle, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import MenuItem from "@mui/material/MenuItem";
import TextField from "@mui/material/TextField";
import Tooltip from "@mui/material/Tooltip";
import {
  DataGrid,
  GridToolbarContainer,
  GridToolbarColumnsButton,
  GridToolbarExport,
  GridToolbarFilterButton,
  type GridColDef,
  type GridComparatorFn,
  type GridRowSelectionModel,
  type GridSortDirection,
} from "@mui/x-data-grid";
import { FaIcon } from "./FaIcon";
import type { License } from "../types/license";
import { formatDate } from "../lib/format";
import { US_STATES } from "../data/options";
import {
  LICENSE_STATUSES,
  LICENSE_TYPES,
  LINES_OF_AUTHORITY,
  PERSON_FIRM_INDICATORS,
  RESIDENCE_INDICATORS,
  SYNC_STATUSES,
  UNDERWRITING_COMPANIES,
} from "../data/licenseOptions";
import { licensePath } from "../lib/licenses";
import { prPrimitives } from "../theme";

/** Sentinel row id for the synthetic "bulk edit" input row pinned above the data. */
const EDIT_ROW_ID = "__license_bulk_edit_row__";

/** "Level" 2 rows route to their L2 Agency's Licenses section, "Level" 3 to their L3 Producer's — opened with that license's drawer already showing. */
function licenseDetailPath(row: License): string | null {
  if (row.levelNumber === "002") return licensePath(`/agency/${row.levelCode}/licenses`, row);
  if (row.levelNumber === "003") return licensePath(`/producer/${row.levelCode}/licenses`, row);
  return null;
}

/**
 * `levelCode` alone is NOT a unique row identity here — an owner can hold
 * one or many licenses (same levelCode, different State/Type/Underwriting
 * Company), so every place that identifies a row for selection, Bulk Edit
 * overrides, or the DataGrid's own `getRowId` needs this full composite key
 * instead, the same convention AuthorityDataGrid.tsx uses for its own rows.
 */
function rowKey(row: License): string {
  return `${row.levelCode}|${row.licenseState}|${row.licenseType}|${row.underwritingCompany}`;
}

type FieldEditor = { kind: "text" } | { kind: "select"; options: string[]; placeholder: string };

/** Which columns get an input in the bulk-edit row, and what kind. Omitted fields (Actions, Last Update, Last Update by) aren't bulk-editable. */
const FIELD_EDITORS: Partial<Record<keyof License, FieldEditor>> = {
  levelNumber: { kind: "text" },
  branch: { kind: "text" },
  legacyLevelCode: { kind: "text" },
  levelCode: { kind: "text" },
  agencyProducerName: { kind: "text" },
  licenseType: { kind: "select", options: LICENSE_TYPES, placeholder: "Type" },
  licenseStatus: { kind: "select", options: LICENSE_STATUSES, placeholder: "Status" },
  stateLicenseNumber: { kind: "text" },
  npn: { kind: "text" },
  syncStatus: { kind: "select", options: SYNC_STATUSES, placeholder: "Sync" },
  licenseName: { kind: "text" },
  licenseState: { kind: "select", options: US_STATES, placeholder: "State" },
  licenseEffectiveDate: { kind: "text" },
  licenseExpirationDate: { kind: "text" },
  personFirmIndicator: { kind: "select", options: PERSON_FIRM_INDICATORS, placeholder: "Select" },
  underwritingCompany: { kind: "select", options: UNDERWRITING_COMPANIES, placeholder: "Select" },
  residenceIndicator: { kind: "select", options: RESIDENCE_INDICATORS, placeholder: "Select" },
  lineOfAuthority: { kind: "select", options: LINES_OF_AUTHORITY, placeholder: "Select" },
};

function blankEditRow(): License {
  return {
    levelCode: EDIT_ROW_ID,
    levelNumber: "",
    branch: "",
    legacyLevelCode: "",
    agencyProducerName: "",
    licenseType: "",
    licenseStatus: "" as License["licenseStatus"],
    stateLicenseNumber: "",
    npn: "",
    syncStatus: "" as License["syncStatus"],
    licenseName: "",
    licenseState: "",
    licenseEffectiveDate: "",
    licenseExpirationDate: "",
    personFirmIndicator: "" as License["personFirmIndicator"],
    underwritingCompany: "",
    residenceIndicator: "" as License["residenceIndicator"],
    lineOfAuthority: "",
    lastUpdate: "",
    lastUpdateBy: "",
  };
}

/** One input in the bulk-edit row, with the green "apply to selected rows" button once a value is set. */
function EditRowCell({
  field,
  value,
  onChange,
  onApply,
  showApply,
}: {
  field: keyof License;
  value: string;
  onChange: (v: string) => void;
  onApply: () => void;
  showApply: boolean;
}) {
  const editor = FIELD_EDITORS[field];
  if (!editor) return null;

  return (
    <Box
      sx={{ display: "flex", alignItems: "center", gap: "6px", width: "100%" }}
      onClick={(e) => e.stopPropagation()}
      // The DataGrid binds Space (row selection toggle) and other navigation keys at the
      // cell/row level, which otherwise swallows them before they reach the input.
      onKeyDown={(e) => e.stopPropagation()}
    >
      {editor.kind === "text" ? (
        <TextField
          size="small"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          sx={{ flex: 1, minWidth: 0, bgcolor: "background.paper" }}
        />
      ) : (
        <TextField
          select
          size="small"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          sx={{ flex: 1, minWidth: 90, bgcolor: "background.paper" }}
          slotProps={{ select: { displayEmpty: true } }}
        >
          <MenuItem value="">
            <em>{editor.placeholder}</em>
          </MenuItem>
          {editor.options.map((opt) => (
            <MenuItem key={opt} value={opt}>
              {opt}
            </MenuItem>
          ))}
        </TextField>
      )}
      {showApply && value !== "" && (
        <Tooltip title="Apply this value to the selected rows">
          <IconButton
            size="small"
            onClick={onApply}
            sx={{
              flexShrink: 0,
              bgcolor: "#43a047",
              color: "#fff",
              "&:hover": { bgcolor: "#388e3c" },
            }}
          >
            <FaIcon icon="arrows-rotate" sx={{ fontSize: "0.8rem" }} />
          </IconButton>
        </Tooltip>
      )}
    </Box>
  );
}

interface BuildColumnsParams {
  bulkEditMode: boolean;
  editValues: Partial<Record<keyof License, string>>;
  setEditValue: (field: keyof License, value: string) => void;
  applyColumnValue: (field: keyof License) => void;
  hasSelection: boolean;
  isPendingField: (row: License, field: keyof License) => boolean;
  onOpenLicense: (row: License) => void;
}

/**
 * Sorting stays fully functional while the pinned bulk-edit input row is present —
 * this comparator just special-cases the synthetic edit row so it always floats to
 * the top regardless of which column or direction is sorted.
 *
 * Plain `sortComparator` isn't enough: for a descending sort, the DataGrid doesn't
 * re-run the comparator with swapped args — it just negates whatever it returns,
 * which would flip an "always first" pin to "always last". `getSortComparator`
 * (which receives the direction directly) lets us pin the edit row correctly both ways.
 */
function editRowFirstGetSortComparator(direction: GridSortDirection): GridComparatorFn {
  return (v1, v2, p1, p2) => {
    if (p1.id === EDIT_ROW_ID) return -1;
    if (p2.id === EDIT_ROW_ID) return 1;
    if (v1 === v2) return 0;
    const cmp = String(v1).localeCompare(String(v2), undefined, { numeric: true, sensitivity: "base" });
    return direction === "desc" ? -cmp : cmp;
  };
}

function buildColumns({
  bulkEditMode,
  editValues,
  setEditValue,
  applyColumnValue,
  hasSelection,
  isPendingField,
  onOpenLicense,
}: BuildColumnsParams): GridColDef<License>[] {
  const isEditRow = (row: License) => row.levelCode === EDIT_ROW_ID;

  const editableColDef = (
    field: keyof License,
  ): Pick<GridColDef<License>, "renderCell" | "getSortComparator" | "cellClassName"> => ({
    getSortComparator: editRowFirstGetSortComparator,
    cellClassName: ({ row }) => (isPendingField(row, field) ? "cell--pendingEdit" : ""),
    renderCell: ({ row, value }) => {
      if (!isEditRow(row)) return value as string;
      return (
        <EditRowCell
          field={field}
          value={editValues[field] ?? ""}
          onChange={(v) => setEditValue(field, v)}
          onApply={() => applyColumnValue(field)}
          showApply={hasSelection}
        />
      );
    },
  });

  // A plain `valueFormatter` never runs here: `renderCell` (set below, needed so the
  // bulk-edit input row can still render for these fields) always wins over it, so
  // the date has to be formatted directly inside `renderCell` instead.
  const dateColDef = (
    field: keyof License,
  ): Pick<GridColDef<License>, "renderCell" | "getSortComparator" | "cellClassName"> => ({
    getSortComparator: editRowFirstGetSortComparator,
    cellClassName: ({ row }) => (isPendingField(row, field) ? "cell--pendingEdit" : ""),
    renderCell: ({ row, value }) => {
      if (!isEditRow(row)) return value ? formatDate(value as string) : "";
      return (
        <EditRowCell
          field={field}
          value={editValues[field] ?? ""}
          onChange={(v) => setEditValue(field, v)}
          onApply={() => applyColumnValue(field)}
          showApply={hasSelection}
        />
      );
    },
  });

  return [
    { field: "levelNumber", headerName: "Level", width: 57, ...editableColDef("levelNumber") },
    { field: "levelCode", headerName: "Level Code", width: 100, ...editableColDef("levelCode") },
    { field: "agencyProducerName", headerName: "Agency/Producer name", width: 244, ...editableColDef("agencyProducerName") },
    { field: "licenseType", headerName: "License Type", width: 100, ...editableColDef("licenseType") },
    { field: "licenseStatus", headerName: "Status", width: 84, ...editableColDef("licenseStatus") },
    { field: "stateLicenseNumber", headerName: "SLN", width: 90, ...editableColDef("stateLicenseNumber") },
    { field: "npn", headerName: "NPN", width: 92, ...editableColDef("npn") },
    { field: "licenseName", headerName: "License Name", width: 139, ...editableColDef("licenseName") },
    { field: "licenseState", headerName: "State", width: 68, ...editableColDef("licenseState") },
    { field: "licenseExpirationDate", headerName: "Expiration", width: 101, ...dateColDef("licenseExpirationDate") },
    { field: "branch", headerName: "Branch", width: 200, ...editableColDef("branch") },
    { field: "legacyLevelCode", headerName: "Legacy Level Code", width: 150, ...editableColDef("legacyLevelCode") },
    { field: "syncStatus", headerName: "Sync Status", width: 120, ...editableColDef("syncStatus") },
    { field: "licenseEffectiveDate", headerName: "License Effective Date", width: 160, ...dateColDef("licenseEffectiveDate") },
    { field: "personFirmIndicator", headerName: "Person/Firm Indicator", width: 160, ...editableColDef("personFirmIndicator") },
    { field: "underwritingCompany", headerName: "Underwriting Company", width: 220, ...editableColDef("underwritingCompany") },
    { field: "residenceIndicator", headerName: "Residence Indicator", width: 150, ...editableColDef("residenceIndicator") },
    { field: "lineOfAuthority", headerName: "Line of Authority", width: 170, ...editableColDef("lineOfAuthority") },
    {
      field: "lastUpdate",
      headerName: "Last Update",
      width: 130,
      getSortComparator: editRowFirstGetSortComparator,
      valueFormatter: (value: string) => (value ? formatDate(value) : ""),
    },
    { field: "lastUpdateBy", headerName: "Last Update by", width: 140, getSortComparator: editRowFirstGetSortComparator },
    {
      field: "actions",
      headerName: "Actions",
      width: 69,
      sortable: false,
      filterable: false,
      disableColumnMenu: true,
      align: "center",
      headerAlign: "center",
      renderCell: ({ row }) => {
        if (isEditRow(row) || bulkEditMode) return null;
        const hasDetail = licenseDetailPath(row) !== null;
        return (
          <Tooltip title={hasDetail ? "View license" : "No detail page for this level"}>
            <span>
              <IconButton size="small" disabled={!hasDetail} onClick={() => onOpenLicense(row)}>
                <FaIcon icon="arrow-right" sx={{ fontSize: "1rem" }} />
              </IconButton>
            </span>
          </Tooltip>
        );
      },
    },
  ];
}

/** Default-visible columns match the "Licenses Search R 2" mockup; the rest are one click away via Columns. */
const DEFAULT_HIDDEN_FIELDS = [
  "branch",
  "legacyLevelCode",
  "syncStatus",
  "licenseEffectiveDate",
  "personFirmIndicator",
  "underwritingCompany",
  "residenceIndicator",
  "lineOfAuthority",
  "lastUpdate",
  "lastUpdateBy",
];

interface ToolbarProps {
  bulkEditMode: boolean;
  canSave: boolean;
  canDuplicate: boolean;
  onToggleBulkEdit: () => void;
  onCancel: () => void;
  onDuplicate: () => void;
  onSave: () => void;
}

/** Shared text style for every toolbar button, matching the AgencyDataGrid toolbar exactly. */
const TOOLBAR_BUTTON_SX = {
  fontSize: 14,
  fontWeight: 700,
  letterSpacing: "0.46px",
  textTransform: "none",
} as const;

/** The DataGrid's native toolbar buttons (Filters/Columns/Export) type `slotProps.button` without `sx` — only `style`. */
const TOOLBAR_BUTTON_STYLE: React.CSSProperties = { ...TOOLBAR_BUTTON_SX };

function Toolbar({ bulkEditMode, canSave, canDuplicate, onToggleBulkEdit, onCancel, onDuplicate, onSave }: ToolbarProps) {
  return (
    <GridToolbarContainer sx={{ p: "4px 4px 0", justifyContent: "space-between" }}>
      <Box sx={{ display: "flex", gap: 1, alignItems: "center" }}>
        <Button
          size="small"
          onClick={onToggleBulkEdit}
          disableRipple
          startIcon={<FaIcon icon={bulkEditMode ? "xmark" : "pen"} sx={{ fontSize: "0.9rem" }} />}
          sx={
            bulkEditMode
              ? {
                  ...TOOLBAR_BUTTON_SX,
                  color: "primary.contrastText",
                  bgcolor: "primary.main",
                  px: "8px",
                  "&:hover": { bgcolor: "primary.dark" },
                }
              : { ...TOOLBAR_BUTTON_SX, color: "primary.main" }
          }
        >
          Bulk Edit
        </Button>

        {bulkEditMode && (
          <>
            <Button
              size="small"
              onClick={onCancel}
              disableRipple
              startIcon={<FaIcon icon="xmark" sx={{ fontSize: "0.9rem" }} />}
              sx={{ ...TOOLBAR_BUTTON_SX, color: "primary.main" }}
            >
              Cancel
            </Button>
            <Button
              size="small"
              onClick={onDuplicate}
              disabled={!canDuplicate}
              disableRipple
              startIcon={<FaIcon icon="copy" variant="regular" sx={{ fontSize: "0.9rem" }} />}
              sx={{ ...TOOLBAR_BUTTON_SX, color: canDuplicate ? "text.secondary" : "text.disabled" }}
            >
              Duplicate
            </Button>
            <Button
              size="small"
              onClick={onSave}
              disabled={!canSave}
              disableRipple
              startIcon={<FaIcon icon="cloud-arrow-up" sx={{ fontSize: "0.9rem" }} />}
              sx={{ ...TOOLBAR_BUTTON_SX, color: canSave ? "text.secondary" : "text.disabled" }}
            >
              Save
            </Button>
          </>
        )}

        {!bulkEditMode && (
          <GridToolbarFilterButton
            slotProps={{
              button: { startIcon: <FaIcon icon="filter" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
            }}
          />
        )}
      </Box>
      <Box sx={{ display: "flex", gap: 1 }}>
        <GridToolbarColumnsButton
          slotProps={{
            button: { startIcon: <FaIcon icon="table-columns" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
          }}
        />
        <GridToolbarExport
          slotProps={{
            button: { startIcon: <FaIcon icon="download" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
          }}
        />
      </Box>
    </GridToolbarContainer>
  );
}

interface Props {
  rows: License[];
  /** Fires whenever "in Bulk Edit mode with at least one unsaved change" flips, so a parent can guard navigation/new searches. */
  onDirtyChange?: (dirty: boolean) => void;
}

/** Lets a parent (the search page) check for and resolve unsaved Bulk Edit changes before navigating away or re-searching. */
export interface LicenseDataGridHandle {
  hasUnsavedChanges: () => boolean;
  saveChanges: () => void;
  discardChanges: () => void;
}

let duplicateCounter = 0;

interface PersistedBulkEditState {
  bulkEditMode: boolean;
  overrides: Record<string, Partial<License>>;
  duplicatedRows: License[];
  dirty: boolean;
  sessionSnapshot: { overrides: Record<string, Partial<License>>; duplicatedRows: License[] };
}

/**
 * A blocked in-app navigation (react-router's `useBlocker`, used by the search page to
 * confirm before leaving with unsaved changes) can briefly unmount and remount this
 * component while the confirmation is pending — which would otherwise wipe the very
 * changes the confirmation dialog is asking about. Mirroring the bulk-edit state into
 * this module-level singleton (outside React's tree, so it survives that remount) and
 * lazily re-hydrating from it on mount closes that gap. Mirrors AgencyDataGrid's own
 * `persistedBulkEditState`.
 */
let persistedBulkEditState: PersistedBulkEditState | null = null;

export const LicenseDataGrid = forwardRef<LicenseDataGridHandle, Props>(function LicenseDataGrid(
  { rows, onDirtyChange },
  ref,
) {
  const navigate = useNavigate();
  const [bulkEditMode, setBulkEditMode] = useState(() => persistedBulkEditState?.bulkEditMode ?? false);
  const [selectionModel, setSelectionModel] = useState<GridRowSelectionModel>({ type: "include", ids: new Set() });
  const [editValues, setEditValues] = useState<Partial<Record<keyof License, string>>>({});
  const [overrides, setOverrides] = useState<Record<string, Partial<License>>>(
    () => persistedBulkEditState?.overrides ?? {},
  );
  const [duplicatedRows, setDuplicatedRows] = useState<License[]>(() => persistedBulkEditState?.duplicatedRows ?? []);
  const [dirty, setDirty] = useState(() => persistedBulkEditState?.dirty ?? false);
  const [paginationModel, setPaginationModel] = useState({ pageSize: 10, page: 0 });

  const sessionSnapshot = useRef<{ overrides: Record<string, Partial<License>>; duplicatedRows: License[] }>(
    persistedBulkEditState?.sessionSnapshot ?? { overrides: {}, duplicatedRows: [] },
  );

  useEffect(() => {
    persistedBulkEditState = { bulkEditMode, overrides, duplicatedRows, dirty, sessionSnapshot: sessionSnapshot.current };
  });

  const selectedIds = useMemo(() => [...selectionModel.ids].map(String), [selectionModel]);

  /** A field is "pending" (edited but not saved) when its override differs from what was there when this bulk-edit session began. */
  const isPendingField = (row: License, field: keyof License): boolean => {
    if (!bulkEditMode || row.levelCode === EDIT_ROW_ID) return false;
    const current = overrides[rowKey(row)]?.[field];
    if (current === undefined) return false;
    return current !== sessionSnapshot.current.overrides[rowKey(row)]?.[field];
  };

  const rowHasPendingEdit = (row: License): boolean => {
    if (!bulkEditMode || row.levelCode === EDIT_ROW_ID) return false;
    // A row Duplicated this session is itself an unsaved change, even with no field overrides of its own.
    const isNewDuplicate =
      !sessionSnapshot.current.duplicatedRows.some((d) => rowKey(d) === rowKey(row)) &&
      duplicatedRows.some((d) => rowKey(d) === rowKey(row));
    if (isNewDuplicate) return true;
    const rowOverride = overrides[rowKey(row)];
    if (!rowOverride) return false;
    const snapshotOverride = sessionSnapshot.current.overrides[rowKey(row)] ?? {};
    return (Object.keys(rowOverride) as (keyof License)[]).some(
      (key) => rowOverride[key] !== snapshotOverride[key],
    );
  };

  const setEditValue = (field: keyof License, value: string) => {
    setEditValues((prev) => ({ ...prev, [field]: value }));
  };

  const applyColumnValue = (field: keyof License) => {
    const value = editValues[field];
    if (value === undefined || value === "" || selectedIds.length === 0) return;
    setOverrides((prev) => {
      const next = { ...prev };
      for (const id of selectedIds) {
        next[id] = { ...next[id], [field]: value };
      }
      return next;
    });
    setDirty(true);
  };

  const handleToggleBulkEdit = () => {
    if (bulkEditMode) {
      // Same as Cancel — the toggle reverts this session's pending changes.
      handleCancel();
      return;
    }
    sessionSnapshot.current = { overrides, duplicatedRows };
    setBulkEditMode(true);
    setSelectionModel({ type: "include", ids: new Set() });
    setEditValues({});
    setDirty(false);
    setPaginationModel((p) => ({ ...p, page: 0 }));
  };

  const handleCancel = () => {
    setOverrides(sessionSnapshot.current.overrides);
    setDuplicatedRows(sessionSnapshot.current.duplicatedRows);
    setBulkEditMode(false);
    setSelectionModel({ type: "include", ids: new Set() });
    setEditValues({});
    setDirty(false);
  };

  const handleSave = () => {
    setBulkEditMode(false);
    setSelectionModel({ type: "include", ids: new Set() });
    setEditValues({});
    setDirty(false);
  };

  const hasUnsavedChanges = bulkEditMode && dirty;

  useEffect(() => {
    onDirtyChange?.(hasUnsavedChanges);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasUnsavedChanges]);

  useImperativeHandle(
    ref,
    () => ({
      hasUnsavedChanges: () => hasUnsavedChanges,
      saveChanges: handleSave,
      discardChanges: handleCancel,
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [hasUnsavedChanges],
  );

  const handleDuplicate = () => {
    if (selectedIds.length === 0) return;
    const source = [...rows, ...duplicatedRows];
    const copies = selectedIds
      .map((id) => source.find((r) => rowKey(r) === id))
      .filter((r): r is License => !!r)
      // Changing levelCode alone is enough to keep the copy's rowKey unique too, since
      // levelCode is rowKey's first segment.
      .map((r) => ({ ...r, ...overrides[rowKey(r)], levelCode: `${r.levelCode}-COPY${++duplicateCounter}` }));
    setDuplicatedRows((prev) => [...prev, ...copies]);
    setSelectionModel({ type: "include", ids: new Set() });
    setDirty(true);
  };

  const columns = useMemo(
    () =>
      buildColumns({
        bulkEditMode,
        editValues,
        setEditValue,
        applyColumnValue,
        hasSelection: selectedIds.length > 0,
        isPendingField,
        onOpenLicense: (row) => {
          const path = licenseDetailPath(row);
          if (path) navigate(path);
        },
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [bulkEditMode, editValues, selectedIds, overrides, navigate],
  );

  const displayRows = useMemo(() => {
    const withOverrides = rows.map((r) => (overrides[rowKey(r)] ? { ...r, ...overrides[rowKey(r)] } : r));
    const all = [...withOverrides, ...duplicatedRows];
    return bulkEditMode ? [blankEditRow(), ...all] : all;
  }, [rows, overrides, duplicatedRows, bulkEditMode]);

  // Bound via closure instead of DataGrid's slotProps (which types the toolbar slot
  // strictly and would need module augmentation for these custom props).
  const ToolbarWithState = () => (
    <Toolbar
      bulkEditMode={bulkEditMode}
      canSave={dirty}
      canDuplicate={selectedIds.length > 0}
      onToggleBulkEdit={handleToggleBulkEdit}
      onCancel={handleCancel}
      onDuplicate={handleDuplicate}
      onSave={handleSave}
    />
  );

  return (
    <Box sx={{ width: "100%" }}>
      <DataGrid
        rows={displayRows}
        columns={columns}
        getRowId={rowKey}
        getRowClassName={(params) => {
          if (params.id === EDIT_ROW_ID) return "MuiDataGrid-row--editInput";
          return rowHasPendingEdit(params.row) ? "row--pendingEdit" : "";
        }}
        rowHeight={52}
        columnHeaderHeight={56}
        showToolbar
        slots={{ toolbar: ToolbarWithState }}
        sx={{
          "& .MuiDataGrid-columnHeaders": { fontSize: 14 },
          "& .MuiDataGrid-cell": { fontSize: 16 },
          "& .MuiDataGrid-row--editInput": { bgcolor: "grey.50" },
          // "warning/light" — a cell edited (via the green apply button) but not yet Saved.
          "& .MuiDataGrid-cell.cell--pendingEdit": { bgcolor: prPrimitives.color.warningLight },
          // "warning/paper 1" — an unselected row that has at least one pending edit.
          "& .MuiDataGrid-row.row--pendingEdit, & .MuiDataGrid-row.row--pendingEdit:hover": {
            bgcolor: prPrimitives.color.warningPaper1,
          },
          // "primary/paper 1" — a selected row, overriding DataGrid's own baked-in .Mui-selected background.
          "& .MuiDataGrid-row.Mui-selected, & .MuiDataGrid-row.Mui-selected:hover": {
            backgroundColor: `${prPrimitives.color.primaryPaper1} !important`,
          },
        }}
        checkboxSelection={bulkEditMode}
        isRowSelectable={(params) => params.id !== EDIT_ROW_ID}
        rowSelectionModel={selectionModel}
        onRowSelectionModelChange={setSelectionModel}
        disableRowSelectionOnClick
        paginationModel={paginationModel}
        onPaginationModelChange={setPaginationModel}
        initialState={{
          columns: {
            columnVisibilityModel: Object.fromEntries(DEFAULT_HIDDEN_FIELDS.map((f) => [f, false])),
          },
        }}
        pageSizeOptions={[5, 10, 25, 50]}
        autoHeight
      />
    </Box>
  );
});
