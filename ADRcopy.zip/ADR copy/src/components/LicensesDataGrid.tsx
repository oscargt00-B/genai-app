import { useMemo } from "react";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import {
  DataGrid,
  GridToolbarContainer,
  GridToolbarColumnsButton,
  GridToolbarExport,
  GridToolbarFilterButton,
  type GridColDef,
} from "@mui/x-data-grid";
import { FaIcon } from "./FaIcon";
import type { License } from "../types/license";
import { formatDate } from "../lib/format";
import { licenseRowKey } from "../lib/licenses";

/** Shared text style for every toolbar button, matching every other grid in the app. */
const TOOLBAR_BUTTON_SX = {
  fontSize: 14,
  fontWeight: 700,
  letterSpacing: "0.46px",
  textTransform: "none",
} as const;
const TOOLBAR_BUTTON_STYLE: React.CSSProperties = { ...TOOLBAR_BUTTON_SX };

function Toolbar() {
  return (
    <GridToolbarContainer sx={{ p: "4px 4px 0", justifyContent: "flex-end" }}>
      <Box sx={{ display: "flex", gap: 1 }}>
        <GridToolbarFilterButton
          slotProps={{
            button: { startIcon: <FaIcon icon="filter" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
          }}
        />
        <GridToolbarColumnsButton
          slotProps={{
            button: { startIcon: <FaIcon icon="table-columns" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
          }}
        />
        <GridToolbarExport
          slotProps={{
            button: { startIcon: <FaIcon icon="download" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
          }}
        />
      </Box>
    </GridToolbarContainer>
  );
}

interface Props {
  licenses: License[];
  /** Opens the License Details drawer for the clicked row — matches `node-id=14314-176571`/`14314-181766`'s pencil action (edits aren't wired to any backend, so this just displays the record). */
  onEditLicense: (license: License) => void;
}

/**
 * The "Licenses" section's embedded results table, matching
 * `node-id=14314-176571` (L2) / `14314-181766` (L3) — the two are
 * structurally identical (same columns, same row data in the mock), unlike
 * Authority (Contracts) where L3 adds an extra ID column. An agency or
 * producer can hold one or many licenses, each identified by (License
 * State, License Type, Underwriting Company).
 *
 * Like ContractsDataGrid, this embedded table doesn't offer Bulk Edit even
 * though the Figma toolbar shows a "Bulk Edit" button — licenses are already
 * fully editable at the record level via the standalone "Licenses" search
 * page's own Bulk Edit, and duplicating that machinery for this narrower,
 * per-owner view wasn't asked for.
 */
export function LicensesDataGrid({ licenses, onEditLicense }: Props) {
  const columns = useMemo<GridColDef<License>[]>(
    () => [
      { field: "licenseState", headerName: "State", width: 64 },
      { field: "licenseType", headerName: "License Type", width: 130 },
      { field: "licenseStatus", headerName: "Status", width: 84 },
      { field: "stateLicenseNumber", headerName: "SLN", width: 100 },
      { field: "npn", headerName: "NPN", width: 100 },
      { field: "licenseName", headerName: "License Name", width: 150 },
      { field: "underwritingCompany", headerName: "UW Company", width: 200 },
      { field: "personFirmIndicator", headerName: "P/F Ind", width: 90 },
      { field: "residenceIndicator", headerName: "Res Ind", width: 110 },
      {
        field: "licenseEffectiveDate",
        headerName: "Effective",
        width: 110,
        valueFormatter: (value: string) => (value ? formatDate(value) : ""),
      },
      {
        field: "actions",
        headerName: "Actions",
        width: 76,
        sortable: false,
        filterable: false,
        disableColumnMenu: true,
        align: "center",
        headerAlign: "center",
        renderCell: ({ row }) => (
          <Tooltip title="Edit license">
            <IconButton size="small" onClick={() => onEditLicense(row)}>
              <FaIcon icon="pen" sx={{ fontSize: "1rem" }} />
            </IconButton>
          </Tooltip>
        ),
      },
    ],
    [onEditLicense],
  );

  return (
    <Box sx={{ width: "100%" }}>
      <DataGrid
        rows={licenses}
        columns={columns}
        getRowId={licenseRowKey}
        rowHeight={52}
        columnHeaderHeight={56}
        showToolbar
        slots={{ toolbar: Toolbar }}
        sx={{
          "& .MuiDataGrid-columnHeaders": { fontSize: 14 },
          "& .MuiDataGrid-cell": { fontSize: 16 },
        }}
        disableRowSelectionOnClick
        initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
        pageSizeOptions={[5, 10, 25]}
        autoHeight
      />
    </Box>
  );
}
