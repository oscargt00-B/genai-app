import type { ReactNode } from "react";
import Box from "@mui/material/Box";
import { TOPBAR_HEIGHT } from "./TopBar";

/** The `<main>` content area shared by the search page and the detail pages — offsets for the fixed TopBar/SideNav. */
export function ShellMain({ navWidth, children }: { navWidth: number; children: ReactNode }) {
  return (
    <Box
      component="main"
      sx={{
        pt: `${TOPBAR_HEIGHT}px`,
        pl: { xs: 0, md: `${navWidth}px` },
        minHeight: "100vh",
        transition: (t) => t.transitions.create("padding-left"),
        bgcolor: "background.default",
        overflowX: "hidden",
      }}
    >
      {children}
    </Box>
  );
}
