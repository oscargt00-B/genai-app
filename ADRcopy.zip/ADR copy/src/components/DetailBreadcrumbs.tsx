import { useState, type MouseEvent, type ReactNode } from "react";
import { Link as RouterLink, useNavigate } from "react-router-dom";
import Box from "@mui/material/Box";
import Link from "@mui/material/Link";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Tooltip from "@mui/material/Tooltip";
import Typography from "@mui/material/Typography";
import { FaIcon } from "./FaIcon";
import { branchCode, getAgencyGroup } from "../data/agencies";
import type { Agency } from "../types/agency";

const sepSx = { color: "text.disabled", mx: 1, fontSize: 18 };
const crumbSx = { display: "flex", alignItems: "center", gap: "8px", fontSize: 18 };

/**
 * Breadcrumbs shared by the Branch (L1), Agency (L2), and Producer (L3)
 * detail pages — the segment for the current record's own level renders as
 * plain (non-link) text showing its *full, untruncated* name, every
 * *ancestor* level above it collapses to a plain ellipsis icon (full
 * "{code} {name}" available via a hover tooltip, clicking still navigates
 * there), and the trailing segment is a functional dropdown to a sibling
 * one level down (Select L2 Agency / Select L3, or — on an L3 page — the
 * other producers under the same agency).
 */
export function DetailBreadcrumbs({ agency }: { agency: Agency }) {
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const { l2, l3s } = getAgencyGroup(agency.agencyGroupKey);
  const level = agency.levelNumber;
  const branchLevelCode = branchCode(agency.agencyGroupKey);

  let dropdownLabel: ReactNode;
  let dropdownOptions: Agency[];
  let dropdownPath: (levelCode: string) => string;

  if (level === "001") {
    dropdownLabel = "Select L2 Agency";
    dropdownOptions = l2 ? [l2] : [];
    dropdownPath = (code) => `/agency/${code}`;
  } else if (level === "002") {
    dropdownLabel = "Select L3";
    dropdownOptions = l3s;
    dropdownPath = (code) => `/producer/${code}`;
  } else {
    dropdownLabel = (
      <>
        <FaIcon icon="user-pen" sx={{ fontSize: "0.9rem" }} />
        <Box component="span" sx={{ whiteSpace: "nowrap" }}>
          {agency.levelCode} {agency.name}
        </Box>
      </>
    );
    dropdownOptions = l3s.filter((l3) => l3.levelCode !== agency.levelCode);
    dropdownPath = (code) => `/producer/${code}`;
  }

  const handleSelect = (levelCode: string) => {
    setAnchorEl(null);
    navigate(dropdownPath(levelCode));
  };

  return (
    <Box sx={{ display: "flex", alignItems: "center", flexWrap: "wrap" }}>
      <Link component={RouterLink} to="/" underline="hover" sx={{ ...crumbSx, color: "primary.main" }}>
        <FaIcon icon="house" sx={{ fontSize: "0.9rem" }} />
        Home
      </Link>
      <Typography component="span" sx={sepSx}>
        /
      </Typography>

      {level === "001" ? (
        <Typography component="span" sx={{ ...crumbSx, color: "text.primary" }}>
          <FaIcon icon="sitemap" sx={{ fontSize: "0.9rem" }} />
          {branchLevelCode} Branch
        </Typography>
      ) : (
        <Tooltip title={`${branchLevelCode} Branch`}>
          <Link component={RouterLink} to={`/branch/${branchLevelCode}`} underline="hover" sx={{ ...crumbSx, color: "primary.main" }}>
            <FaIcon icon="ellipsis" sx={{ fontSize: "0.9rem" }} />
          </Link>
        </Tooltip>
      )}

      {level !== "001" && l2 && (
        <>
          <Typography component="span" sx={sepSx}>
            /
          </Typography>
          {level === "002" ? (
            <Typography component="span" sx={{ ...crumbSx, color: "text.primary" }}>
              <FaIcon icon="building" sx={{ fontSize: "0.9rem" }} />
              <Box component="span" sx={{ whiteSpace: "nowrap" }}>
                {l2.levelCode} {l2.name}
              </Box>
            </Typography>
          ) : (
            <Tooltip title={`${l2.levelCode} ${l2.name}`}>
              <Link component={RouterLink} to={`/agency/${l2.levelCode}`} underline="hover" sx={{ ...crumbSx, color: "primary.main" }}>
                <FaIcon icon="ellipsis" sx={{ fontSize: "0.9rem" }} />
              </Link>
            </Tooltip>
          )}
        </>
      )}

      <Typography component="span" sx={sepSx}>
        /
      </Typography>

      <Box
        component="button"
        onClick={(e: MouseEvent<HTMLElement>) => dropdownOptions.length > 0 && setAnchorEl(e.currentTarget)}
        sx={{
          ...crumbSx,
          border: "none",
          background: "none",
          p: 0,
          cursor: dropdownOptions.length > 0 ? "pointer" : "default",
          color: level === "003" ? "text.primary" : "text.disabled",
          fontFamily: "inherit",
        }}
      >
        {dropdownLabel}
        {dropdownOptions.length > 0 && <FaIcon icon="chevron-down" sx={{ fontSize: "0.75rem" }} />}
      </Box>

      <Menu anchorEl={anchorEl} open={!!anchorEl} onClose={() => setAnchorEl(null)}>
        {dropdownOptions.map((option) => (
          <MenuItem key={option.levelCode} onClick={() => handleSelect(option.levelCode)}>
            {option.levelCode} {option.name}
          </MenuItem>
        ))}
      </Menu>
    </Box>
  );
}
