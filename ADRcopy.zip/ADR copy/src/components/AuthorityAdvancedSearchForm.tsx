import type { FormEvent } from "react";
import Autocomplete from "@mui/material/Autocomplete";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import MenuItem from "@mui/material/MenuItem";
import TextField from "@mui/material/TextField";
import { FaIcon } from "./FaIcon";
import type { AuthorityAdvancedSearchCriteria } from "../types/authority";
import { branchNames } from "../data/agencies";
import { AUTHORITY_STATUSES, CONTRACT_TYPES, LOB_OPTIONS, SERVICE_CENTER_INDICATORS } from "../data/authorityOptions";
import { US_STATES } from "../data/options";
import { prPrimitives } from "../theme";

const FIELD_WIDTH = { xs: "100%", sm: 260 };

interface Props {
  criteria: AuthorityAdvancedSearchCriteria;
  onChange: (next: AuthorityAdvancedSearchCriteria) => void;
  onSubmit: () => void;
  onReset: () => void;
  onHide: () => void;
  /** Show the Reset button — only present once a search has produced results. */
  showReset: boolean;
  agencyNameOptions: string[];
}

export function AuthorityAdvancedSearchForm({
  criteria,
  onChange,
  onSubmit,
  onReset,
  onHide,
  showReset,
  agencyNameOptions,
}: Props) {
  const set = <K extends keyof AuthorityAdvancedSearchCriteria>(key: K, value: AuthorityAdvancedSearchCriteria[K]) =>
    onChange({ ...criteria, [key]: value });

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    onSubmit();
  };

  return (
    <Box
      component="form"
      onSubmit={handleSubmit}
      sx={{
        bgcolor: prPrimitives.color.paper3,
        borderRadius: `${prPrimitives.radius.xl}px`,
        px: `${prPrimitives.spacing.large}px`,
        py: 2,
      }}
    >
      <Box sx={{ display: "flex", flexWrap: "wrap", gap: "12px 16px" }}>
        <TextField
          select
          label="L1 Branch Name"
          value={criteria.l1BranchName}
          onChange={(e) => set("l1BranchName", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        >
          <MenuItem value="">
            <em>All branches</em>
          </MenuItem>
          {branchNames.map((b) => (
            <MenuItem key={b} value={b}>
              {b}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          label="L2 Agency Code"
          placeholder="L2 Agency Code"
          value={criteria.l2AgencyCode}
          onChange={(e) => set("l2AgencyCode", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <TextField
          label="L3 Producer Code"
          placeholder="L3 Producer Code"
          value={criteria.l3ProducerCode}
          onChange={(e) => set("l3ProducerCode", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <TextField
          select
          label="Contract State"
          value={criteria.contractState}
          onChange={(e) => set("contractState", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        >
          <MenuItem value="">
            <em>Any state</em>
          </MenuItem>
          {US_STATES.map((s) => (
            <MenuItem key={s} value={s}>
              {s}
            </MenuItem>
          ))}
        </TextField>

        <Autocomplete
          multiple
          size="small"
          options={agencyNameOptions}
          value={criteria.l2AgencyName}
          onChange={(_e, value) => set("l2AgencyName", value)}
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
          renderInput={(params) => <TextField {...params} label="L2 Agency Name" />}
          slotProps={{
            chip: { deleteIcon: <FaIcon icon="circle-xmark" sx={{ fontSize: "1rem !important" }} /> },
          }}
        />

        <TextField
          label="L3 Producer Name"
          placeholder="L3 Producer Name"
          value={criteria.l3ProducerName}
          onChange={(e) => set("l3ProducerName", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <TextField
          select
          label="LOB"
          value={criteria.lob}
          onChange={(e) => set("lob", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        >
          <MenuItem value="">
            <em>Any LOB</em>
          </MenuItem>
          {LOB_OPTIONS.map((l) => (
            <MenuItem key={l} value={l}>
              {l}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          label="Underwriting Company"
          placeholder="Underwriting Company"
          value={criteria.underwritingCompany}
          onChange={(e) => set("underwritingCompany", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <TextField
          select
          label="Contract Type"
          value={criteria.contractType}
          onChange={(e) => set("contractType", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        >
          <MenuItem value="">
            <em>Any type</em>
          </MenuItem>
          {CONTRACT_TYPES.map((t) => (
            <MenuItem key={t} value={t}>
              {t}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          select
          label="Contract Status"
          value={criteria.contractStatus}
          onChange={(e) => set("contractStatus", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        >
          <MenuItem value="">
            <em>Any status</em>
          </MenuItem>
          {AUTHORITY_STATUSES.map((s) => (
            <MenuItem key={s} value={s}>
              {s}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          label="Contract Number"
          placeholder="Contract Number"
          value={criteria.contractNumber}
          onChange={(e) => set("contractNumber", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <TextField
          label="Appointment Date"
          placeholder="MM/DD/YYYY"
          value={criteria.appointmentDate}
          onChange={(e) => set("appointmentDate", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
          slotProps={{
            input: { endAdornment: <FaIcon icon="calendar" variant="regular" sx={{ fontSize: "1rem" }} /> },
          }}
        />

        <TextField
          label="New Business Indicator"
          placeholder="New Business Indicator"
          value={criteria.newBusinessIndicator}
          onChange={(e) => set("newBusinessIndicator", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <TextField
          select
          label="Service Center Indicator"
          value={criteria.serviceCenterIndicator}
          onChange={(e) => set("serviceCenterIndicator", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        >
          <MenuItem value="">
            <em>Any</em>
          </MenuItem>
          {SERVICE_CENTER_INDICATORS.map((s) => (
            <MenuItem key={s} value={s}>
              {s}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          label="Underwriting Group"
          placeholder="Underwriting Group"
          value={criteria.underwritingGroup}
          onChange={(e) => set("underwritingGroup", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <TextField
          label="Marketing Group"
          placeholder="Marketing Group"
          value={criteria.marketingGroup}
          onChange={(e) => set("marketingGroup", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />
      </Box>

      <Box sx={{ display: "flex", alignItems: "center", gap: 3, mt: 2 }}>
        <Button type="submit" variant="contained" sx={{ width: 162 }}>
          Search
        </Button>
        {showReset && (
          <Button variant="outlined" onClick={onReset}>
            Reset
          </Button>
        )}
        <Box sx={{ flex: 1 }} />
        <Button
          variant="outlined"
          endIcon={<FaIcon icon="chevron-up" variant="regular" sx={{ fontSize: "0.875rem" }} />}
          onClick={onHide}
        >
          Hide
        </Button>
      </Box>
    </Box>
  );
}
