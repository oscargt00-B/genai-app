import type { FormEvent } from "react";
import Autocomplete from "@mui/material/Autocomplete";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import MenuItem from "@mui/material/MenuItem";
import TextField from "@mui/material/TextField";
import { FaIcon } from "./FaIcon";
import type { AdvancedSearchCriteria } from "../types/agency";
import { branchNames } from "../data/agencies";
import { prPrimitives } from "../theme";

const FIELD_WIDTH = { xs: "100%", sm: 260 };

interface Props {
  criteria: AdvancedSearchCriteria;
  onChange: (next: AdvancedSearchCriteria) => void;
  onSubmit: () => void;
  onReset: () => void;
  onHide: () => void;
  /** Show the Reset button — only present once a search has produced results ("Home Search R 1"). */
  showReset: boolean;
  agencyNameOptions: string[];
}

export function AdvancedSearchForm({
  criteria,
  onChange,
  onSubmit,
  onReset,
  onHide,
  showReset,
  agencyNameOptions,
}: Props) {
  const set = <K extends keyof AdvancedSearchCriteria>(key: K, value: AdvancedSearchCriteria[K]) =>
    onChange({ ...criteria, [key]: value });

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    onSubmit();
  };

  return (
    <Box
      component="form"
      onSubmit={handleSubmit}
      sx={{
        bgcolor: prPrimitives.color.paper3,
        borderRadius: `${prPrimitives.radius.xl}px`,
        px: `${prPrimitives.spacing.large}px`,
        py: 2,
      }}
    >
      <Box
        sx={{
          display: "flex",
          flexWrap: "wrap",
          gap: "12px 16px",
        }}
      >
        <TextField
          select
          label="L1 Branch Name"
          value={criteria.l1BranchName}
          onChange={(e) => set("l1BranchName", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        >
          <MenuItem value="">
            <em>All branches</em>
          </MenuItem>
          {branchNames.map((b) => (
            <MenuItem key={b} value={b}>
              {b}
            </MenuItem>
          ))}
        </TextField>

        <TextField
          label="L2 Agency Code"
          placeholder="L2 Agency Code"
          value={criteria.l2AgencyCode}
          onChange={(e) => set("l2AgencyCode", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <TextField
          label="L3 Producer Code"
          placeholder="L3 Producer Code"
          value={criteria.l3ProducerCode}
          onChange={(e) => set("l3ProducerCode", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <TextField
          label="Agency Group Key"
          placeholder="Agency Group Key"
          value={criteria.agencyGroupKey}
          onChange={(e) => set("agencyGroupKey", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <Autocomplete
          multiple
          size="small"
          options={agencyNameOptions}
          value={criteria.l2AgencyName}
          onChange={(_e, value) => set("l2AgencyName", value)}
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
          renderInput={(params) => <TextField {...params} label="L2 Agency Name" />}
          slotProps={{
            chip: { deleteIcon: <FaIcon icon="circle-xmark" sx={{ fontSize: "1rem !important" }} /> },
          }}
        />

        <TextField
          label="L3 Producer Name"
          placeholder="L3 Producer Name"
          value={criteria.l3ProducerName}
          onChange={(e) => set("l3ProducerName", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <TextField
          label="NPN"
          placeholder="NPN"
          value={criteria.npn}
          onChange={(e) => set("npn", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />

        <TextField
          label="Tax ID"
          placeholder="Tax ID"
          value={criteria.taxId}
          onChange={(e) => set("taxId", e.target.value)}
          size="small"
          sx={{ width: FIELD_WIDTH, maxWidth: { xs: 420, sm: 260 }, bgcolor: "background.paper" }}
        />
      </Box>

      <Box sx={{ display: "flex", alignItems: "center", gap: 3, mt: 2 }}>
        <Button type="submit" variant="contained" sx={{ width: 162 }}>
          Search
        </Button>
        {showReset && (
          <Button variant="outlined" onClick={onReset}>
            Reset
          </Button>
        )}
        <Box sx={{ flex: 1 }} />
        <Button
          variant="outlined"
          endIcon={<FaIcon icon="chevron-up" variant="regular" sx={{ fontSize: "0.875rem" }} />}
          onClick={onHide}
        >
          Hide
        </Button>
      </Box>
    </Box>
  );
}
