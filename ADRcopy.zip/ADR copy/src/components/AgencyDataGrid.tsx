import { forwardRef, useEffect, useImperativeHandle, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import MenuItem from "@mui/material/MenuItem";
import TextField from "@mui/material/TextField";
import Tooltip from "@mui/material/Tooltip";
import {
  DataGrid,
  GridToolbarContainer,
  GridToolbarColumnsButton,
  GridToolbarExport,
  GridToolbarFilterButton,
  type GridColDef,
  type GridComparatorFn,
  type GridRowSelectionModel,
  type GridSortDirection,
} from "@mui/x-data-grid";
import { FaIcon } from "./FaIcon";
import type { Agency } from "../types/agency";
import { formatDate } from "../lib/format";
import { CHANNELS, HEIR_STATUSES, HEIR_TYPES, US_STATES } from "../data/options";
import { prPrimitives } from "../theme";

/** "Level" 1 rows go to Branch Details, "Level" 2 to Agency Details, "Level" 3 to Producer Details. */
function detailPath(row: Agency): string | null {
  if (row.levelNumber === "001") return `/branch/${row.levelCode}`;
  if (row.levelNumber === "002") return `/agency/${row.levelCode}`;
  if (row.levelNumber === "003") return `/producer/${row.levelCode}`;
  return null;
}

/** Sentinel row id for the synthetic "bulk edit" input row pinned above the data. */
const EDIT_ROW_ID = "__bulk_edit_row__";

type FieldEditor = { kind: "text" } | { kind: "select"; options: string[]; placeholder: string };

/** Which columns get an input in the bulk-edit row, and what kind. Omitted fields (Actions, Last Update, Last Update by) aren't bulk-editable. */
const FIELD_EDITORS: Partial<Record<keyof Agency, FieldEditor>> = {
  levelNumber: { kind: "text" },
  agencyGroupKey: { kind: "text" },
  branch: { kind: "text" },
  levelCode: { kind: "text" },
  name: { kind: "text" },
  mainAddress1: { kind: "text" },
  mainAddress2: { kind: "text" },
  mainCity: { kind: "text" },
  mainState: { kind: "select", options: US_STATES, placeholder: "State" },
  zipCode: { kind: "text" },
  legacyLevelCode: { kind: "text" },
  heirStatus: { kind: "select", options: HEIR_STATUSES, placeholder: "Select" },
  heirId: { kind: "text" },
  heirType: { kind: "select", options: HEIR_TYPES, placeholder: "Select" },
  channel: { kind: "select", options: CHANNELS, placeholder: "Select" },
  mainPhoneNumber: { kind: "text" },
  npn: { kind: "text" },
  taxId: { kind: "text" },
};

function blankEditRow(): Agency {
  return {
    levelCode: EDIT_ROW_ID,
    levelNumber: "",
    agencyGroupKey: "",
    branch: "",
    legacyLevelCode: "",
    name: "",
    mainAddress1: "",
    mainAddress2: "",
    mainCity: "",
    mainState: "",
    zipCode: "",
    heirStatus: "" as Agency["heirStatus"],
    heirId: "",
    heirType: "" as Agency["heirType"],
    channel: "" as Agency["channel"],
    mainPhoneNumber: "",
    npn: "",
    taxId: "",
    lastUpdate: "",
    lastUpdateBy: "",
  };
}

/** One input in the bulk-edit row, with the green "apply to selected rows" button once a value is set. */
function EditRowCell({
  field,
  value,
  onChange,
  onApply,
  showApply,
}: {
  field: keyof Agency;
  value: string;
  onChange: (v: string) => void;
  onApply: () => void;
  showApply: boolean;
}) {
  const editor = FIELD_EDITORS[field];
  if (!editor) return null;

  return (
    <Box
      sx={{ display: "flex", alignItems: "center", gap: "6px", width: "100%" }}
      onClick={(e) => e.stopPropagation()}
      // The DataGrid binds Space (row selection toggle) and other navigation keys at the
      // cell/row level, which otherwise swallows them before they reach the input — most
      // noticeably making it impossible to type a space into these text fields.
      onKeyDown={(e) => e.stopPropagation()}
    >
      {editor.kind === "text" ? (
        <TextField
          size="small"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          sx={{ flex: 1, minWidth: 0, bgcolor: "background.paper" }}
        />
      ) : (
        <TextField
          select
          size="small"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          sx={{ flex: 1, minWidth: 90, bgcolor: "background.paper" }}
          slotProps={{ select: { displayEmpty: true } }}
        >
          <MenuItem value="">
            <em>{editor.placeholder}</em>
          </MenuItem>
          {editor.options.map((opt) => (
            <MenuItem key={opt} value={opt}>
              {opt}
            </MenuItem>
          ))}
        </TextField>
      )}
      {showApply && value !== "" && (
        <Tooltip title="Apply this value to the selected rows">
          <IconButton
            size="small"
            onClick={onApply}
            sx={{
              flexShrink: 0,
              bgcolor: "#43a047",
              color: "#fff",
              "&:hover": { bgcolor: "#388e3c" },
            }}
          >
            <FaIcon icon="arrows-rotate" sx={{ fontSize: "0.8rem" }} />
          </IconButton>
        </Tooltip>
      )}
    </Box>
  );
}

interface BuildColumnsParams {
  onOpenDetail: (row: Agency) => void;
  bulkEditMode: boolean;
  editValues: Partial<Record<keyof Agency, string>>;
  setEditValue: (field: keyof Agency, value: string) => void;
  applyColumnValue: (field: keyof Agency) => void;
  hasSelection: boolean;
  isPendingField: (row: Agency, field: keyof Agency) => boolean;
}

/**
 * Sorting stays fully functional while the pinned bulk-edit input row is present
 * (matching the default grid's own sort behavior for every real row) — this
 * comparator just special-cases the synthetic edit row so it always floats to
 * the top regardless of which column or direction is sorted, rather than
 * getting shuffled in among the data like an empty-valued real row would.
 *
 * Plain `sortComparator` isn't enough here: for a descending sort, the DataGrid
 * doesn't re-run the comparator with swapped args — it just negates whatever it
 * returns, which would flip our "always first" pin to "always last". Using
 * `getSortComparator` (which receives the direction directly) instead lets us
 * pin the edit row correctly in both directions ourselves.
 */
function editRowFirstGetSortComparator(direction: GridSortDirection): GridComparatorFn {
  return (v1, v2, p1, p2) => {
    if (p1.id === EDIT_ROW_ID) return -1;
    if (p2.id === EDIT_ROW_ID) return 1;
    if (v1 === v2) return 0;
    const cmp = String(v1).localeCompare(String(v2), undefined, { numeric: true, sensitivity: "base" });
    return direction === "desc" ? -cmp : cmp;
  };
}

function buildColumns({
  onOpenDetail,
  bulkEditMode,
  editValues,
  setEditValue,
  applyColumnValue,
  hasSelection,
  isPendingField,
}: BuildColumnsParams): GridColDef<Agency>[] {
  const isEditRow = (row: Agency) => row.levelCode === EDIT_ROW_ID;

  const editableColDef = (
    field: keyof Agency,
  ): Pick<GridColDef<Agency>, "renderCell" | "getSortComparator" | "cellClassName"> => ({
    getSortComparator: editRowFirstGetSortComparator,
    cellClassName: ({ row }) => (isPendingField(row, field) ? "cell--pendingEdit" : ""),
    renderCell: ({ row, value }) => {
      if (!isEditRow(row)) return value as string;
      return (
        <EditRowCell
          field={field}
          value={editValues[field] ?? ""}
          onChange={(v) => setEditValue(field, v)}
          onApply={() => applyColumnValue(field)}
          showApply={hasSelection}
        />
      );
    },
  });

  return [
    { field: "levelNumber", headerName: "Level", width: 80, ...editableColDef("levelNumber") },
    { field: "agencyGroupKey", headerName: "AG Key", width: 120, ...editableColDef("agencyGroupKey") },
    { field: "branch", headerName: "Branch", width: 200, ...editableColDef("branch") },
    { field: "levelCode", headerName: "Level Code", width: 120, ...editableColDef("levelCode") },
    { field: "name", headerName: "Agency/Producer Name", width: 260, ...editableColDef("name") },
    { field: "mainAddress1", headerName: "Main Address 1", width: 170, ...editableColDef("mainAddress1") },
    { field: "mainAddress2", headerName: "Main Address 2", width: 150, ...editableColDef("mainAddress2") },
    { field: "mainCity", headerName: "City", width: 130, ...editableColDef("mainCity") },
    { field: "mainState", headerName: "State", width: 110, ...editableColDef("mainState") },
    { field: "zipCode", headerName: "Zip Code", width: 100, ...editableColDef("zipCode") },
    { field: "legacyLevelCode", headerName: "Legacy Level Code", width: 150, ...editableColDef("legacyLevelCode") },
    { field: "heirStatus", headerName: "Heir Status", width: 130, ...editableColDef("heirStatus") },
    { field: "heirId", headerName: "Heir ID", width: 110, ...editableColDef("heirId") },
    { field: "heirType", headerName: "Heir Type", width: 120, ...editableColDef("heirType") },
    { field: "channel", headerName: "Channel", width: 150, ...editableColDef("channel") },
    { field: "mainPhoneNumber", headerName: "Main Phone Number", width: 160, ...editableColDef("mainPhoneNumber") },
    { field: "npn", headerName: "NPN", width: 100, ...editableColDef("npn") },
    { field: "taxId", headerName: "Tax ID", width: 120, ...editableColDef("taxId") },
    {
      field: "lastUpdate",
      headerName: "Last Update",
      width: 130,
      getSortComparator: editRowFirstGetSortComparator,
      valueFormatter: (value: string) => (value ? formatDate(value) : ""),
    },
    { field: "lastUpdateBy", headerName: "Last Update by", width: 140, getSortComparator: editRowFirstGetSortComparator },
    {
      field: "actions",
      headerName: "Actions",
      width: 90,
      sortable: false,
      filterable: false,
      disableColumnMenu: true,
      align: "center",
      headerAlign: "center",
      renderCell: ({ row }) => {
        if (isEditRow(row) || bulkEditMode) return null;
        const hasDetail = detailPath(row) !== null;
        return (
          <Tooltip title={hasDetail ? "View details" : "No detail page for this level"}>
            <span>
              <IconButton size="small" disabled={!hasDetail} onClick={() => onOpenDetail(row)}>
                <FaIcon icon="arrow-right" sx={{ fontSize: "1rem" }} />
              </IconButton>
            </span>
          </Tooltip>
        );
      },
    },
  ];
}

/** Default-visible columns match the "Home Search R 1" mockup; the rest are one click away via Columns. */
const DEFAULT_HIDDEN_FIELDS = [
  "mainAddress2",
  "zipCode",
  "legacyLevelCode",
  "heirStatus",
  "heirId",
  "heirType",
  "channel",
  "mainPhoneNumber",
  "npn",
  "taxId",
  "lastUpdate",
  "lastUpdateBy",
];

interface ToolbarProps {
  bulkEditMode: boolean;
  canSave: boolean;
  canDuplicate: boolean;
  onToggleBulkEdit: () => void;
  onCancel: () => void;
  onDuplicate: () => void;
  onSave: () => void;
}

/**
 * Shared text style for every toolbar button — bold 14px with 0.46px tracking,
 * matching the design. Applied both to our own Buttons below and, via
 * `slotProps.button.sx`, to the DataGrid's native Filters/Columns/Export
 * buttons, whose default MUI Button typography otherwise looks distinctly
 * lighter/smaller next to the custom ones.
 */
const TOOLBAR_BUTTON_SX = {
  fontSize: 14,
  fontWeight: 700,
  letterSpacing: "0.46px",
  textTransform: "none",
} as const;

/** The DataGrid's native toolbar buttons (Filters/Columns/Export) type `slotProps.button` without `sx` — only `style`. */
const TOOLBAR_BUTTON_STYLE: React.CSSProperties = { ...TOOLBAR_BUTTON_SX };

function Toolbar({ bulkEditMode, canSave, canDuplicate, onToggleBulkEdit, onCancel, onDuplicate, onSave }: ToolbarProps) {
  return (
    <GridToolbarContainer sx={{ p: "4px 4px 0", justifyContent: "space-between" }}>
      <Box sx={{ display: "flex", gap: 1, alignItems: "center" }}>
        <Button
          size="small"
          onClick={onToggleBulkEdit}
          disableRipple
          startIcon={<FaIcon icon={bulkEditMode ? "xmark" : "pen"} sx={{ fontSize: "0.9rem" }} />}
          sx={
            bulkEditMode
              ? {
                  ...TOOLBAR_BUTTON_SX,
                  color: "primary.contrastText",
                  bgcolor: "primary.main",
                  px: "8px",
                  "&:hover": { bgcolor: "primary.dark" },
                }
              : { ...TOOLBAR_BUTTON_SX, color: "primary.main" }
          }
        >
          Bulk Edit
        </Button>

        {bulkEditMode && (
          <>
            <Button
              size="small"
              onClick={onCancel}
              disableRipple
              startIcon={<FaIcon icon="xmark" sx={{ fontSize: "0.9rem" }} />}
              sx={{ ...TOOLBAR_BUTTON_SX, color: "primary.main" }}
            >
              Cancel
            </Button>
            <Button
              size="small"
              onClick={onDuplicate}
              disabled={!canDuplicate}
              disableRipple
              startIcon={<FaIcon icon="copy" variant="regular" sx={{ fontSize: "0.9rem" }} />}
              sx={{ ...TOOLBAR_BUTTON_SX, color: canDuplicate ? "text.secondary" : "text.disabled" }}
            >
              Duplicate
            </Button>
            <Button
              size="small"
              onClick={onSave}
              disabled={!canSave}
              disableRipple
              startIcon={<FaIcon icon="cloud-arrow-up" sx={{ fontSize: "0.9rem" }} />}
              sx={{ ...TOOLBAR_BUTTON_SX, color: canSave ? "text.secondary" : "text.disabled" }}
            >
              Save
            </Button>
          </>
        )}

        {!bulkEditMode && (
          <GridToolbarFilterButton
            slotProps={{
              button: { startIcon: <FaIcon icon="filter" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
            }}
          />
        )}
      </Box>
      <Box sx={{ display: "flex", gap: 1 }}>
        <GridToolbarColumnsButton
          slotProps={{
            button: { startIcon: <FaIcon icon="table-columns" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
          }}
        />
        <GridToolbarExport
          slotProps={{
            button: { startIcon: <FaIcon icon="download" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
          }}
        />
      </Box>
    </GridToolbarContainer>
  );
}

interface Props {
  rows: Agency[];
  /** Fires whenever "in Bulk Edit mode with at least one unsaved change" flips, so a parent can guard navigation/new searches. */
  onDirtyChange?: (dirty: boolean) => void;
}

/** Lets a parent (the search page) check for and resolve unsaved Bulk Edit changes before navigating away or re-searching. */
export interface AgencyDataGridHandle {
  hasUnsavedChanges: () => boolean;
  saveChanges: () => void;
  discardChanges: () => void;
}

let duplicateCounter = 0;

interface PersistedBulkEditState {
  bulkEditMode: boolean;
  overrides: Record<string, Partial<Agency>>;
  duplicatedRows: Agency[];
  dirty: boolean;
  sessionSnapshot: { overrides: Record<string, Partial<Agency>>; duplicatedRows: Agency[] };
}

/**
 * A blocked in-app navigation (react-router's `useBlocker`, used by the search page to
 * confirm before leaving with unsaved changes) can briefly unmount and remount this
 * component while the confirmation is pending — which would otherwise wipe the very
 * changes the confirmation dialog is asking about. Mirroring the bulk-edit state into
 * this module-level singleton (outside React's tree, so it survives that remount) and
 * lazily re-hydrating from it on mount closes that gap.
 */
let persistedBulkEditState: PersistedBulkEditState | null = null;

export const AgencyDataGrid = forwardRef<AgencyDataGridHandle, Props>(function AgencyDataGrid(
  { rows, onDirtyChange },
  ref,
) {
  const navigate = useNavigate();

  const [bulkEditMode, setBulkEditMode] = useState(() => persistedBulkEditState?.bulkEditMode ?? false);
  const [selectionModel, setSelectionModel] = useState<GridRowSelectionModel>({ type: "include", ids: new Set() });
  const [editValues, setEditValues] = useState<Partial<Record<keyof Agency, string>>>({});
  const [overrides, setOverrides] = useState<Record<string, Partial<Agency>>>(
    () => persistedBulkEditState?.overrides ?? {},
  );
  const [duplicatedRows, setDuplicatedRows] = useState<Agency[]>(() => persistedBulkEditState?.duplicatedRows ?? []);
  const [dirty, setDirty] = useState(() => persistedBulkEditState?.dirty ?? false);
  const [paginationModel, setPaginationModel] = useState({ pageSize: 10, page: 0 });

  const sessionSnapshot = useRef<{ overrides: Record<string, Partial<Agency>>; duplicatedRows: Agency[] }>(
    persistedBulkEditState?.sessionSnapshot ?? { overrides: {}, duplicatedRows: [] },
  );

  useEffect(() => {
    persistedBulkEditState = { bulkEditMode, overrides, duplicatedRows, dirty, sessionSnapshot: sessionSnapshot.current };
  });

  const selectedIds = useMemo(() => [...selectionModel.ids].map(String), [selectionModel]);

  /** A field is "pending" (edited but not saved) when its override differs from what was there when this bulk-edit session began. */
  const isPendingField = (row: Agency, field: keyof Agency): boolean => {
    if (!bulkEditMode || row.levelCode === EDIT_ROW_ID) return false;
    const current = overrides[row.levelCode]?.[field];
    if (current === undefined) return false;
    return current !== sessionSnapshot.current.overrides[row.levelCode]?.[field];
  };

  const rowHasPendingEdit = (row: Agency): boolean => {
    if (!bulkEditMode || row.levelCode === EDIT_ROW_ID) return false;
    // A row Duplicated this session is itself an unsaved change, even with no field overrides of its own.
    const isNewDuplicate =
      !sessionSnapshot.current.duplicatedRows.some((d) => d.levelCode === row.levelCode) &&
      duplicatedRows.some((d) => d.levelCode === row.levelCode);
    if (isNewDuplicate) return true;
    const rowOverride = overrides[row.levelCode];
    if (!rowOverride) return false;
    const snapshotOverride = sessionSnapshot.current.overrides[row.levelCode] ?? {};
    return (Object.keys(rowOverride) as (keyof Agency)[]).some(
      (key) => rowOverride[key] !== snapshotOverride[key],
    );
  };

  const setEditValue = (field: keyof Agency, value: string) => {
    setEditValues((prev) => ({ ...prev, [field]: value }));
  };

  const applyColumnValue = (field: keyof Agency) => {
    const value = editValues[field];
    if (value === undefined || value === "" || selectedIds.length === 0) return;
    setOverrides((prev) => {
      const next = { ...prev };
      for (const id of selectedIds) {
        next[id] = { ...next[id], [field]: value };
      }
      return next;
    });
    setDirty(true);
  };

  const handleToggleBulkEdit = () => {
    if (bulkEditMode) {
      // Same as Cancel — the toggle reverts this session's pending changes.
      handleCancel();
      return;
    }
    sessionSnapshot.current = { overrides, duplicatedRows };
    setBulkEditMode(true);
    setSelectionModel({ type: "include", ids: new Set() });
    setEditValues({});
    setDirty(false);
    setPaginationModel((p) => ({ ...p, page: 0 }));
  };

  const handleCancel = () => {
    setOverrides(sessionSnapshot.current.overrides);
    setDuplicatedRows(sessionSnapshot.current.duplicatedRows);
    setBulkEditMode(false);
    setSelectionModel({ type: "include", ids: new Set() });
    setEditValues({});
    setDirty(false);
  };

  const handleSave = () => {
    setBulkEditMode(false);
    setSelectionModel({ type: "include", ids: new Set() });
    setEditValues({});
    setDirty(false);
  };

  const hasUnsavedChanges = bulkEditMode && dirty;

  useEffect(() => {
    onDirtyChange?.(hasUnsavedChanges);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasUnsavedChanges]);

  useImperativeHandle(
    ref,
    () => ({
      hasUnsavedChanges: () => hasUnsavedChanges,
      saveChanges: handleSave,
      discardChanges: handleCancel,
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [hasUnsavedChanges],
  );

  const handleDuplicate = () => {
    if (selectedIds.length === 0) return;
    const source = [...rows, ...duplicatedRows];
    const copies = selectedIds
      .map((id) => source.find((r) => r.levelCode === id))
      .filter((r): r is Agency => !!r)
      .map((r) => ({ ...r, ...overrides[r.levelCode], levelCode: `${r.levelCode}-COPY${++duplicateCounter}` }));
    setDuplicatedRows((prev) => [...prev, ...copies]);
    setSelectionModel({ type: "include", ids: new Set() });
    setDirty(true);
  };

  const columns = useMemo(
    () =>
      buildColumns({
        onOpenDetail: (row) => {
          const path = detailPath(row);
          if (path) navigate(path);
        },
        bulkEditMode,
        editValues,
        setEditValue,
        applyColumnValue,
        hasSelection: selectedIds.length > 0,
        isPendingField,
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [navigate, bulkEditMode, editValues, selectedIds, overrides],
  );

  const displayRows = useMemo(() => {
    const withOverrides = rows.map((r) => (overrides[r.levelCode] ? { ...r, ...overrides[r.levelCode] } : r));
    const all = [...withOverrides, ...duplicatedRows];
    return bulkEditMode ? [blankEditRow(), ...all] : all;
  }, [rows, overrides, duplicatedRows, bulkEditMode]);

  // Bound via closure instead of DataGrid's slotProps (which types the toolbar slot
  // strictly and would need module augmentation for these custom props).
  const ToolbarWithState = () => (
    <Toolbar
      bulkEditMode={bulkEditMode}
      canSave={dirty}
      canDuplicate={selectedIds.length > 0}
      onToggleBulkEdit={handleToggleBulkEdit}
      onCancel={handleCancel}
      onDuplicate={handleDuplicate}
      onSave={handleSave}
    />
  );

  return (
    <Box sx={{ width: "100%" }}>
      <DataGrid
        rows={displayRows}
        columns={columns}
        getRowId={(row) => row.levelCode}
        getRowClassName={(params) => {
          if (params.id === EDIT_ROW_ID) return "MuiDataGrid-row--editInput";
          return rowHasPendingEdit(params.row) ? "row--pendingEdit" : "";
        }}
        rowHeight={52}
        columnHeaderHeight={56}
        showToolbar
        slots={{ toolbar: ToolbarWithState }}
        sx={{
          "& .MuiDataGrid-columnHeaders": { fontSize: 14 },
          "& .MuiDataGrid-cell": { fontSize: 16 },
          "& .MuiDataGrid-row--editInput": { bgcolor: "grey.50" },
          // "warning/light" — a cell edited (via the green apply button) but not yet Saved.
          "& .MuiDataGrid-cell.cell--pendingEdit": { bgcolor: prPrimitives.color.warningLight },
          // "warning/paper 1" — an unselected row that has at least one pending edit.
          "& .MuiDataGrid-row.row--pendingEdit, & .MuiDataGrid-row.row--pendingEdit:hover": {
            bgcolor: prPrimitives.color.warningPaper1,
          },
          // "primary/paper 1" — a selected row. DataGrid bakes its default .Mui-selected background
          // (a primary.main/selectedOpacity blend) into its own generated style at definition time
          // rather than reading a live CSS variable, so only a directly-targeted, higher-priority
          // rule actually wins here.
          "& .MuiDataGrid-row.Mui-selected, & .MuiDataGrid-row.Mui-selected:hover": {
            backgroundColor: `${prPrimitives.color.primaryPaper1} !important`,
          },
        }}
        checkboxSelection={bulkEditMode}
        isRowSelectable={(params) => params.id !== EDIT_ROW_ID}
        rowSelectionModel={selectionModel}
        onRowSelectionModelChange={setSelectionModel}
        disableRowSelectionOnClick
        paginationModel={paginationModel}
        onPaginationModelChange={setPaginationModel}
        initialState={{
          columns: {
            columnVisibilityModel: Object.fromEntries(DEFAULT_HIDDEN_FIELDS.map((f) => [f, false])),
          },
        }}
        pageSizeOptions={[5, 10, 25, 50]}
        autoHeight
      />
    </Box>
  );
});
