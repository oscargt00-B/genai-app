import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import Typography from "@mui/material/Typography";
import { FaIcon } from "./FaIcon";
import { prPrimitives } from "../theme";
import { formatDate, formatDateTime } from "../lib/format";
import type { Authority } from "../types/authority";

/** Every field below is optional in the mock data — blanks render as "-", matching the design. */
const dash = (v: string) => (v && v.trim() ? v : "-");
const dashDate = (v: string) => (v ? formatDate(v) : "-");

const fieldRowSx = { display: "flex", justifyContent: "space-between", gap: "16px", py: "3.5px", fontSize: 14 };

function FieldRow({ label, value, dimmed }: { label: string; value: string; dimmed?: boolean }) {
  const color = dimmed ? "text.disabled" : "text.primary";
  return (
    <Box sx={fieldRowSx}>
      <Typography component="span" sx={{ fontWeight: 700, color, whiteSpace: "nowrap" }}>
        {label}:
      </Typography>
      <Typography component="span" sx={{ fontSize: 14, color }}>
        {value}
      </Typography>
    </Box>
  );
}

function AdminField({ label, value }: { label: string; value: string }) {
  return (
    <Box sx={{ minWidth: 140 }}>
      <Typography sx={{ fontSize: 12, fontWeight: 700, color: "text.primary" }}>{label}:</Typography>
      <Typography sx={{ fontSize: 12, color: "text.primary" }}>{value}</Typography>
    </Box>
  );
}

interface Props {
  contract: Authority;
}

/**
 * The "Contract Details" card + admin info bar shown on a Contract Details
 * page — the same 22 fields (12+10, two columns) and 6 admin fields
 * regardless of L2 vs L3 (confirmed structurally identical between
 * `node-id=14314-179329` and `14314-182968`); the two pages differ only in
 * their surrounding chrome (side nav accent, breadcrumb depth), not this
 * content. Contract State/Line of Business/Underwriting Company render
 * dimmed — they're the contract's own identity, not editable fields.
 */
export function ContractDetailContent({ contract }: Props) {
  return (
    <Box sx={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 0, justifyContent: "space-between", pt: 1 }}>
      <Box sx={{ display: "flex", flexDirection: "column", gap: "12px" }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Typography sx={{ fontSize: 24, letterSpacing: "0.25px", color: "text.primary" }}>
            {contract.contractState}, {contract.lob}, {contract.underwritingCompany}
          </Typography>
          <Tooltip title="Delete (not wired — no backend to delete against)">
            <span>
              <IconButton size="small" disabled>
                <FaIcon icon="trash" sx={{ fontSize: "1rem" }} />
              </IconButton>
            </span>
          </Tooltip>
          <Button
            variant="outlined"
            size="small"
            disabled
            endIcon={<FaIcon icon="chevron-down" sx={{ fontSize: "0.75rem" }} />}
            sx={{ fontSize: 14 }}
          >
            {contract.contractStatus}
          </Button>
        </Box>

        <Box
          sx={{
            border: "1px solid",
            borderColor: "divider",
            borderRadius: `${prPrimitives.radius.l}px`,
            p: 3,
          }}
        >
          <Typography sx={{ fontSize: 16, fontWeight: 700, color: "text.primary", mb: 2 }}>Contract Details</Typography>
          <Box sx={{ display: "flex", flexWrap: "wrap", gap: "24px" }}>
            <Box sx={{ display: "flex", flexDirection: "column", width: 380, maxWidth: "100%" }}>
              <FieldRow label="Contract State" value={contract.contractState} dimmed />
              <FieldRow label="Line of Business" value={contract.lob} dimmed />
              <FieldRow label="Underwriting Company" value={contract.underwritingCompany} dimmed />
              <FieldRow label="Contract Type" value={dash(contract.contractType)} />
              <FieldRow label="Contract Effective Date" value={dashDate(contract.contractEffectiveDate)} />
              <FieldRow label="Contract Number" value={dash(contract.contractNumber)} />
              <FieldRow label="Appointment Date" value={dashDate(contract.contractAppointmentDate)} />
              <FieldRow label="New Business Indicator" value={dash(contract.newBusinessIndicator)} />
              <FieldRow label="Web Display Name" value={dash(contract.webDisplayName)} />
              <FieldRow label="Commission Group" value={dash(contract.commissionGroup)} />
              <FieldRow label="Service Center Indicator" value={dash(contract.serviceCenterIndicator)} />
              <FieldRow label="Aggregation Group" value={dash(contract.aggregationGroup)} />
            </Box>
            <Box sx={{ display: "flex", flexDirection: "column", width: 380, maxWidth: "100%" }}>
              <FieldRow label="Marketing Group" value={dash(contract.marketingGroup)} />
              <FieldRow label="Report Order Group" value={dash(contract.reportOrderGroup)} />
              <FieldRow label="Underwriting Group" value={dash(contract.underwritingGroup)} />
              <FieldRow label="Profit Sharing" value={dash(contract.profitSharing)} />
              <FieldRow label="Profit Sharing Rollup Code" value={dash(contract.psrProfitSharingRollupCode)} />
              <FieldRow label="Super Agent" value={dash(contract.superAgent)} />
              <FieldRow label="Exp/Letter Term Date" value={dashDate(contract.expLetterTermDate)} />
              <FieldRow label="Renewal Term Date" value={dashDate(contract.renewalTermDate)} />
              <FieldRow label="NB Termination Date" value={dashDate(contract.nbTerminationDate)} />
              <FieldRow label="RC1 Use Default" value={dash(contract.rc1UseDefault)} />
            </Box>
          </Box>
        </Box>
      </Box>

      <Box
        sx={{
          bgcolor: "primary.light",
          borderRadius: `${prPrimitives.radius.l}px`,
          p: 2,
          display: "flex",
          flexWrap: "wrap",
          gap: "12px",
          mt: "12px",
        }}
      >
        <AdminField label="Contract Id" value={dash(contract.contractId)} />
        <AdminField label="Bus Entity Id" value={dash(contract.busEntityId)} />
        <AdminField label="Polstar Config" value={dash(contract.polstarConfig)} />
        <AdminField label="Authority Pro Config" value={dash(contract.authorityProConfig)} />
        <AdminField
          label="Last Pol. Sys. Push"
          value={contract.lastPolSysPush ? `${formatDateTime(contract.lastPolSysPush)} by ${contract.lastUpdateBy}` : "-"}
        />
        <AdminField
          label="Last update"
          value={contract.lastUpdate ? `${formatDate(contract.lastUpdate)} by ${contract.lastUpdateBy}` : "-"}
        />
      </Box>
    </Box>
  );
}
