import type { ReactNode } from "react";
import { TopBar } from "./TopBar";
import { DetailSideNav } from "./DetailSideNav";
import { ShellMain } from "./ShellMain";
import { NotFoundDetail } from "./NotFoundDetail";
import { useSidebarShell } from "../hooks/useSidebarShell";

interface DetailNavConfig {
  level: "L1" | "L2" | "L3";
  code: string;
  name: string;
  sectionLabel: string;
  optionsLabel?: string;
  showQmas?: boolean;
  detailsPath?: string;
  contractsPath?: string;
  licensesPath?: string;
  activeItem?: "details" | "contracts" | "licenses";
}

interface Props {
  navConfig: DetailNavConfig;
  /** Whichever record this page is scoped to (an Agency/Producer, or a specific Contract) — `undefined` renders the "not found" state instead of `children`. */
  found: boolean;
  levelCode: string;
  children: ReactNode;
}

/**
 * The chrome shared by every L1/L2/L3 detail-family page (Agency/Producer
 * Details, and now the "Authority (Contracts)" section + Contract Details
 * pages nested under them) — TopBar, DetailSideNav, and the `<main>` shell,
 * factored out so each page only has to supply its own content.
 */
export function DetailShell({ navConfig, found, levelCode, children }: Props) {
  const shell = useSidebarShell();

  return (
    <>
      <TopBar onMenuClick={shell.isMobile ? shell.openMobile : undefined} />
      {shell.isMobile ? (
        <DetailSideNav variant="temporary" open={shell.mobileOpen} onClose={shell.closeMobile} {...navConfig} />
      ) : (
        <DetailSideNav
          variant="permanent"
          collapsed={shell.collapsed}
          onToggleCollapsed={shell.toggleCollapsed}
          {...navConfig}
        />
      )}
      <ShellMain navWidth={shell.navWidth}>{found ? children : <NotFoundDetail levelCode={levelCode} />}</ShellMain>
    </>
  );
}
