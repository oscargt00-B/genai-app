import { Link as RouterLink } from "react-router-dom";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import Box from "@mui/material/Box";
import { FaIcon } from "./FaIcon";
import prLogo from "../assets/pr-logo.svg";

export const TOPBAR_HEIGHT = 64;

interface Props {
  onMenuClick?: () => void;
}

export function TopBar({ onMenuClick }: Props) {
  return (
    <AppBar
      position="fixed"
      color="primary"
      elevation={4}
      sx={{ zIndex: (t) => t.zIndex.drawer + 1, height: TOPBAR_HEIGHT }}
    >
      <Toolbar
        sx={{
          height: TOPBAR_HEIGHT,
          minHeight: `${TOPBAR_HEIGHT}px !important`,
          px: { xs: 2, lg: "28px" },
          gap: 1,
        }}
      >
        {onMenuClick && (
          <IconButton color="inherit" edge="start" onClick={onMenuClick} sx={{ mr: 1 }}>
            <FaIcon icon="bars" />
          </IconButton>
        )}
        <Box sx={{ flex: 1, display: "flex", alignItems: "center", gap: 2, minWidth: 0 }}>
          <Box
            component={RouterLink}
            to="/"
            aria-label="Go to home"
            sx={{ display: "flex", alignItems: "center", flexShrink: 0 }}
          >
            <img
              src={prLogo}
              alt="Plymouth Rock Assurance"
              style={{ height: 28, width: "auto", flexShrink: 0 }}
            />
          </Box>
        </Box>
        <Typography
          variant="subtitle1"
          component="p"
          sx={{ px: { xs: 1, sm: 3 }, whiteSpace: "nowrap", display: { xs: "none", sm: "block" } }}
        >
          ADR - Mod
        </Typography>
        <Button
          color="inherit"
          startIcon={<FaIcon icon="circle-user" variant="regular" sx={{ fontSize: "1.125rem" }} />}
          endIcon={<FaIcon icon="chevron-down" sx={{ fontSize: "0.75rem" }} />}
          sx={{ textTransform: "none", whiteSpace: "nowrap" }}
        >
          <Box component="span" sx={{ display: { xs: "none", sm: "inline" } }}>
            Username
          </Box>
        </Button>
      </Toolbar>
    </AppBar>
  );
}
