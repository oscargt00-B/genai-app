import Box from "@mui/material/Box";
import type { SxProps, Theme } from "@mui/material/styles";

interface Props {
  /** Icon name without the "fa-" prefix, e.g. "house", "sliders", "circle-user". */
  icon: string;
  /** Font Awesome Pro style — defaults to "solid" (matches the filled icons throughout the design). */
  variant?: "solid" | "regular" | "brands";
  sx?: SxProps<Theme>;
  className?: string;
}

/** Renders one glyph from the local Font Awesome Pro kit (src/assets/fontawesome*.css). */
export function FaIcon({ icon, variant = "solid", sx, className }: Props) {
  const styleClass = variant === "brands" ? "fa-brands" : variant === "regular" ? "fa-regular" : "fa-solid";
  return (
    <Box
      component="i"
      aria-hidden="true"
      className={[styleClass, `fa-${icon}`, className].filter(Boolean).join(" ")}
      sx={{ fontSize: "1.25rem", lineHeight: 1, ...sx }}
    />
  );
}
