import { useState, type MouseEvent } from "react";
import { Link as RouterLink, useNavigate } from "react-router-dom";
import Box from "@mui/material/Box";
import Link from "@mui/material/Link";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Tooltip from "@mui/material/Tooltip";
import Typography from "@mui/material/Typography";
import { FaIcon } from "./FaIcon";
import { branchCode, getAgencyGroup } from "../data/agencies";
import { contractPath } from "../lib/contracts";
import type { Agency } from "../types/agency";
import type { Authority } from "../types/authority";

const sepSx = { color: "text.disabled", mx: 1, fontSize: 18 };
const crumbSx = { display: "flex", alignItems: "center", gap: "8px", fontSize: 18 };

interface Props {
  /** The L2 Agency or L3 Producer that owns this contract. */
  agency: Agency;
  contract: Authority;
  /** Every contract belonging to the same owner, for the trailing dropdown's sibling list. */
  siblingContracts: Authority[];
}

/**
 * Breadcrumbs for a Contract Details page (`node-id=14314-179329` for L2,
 * `14314-182968` for L3) — the same Home/Branch/Agency(/Producer) chain as
 * DetailBreadcrumbs, except the owning record is always a link here (we've
 * navigated one level past it), plus a trailing dropdown segment
 * identifying the contract itself by State, LOB, Underwriting Company,
 * matching how the design's own last segment lets you jump to a sibling
 * contract of the same owner. The current level here is the *contract*
 * (shown by name in the trailing segment), so every ancestor above it —
 * Branch, L2, and the owning Agency/Producer — collapses to a plain
 * ellipsis icon, same as DetailBreadcrumbs' own ancestor segments: full
 * "{code} {name}" via a hover tooltip, clicking still navigates there.
 */
export function ContractBreadcrumbs({ agency, contract, siblingContracts }: Props) {
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const { l2 } = getAgencyGroup(agency.agencyGroupKey);
  const level = agency.levelNumber;
  const branchLevelCode = branchCode(agency.agencyGroupKey);
  const ownerPath = level === "002" ? `/agency/${agency.levelCode}` : `/producer/${agency.levelCode}`;

  const contractLabel = `${contract.contractState}, ${contract.lob}, ${contract.underwritingCompany}`;
  const others = siblingContracts.filter(
    (c) =>
      !(
        c.contractState === contract.contractState &&
        c.lob === contract.lob &&
        c.underwritingCompany === contract.underwritingCompany
      ),
  );

  const handleSelect = (c: Authority) => {
    setAnchorEl(null);
    navigate(contractPath(`${ownerPath}/contracts`, c));
  };

  return (
    <Box sx={{ display: "flex", alignItems: "center", flexWrap: "wrap" }}>
      <Link component={RouterLink} to="/" underline="hover" sx={{ ...crumbSx, color: "primary.main" }}>
        <FaIcon icon="house" sx={{ fontSize: "0.9rem" }} />
        Home
      </Link>
      <Typography component="span" sx={sepSx}>
        /
      </Typography>

      <Tooltip title={`${branchLevelCode} Branch`}>
        <Link component={RouterLink} to={`/branch/${branchLevelCode}`} underline="hover" sx={{ ...crumbSx, color: "primary.main" }}>
          <FaIcon icon="ellipsis" sx={{ fontSize: "0.9rem" }} />
        </Link>
      </Tooltip>

      {level !== "002" && l2 && (
        <>
          <Typography component="span" sx={sepSx}>
            /
          </Typography>
          <Tooltip title={`${l2.levelCode} ${l2.name}`}>
            <Link component={RouterLink} to={`/agency/${l2.levelCode}`} underline="hover" sx={{ ...crumbSx, color: "primary.main" }}>
              <FaIcon icon="ellipsis" sx={{ fontSize: "0.9rem" }} />
            </Link>
          </Tooltip>
        </>
      )}

      <Typography component="span" sx={sepSx}>
        /
      </Typography>
      <Tooltip title={`${agency.levelCode} ${agency.name}`}>
        <Link component={RouterLink} to={ownerPath} underline="hover" sx={{ ...crumbSx, color: "primary.main" }}>
          <FaIcon icon="ellipsis" sx={{ fontSize: "0.9rem" }} />
        </Link>
      </Tooltip>

      <Typography component="span" sx={sepSx}>
        /
      </Typography>
      <Box
        component="button"
        onClick={(e: MouseEvent<HTMLElement>) => others.length > 0 && setAnchorEl(e.currentTarget)}
        sx={{
          ...crumbSx,
          border: "none",
          background: "none",
          p: 0,
          cursor: others.length > 0 ? "pointer" : "default",
          color: "text.primary",
          fontFamily: "inherit",
        }}
      >
        <FaIcon icon="file-signature" sx={{ fontSize: "0.9rem" }} />
        {contractLabel}
        {others.length > 0 && <FaIcon icon="chevron-down" sx={{ fontSize: "0.75rem" }} />}
      </Box>

      <Menu anchorEl={anchorEl} open={!!anchorEl} onClose={() => setAnchorEl(null)}>
        {others.map((c) => (
          <MenuItem key={`${c.contractState}|${c.lob}|${c.underwritingCompany}`} onClick={() => handleSelect(c)}>
            {c.contractState}, {c.lob}, {c.underwritingCompany}
          </MenuItem>
        ))}
      </Menu>
    </Box>
  );
}
