import { Link as RouterLink, useLocation } from "react-router-dom";
import Box from "@mui/material/Box";
import Divider from "@mui/material/Divider";
import Drawer from "@mui/material/Drawer";
import IconButton from "@mui/material/IconButton";
import List from "@mui/material/List";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Tooltip from "@mui/material/Tooltip";
import { FaIcon } from "./FaIcon";
import { TOPBAR_HEIGHT } from "./TopBar";

export const SIDENAV_WIDTH = 266;
/** Icon-only rail width — matches the "L1 menu collapsed" / "Collapsed Main" Figma variant. */
export const SIDENAV_WIDTH_COLLAPSED = 56;

/** `to` is omitted for items with no page behind them yet (no linked Figma frame) — they render inert, matching the design's visual-only tabs. */
const NAV_ITEMS: { label: string; icon: string; to?: string }[] = [
  { label: "Home", icon: "house", to: "/" },
  { label: "All Licenses", icon: "id-card", to: "/licenses" },
  { label: "All Authority (Contracts)", icon: "file-signature", to: "/authority" },
  { label: "All Contacts", icon: "address-book", to: "/contacts" },
  { label: "All Addresses", icon: "location-dot", to: "/addresses" },
];

function NavItem({
  icon,
  label,
  to,
  active,
  collapsed,
}: {
  icon: string;
  label: string;
  to?: string;
  active: boolean;
  collapsed: boolean;
}) {
  const button = (
    <ListItemButton
      {...(to ? { component: RouterLink, to } : {})}
      selected={active}
      sx={{
        px: 2,
        py: "9px",
        justifyContent: collapsed ? "center" : "flex-start",
        color: active ? "primary.main" : "primary.contrastText",
        bgcolor: active ? "primary.contrastText" : "transparent",
        "&:hover": {
          bgcolor: active ? "primary.contrastText" : "rgba(255,255,255,0.08)",
        },
        "&.Mui-selected": { bgcolor: "primary.contrastText" },
        "&.Mui-selected:hover": { bgcolor: "primary.contrastText" },
      }}
    >
      <ListItemIcon sx={{ minWidth: collapsed ? 0 : 32, color: "inherit", justifyContent: "center" }}>
        <FaIcon icon={icon} sx={{ fontSize: "1.125rem" }} />
      </ListItemIcon>
      {!collapsed && (
        <ListItemText
          primary={label}
          slotProps={{ primary: { sx: { fontSize: 16, letterSpacing: "0.4px" } } }}
        />
      )}
    </ListItemButton>
  );

  if (!collapsed) return button;
  return (
    <Tooltip title={label} placement="right">
      {button}
    </Tooltip>
  );
}

function NavContent({ collapsed = false }: { collapsed?: boolean }) {
  const railWidth = collapsed ? SIDENAV_WIDTH_COLLAPSED : SIDENAV_WIDTH;
  const { pathname } = useLocation();

  return (
    <Box sx={{ display: "flex", flexDirection: "column", height: "100%", py: 3 }}>
      <List disablePadding sx={{ width: railWidth }}>
        {NAV_ITEMS.map((item) => (
          <NavItem key={item.label} {...item} active={!!item.to && pathname === item.to} collapsed={collapsed} />
        ))}
      </List>

      <Box sx={{ flex: 1 }} />

      <Box sx={{ width: railWidth, px: collapsed ? 0 : "10px", pb: collapsed ? 0 : "10px" }}>
        {!collapsed && <Divider sx={{ borderColor: "rgba(255,255,255,0.3)", mb: 0 }} />}
        <NavItem icon="gear" label="Admin" active={false} collapsed={collapsed} />
        {collapsed && <Divider sx={{ borderColor: "rgba(255,255,255,0.3)", mx: "1px" }} />}
      </Box>
    </Box>
  );
}

interface PermanentProps {
  variant: "permanent";
  collapsed: boolean;
  onToggleCollapsed: () => void;
}

interface TemporaryProps {
  variant: "temporary";
  open: boolean;
  onClose: () => void;
}

export function SideNav(props: PermanentProps | TemporaryProps) {
  if (props.variant === "temporary") {
    return (
      <Drawer
        variant="temporary"
        anchor="left"
        open={props.open}
        onClose={props.onClose}
        ModalProps={{ keepMounted: true }}
        sx={{
          "& .MuiDrawer-paper": {
            width: SIDENAV_WIDTH,
            bgcolor: "primary.main",
            boxSizing: "border-box",
          },
        }}
      >
        <Box sx={{ height: TOPBAR_HEIGHT }} />
        <NavContent />
      </Drawer>
    );
  }

  const width = props.collapsed ? SIDENAV_WIDTH_COLLAPSED : SIDENAV_WIDTH;

  return (
    <>
      <Box
        component="nav"
        sx={{
          position: "fixed",
          top: TOPBAR_HEIGHT,
          left: 0,
          bottom: 0,
          width,
          bgcolor: "primary.main",
          transition: (t) => t.transitions.create("width"),
          overflow: "hidden",
          zIndex: (t) => t.zIndex.appBar - 1,
        }}
      >
        <NavContent collapsed={props.collapsed} />
      </Box>

      {/* Rendered outside the rail's overflow:hidden clip so it isn't cut off — it
          intentionally straddles the rail's right edge, matching the Figma design. */}
      <Tooltip title={props.collapsed ? "Expand navigation" : "Collapse navigation"} placement="right">
        <IconButton
          onClick={props.onToggleCollapsed}
          size="small"
          sx={{
            position: "fixed",
            left: width - 15,
            bottom: 39,
            bgcolor: "primary.main",
            color: "primary.contrastText",
            boxShadow: 6,
            transition: (t) => t.transitions.create("left"),
            zIndex: (t) => t.zIndex.appBar,
            "&:hover": { bgcolor: "primary.dark" },
          }}
        >
          <FaIcon icon={props.collapsed ? "angles-right" : "angles-left"} sx={{ fontSize: "0.875rem" }} />
        </IconButton>
      </Tooltip>
    </>
  );
}
