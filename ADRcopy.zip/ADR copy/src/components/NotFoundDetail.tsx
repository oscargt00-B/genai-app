import { Link as RouterLink } from "react-router-dom";
import Box from "@mui/material/Box";
import Link from "@mui/material/Link";
import Typography from "@mui/material/Typography";
import { FaIcon } from "./FaIcon";

export function NotFoundDetail({ levelCode }: { levelCode: string }) {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 1,
        py: 12,
        px: 2,
      }}
    >
      <FaIcon icon="triangle-exclamation" sx={{ fontSize: 28, color: "text.disabled" }} />
      <Typography sx={{ fontWeight: 600, color: "text.secondary" }}>
        No record found for Level Code "{levelCode}"
      </Typography>
      <Link component={RouterLink} to="/" underline="hover" sx={{ fontSize: 14 }}>
        Back to search
      </Link>
    </Box>
  );
}
