import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import {
  DataGrid,
  GridToolbarContainer,
  GridToolbarColumnsButton,
  GridToolbarExport,
  GridToolbarFilterButton,
  type GridColDef,
} from "@mui/x-data-grid";
import { FaIcon } from "./FaIcon";
import type { Authority } from "../types/authority";
import { formatDate } from "../lib/format";
import { contractPath } from "../lib/contracts";

/** Shared text style for every toolbar button, matching every other grid in the app. */
const TOOLBAR_BUTTON_SX = {
  fontSize: 14,
  fontWeight: 700,
  letterSpacing: "0.46px",
  textTransform: "none",
} as const;
const TOOLBAR_BUTTON_STYLE: React.CSSProperties = { ...TOOLBAR_BUTTON_SX };

function Toolbar() {
  return (
    <GridToolbarContainer sx={{ p: "4px 4px 0", justifyContent: "flex-end" }}>
      <Box sx={{ display: "flex", gap: 1 }}>
        <GridToolbarFilterButton
          slotProps={{
            button: { startIcon: <FaIcon icon="filter" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
          }}
        />
        <GridToolbarColumnsButton
          slotProps={{
            button: { startIcon: <FaIcon icon="table-columns" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
          }}
        />
        <GridToolbarExport
          slotProps={{
            button: { startIcon: <FaIcon icon="download" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
          }}
        />
      </Box>
    </GridToolbarContainer>
  );
}

interface Props {
  level: "L2" | "L3";
  contracts: Authority[];
  /** The owner's own base route, e.g. `/agency/2010001` or `/producer/3010001` — contract detail links nest under `${basePath}/contracts/...`. */
  basePath: string;
}

/**
 * The "Authority (Contracts)" section's embedded results table, matching
 * `node-id=14314-176865` (L2) / `14314-182655` (L3) — an agency or producer
 * can hold one or many contracts, each identified by (State, LOB,
 * Underwriting Company). Clicking a row's Actions arrow navigates to that
 * contract's own detail page. L3's table adds a leading Contract ID column
 * and narrower widths that L2's doesn't have — everything else is shared.
 *
 * Unlike the other grids in this app, this embedded table doesn't offer
 * Bulk Edit — contracts are already fully editable at the record level via
 * the standalone "All Authority (Contracts)" search page's own Bulk Edit,
 * and duplicating that machinery for this narrower, per-owner view wasn't
 * asked for.
 */
export function ContractsDataGrid({ level, contracts, basePath }: Props) {
  const navigate = useNavigate();

  const columns = useMemo<GridColDef<Authority>[]>(() => {
    const dateCol = (field: keyof Authority, headerName: string, width: number): GridColDef<Authority> => ({
      field,
      headerName,
      width,
      valueFormatter: (value: string) => (value ? formatDate(value) : ""),
    });

    const cols: GridColDef<Authority>[] = [];
    if (level === "L3") {
      cols.push({ field: "contractId", headerName: "ID", width: 76 });
    }
    cols.push(
      { field: "contractState", headerName: "State", width: 64 },
      { field: "lob", headerName: "LOB", width: level === "L3" ? 150 : 110 },
      { field: "underwritingCompany", headerName: "UW Company", width: level === "L3" ? 150 : 200 },
      { field: "contractType", headerName: "Contract Type", width: 120 },
      { field: "contractStatus", headerName: "Status", width: 90 },
      { field: "newBusinessIndicator", headerName: "NBI", width: 70 },
      {
        field: "contractNumber",
        headerName: level === "L3" ? "Contract N." : "Contract Number",
        width: level === "L3" ? 110 : 150,
      },
      dateCol("expLetterTermDate", "Exp/Letter Term", 140),
      dateCol("renewalTermDate", "Renewal Term Date", 150),
      {
        field: "actions",
        headerName: "Actions",
        width: 76,
        sortable: false,
        filterable: false,
        disableColumnMenu: true,
        align: "center",
        headerAlign: "center",
        renderCell: ({ row }) => (
          <Tooltip title="View contract">
            <IconButton size="small" onClick={() => navigate(contractPath(basePath, row))}>
              <FaIcon icon="arrow-right" sx={{ fontSize: "1rem" }} />
            </IconButton>
          </Tooltip>
        ),
      },
    );
    return cols;
  }, [level, basePath, navigate]);

  return (
    <Box sx={{ width: "100%" }}>
      <DataGrid
        rows={contracts}
        columns={columns}
        getRowId={(row) => `${row.contractState}|${row.lob}|${row.underwritingCompany}`}
        rowHeight={52}
        columnHeaderHeight={56}
        showToolbar
        slots={{ toolbar: Toolbar }}
        sx={{
          "& .MuiDataGrid-columnHeaders": { fontSize: 14 },
          "& .MuiDataGrid-cell": { fontSize: 16 },
        }}
        disableRowSelectionOnClick
        initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
        pageSizeOptions={[5, 10, 25]}
        autoHeight
      />
    </Box>
  );
}
