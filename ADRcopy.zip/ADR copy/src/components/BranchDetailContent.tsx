import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import { FaIcon } from "./FaIcon";
import { prPrimitives } from "../theme";
import { formatDate } from "../lib/format";
import type { Agency } from "../types/agency";
import type { AgencyDetailExtra } from "../data/agencyDetails";

function FieldRow({ label, value }: { label: string; value: string }) {
  return (
    <Box sx={{ display: "flex", gap: "8px", py: "3.5px", fontSize: 14 }}>
      <Typography component="span" sx={{ fontWeight: 700, color: "text.primary", whiteSpace: "nowrap" }}>
        {label}:
      </Typography>
      <Typography component="span" sx={{ fontSize: 14, color: "text.primary" }}>
        {value}
      </Typography>
    </Box>
  );
}

function AdminField({ label, value }: { label: string; value: string }) {
  return (
    <Box sx={{ minWidth: 140 }}>
      <Typography sx={{ fontSize: 12, fontWeight: 700, color: "text.primary" }}>{label}:</Typography>
      <Typography sx={{ fontSize: 12, color: "text.primary" }}>{value}</Typography>
    </Box>
  );
}

interface Props {
  branch: Agency;
  extra: AgencyDetailExtra;
}

/** The "Branch Details" (L1) page content — a single Branch Information card, no Addresses section. */
export function BranchDetailContent({ branch, extra }: Props) {
  return (
    <Box sx={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 0, justifyContent: "space-between", pt: 1 }}>
      <Box sx={{ display: "flex", flexDirection: "column", gap: "12px" }}>
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Typography sx={{ fontSize: 24, letterSpacing: "0.25px", color: "text.primary" }}>Branch Details</Typography>
          <Button variant="contained" size="large" startIcon={<FaIcon icon="plus" variant="regular" sx={{ fontSize: "1rem" }} />}>
            New L2 Agency
          </Button>
        </Box>

        <Box
          sx={{
            position: "relative",
            border: "1px solid",
            borderColor: "divider",
            borderRadius: `${prPrimitives.radius.l}px`,
            display: "flex",
            flexWrap: "wrap",
          }}
        >
          <Box sx={{ display: "flex", flexDirection: "column", gap: 1, p: 3, width: 400 }}>
            <Typography sx={{ fontSize: 16, fontWeight: 700, color: "text.primary" }}>Branch Information</Typography>
            <Box sx={{ borderBottom: "1px solid", borderColor: "divider", width: 176 }} />
            <Box>
              <FieldRow label="L1 Branch Name" value={branch.name} />
              <FieldRow label="Distribution Channel" value={branch.channel} />
            </Box>
          </Box>
          <IconButton size="small" sx={{ position: "absolute", top: 15, right: 16, color: "primary.main" }}>
            <FaIcon icon="pen" sx={{ fontSize: "0.9rem" }} />
          </IconButton>
        </Box>
      </Box>

      <Box
        sx={{
          bgcolor: "primary.light",
          borderRadius: `${prPrimitives.radius.l}px`,
          p: 2,
          display: "flex",
          flexWrap: "wrap",
          gap: "24px",
          mt: "12px",
        }}
      >
        <AdminField label="Agent Hier Id" value={extra.agentHierId} />
        <AdminField label="Bus Entity Id" value={extra.busEntityId} />
        <AdminField label="Agent Hier Type" value={extra.agentHierType} />
        <AdminField label="Last Pol. Sys. Push" value={`${formatDate(extra.lastPolSysPush)} ${extra.updatedBy}`} />
        <AdminField label="Last update" value={`${formatDate(extra.lastEntityUpdate)} by ${extra.updatedBy}`} />
      </Box>
    </Box>
  );
}
