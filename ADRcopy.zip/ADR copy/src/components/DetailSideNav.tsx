import { Link as RouterLink } from "react-router-dom";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Drawer from "@mui/material/Drawer";
import IconButton from "@mui/material/IconButton";
import List from "@mui/material/List";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Tooltip from "@mui/material/Tooltip";
import Typography from "@mui/material/Typography";
import { lighten } from "@mui/material/styles";
import { FaIcon } from "./FaIcon";
import { TOPBAR_HEIGHT } from "./TopBar";
import { SIDENAV_WIDTH, SIDENAV_WIDTH_COLLAPSED } from "./SideNav";
import { prPrimitives } from "../theme";

export { SIDENAV_WIDTH, SIDENAV_WIDTH_COLLAPSED };

/**
 * The Figma detail frames bind the side nav's background to a different
 * color variable per level — confirmed by sampling pixels from each frame's
 * screenshot: "primary/main" (#0078d6) on the L1 Branch page, "primary/dark"
 * (#004884) on the L2 Agency page, "neutral/dark" (#2e3845) on the L3
 * Producer page.
 */
function accentColorFor(level: "L1" | "L2" | "L3"): string {
  if (level === "L1") return prPrimitives.color.primaryMain;
  return level === "L2" ? prPrimitives.color.primaryDark : prPrimitives.color.neutralDark;
}

const SECTION_ICON: Record<"L1" | "L2" | "L3", string> = {
  L1: "sitemap",
  L2: "building",
  L3: "user-pen",
};


interface DetailNavConfig {
  level: "L1" | "L2" | "L3";
  code: string;
  name: string;
  /** "Branch Details" | "Agency Details" | "Producer Details" */
  sectionLabel: string;
  /** "Agency Options" | "Producer Options" — L1 has no sub-items, so this is unused there. */
  optionsLabel?: string;
  /** L3 pages show an extra "QMAs" item that L1/L2 pages don't. */
  showQmas?: boolean;
  /** Route back to the Details section — only "Authority (Contracts)" and "Licenses" are real links besides this one; the rest render inert. */
  detailsPath?: string;
  /** Route to the "Authority (Contracts)" section — omitted (L1) leaves that item inert, matching the other still-unwired items. */
  contractsPath?: string;
  /** Route to the "Licenses" section — omitted (L1) leaves that item inert, matching the other still-unwired items. */
  licensesPath?: string;
  /** Which top-level item is highlighted as active — defaults to "details". */
  activeItem?: "details" | "contracts" | "licenses";
}

function NavContent({ config, collapsed = false }: { config: DetailNavConfig; collapsed?: boolean }) {
  const { level, code, name, sectionLabel, optionsLabel, showQmas, detailsPath, contractsPath, licensesPath, activeItem = "details" } = config;
  const railWidth = collapsed ? SIDENAV_WIDTH_COLLAPSED : SIDENAV_WIDTH;
  const isL1 = level === "L1";
  const sectionIcon = SECTION_ICON[level];
  const accent = accentColorFor(level);
  const contrastText = prPrimitives.color.primaryContrast;
  // The avatar circle's text is always primary/dark in the Figma frames,
  // regardless of the rail's own accent color for that level.
  const avatarTextColor = prPrimitives.color.primaryDark;

  return (
    <Box sx={{ display: "flex", flexDirection: "column", height: "100%", py: 3 }}>
      {!collapsed && (
        <Box sx={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 0.75, px: 2, pb: 2 }}>
          <Box
            sx={{
              width: 54,
              height: 54,
              borderRadius: "50%",
              bgcolor: contrastText,
              color: avatarTextColor,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 700,
              fontSize: 24,
            }}
          >
            {level}
          </Box>
          <Typography sx={{ color: contrastText, fontSize: 18, textAlign: "center" }}>{name}</Typography>
          <Typography sx={{ color: contrastText, fontSize: 12, letterSpacing: "0.4px" }}>{code}</Typography>
          <Button
            variant="outlined"
            size="small"
            startIcon={<FaIcon icon="rotate" variant="regular" sx={{ fontSize: "0.8rem" }} />}
            sx={{
              mt: 0.5,
              color: contrastText,
              borderColor: "rgba(255,255,255,0.5)",
              borderRadius: "32px",
              "&:hover": { borderColor: contrastText, bgcolor: "rgba(255,255,255,0.08)" },
            }}
          >
            System Sync
          </Button>
        </Box>
      )}

      <List disablePadding sx={{ width: railWidth }}>
        <ListItemButton
          {...(detailsPath ? { component: RouterLink, to: detailsPath } : {})}
          selected={activeItem === "details"}
          sx={{
            px: 2,
            py: "9px",
            justifyContent: collapsed ? "center" : "flex-start",
            color: accent,
            bgcolor: activeItem === "details" ? contrastText : accent,
            "&.Mui-selected": { bgcolor: contrastText },
            "&.Mui-selected:hover": { bgcolor: contrastText },
            "&:not(.Mui-selected)": { color: contrastText },
            "&:not(.Mui-selected):hover": { bgcolor: accent, opacity: 0.9 },
          }}
        >
          <ListItemIcon sx={{ minWidth: collapsed ? 0 : 32, color: "inherit", justifyContent: "center" }}>
            <FaIcon icon={sectionIcon} sx={{ fontSize: "1.125rem" }} />
          </ListItemIcon>
          {!collapsed && (
            <>
              <ListItemText
                primary={sectionLabel}
                slotProps={{ primary: { sx: { fontSize: 16, letterSpacing: "0.4px" } } }}
              />
              {!isL1 && <FaIcon icon="chevron-up" variant="regular" sx={{ fontSize: "0.9rem" }} />}
            </>
          )}
        </ListItemButton>

        {!collapsed &&
          !isL1 &&
          activeItem === "details" &&
          ["Contacts", optionsLabel, "360 Codes"].map((label) => (
            <ListItemButton key={label} sx={{ pl: "38px", pr: 2, py: "9px", color: contrastText }}>
              <Box
                component="span"
                sx={{ width: 6, height: 6, borderRadius: "50%", bgcolor: contrastText, mr: "18px", flexShrink: 0 }}
              />
              <ListItemText
                primary={label}
                slotProps={{ primary: { sx: { fontSize: 16, letterSpacing: "0.4px" } } }}
              />
            </ListItemButton>
          ))}

        {!isL1 && (
          <>
            <NavRow
              key="Licenses"
              label="Licenses"
              icon="id-card"
              collapsed={collapsed}
              textColor={contrastText}
              to={licensesPath}
              selected={activeItem === "licenses"}
              selectedBg={contrastText}
              selectedColor={accent}
            />
            <NavRow
              key="Authority (Contracts)"
              label="Authority (Contracts)"
              icon="file-signature"
              collapsed={collapsed}
              textColor={contrastText}
              to={contractsPath}
              selected={activeItem === "contracts"}
              selectedBg={contrastText}
              selectedColor={accent}
            />
            <NavRow key="Agency Tier" label="Agency Tier" icon="layer-group" collapsed={collapsed} textColor={contrastText} />
            {showQmas && <NavRow label="QMAs" icon="user-group" collapsed={collapsed} textColor={contrastText} />}
            <NavRow label="Commission Rates" icon="arrow-up-right-from-square" collapsed={collapsed} textColor={contrastText} />
          </>
        )}
      </List>

      <Box sx={{ flex: 1 }} />
    </Box>
  );
}

function NavRow({
  label,
  icon,
  collapsed,
  textColor,
  to,
  selected,
  selectedBg,
  selectedColor,
}: {
  label: string;
  icon: string;
  collapsed: boolean;
  textColor: string;
  /** Omitted for the still-unwired items (Licenses, Agency Tier, QMAs, Commission Rates) — they stay inert, matching the design's visual-only tabs. */
  to?: string;
  selected?: boolean;
  selectedBg?: string;
  selectedColor?: string;
}) {
  const button = (
    <ListItemButton
      {...(to ? { component: RouterLink, to } : {})}
      selected={selected}
      sx={{
        px: 2,
        py: "9px",
        justifyContent: collapsed ? "center" : "flex-start",
        color: textColor,
        "&.Mui-selected": { bgcolor: selectedBg, color: selectedColor },
        "&.Mui-selected:hover": { bgcolor: selectedBg },
      }}
    >
      <ListItemIcon sx={{ minWidth: collapsed ? 0 : 32, color: "inherit", justifyContent: "center" }}>
        <FaIcon icon={icon} sx={{ fontSize: "1.125rem" }} />
      </ListItemIcon>
      {!collapsed && (
        <ListItemText primary={label} slotProps={{ primary: { sx: { fontSize: 16, letterSpacing: "0.4px" } } }} />
      )}
    </ListItemButton>
  );
  if (!collapsed) return button;
  return (
    <Tooltip title={label} placement="right">
      {button}
    </Tooltip>
  );
}

interface PermanentProps extends DetailNavConfig {
  variant: "permanent";
  collapsed: boolean;
  onToggleCollapsed: () => void;
}

interface TemporaryProps extends DetailNavConfig {
  variant: "temporary";
  open: boolean;
  onClose: () => void;
}

export function DetailSideNav(props: PermanentProps | TemporaryProps) {
  const accent = accentColorFor(props.level);
  const accentHover = lighten(accent, 0.15);

  if (props.variant === "temporary") {
    return (
      <Drawer
        variant="temporary"
        anchor="left"
        open={props.open}
        onClose={props.onClose}
        ModalProps={{ keepMounted: true }}
        sx={{ "& .MuiDrawer-paper": { width: SIDENAV_WIDTH, bgcolor: accent, boxSizing: "border-box" } }}
      >
        <Box sx={{ height: TOPBAR_HEIGHT }} />
        <NavContent config={props} />
      </Drawer>
    );
  }

  const width = props.collapsed ? SIDENAV_WIDTH_COLLAPSED : SIDENAV_WIDTH;

  return (
    <>
      <Box
        component="nav"
        sx={{
          position: "fixed",
          top: TOPBAR_HEIGHT,
          left: 0,
          bottom: 0,
          width,
          bgcolor: accent,
          transition: (t) => t.transitions.create("width"),
          overflow: "hidden",
          zIndex: (t) => t.zIndex.appBar - 1,
        }}
      >
        <NavContent config={props} collapsed={props.collapsed} />
      </Box>

      <Tooltip title={props.collapsed ? "Expand navigation" : "Collapse navigation"} placement="right">
        <IconButton
          onClick={props.onToggleCollapsed}
          size="small"
          sx={{
            position: "fixed",
            left: width - 15,
            bottom: 39,
            bgcolor: accent,
            color: "primary.contrastText",
            boxShadow: 6,
            transition: (t) => t.transitions.create("left"),
            zIndex: (t) => t.zIndex.appBar,
            "&:hover": { bgcolor: accentHover },
          }}
        >
          <FaIcon icon={props.collapsed ? "angles-right" : "angles-left"} sx={{ fontSize: "0.875rem" }} />
        </IconButton>
      </Tooltip>
    </>
  );
}
