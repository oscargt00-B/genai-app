import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import { FaIcon } from "./FaIcon";
import { prPrimitives } from "../theme";
import { formatDate } from "../lib/format";
import type { Agency } from "../types/agency";
import type { AgencyDetailExtra } from "../data/agencyDetails";

const fieldRowSx = { display: "flex", gap: "8px", py: "3.5px", fontSize: 14 };
const fieldLabelSx = { fontWeight: 700, color: "text.primary", whiteSpace: "nowrap" as const };

function FieldRow({ label, value }: { label: string; value: string }) {
  return (
    <Box sx={fieldRowSx}>
      <Typography component="span" sx={fieldLabelSx}>
        {label}:
      </Typography>
      <Typography component="span" sx={{ fontSize: 14, color: "text.primary" }}>
        {value}
      </Typography>
    </Box>
  );
}

function AdminField({ label, value }: { label: string; value: string }) {
  return (
    <Box sx={{ minWidth: 140 }}>
      <Typography sx={{ fontSize: 12, fontWeight: 700, color: "text.primary" }}>{label}:</Typography>
      <Typography sx={{ fontSize: 12, color: "text.primary" }}>{value}</Typography>
    </Box>
  );
}

interface Props {
  agency: Agency;
  extra: AgencyDetailExtra;
  /** "Agency Details" | "Producer Details" */
  headline: string;
  /** "L2 Agency Name" | "L3 Producer Name" */
  companyNameLabel: string;
  /** "New L3 Producer" — only the Agency (L2) page offers this. */
  newButtonLabel?: string;
  showESalesOnly: boolean;
  /** L2 pages split the "last update" admin fields in two; L3 pages combine them into one. */
  adminUpdateStyle: "split" | "combined";
}

export function AgencyDetailContent({
  agency,
  extra,
  headline,
  companyNameLabel,
  newButtonLabel,
  showESalesOnly,
  adminUpdateStyle,
}: Props) {
  return (
    <Box sx={{ display: "flex", flexDirection: "column", flex: 1, minHeight: 0, justifyContent: "space-between", pt: 1 }}>
      <Box sx={{ display: "flex", flexDirection: "column", gap: "12px" }}>
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Typography sx={{ fontSize: 24, letterSpacing: "0.25px", color: "text.primary" }}>{headline}</Typography>
          {newButtonLabel && (
            <Button variant="contained" size="large" startIcon={<FaIcon icon="plus" variant="regular" sx={{ fontSize: "1rem" }} />}>
              {newButtonLabel}
            </Button>
          )}
        </Box>

        <Box sx={{ position: "relative", border: "1px solid", borderColor: "divider", borderRadius: `${prPrimitives.radius.l}px`, display: "flex", flexWrap: "wrap" }}>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 1, p: 3, width: 368 }}>
            <Typography sx={{ fontSize: 16, fontWeight: 700, color: "text.primary" }}>Company Information</Typography>
            <Box sx={{ borderBottom: "1px solid", borderColor: "divider", width: 176 }} />
            <Box>
              <FieldRow label={companyNameLabel} value={agency.name} />
              <FieldRow label="Tax ID" value={agency.taxId} />
              <FieldRow label="Agency Group Key" value={agency.agencyGroupKey} />
              <FieldRow label="Circle Of Excl" value={extra.circleOfExcl} />
              <FieldRow label="Dist Channel" value={extra.distChannelCode} />
              {showESalesOnly && <FieldRow label="eSales Only" value={extra.eSalesOnly} />}
            </Box>
          </Box>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 1, p: 3, width: 285 }}>
            <Typography sx={{ fontSize: 16, fontWeight: 700, color: "text.primary" }}>Individual Information</Typography>
            <Box sx={{ borderBottom: "1px solid", borderColor: "divider", width: 176 }} />
            <Box>
              <FieldRow label="First Name" value={extra.firstName} />
              <FieldRow label="Middle Name" value={extra.middleName} />
              <FieldRow label="Last Name" value={extra.lastName} />
            </Box>
          </Box>
          <IconButton size="small" sx={{ position: "absolute", top: 15, right: 16, color: "primary.main" }}>
            <FaIcon icon="pen" sx={{ fontSize: "0.9rem" }} />
          </IconButton>
        </Box>

        <Box sx={{ display: "flex", flexDirection: "column", gap: "12px", pt: "12px" }}>
          <Typography sx={{ fontSize: 24, letterSpacing: "0.25px", color: "text.primary" }}>Addresses</Typography>
          <Box
            sx={{
              border: "1px solid",
              borderColor: "divider",
              borderRadius: `${prPrimitives.radius.l}px`,
              p: 3,
              display: "flex",
              flexWrap: "wrap",
              gap: "16px",
            }}
          >
            {extra.addresses.map((addr) => (
              <Box key={addr.type} sx={{ display: "flex", flexDirection: "column", gap: 1, width: 190 }}>
                <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 700, color: "text.primary" }}>{addr.type}</Typography>
                  <IconButton size="small" sx={{ color: "primary.main" }}>
                    <FaIcon icon="pen" sx={{ fontSize: "0.85rem" }} />
                  </IconButton>
                </Box>
                <Box sx={{ borderBottom: "1px solid", borderColor: "divider" }} />
                <Typography sx={{ fontSize: 16, color: "text.primary", whiteSpace: "pre-line" }}>
                  {[addr.line1, addr.line2].filter(Boolean).join("\n")}
                  {"\n"}
                  {addr.cityStateZip}
                  {"\n"}
                  {addr.county}
                  {addr.fax ? `\nF: ${addr.fax}` : ""}
                  {addr.phone ? `\nP: ${addr.phone}` : ""}
                </Typography>
                {addr.type === "Main" && (
                  <Button
                    size="small"
                    endIcon={<FaIcon icon="chevron-right" sx={{ fontSize: "0.7rem" }} />}
                    sx={{ alignSelf: "flex-start", fontSize: 14, px: "5px" }}
                  >
                    Edit 360 Codes
                  </Button>
                )}
              </Box>
            ))}
            <Box sx={{ display: "flex", alignItems: "flex-start", pl: 1.5 }}>
              <Button variant="contained" startIcon={<FaIcon icon="plus" variant="regular" sx={{ fontSize: "0.9rem" }} />}>
                Address
              </Button>
            </Box>
          </Box>
        </Box>
      </Box>

      <Box
        sx={{
          bgcolor: "primary.light",
          borderRadius: `${prPrimitives.radius.l}px`,
          p: 2,
          display: "flex",
          flexWrap: "wrap",
          gap: "12px",
          mt: "12px",
        }}
      >
        <AdminField label="Agent Hier Id" value={extra.agentHierId} />
        <AdminField label="Bus Entity Id" value={extra.busEntityId} />
        <AdminField label="Agent Hier Type" value={extra.agentHierType} />
        {adminUpdateStyle === "split" ? (
          <>
            <AdminField label="Last entity update" value={`${formatDate(extra.lastEntityUpdate)} by ${extra.updatedBy}`} />
            <AdminField label="Last address update" value={`${formatDate(extra.lastAddressUpdate)} by ${extra.updatedBy}`} />
            <AdminField label="Last Pol. Sys. Push" value={`${formatDate(extra.lastPolSysPush)} ${extra.updatedBy}`} />
          </>
        ) : (
          <>
            <AdminField label="Last Pol. Sys. Push" value={`${formatDate(extra.lastPolSysPush)} ${extra.updatedBy}`} />
            <AdminField label="Last update" value={`${formatDate(extra.lastEntityUpdate)} by ${extra.updatedBy}`} />
          </>
        )}
      </Box>
    </Box>
  );
}
