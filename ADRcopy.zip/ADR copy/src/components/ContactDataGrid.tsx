import { forwardRef, useEffect, useImperativeHandle, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import MenuItem from "@mui/material/MenuItem";
import TextField from "@mui/material/TextField";
import Tooltip from "@mui/material/Tooltip";
import {
  DataGrid,
  GridToolbarContainer,
  GridToolbarColumnsButton,
  GridToolbarExport,
  GridToolbarFilterButton,
  type GridColDef,
  type GridComparatorFn,
  type GridRowSelectionModel,
  type GridSortDirection,
} from "@mui/x-data-grid";
import { FaIcon } from "./FaIcon";
import type { Contact } from "../types/contact";
import { formatDate } from "../lib/format";
import { CONTACT_TYPES, PREFIXES, SUFFIXES } from "../data/contactOptions";
import { UNDERWRITING_COMPANIES } from "../data/licenseOptions";
import { prPrimitives } from "../theme";

/** Sentinel row id for the synthetic "bulk edit" input row pinned above the data. */
const EDIT_ROW_ID = "__contact_bulk_edit_row__";

/** "Level" 2 rows route to their L2 Agency's Details page, "Level" 3 to their L3 Producer's. */
function contactOwnerPath(row: Contact): string | null {
  if (row.levelNumber === "002") return `/agency/${row.levelCode}`;
  if (row.levelNumber === "003") return `/producer/${row.levelCode}`;
  return null;
}

type FieldEditor = { kind: "text" } | { kind: "select"; options: string[]; placeholder: string };

/** Which columns get an input in the bulk-edit row, and what kind. Omitted fields (Actions, Last Update, Last Update by) aren't bulk-editable. */
const FIELD_EDITORS: Partial<Record<keyof Contact, FieldEditor>> = {
  contactId: { kind: "text" },
  levelNumber: { kind: "text" },
  branch: { kind: "text" },
  legacyLevelCode: { kind: "text" },
  levelCode: { kind: "text" },
  agencyProducerName: { kind: "text" },
  uwCompanyName: { kind: "select", options: UNDERWRITING_COMPANIES, placeholder: "Select" },
  contactType: { kind: "select", options: CONTACT_TYPES, placeholder: "Type" },
  prefix: { kind: "select", options: PREFIXES, placeholder: "Prefix" },
  firstName: { kind: "text" },
  middleName: { kind: "text" },
  lastName: { kind: "text" },
  suffix: { kind: "select", options: SUFFIXES, placeholder: "Suffix" },
  phone: { kind: "text" },
  cellPhone: { kind: "text" },
  email: { kind: "text" },
  imageRightId: { kind: "text" },
};

function blankEditRow(): Contact {
  return {
    contactId: EDIT_ROW_ID,
    levelNumber: "",
    branch: "",
    legacyLevelCode: "",
    levelCode: "",
    agencyProducerName: "",
    uwCompanyName: "",
    contactType: "",
    prefix: "",
    firstName: "",
    middleName: "",
    lastName: "",
    suffix: "",
    phone: "",
    cellPhone: "",
    email: "",
    imageRightId: "",
    lastUpdate: "",
    lastUpdateBy: "",
  };
}

/** One input in the bulk-edit row, with the green "apply to selected rows" button once a value is set. */
function EditRowCell({
  field,
  value,
  onChange,
  onApply,
  showApply,
}: {
  field: keyof Contact;
  value: string;
  onChange: (v: string) => void;
  onApply: () => void;
  showApply: boolean;
}) {
  const editor = FIELD_EDITORS[field];
  if (!editor) return null;

  return (
    <Box
      sx={{ display: "flex", alignItems: "center", gap: "6px", width: "100%" }}
      onClick={(e) => e.stopPropagation()}
      // The DataGrid binds Space (row selection toggle) and other navigation keys at the
      // cell/row level, which otherwise swallows them before they reach the input.
      onKeyDown={(e) => e.stopPropagation()}
    >
      {editor.kind === "text" ? (
        <TextField
          size="small"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          sx={{ flex: 1, minWidth: 0, bgcolor: "background.paper" }}
        />
      ) : (
        <TextField
          select
          size="small"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          sx={{ flex: 1, minWidth: 90, bgcolor: "background.paper" }}
          slotProps={{ select: { displayEmpty: true } }}
        >
          <MenuItem value="">
            <em>{editor.placeholder}</em>
          </MenuItem>
          {editor.options.map((opt) => (
            <MenuItem key={opt} value={opt}>
              {opt}
            </MenuItem>
          ))}
        </TextField>
      )}
      {showApply && value !== "" && (
        <Tooltip title="Apply this value to the selected rows">
          <IconButton
            size="small"
            onClick={onApply}
            sx={{
              flexShrink: 0,
              bgcolor: "#43a047",
              color: "#fff",
              "&:hover": { bgcolor: "#388e3c" },
            }}
          >
            <FaIcon icon="arrows-rotate" sx={{ fontSize: "0.8rem" }} />
          </IconButton>
        </Tooltip>
      )}
    </Box>
  );
}

interface BuildColumnsParams {
  bulkEditMode: boolean;
  editValues: Partial<Record<keyof Contact, string>>;
  setEditValue: (field: keyof Contact, value: string) => void;
  applyColumnValue: (field: keyof Contact) => void;
  hasSelection: boolean;
  isPendingField: (row: Contact, field: keyof Contact) => boolean;
  onOpenOwner: (row: Contact) => void;
}

/**
 * Sorting stays fully functional while the pinned bulk-edit input row is present —
 * this comparator just special-cases the synthetic edit row so it always floats to
 * the top regardless of which column or direction is sorted.
 */
function editRowFirstGetSortComparator(direction: GridSortDirection): GridComparatorFn {
  return (v1, v2, p1, p2) => {
    if (p1.id === EDIT_ROW_ID) return -1;
    if (p2.id === EDIT_ROW_ID) return 1;
    if (v1 === v2) return 0;
    const cmp = String(v1).localeCompare(String(v2), undefined, { numeric: true, sensitivity: "base" });
    return direction === "desc" ? -cmp : cmp;
  };
}

function buildColumns({
  bulkEditMode,
  editValues,
  setEditValue,
  applyColumnValue,
  hasSelection,
  isPendingField,
  onOpenOwner,
}: BuildColumnsParams): GridColDef<Contact>[] {
  const isEditRow = (row: Contact) => row.contactId === EDIT_ROW_ID;

  const editableColDef = (
    field: keyof Contact,
  ): Pick<GridColDef<Contact>, "renderCell" | "getSortComparator" | "cellClassName"> => ({
    getSortComparator: editRowFirstGetSortComparator,
    cellClassName: ({ row }) => (isPendingField(row, field) ? "cell--pendingEdit" : ""),
    renderCell: ({ row, value }) => {
      if (!isEditRow(row)) return value as string;
      return (
        <EditRowCell
          field={field}
          value={editValues[field] ?? ""}
          onChange={(v) => setEditValue(field, v)}
          onApply={() => applyColumnValue(field)}
          showApply={hasSelection}
        />
      );
    },
  });

  return [
    { field: "levelNumber", headerName: "Level", width: 60, ...editableColDef("levelNumber") },
    { field: "levelCode", headerName: "Level Code", width: 100, ...editableColDef("levelCode") },
    { field: "agencyProducerName", headerName: "Agency/Producer name", width: 200, ...editableColDef("agencyProducerName") },
    { field: "contactType", headerName: "Contact Type", width: 140, ...editableColDef("contactType") },
    { field: "firstName", headerName: "First Name", width: 120, ...editableColDef("firstName") },
    { field: "lastName", headerName: "Last Name", width: 120, ...editableColDef("lastName") },
    { field: "phone", headerName: "Phone", width: 130, ...editableColDef("phone") },
    { field: "email", headerName: "Email", width: 180, ...editableColDef("email") },
    { field: "imageRightId", headerName: "Image Right ID", width: 130, ...editableColDef("imageRightId") },
    { field: "contactId", headerName: "Contact ID", width: 110, ...editableColDef("contactId") },
    { field: "branch", headerName: "Branch", width: 200, ...editableColDef("branch") },
    { field: "legacyLevelCode", headerName: "Legacy Level Code", width: 150, ...editableColDef("legacyLevelCode") },
    { field: "uwCompanyName", headerName: "UW Company Name", width: 220, ...editableColDef("uwCompanyName") },
    { field: "prefix", headerName: "Prefix", width: 90, ...editableColDef("prefix") },
    { field: "middleName", headerName: "Middle Name", width: 120, ...editableColDef("middleName") },
    { field: "suffix", headerName: "Suffix", width: 90, ...editableColDef("suffix") },
    { field: "cellPhone", headerName: "Cell Phone", width: 130, ...editableColDef("cellPhone") },
    {
      field: "lastUpdate",
      headerName: "Last Update",
      width: 130,
      getSortComparator: editRowFirstGetSortComparator,
      valueFormatter: (value: string) => (value ? formatDate(value) : ""),
    },
    { field: "lastUpdateBy", headerName: "Last Update by", width: 140, getSortComparator: editRowFirstGetSortComparator },
    {
      field: "actions",
      headerName: "Actions",
      width: 90,
      sortable: false,
      filterable: false,
      disableColumnMenu: true,
      align: "center",
      headerAlign: "center",
      renderCell: ({ row }) => {
        if (isEditRow(row) || bulkEditMode) return null;
        const hasDetail = contactOwnerPath(row) !== null;
        return (
          <Tooltip title={hasDetail ? "View Agency/Producer" : "No detail page for this level"}>
            <span>
              <IconButton size="small" disabled={!hasDetail} onClick={() => onOpenOwner(row)}>
                <FaIcon icon="arrow-right" sx={{ fontSize: "1rem" }} />
              </IconButton>
            </span>
          </Tooltip>
        );
      },
    },
  ];
}

/** Default-visible columns match the "Contacts Search R 1" mockup; the rest are one click away via Columns. */
const DEFAULT_HIDDEN_FIELDS = [
  "contactId",
  "branch",
  "legacyLevelCode",
  "uwCompanyName",
  "prefix",
  "middleName",
  "suffix",
  "cellPhone",
  "lastUpdate",
  "lastUpdateBy",
];

interface ToolbarProps {
  bulkEditMode: boolean;
  canSave: boolean;
  canDuplicate: boolean;
  onToggleBulkEdit: () => void;
  onCancel: () => void;
  onDuplicate: () => void;
  onSave: () => void;
}

/** Shared text style for every toolbar button, matching every other grid in the app. */
const TOOLBAR_BUTTON_SX = {
  fontSize: 14,
  fontWeight: 700,
  letterSpacing: "0.46px",
  textTransform: "none",
} as const;

/** The DataGrid's native toolbar buttons (Filters/Columns/Export) type `slotProps.button` without `sx` — only `style`. */
const TOOLBAR_BUTTON_STYLE: React.CSSProperties = { ...TOOLBAR_BUTTON_SX };

function Toolbar({ bulkEditMode, canSave, canDuplicate, onToggleBulkEdit, onCancel, onDuplicate, onSave }: ToolbarProps) {
  return (
    <GridToolbarContainer sx={{ p: "4px 4px 0", justifyContent: "space-between" }}>
      <Box sx={{ display: "flex", gap: 1, alignItems: "center" }}>
        <Button
          size="small"
          onClick={onToggleBulkEdit}
          disableRipple
          startIcon={<FaIcon icon={bulkEditMode ? "xmark" : "pen"} sx={{ fontSize: "0.9rem" }} />}
          sx={
            bulkEditMode
              ? {
                  ...TOOLBAR_BUTTON_SX,
                  color: "primary.contrastText",
                  bgcolor: "primary.main",
                  px: "8px",
                  "&:hover": { bgcolor: "primary.dark" },
                }
              : { ...TOOLBAR_BUTTON_SX, color: "primary.main" }
          }
        >
          Bulk Edit
        </Button>

        {bulkEditMode && (
          <>
            <Button
              size="small"
              onClick={onCancel}
              disableRipple
              startIcon={<FaIcon icon="xmark" sx={{ fontSize: "0.9rem" }} />}
              sx={{ ...TOOLBAR_BUTTON_SX, color: "primary.main" }}
            >
              Cancel
            </Button>
            <Button
              size="small"
              onClick={onDuplicate}
              disabled={!canDuplicate}
              disableRipple
              startIcon={<FaIcon icon="copy" variant="regular" sx={{ fontSize: "0.9rem" }} />}
              sx={{ ...TOOLBAR_BUTTON_SX, color: canDuplicate ? "text.secondary" : "text.disabled" }}
            >
              Duplicate
            </Button>
            <Button
              size="small"
              onClick={onSave}
              disabled={!canSave}
              disableRipple
              startIcon={<FaIcon icon="cloud-arrow-up" sx={{ fontSize: "0.9rem" }} />}
              sx={{ ...TOOLBAR_BUTTON_SX, color: canSave ? "text.secondary" : "text.disabled" }}
            >
              Save
            </Button>
          </>
        )}

        {!bulkEditMode && (
          <GridToolbarFilterButton
            slotProps={{
              button: { startIcon: <FaIcon icon="filter" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
            }}
          />
        )}
      </Box>
      <Box sx={{ display: "flex", gap: 1 }}>
        <GridToolbarColumnsButton
          slotProps={{
            button: { startIcon: <FaIcon icon="table-columns" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
          }}
        />
        <GridToolbarExport
          slotProps={{
            button: { startIcon: <FaIcon icon="download" sx={{ fontSize: "0.9rem" }} />, style: TOOLBAR_BUTTON_STYLE },
          }}
        />
      </Box>
    </GridToolbarContainer>
  );
}

interface Props {
  rows: Contact[];
  /** Fires whenever "in Bulk Edit mode with at least one unsaved change" flips, so a parent can guard navigation/new searches. */
  onDirtyChange?: (dirty: boolean) => void;
}

/** Lets a parent (the search page) check for and resolve unsaved Bulk Edit changes before navigating away or re-searching. */
export interface ContactDataGridHandle {
  hasUnsavedChanges: () => boolean;
  saveChanges: () => void;
  discardChanges: () => void;
}

let duplicateCounter = 0;

interface PersistedBulkEditState {
  bulkEditMode: boolean;
  overrides: Record<string, Partial<Contact>>;
  duplicatedRows: Contact[];
  dirty: boolean;
  sessionSnapshot: { overrides: Record<string, Partial<Contact>>; duplicatedRows: Contact[] };
}

/**
 * A blocked in-app navigation (react-router's `useBlocker`, used by the search page to
 * confirm before leaving with unsaved changes) can briefly unmount and remount this
 * component while the confirmation is pending — which would otherwise wipe the very
 * changes the confirmation dialog is asking about. Mirroring the bulk-edit state into
 * this module-level singleton (outside React's tree, so it survives that remount) and
 * lazily re-hydrating from it on mount closes that gap. Mirrors LicenseDataGrid's own
 * `persistedBulkEditState`.
 */
let persistedBulkEditState: PersistedBulkEditState | null = null;

export const ContactDataGrid = forwardRef<ContactDataGridHandle, Props>(function ContactDataGrid(
  { rows, onDirtyChange },
  ref,
) {
  const navigate = useNavigate();
  const [bulkEditMode, setBulkEditMode] = useState(() => persistedBulkEditState?.bulkEditMode ?? false);
  const [selectionModel, setSelectionModel] = useState<GridRowSelectionModel>({ type: "include", ids: new Set() });
  const [editValues, setEditValues] = useState<Partial<Record<keyof Contact, string>>>({});
  const [overrides, setOverrides] = useState<Record<string, Partial<Contact>>>(
    () => persistedBulkEditState?.overrides ?? {},
  );
  const [duplicatedRows, setDuplicatedRows] = useState<Contact[]>(() => persistedBulkEditState?.duplicatedRows ?? []);
  const [dirty, setDirty] = useState(() => persistedBulkEditState?.dirty ?? false);
  const [paginationModel, setPaginationModel] = useState({ pageSize: 10, page: 0 });

  const sessionSnapshot = useRef<{ overrides: Record<string, Partial<Contact>>; duplicatedRows: Contact[] }>(
    persistedBulkEditState?.sessionSnapshot ?? { overrides: {}, duplicatedRows: [] },
  );

  useEffect(() => {
    persistedBulkEditState = { bulkEditMode, overrides, duplicatedRows, dirty, sessionSnapshot: sessionSnapshot.current };
  });

  const selectedIds = useMemo(() => [...selectionModel.ids].map(String), [selectionModel]);

  /** A field is "pending" (edited but not saved) when its override differs from what was there when this bulk-edit session began. */
  const isPendingField = (row: Contact, field: keyof Contact): boolean => {
    if (!bulkEditMode || row.contactId === EDIT_ROW_ID) return false;
    const current = overrides[row.contactId]?.[field];
    if (current === undefined) return false;
    return current !== sessionSnapshot.current.overrides[row.contactId]?.[field];
  };

  const rowHasPendingEdit = (row: Contact): boolean => {
    if (!bulkEditMode || row.contactId === EDIT_ROW_ID) return false;
    // A row Duplicated this session is itself an unsaved change, even with no field overrides of its own.
    const isNewDuplicate =
      !sessionSnapshot.current.duplicatedRows.some((d) => d.contactId === row.contactId) &&
      duplicatedRows.some((d) => d.contactId === row.contactId);
    if (isNewDuplicate) return true;
    const rowOverride = overrides[row.contactId];
    if (!rowOverride) return false;
    const snapshotOverride = sessionSnapshot.current.overrides[row.contactId] ?? {};
    return (Object.keys(rowOverride) as (keyof Contact)[]).some(
      (key) => rowOverride[key] !== snapshotOverride[key],
    );
  };

  const setEditValue = (field: keyof Contact, value: string) => {
    setEditValues((prev) => ({ ...prev, [field]: value }));
  };

  const applyColumnValue = (field: keyof Contact) => {
    const value = editValues[field];
    if (value === undefined || value === "" || selectedIds.length === 0) return;
    setOverrides((prev) => {
      const next = { ...prev };
      for (const id of selectedIds) {
        next[id] = { ...next[id], [field]: value };
      }
      return next;
    });
    setDirty(true);
  };

  const handleToggleBulkEdit = () => {
    if (bulkEditMode) {
      // Same as Cancel — the toggle reverts this session's pending changes.
      handleCancel();
      return;
    }
    sessionSnapshot.current = { overrides, duplicatedRows };
    setBulkEditMode(true);
    setSelectionModel({ type: "include", ids: new Set() });
    setEditValues({});
    setDirty(false);
    setPaginationModel((p) => ({ ...p, page: 0 }));
  };

  const handleCancel = () => {
    setOverrides(sessionSnapshot.current.overrides);
    setDuplicatedRows(sessionSnapshot.current.duplicatedRows);
    setBulkEditMode(false);
    setSelectionModel({ type: "include", ids: new Set() });
    setEditValues({});
    setDirty(false);
  };

  const handleSave = () => {
    setBulkEditMode(false);
    setSelectionModel({ type: "include", ids: new Set() });
    setEditValues({});
    setDirty(false);
  };

  const hasUnsavedChanges = bulkEditMode && dirty;

  useEffect(() => {
    onDirtyChange?.(hasUnsavedChanges);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasUnsavedChanges]);

  useImperativeHandle(
    ref,
    () => ({
      hasUnsavedChanges: () => hasUnsavedChanges,
      saveChanges: handleSave,
      discardChanges: handleCancel,
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [hasUnsavedChanges],
  );

  const handleDuplicate = () => {
    if (selectedIds.length === 0) return;
    const source = [...rows, ...duplicatedRows];
    const copies = selectedIds
      .map((id) => source.find((r) => r.contactId === id))
      .filter((r): r is Contact => !!r)
      .map((r) => ({ ...r, ...overrides[r.contactId], contactId: `${r.contactId}-COPY${++duplicateCounter}` }));
    setDuplicatedRows((prev) => [...prev, ...copies]);
    setSelectionModel({ type: "include", ids: new Set() });
    setDirty(true);
  };

  const columns = useMemo(
    () =>
      buildColumns({
        bulkEditMode,
        editValues,
        setEditValue,
        applyColumnValue,
        hasSelection: selectedIds.length > 0,
        isPendingField,
        onOpenOwner: (row) => {
          const path = contactOwnerPath(row);
          if (path) navigate(path);
        },
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [bulkEditMode, editValues, selectedIds, overrides, navigate],
  );

  const displayRows = useMemo(() => {
    const withOverrides = rows.map((r) => (overrides[r.contactId] ? { ...r, ...overrides[r.contactId] } : r));
    const all = [...withOverrides, ...duplicatedRows];
    return bulkEditMode ? [blankEditRow(), ...all] : all;
  }, [rows, overrides, duplicatedRows, bulkEditMode]);

  // Bound via closure instead of DataGrid's slotProps (which types the toolbar slot
  // strictly and would need module augmentation for these custom props).
  const ToolbarWithState = () => (
    <Toolbar
      bulkEditMode={bulkEditMode}
      canSave={dirty}
      canDuplicate={selectedIds.length > 0}
      onToggleBulkEdit={handleToggleBulkEdit}
      onCancel={handleCancel}
      onDuplicate={handleDuplicate}
      onSave={handleSave}
    />
  );

  return (
    <Box sx={{ width: "100%" }}>
      <DataGrid
        rows={displayRows}
        columns={columns}
        getRowId={(row) => row.contactId}
        getRowClassName={(params) => {
          if (params.id === EDIT_ROW_ID) return "MuiDataGrid-row--editInput";
          return rowHasPendingEdit(params.row) ? "row--pendingEdit" : "";
        }}
        rowHeight={52}
        columnHeaderHeight={56}
        showToolbar
        slots={{ toolbar: ToolbarWithState }}
        sx={{
          "& .MuiDataGrid-columnHeaders": { fontSize: 14 },
          "& .MuiDataGrid-cell": { fontSize: 16 },
          "& .MuiDataGrid-row--editInput": { bgcolor: "grey.50" },
          // "warning/light" — a cell edited (via the green apply button) but not yet Saved.
          "& .MuiDataGrid-cell.cell--pendingEdit": { bgcolor: prPrimitives.color.warningLight },
          // "warning/paper 1" — an unselected row that has at least one pending edit.
          "& .MuiDataGrid-row.row--pendingEdit, & .MuiDataGrid-row.row--pendingEdit:hover": {
            bgcolor: prPrimitives.color.warningPaper1,
          },
          // "primary/paper 1" — a selected row, overriding DataGrid's own baked-in .Mui-selected background.
          "& .MuiDataGrid-row.Mui-selected, & .MuiDataGrid-row.Mui-selected:hover": {
            backgroundColor: `${prPrimitives.color.primaryPaper1} !important`,
          },
        }}
        checkboxSelection={bulkEditMode}
        isRowSelectable={(params) => params.id !== EDIT_ROW_ID}
        rowSelectionModel={selectionModel}
        onRowSelectionModelChange={setSelectionModel}
        disableRowSelectionOnClick
        paginationModel={paginationModel}
        onPaginationModelChange={setPaginationModel}
        initialState={{
          columns: {
            columnVisibilityModel: Object.fromEntries(DEFAULT_HIDDEN_FIELDS.map((f) => [f, false])),
          },
        }}
        pageSizeOptions={[5, 10, 25, 50]}
        autoHeight
      />
    </Box>
  );
});
