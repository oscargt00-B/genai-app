import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './assets/fontawesome-fonts.css'
import './assets/fontawesome.min.css'
import './index.css'
import App from './App.tsx'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
