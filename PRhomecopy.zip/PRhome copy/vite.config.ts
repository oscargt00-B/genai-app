import { defineConfig } from 'vite'
import path from 'path'
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'

function figmaAssetPlaceholders() {
  return {
    name: 'figma-asset-placeholders',
    enforce: 'pre' as const,
    resolveId(id: string) {
      if (id.startsWith('figma:asset/')) {
        return `\0${id}`
      }
      return null
    },
    load(id: string) {
      if (!id.startsWith('\0figma:asset/')) {
        return null
      }

      const label = encodeURIComponent('Figma asset')
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800"><rect width="1200" height="800" fill="#e9f2fc"/><path d="M0 560 C180 500 290 620 460 560 S760 470 980 540 S1160 590 1200 540 V800 H0 Z" fill="#badbff"/><circle cx="940" cy="190" r="96" fill="#ff7826" opacity=".85"/><text x="600" y="410" text-anchor="middle" font-family="Arial, sans-serif" font-size="54" font-weight="700" fill="#0351aa">${label}</text></svg>`

      return `export default ${JSON.stringify(`data:image/svg+xml,${encodeURIComponent(svg)}`)}`
    },
  }
}

export default defineConfig({
  plugins: [
    // The React and Tailwind plugins are both required for Make, even if
    // Tailwind is not being actively used – do not remove them
    react(),
    tailwindcss(),
    figmaAssetPlaceholders(),
  ],
  resolve: {
    alias: {
      // Alias @ to the src directory
      '@': path.resolve(__dirname, './src'),
    },
  },
})
