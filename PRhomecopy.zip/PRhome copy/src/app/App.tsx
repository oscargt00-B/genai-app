import { Button } from '@/app/components/ui/button';
import PrSite from '@/imports/PrSite5-2-4074';
import PrSite6 from '@/imports/PrSite6';
import { useState, useRef, useEffect } from 'react';
import { Mic, AudioLines,AudioWaveform, ArrowRight, ChevronDown } from 'lucide-react';
import { AutoQuoteCard } from './components/AutoQuoteCard';
import heroImage from '@/assets/janine-car-hero.jpg';
import svgPaths from '@/imports/svg-oxxrh33vi2';
import svgPaths2 from '@/imports/svg-j13ig5jkrp';
import svgPaths3 from '@/imports/svg-pubmwjii9z';
import { imgGroup, imgGroup1, imgGroup2, imgGroup3, imgGroup4, imgGroup5, imgGroup6, imgGroup7, imgGroup8, imgGroup9, imgGroup10, imgGroup11, imgGroup12, imgGroup13 } from '@/imports/svg-dyqrd';
import imgGoogleLogo from 'figma:asset/ccc4cb9d838d770d66acfbb49291ab7964e6d3d0.png';
import imgMomAndDaughterViewingDentInBlueCar from 'figma:asset/436e396f7a88e87509562a5646d24fd0058c6411.png';
import imgHappyManDrivingACar from 'figma:asset/ebaafa789d8152a2592a98b92db4c12b6d3a4d85.png';
import imgAHappyFamilyThatJustLearnedHowMuchHomeownersInsuranceTheyNeed from 'figma:asset/d68da8f121807ba50112ea8edb9ba25d7d6c7a83.png';
import imgPersonShovelingSnow from 'figma:asset/47bb653b811563bd0bae5d4439b5e37f0cd80e6f.png';
import imgQrCode from 'figma:asset/ba7531f1548862274299a2f807225786071f163e.png';
import imgComponent1 from 'figma:asset/434cffd530251e01e0484e78b2055415bdc6c51d.png';
import imgVector from 'figma:asset/01c9d9edba045c99fdffb4cb7f8ed8ce5b3db1a7.png';
import imgSkyline from 'figma:asset/343919a8e50e8b781947caf6937d1dd9ba6a1d0e.png';

function PlymouthRockLogo() {
  return (
    <div className="h-[32px] w-[152px] sm:h-[40px] sm:w-[190px] relative">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 187.253 35.5756">
        <g>
          <path d={svgPaths.p2829fd00} fill="white" />
          <g>
            <path d={svgPaths.p31c5ed00} fill="white" />
            <path d={svgPaths.pa462600} fill="white" />
            <path d={svgPaths.p2b7bbf80} fill="white" />
            <path d={svgPaths.pe866980} fill="white" />
            <path d={svgPaths.p28a33100} fill="white" />
            <path d={svgPaths.pf44700} fill="white" />
            <path d={svgPaths.p15534000} fill="white" />
            <path d={svgPaths.p990f280} fill="white" />
            <path d={svgPaths.p36593600} fill="white" />
            <path d={svgPaths.p2b859500} fill="white" />
            <path d={svgPaths.p32240a00} fill="white" />
            <path d={svgPaths.p17aea80} fill="white" />
          </g>
          <g>
            <path d={svgPaths.p324d5d80} fill="white" />
            <path d={svgPaths.p28e61580} fill="white" />
            <path d={svgPaths.p1251d900} fill="white" />
            <path d={svgPaths.p7875900} fill="white" />
            <path d={svgPaths.p281992} fill="white" />
            <path d={svgPaths.p1b154600} fill="white" />
            <path d={svgPaths.p20b83500} fill="white" />
            <path d={svgPaths.p14fabe00} fill="white" />
            <path d={svgPaths.p2c14c2d0} fill="white" />
          </g>
          <g>
            <path d={svgPaths.p3fb4fc80} fill="white" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function SearchIcon() {
  return (
    <svg className="w-[21px] h-[21px]" fill="none" viewBox="0 0 21 21">
      <g clipPath="url(#clip0)">
        <path d={svgPaths.p2f974b00} fill="white" />
      </g>
      <defs>
        <clipPath id="clip0">
          <rect fill="white" height="21" width="21" />
        </clipPath>
      </defs>
    </svg>
  );
}

function UserIcon() {
  return (
    <svg className="w-[14px] h-[15.859px]" fill="none" viewBox="0 0 14 15.8594">
      <path d={svgPaths.p3e4bbf00} fill="black" />
    </svg>
  );
}

function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="w-full">
      {/* Top Navigation */}
      <div className="bg-[#0078d6] h-[70px] w-full">
        <div className="max-w-[1280px] mx-auto px-4 h-full flex items-center justify-between">
          {/* Menu Icon */}
          <button className="text-white p-2">
            <div className="w-6 h-0.5 bg-white mb-1"></div>
            <div className="w-6 h-0.5 bg-white mb-1"></div>
            <div className="w-6 h-0.5 bg-white"></div>
          </button>

          {/* Logo */}
          <a href="/" className="flex-1 flex justify-center md:justify-start md:ml-8">
            <PlymouthRockLogo />
          </a>

          {/* Right Section */}
          <div className="flex items-center gap-4">
            <button className="text-white hover:opacity-80 transition-opacity">
              <SearchIcon />
            </button>
            <a href="tel:844-242-3555" className="hidden md:block text-white underline text-[16px] font-medium hover:opacity-80">
              844-242-3555
            </a>
            <a
              href="/login"
              className="bg-[#ff7826] hover:bg-[#ff6610] transition-colors text-black px-4 py-1.5 rounded-full shadow-lg flex items-center gap-2"
            >
              <UserIcon />
              <span className="text-[14px] font-medium">Log in</span>
            </a>
          </div>
        </div>
      </div>

      {/* Secondary Navigation */}
      <div className="bg-[#0351aa] py-3">
        <div className="max-w-[1075px] mx-auto px-4 flex items-center justify-center gap-3 sm:gap-8">
          <a href="#quickpay" className="text-white text-[14px] sm:text-[16px] font-semibold underline hover:opacity-80 transition-opacity whitespace-nowrap">
            Quick pay
          </a>
          <a href="#claims" className="text-white text-[14px] sm:text-[16px] font-semibold underline hover:opacity-80 transition-opacity whitespace-nowrap">
            Claims center
          </a>
          <a href="#manage" className="text-white text-[14px] sm:text-[16px] font-semibold underline hover:opacity-80 transition-opacity whitespace-nowrap">
            Manage policy
          </a>
        </div>
      </div>
    </header>
  );
}

function AutoIcon() {
  return (
    <svg className="w-[38px] h-[38px]" fill="none" viewBox="0 0 38 38">
      <path d={svgPaths.p38ef4f00} fill="#D3E5F9" stroke="#0078D6" strokeMiterlimit="10" strokeWidth="0.883721" />
      <path d={svgPaths.p1c957400} stroke="#0078D6" strokeMiterlimit="10" strokeWidth="0.883721" />
      <path d={svgPaths.p293dc280} fill="#A7CAF2" stroke="#0078D6" strokeMiterlimit="10" strokeWidth="0.883721" />
      <path d={svgPaths.p1b5b3a40} fill="white" stroke="#0078D6" strokeMiterlimit="10" strokeWidth="0.883721" />
      <path d={svgPaths.p1867b800} fill="white" stroke="#0078D6" strokeMiterlimit="10" strokeWidth="0.883721" />
      <path d="M14.4931 24.4188H24.4111" stroke="#0078D6" strokeLinecap="round" strokeMiterlimit="10" strokeWidth="0.883721" />
      <path d="M14.4931 22.0704H24.4111" stroke="#0078D6" strokeLinecap="round" strokeMiterlimit="10" strokeWidth="0.883721" />
    </svg>
  );
}

function HomeIcon() {
  return (
    <svg className="w-[34px] h-[34px]" fill="none" viewBox="0 0 34 34">
      <path d={svgPaths.p59fca00} fill="#D3E5F9" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p21edd200} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.pb865700} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p11bf180} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p1fb9a080} fill="#A7CAF2" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p21c42b00} fill="#A7CAF2" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
    </svg>
  );
}

function CondoIcon() {
  return (
    <svg className="w-[34px] h-[34px]" fill="none" viewBox="0 0 34 34">
      <path d={svgPaths.p2ccc1b80} fill="#D3E5F9" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p32b89d32} fill="#D3E5F9" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p199e7880} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p1995b100} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p31c64b00} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p1fb38e00} fill="#A7CAF2" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p18835bf0} fill="#A7CAF2" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p393a3f00} fill="#A7CAF2" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p23653570} fill="#A7CAF2" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
    </svg>
  );
}

function RentersIcon() {
  return (
    <svg className="w-[34px] h-[34px]" fill="none" viewBox="0 0 34 34">
      <path d={svgPaths.p15170700} fill="#D3E5F9" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p7963680} fill="#D3E5F9" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p109225b0} fill="#D3E5F9" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p3c538100} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p2c43c100} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p2abb3b00} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p98d1580} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p2267c500} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p183d06c0} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.pff6e800} fill="#A7CAF2" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p259929f0} fill="#A7CAF2" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p21453000} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p27b6e300} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p180ded00} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p8f7e000} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p374b3580} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
      <path d={svgPaths.p2e52a900} fill="white" stroke="#0078D6" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
    </svg>
  );
}

function ArrowIcon() {
  return (
    <svg className="w-[16px] h-[16px]" fill="none" viewBox="0 0 16 16">
      <path d={svgPaths.p22fb9200} fill="#0078D6" />
    </svg>
  );
}

function LocationIcon() {
  return (
    <svg className="w-[22px] h-[21.328px]" fill="none" viewBox="0 0 22 21.3281">
      <path d={svgPaths.p1d4ad700} fill="#0067B7" stroke="#0067B7" strokeWidth="0.666503" />
    </svg>
  );
}

function InsuranceButton({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className="bg-white border border-[#ff7826] rounded-2xl px-1 py-3 w-[80px] sm:w-[90px] flex flex-col items-center gap-1 hover:shadow-lg hover:scale-105 transition-all duration-200"
    >
      {icon}
      <span className="text-[12px] sm:text-[14px] font-semibold text-black">{label}</span>
    </button>
  );
}

function QuoteCard({ address, firstName }: { address: string; firstName?: string }) {
  const [selectedTab, setSelectedTab] = useState(0);
  
  const coverageOptions = [
    { name: 'Good Coverage', price: '$232/mo' },
    { name: 'Better Coverage', price: '$291/mo' },
    { name: 'Best Coverage', price: '$358/mo' }
  ];

  const coverageDetails = [
    { label: 'Dwelling', value: '$439,000', gray: false },
    { label: 'Personal Property - Increased Limits', value: '$219,500', gray: true },
    { label: 'Personal Liability', value: '$300,000', gray: false },
    { label: 'Medical Payments', value: '$1,000', gray: true },
    { label: 'Policy Deductible', value: '$2,500', gray: false }
  ];

  return (
    <div className="w-full border border-[#bec7d1] rounded-[30px] py-4 sm:py-6 bg-white">
      {/* Header */}
      <div className="px-3 sm:px-6 mb-4 sm:mb-6">
        <p className="font-['Manrope',sans-serif] text-[24px] sm:text-[32px] leading-[32px] sm:leading-[42px] text-[#0078d6] text-center">
          Hi {firstName || 'Joe'}, here's your home quote for
        </p>
        <p className="font-['Manrope',sans-serif] text-[16px] sm:text-[20px] leading-[24px] sm:leading-[28px] text-[rgba(0,0,0,0.6)] text-center mt-1 break-words">
          {address}
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-start justify-center mb-4 sm:mb-6 relative overflow-x-auto px-2">
        {coverageOptions.map((option, index) => (
          <button
            key={index}
            onClick={() => setSelectedTab(index)}
            className={`px-2 sm:px-4 py-2 text-center relative whitespace-nowrap flex-shrink-0 ${
              selectedTab === index
                ? 'font-["Open_Sans",sans-serif] font-bold text-[#0078d6]'
                : 'font-["Open_Sans",sans-serif] text-[rgba(0,0,0,0.6)]'
            }`}
          >
            <div className="text-[14px] sm:text-[16px] leading-[20px] sm:leading-[22px]">
              {option.name}
              <br />
              {option.price}
            </div>
            {selectedTab === index && (
              <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#0078d6]" />
            )}
          </button>
        ))}
      </div>

      {/* Coverage Details */}
      <div className="px-3 sm:px-6 mb-4 sm:mb-6">
        <p className="font-['Manrope',sans-serif] text-[18px] sm:text-[20px] leading-[26px] sm:leading-[28px] text-black text-center mb-4">
          {coverageOptions[selectedTab].name} includes:
        </p>
        
        <div className="w-full max-w-[450px] mx-auto">
          {coverageDetails.map((detail, index) => (
            <div
              key={index}
              className={`flex items-center justify-between py-1.5 gap-2 ${
                detail.gray ? 'bg-[#f8f8fa]' : 'bg-white'
              }`}
            >
              <div className="flex items-center flex-1 min-w-0 pr-2">
                <p className="font-['Open_Sans',sans-serif] text-[14px] sm:text-[16px] leading-[22px] sm:leading-[26px] text-black flex-1 break-words">
                  {detail.label}
                </p>
                {/* <ChevronDown className="w-5 h-5 sm:w-6 sm:h-6 text-black ml-1 sm:ml-2 flex-shrink-0" /> */}
              </div>
              <p className="font-['Open_Sans',sans-serif] text-[14px] sm:text-[16px] leading-[22px] sm:leading-[26px] text-black text-right min-w-[85px] sm:min-w-[109px] flex-shrink-0">
                {detail.value}
              </p>
            </div>
          ))}
          <p className="font-['Open_Sans',sans-serif] text-[11px] sm:text-[12px] leading-[13px] sm:leading-[14px] text-black text-center mt-2">
            Quote Number: MAHQ0005151311
          </p>
        </div>
      </div>

      {/* Continue Button */}
      <div className="px-3 sm:px-6 flex justify-center">
        <button className="bg-[#0078d6] hover:bg-[#0066bb] transition-colors text-white px-4 sm:px-5 py-2.5 sm:py-3 rounded-[32px] font-['Open_Sans',sans-serif] text-[16px] sm:text-[18px] leading-[26px] sm:leading-[30px] w-full max-w-[280px]">
          Continue to purchase
        </button>
      </div>
    </div>
  );
}

function PaymentCard() {
  return (
    <div className="w-full border border-[#bec7d1] rounded-[30px] py-6 sm:py-9 bg-white flex flex-col gap-6 sm:gap-9 items-center px-3">
      {/* Header */}
      <p className="font-['Manrope',sans-serif] text-[28px] sm:text-[32px] leading-[38px] sm:leading-[42px] text-[#0078d6] text-center">
        Your next payment
      </p>
      
      {/* Amount and Date */}
      <div className="flex flex-col items-center text-center">
        <p className="font-['Manrope',sans-serif] text-[36px] sm:text-[44px] leading-[48px] sm:leading-[56px] text-black">
          $252.00
        </p>
        <p className="font-['Manrope',sans-serif] text-[18px] sm:text-[20px] leading-[26px] sm:leading-[28px] text-black">
          Is due on 04/14/2026
        </p>
      </div>
      
      {/* Buttons */}
      <div className="flex flex-col gap-2 items-center w-full">
        <button className="bg-[#0078d6] hover:bg-[#0066bb] transition-colors text-white px-5 py-3 rounded-[32px] font-['Open_Sans',sans-serif] text-[16px] sm:text-[18px] leading-[26px] sm:leading-[30px] w-full max-w-[244px]">
          Pay Now
        </button>
        <button className="text-[#0078d6] hover:opacity-80 transition-opacity px-3 py-2 font-['Open_Sans',sans-serif] text-[16px] sm:text-[18px] leading-[26px] sm:leading-[30px] text-center">
          Enable automatic payments
        </button>
      </div>
    </div>
  );
}

function PolicyCard() {
  return (
    <div className="w-full border border-[#0078d6] rounded-[12px] bg-[#f5faff] px-4 sm:px-8 md:px-12 py-4 sm:py-5">
      <div className="flex flex-col gap-1.5">
        <p className="font-['Open_Sans',sans-serif] text-[14px] sm:text-[16px] leading-[20px] sm:leading-[22px] text-black break-words">
          <span className="font-bold">Policy# </span>
          <span>MAH00008014258</span>
        </p>
        <p className="font-['Open_Sans',sans-serif] text-[14px] sm:text-[16px] leading-[22px] sm:leading-[25px] text-black break-words">
          <span className="font-bold">Home Address: </span>
          <span>30 Main St, Boston, MA 02130</span>
        </p>
      </div>
    </div>
  );
}

function HeroSection() {
  const [messages, setMessages] = useState<Array<{ text: string; isUser: boolean; type?: string; address?: string; firstName?: string; quoteType?: 'home' | 'auto' }>>([]);
  const [inputValue, setInputValue] = useState('');
  const [conversationStage, setConversationStage] = useState(0);
  const [quoteData, setQuoteData] = useState({ fullName: '', firstName: '', dob: '', address: '' });
  const [quoteStep, setQuoteStep] = useState(0); // 0: not started, 1: asked for name, 2: asked for dob, 3: asked for address
  const [quoteType, setQuoteType] = useState<'home' | 'auto'>('home'); // Track which type of quote
  const [isRecording, setIsRecording] = useState(false);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    // Add user message
    const newMessages = [...messages, { text: inputValue, isUser: true }];
    setMessages(newMessages);
    setInputValue('');

    // Check for quote request at any time (only if not already in quote flow)
    const lowerInput = inputValue.toLowerCase();
    const isAutoQuote = lowerInput.includes('auto') || lowerInput.includes('car');
    const isHomeQuote = lowerInput.includes('home insurance') || (lowerInput.includes('quote') && !isAutoQuote);
    
    if ((isHomeQuote || isAutoQuote) && conversationStage !== 1) {
      setTimeout(() => {
        setQuoteType(isAutoQuote ? 'auto' : 'home');
        
        // Check if we already have all the required information
        if (quoteData.fullName && quoteData.firstName && quoteData.dob && quoteData.address) {
          // We have all info, show quote directly
          const exampleQuestion = isAutoQuote 
            ? 'What does Bodily Injury mean?' 
            : 'What does Dwelling mean?';
          
          setMessages([
            ...newMessages,
            {
              text: 'Thank you, I got a quote for you from Plymouth Rock Assurance',
              isUser: false
            },
            {
              text: '',
              isUser: false,
              type: 'quote',
              address: quoteData.address,
              firstName: quoteData.firstName,
              quoteType: isAutoQuote ? 'auto' : 'home'
            },
            {
              text: `Here is your quote, you can continue to buy your policy. Would you like me to go over any details with you? For example, you can ask me ${exampleQuestion}`,
              isUser: false
            }
          ]);
          setConversationStage(2);
        } else if (quoteData.fullName && quoteData.firstName) {
          // We have name, check what else we need
          if (quoteData.dob) {
            // We have name and DOB, check if we also have address
            if (quoteData.address) {
              // We have everything, show quote
              const exampleQuestion = isAutoQuote 
                ? 'What does Bodily Injury mean?' 
                : 'What does Dwelling mean?';
              
              setMessages([
                ...newMessages,
                {
                  text: 'Thank you, I got a quote for you from Plymouth Rock Assurance',
                  isUser: false
                },
                {
                  text: '',
                  isUser: false,
                  type: 'quote',
                  address: quoteData.address,
                  firstName: quoteData.firstName,
                  quoteType: isAutoQuote ? 'auto' : 'home'
                },
                {
                  text: `Here is your quote, you can continue to buy your policy. Would you like me to go over any details with you? For example, you can ask me ${exampleQuestion}`,
                  isUser: false
                }
              ]);
              setConversationStage(2);
            } else {
              // We have name and DOB, but need address
              setMessages([
                ...newMessages,
                {
                  text: 'What is your street address?',
                  isUser: false
                }
              ]);
              setConversationStage(1);
              setQuoteStep(3); // Waiting for address
            }
          } else {
            setMessages([
              ...newMessages,
              {
                text: 'What is your date of birth? (MM/DD/YYYY)',
                isUser: false
              }
            ]);
            setConversationStage(1);
            setQuoteStep(2); // Waiting for DOB
          }
        } else {
          // We don't have name, start from beginning
          setMessages([
            ...newMessages,
            {
              text: 'Sure, I can get that for you. Can you please tell me your full name?',
              isUser: false
            }
          ]);
          setConversationStage(1);
          setQuoteStep(1); // Waiting for name
        }
      }, 500);
      return;
    }

    // Check for bill/payment request at any time
    if (inputValue.toLowerCase().includes('bill') || inputValue.toLowerCase().includes('payment') || inputValue.toLowerCase().includes('pay')) {
      setTimeout(() => {
        setMessages([
          ...newMessages,
          {
            text: `Hi ${quoteData.firstName || 'Joe'}! Sure, I checked your account and found this billing statement:`,
            isUser: false
          },
          {
            text: '',
            isUser: false,
            type: 'payment'
          },
          {
            text: 'Would you like to make a payment today?',
            isUser: false
          }
        ]);
        setConversationStage(3);
      }, 500);
      return;
    }

    // Check for claim request at any time
    if (inputValue.toLowerCase().includes('claim')) {
      setTimeout(() => {
        setMessages([
          ...newMessages,
          {
            text: `Hi ${quoteData.firstName || 'Joe'}! Sure, I can help you. First make sure you are in a safe place.
If you need medical attention or emergency services (ambulance, fire, etc.) please **call 911.**`,
            isUser: false
          },
          {
            text: '',
            isUser: false,
            type: 'policy'
          }
        ]);
        setConversationStage(4);
      }, 500);
      return;
    }

    // Handle stage-specific responses
    if (conversationStage === 1) {
      // Handle multi-step quote information collection
      if (quoteStep === 1) {
        // User just provided their name
        setTimeout(() => {
          const firstName = inputValue.trim().split(' ')[0]; // Extract first word as first name
          setQuoteData({ ...quoteData, fullName: inputValue, firstName });
          setMessages([
            ...newMessages,
            {
              text: 'What is your date of birth? (MM/DD/YYYY)',
              isUser: false
            }
          ]);
          setQuoteStep(2); // Now waiting for DOB
        }, 500);
      } else if (quoteStep === 2) {
        // User just provided their DOB
        setTimeout(() => {
          const updatedQuoteData = { ...quoteData, dob: inputValue };
          setQuoteData(updatedQuoteData);
          
          // Check if we already have an address
          if (quoteData.address) {
            // We have address, show quote directly
            const exampleQuestion = quoteType === 'auto' 
              ? 'What does Bodily Injury mean?' 
              : 'What does Dwelling mean?';
            
            setMessages([
              ...newMessages,
              {
                text: 'Thank you, I got a quote for you from Plymouth Rock Assurance',
                isUser: false
              },
              {
                text: '',
                isUser: false,
                type: 'quote',
                address: quoteData.address,
                firstName: quoteData.firstName,
                quoteType: quoteType
              },
              {
                text: `Here is your quote, you can continue to buy your policy. Would you like me to go over any details with you? For example, you can ask me ${exampleQuestion}`,
                isUser: false
              }
            ]);
            setConversationStage(2);
            setQuoteStep(0); // Reset quote step
          } else {
            // Don't have address, ask for it
            setMessages([
              ...newMessages,
              {
                text: 'What is your street address?',
                isUser: false
              }
            ]);
            setQuoteStep(3); // Now waiting for address
          }
        }, 500);
      } else if (quoteStep === 3) {
        // User just provided their address - show quote
        setTimeout(() => {
          const address = inputValue || '30 Main St, Boston, MA 02130';
          setQuoteData({ ...quoteData, address: address }); // Save address to state
          
          const exampleQuestion = quoteType === 'auto' 
            ? 'What does Bodily Injury mean?' 
            : 'What does Dwelling mean?';
          
          setMessages([
            ...newMessages,
            {
              text: 'Thank you, I got a quote for you from Plymouth Rock Assurance',
              isUser: false
            },
            {
              text: '',
              isUser: false,
              type: 'quote',
              address: address,
              firstName: quoteData.firstName,
              quoteType: quoteType
            },
            {
              text: `Here is your quote, you can continue to buy your policy. Would you like me to go over any details with you? For example, you can ask me ${exampleQuestion}`,
              isUser: false
            }
          ]);
          setConversationStage(2);
          setQuoteStep(0); // Reset quote step
        }, 500);
      }
    } else if (conversationStage === 2) {
      // User is asking questions about the quote
      const lowerInput = inputValue.toLowerCase();
      if (lowerInput.includes('dwelling')) {
        setTimeout(() => {
          setMessages([
            ...newMessages,
            {
              text: 'A **Dwelling** is a physical structure. The policy coverage protects you against damages to the physical structure of your home, as well as attached structures like a garage or deck. It also covers permanently installed systems like plumbing and wiring.',
              isUser: false
            },
            {
              text: 'Is there anything else I could help you with?',
              isUser: false
            }
          ]);
        }, 500);
      } else if (lowerInput.includes('bodily injury')) {
        setTimeout(() => {
          setMessages([
            ...newMessages,
            {
              text: '**Bodily injury liability** coverage helps pay for medical expenses, lost wages, and legal fees if you cause an accident that injures someone else. This is a required coverage in most states and helps protect you financially if you\'re found at fault for an accident.',
              isUser: false
            },
            {
              text: 'Is there anything else I could help you with?',
              isUser: false
            }
          ]);
        }, 500);
      } else if (lowerInput.includes('property damage')) {
        setTimeout(() => {
          setMessages([
            ...newMessages,
            {
              text: '**Property damage liability** coverage helps pay for repairs if you damage someone else\'s property with your vehicle. This could include another car, a fence, a building, or other structures. Like bodily injury, this is typically required by law.',
              isUser: false
            },
            {
              text: 'Is there anything else I could help you with?',
              isUser: false
            }
          ]);
        }, 500);
      }
    } else if (conversationStage === 3) {
      // Payment flow - user confirming payment
      if (inputValue.toLowerCase().includes('yes') || inputValue.toLowerCase().includes('bank account')) {
        setTimeout(() => {
          setMessages([
            ...newMessages,
            {
              text: 'Great, I went ahead and charged your account.\n\nYour current bill of $252.00 was payed with your bank account ending on *2345. An email was also sent with a receipt.\\n\\nCan I assist you with anything else?',
              isUser: false
            }
          ]);
          setConversationStage(0); // Reset to allow new requests
        }, 500);
      }
    } else if (conversationStage === 4) {
      // Claim flow - user confirming claim
      if (inputValue.toLowerCase().includes('yes')) {
        setTimeout(() => {
          setMessages([
            ...newMessages,
            {
              text: 'Got it, please tell me what happened?',
              isUser: false
            }
          ]);
        }, 500);
      }
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  // Auto-scroll to bottom to show new messages when they appear
  useEffect(() => {
    if (scrollContainerRef.current && messages.length > 0) {
      // Use double requestAnimationFrame to ensure DOM is fully painted
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          if (scrollContainerRef.current) {
            scrollContainerRef.current.scrollTo({
              top: scrollContainerRef.current.scrollHeight,
              behavior: 'smooth'
            });
          }
        });
      });
    }
  }, [messages]);

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  const toggleRecording = () => {
    // Check if speech recognition is supported
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      alert('Speech recognition is not supported in your browser. Please try Chrome or Edge.');
      return;
    }

    if (isRecording) {
      // Stop recording
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsRecording(false);
    } else {
      // Initialize and start recording
      try {
        const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = false;
        recognitionRef.current.interimResults = false;
        recognitionRef.current.lang = 'en-US';

        recognitionRef.current.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          setInputValue(prev => (prev ? prev + ' ' + transcript : transcript));
        };

        recognitionRef.current.onerror = (event: any) => {
          console.error('Speech recognition error:', event.error);
          setIsRecording(false);

          if (event.error === 'not-allowed') {
            alert('Microphone access was denied. Please allow microphone access in your browser settings and try again.');
          } else if (event.error === 'no-speech') {
            // No speech detected, just stop silently
          } else {
            alert('Speech recognition error: ' + event.error);
          }
        };

        recognitionRef.current.onend = () => {
          setIsRecording(false);
        };

        recognitionRef.current.start();
        setIsRecording(true);
      } catch (error) {
        console.error('Failed to start speech recognition:', error);
        setIsRecording(false);
        alert('Failed to start speech recognition. Please try again.');
      }
    }
  };

  return (
    <div className="relative w-full overflow-hidden">
      {/* Background Image - Center aligned to 85% of viewport width */}
      <div className="absolute left-0 top-0 w-full h-full overflow-hidden pointer-events-none">
        <img src={heroImage} alt="" className="h-full w-full object-cover object-center" />
      </div>

      {/* Content */}
      <div className="relative max-w-[1240px] mx-auto px-2 sm:px-4 py-8 sm:py-12 bg-transparent">
        <div className={`${messages.length > 0 ? 'w-[96vw] min-[1160px]:w-[90vw] max-w-[1168px] p-3 sm:p-4 md:p-6 min-h-[300px] sm:min-h-[500px] max-h-[690px] shadow-lg' : 'max-w-[550px] p-3 sm:p-4 md:p-6'} bg-white/100 backdrop-blur-sm rounded-[20px] flex flex-col transition-all duration-300`}>
          {/* Heading and Chat Messages - Scrollable Area */}
          <div ref={scrollContainerRef} className={`flex-1 overflow-y-auto px-1 sm:px-2 pb-4 min-h-0 ${messages.length > 0 ? 'w-[90vw] max-w-[900px] mx-auto' : 'max-w-[900px]'}`}>
            <div className={`${messages.length > 0 ? 'mb-4 sm:mb-6 md:mb-9' : 'mb-3 sm:mb-4 md:mb-6'}`}>
              <h1 className={`${messages.length > 0 ? 'text-[24px] sm:text-[32px] md:text-[44px] leading-[32px] sm:leading-[42px] md:leading-[56px] text-center' : 'text-[28px] sm:text-[36px] md:text-[48px] leading-[36px] sm:leading-[48px] md:leading-[60px]'} font-['Manrope',sans-serif] text-black transition-all duration-300`}>
                Insurance built for the Northeast.
              </h1>
            </div>

            {/* Chat Messages */}
            {messages.length > 0 && (
              <div className="space-y-4 sm:space-y-6 pb-4 sm:pb-6">
                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
                  >
                    {message.isUser ? (
                      // User message - right aligned with gray background
                      <div className="bg-[#eff1f3] max-w-[90%] sm:max-w-[536px] px-3 sm:px-4 py-2.5 sm:py-3 rounded-2xl">
                        <p className="font-['Open_Sans',sans-serif] leading-[24px] sm:leading-[26px] text-[14px] sm:text-[16px] text-black break-words">
                          {message.text}
                        </p>
                      </div>
                    ) : message.type === 'quote' ? (
                      // Quote card
                      <div className="w-full">
                        {message.quoteType === 'auto' ? (
                          <div className="max-w-[900px]">
                          <AutoQuoteCard firstName={message.firstName} />
                        </div>
                        ) : (
                          <QuoteCard address={message.address || '31 Marion St, Natick, MA 01760'} firstName={message.firstName} />
                        )}
                      </div>
                    ) : message.type === 'payment' ? (
                      // Payment card
                      <div className="w-full">
                        <PaymentCard />
                      </div>
                    ) : message.type === 'policy' ? (
                      // Policy card
                      <div className="w-full">
                        <PolicyCard />
                        <p className="font-['Open_Sans',sans-serif] text-[16px] leading-[26px] text-black mt-4">
                          Is this the home you would like to make a claim for?
                        </p>
                      </div>
                    ) : (
                      // Bot message - left aligned, full width
                      <div className="w-full">
                        <div className="font-['Open_Sans',sans-serif] text-[16px] text-black">
                          {message.text.split('\n').map((line, i) => {
                            if (line.startsWith('•')) {
                              return (
                                <li key={i} className="ml-6 mb-1">
                                  <span className="font-bold">{line.substring(1).trim()}</span>
                                </li>
                              );
                            }
                            // Check if this is the payment confirmation message
                            if (line.includes('Your current bill of') && line.includes('was payed')) {
                              return (
                                <div key={i} className="mb-2">
                                  <div className="w-full border border-[#0078d6] rounded-[12px] bg-[#f5faff] px-4 sm:px-8 md:px-12 py-4 sm:py-5 mb-4">
                                    <p className="font-['Open_Sans',sans-serif] text-[14px] sm:text-[16px] leading-[20px] sm:leading-[22px] text-black break-words">
                                      Your current bill of <b>$252.00</b> was paid with your bank account ending on <b>*2345</b>. An email was also sent with a receipt.
                                    </p>
                                  </div>
                                  <p className="leading-[26px]">Can I assist you with anything else?</p>
                                </div>
                              );
                            }
                            // Check if this is the follow-up question - skip it since it's now shown with the card above
                            if (line.includes('Can I assist you with anything else?')) {
                              return null;
                            }
                            // Parse bold text marked with **text**
                            const parts = line.split(/\*\*(.*?)\*\*/g);
                            return (
                              <p key={i} className="leading-[26px] mb-2">
                                {parts.map((part, partIndex) => {
                                  // Odd indices are the content inside **
                                  if (partIndex % 2 === 1) {
                                    return <span key={partIndex} className="font-bold">{part}</span>;
                                  }
                                  return part;
                                })}
                              </p>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Input Field with Icons - Sticky at Bottom */}
          <div className={`relative rounded-[96px] border border-[#bec7d1] bg-white mt-3 sm:mt-4 flex-shrink-0 ${messages.length > 0 ? 'w-[80vw] max-w-[900px] mx-auto' : 'max-w-[900px]'}`}>
            <div className="flex items-center justify-between px-1.5 sm:px-2 py-[6px]">
              {/* Text Input */}
              <div className="flex-1 px-3 sm:px-[18px] py-[6px]">
                <input
                  ref={inputRef}
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="How can we help you today?"
                  className="w-full bg-transparent border-none outline-none text-[14px] sm:text-[16px] font-['Open_Sans',sans-serif] text-black placeholder:text-[rgba(0,0,0,0.38)]"
                />
              </div>
              
              {/* Icon Buttons */}
              <div className="flex gap-[6px] items-center">
                {/* Microphone Icon Button */}
                <button
                  onClick={toggleRecording}
                  className={`p-[5px] rounded-full transition-colors ${
                    isRecording
                      ? 'bg-red-100 hover:bg-red-200'
                      : 'hover:bg-gray-100'
                  }`}
                >
                  <Mic className={`w-5 h-5 ${isRecording ? 'text-red-600' : 'text-black'}`} />
                </button>
                
                {/* Waveform Icon Button */}
                <button className="p-[5px] rounded-full hover:bg-gray-100 transition-colors">
                  <AudioLines className="w-5 h-5 text-black" />
                </button>
                
                {/* Send Icon Button */}
                <button
                  onClick={handleSendMessage}
                  className="p-2 rounded-full bg-[#0078d6] hover:bg-[#0066bb] transition-colors"
                >
                  <ArrowRight className="w-6 h-6 text-white" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ReviewCard({ rating, text, author }: { rating: number; text: string; author: string }) {
  return (
    <div className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex gap-0.5 mb-3">
        {[...Array(rating)].map((_, i) => (
          <svg key={i} className="w-5 h-5 fill-yellow-400" viewBox="0 0 24 24">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
          </svg>
        ))}
      </div>
      <p className="text-sm text-gray-700 mb-3 leading-relaxed">{text}</p>
      <p className="text-xs text-gray-500">Review by: <span className="font-semibold">{author}</span></p>
    </div>
  );
}

function TestimonialsSection() {
  const reviews = [
    {
      rating: 5,
      text: "All the coverage I need at a reasonable price.",
      author: "Judith P."
    },
    {
      rating: 4,
      text: "Quick, easy and the right price. No brainer.",
      author: "Scott S."
    },
    {
      rating: 5,
      text: "If you are shopping for a new insurance provider I highly suggest connecting with Amy at Plymouth Rock. She was eager to help transform my...",
      author: "Courtney S."
    },
    {
      rating: 5,
      text: "Love it no complaints",
      author: "Hector P."
    }
  ];

  return (
    <div className="bg-gray-50 py-8 sm:py-12">
      <div className="max-w-[1280px] mx-auto px-4">
        {/* Heading */}
        <div className="mb-6 sm:mb-8 text-center">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-2 flex-wrap">
            <h2 className="text-[20px] sm:text-[28px] md:text-[32px] leading-[28px] sm:leading-[38px] md:leading-[42px] text-black text-center">
              <span className="font-normal">Trusted by customers for </span>
              <span className="font-bold">40+ years.</span>
            </h2>
            <div className="flex items-center gap-2">
              <span className="text-[20px] sm:text-[28px] md:text-[32px] leading-[28px] sm:leading-[38px] md:leading-[42px] text-black font-normal">Read our</span>
              <img src={imgGoogleLogo} alt="Google" className="h-[28px] w-[90px] sm:h-[34px] sm:w-[110px] md:h-[38px] md:w-[122px] inline-block" />
              <span className="text-[20px] sm:text-[28px] md:text-[32px] leading-[28px] sm:leading-[38px] md:leading-[42px] text-black font-normal">reviews.</span>
            </div>
          </div>
        </div>

        {/* Review Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reviews.map((review, index) => (
            <ReviewCard key={index} {...review} />
          ))}
        </div>

        {/* Rating Summary */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-600">
            <span className="font-bold">4.1 out of 5</span> based on <span className="font-bold">2756</span> Google reviews as of <span className="font-bold">January 2026</span>
          </p>
        </div>
      </div>
    </div>
  );
}

function QuestionCard({ image, title, readTime, date }: { image: string; title: string; readTime: string; date: string }) {
  return (
    <a
      href="#"
      className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:scale-105"
    >
      <div className="relative h-[200px] overflow-hidden">
        <img src={image} alt={title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
      </div>
      <div className="p-5">
        <h3 className="text-lg font-bold text-gray-900 mb-3 group-hover:text-[#0078d6] transition-colors">{title}</h3>
        <p className="text-sm text-gray-500">
          {readTime} • {date}
        </p>
      </div>
    </a>
  );
}

function InsuranceQuestionsSection() {
  const questions = [
    {
      image: imgMomAndDaughterViewingDentInBlueCar,
      title: "Auto insurance basics",
      readTime: "6 minute read",
      date: "December 2025"
    },
    {
      image: imgHappyManDrivingACar,
      title: "Does paying off a car lower insurance?",
      readTime: "5 minute read",
      date: "April 2025"
    },
    {
      image: imgAHappyFamilyThatJustLearnedHowMuchHomeownersInsuranceTheyNeed,
      title: "How much homeowners insurance coverage do I need?",
      readTime: "6 minute read",
      date: "September 2025"
    },
    {
      image: imgPersonShovelingSnow,
      title: "Winter home maintenance checklist",
      readTime: "4 minute read",
      date: "December 2025"
    }
  ];

  return (
    <div className="bg-[#0078d6] py-12 sm:py-16">
      <div className="max-w-[1280px] mx-auto px-4">
        <h2 className="text-white text-center text-[24px] sm:text-[28px] md:text-[32px] font-normal leading-[32px] sm:leading-[38px] md:leading-[42px] mb-8 sm:mb-12">
          Find answers to your insurance questions.
        </h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {questions.map((question, index) => (
            <QuestionCard key={index} {...question} />
          ))}
        </div>
      </div>
    </div>
  );
}

function ForbesBadge() {
  return (
    <div className="h-[200px] w-[198px] sm:h-[240px] sm:w-[238px] md:h-[288px] md:w-[286px] relative mx-auto">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 306.207 307.832">
        <g>
          <path d={svgPaths2.p1321e800} fill="#0351AA" />
          <g filter="url(#filter0_d)">
            <path d={svgPaths2.p2cebd500} fill="white" />
          </g>
          <path d={svgPaths2.p28fb7700} fill="white" />
          <path d={svgPaths2.pc3036f0} fill="white" />
          <path d={svgPaths2.p2acc3c00} fill="white" />
          <path d={svgPaths2.p37e27680} fill="white" />
          <path d={svgPaths2.p390ab100} fill="white" />
          <path d={svgPaths2.p3a4c9c00} fill="white" />
          <path d={svgPaths2.p201a6bc0} fill="white" />
          <path d={svgPaths2.p27f8da00} fill="white" />
          <path d={svgPaths2.pb83ec00} fill="white" />
          <path d={svgPaths2.p228ee180} fill="white" />
          <path d={svgPaths2.p311e0900} fill="white" />
          <path d={svgPaths2.p3a2e3400} fill="white" />
          <path d={svgPaths2.pcd2f7c0} fill="white" />
          <path d={svgPaths2.p3fbdb200} fill="white" />
          <path d={svgPaths2.p94b1900} fill="white" />
          <path d={svgPaths2.p24904500} fill="white" />
          <path d={svgPaths2.p215a38f0} fill="white" />
          <path d={svgPaths2.p33956500} fill="white" />
          <path d={svgPaths2.p1805e5f0} fill="white" />
          <path clipRule="evenodd" d={svgPaths2.p2ed69c00} fill="white" fillRule="evenodd" />
          <path clipRule="evenodd" d={svgPaths2.p3248f80} fill="white" fillRule="evenodd" />
          <path clipRule="evenodd" d={svgPaths2.p2027acd1} fill="white" fillRule="evenodd" />
          <path clipRule="evenodd" d={svgPaths2.pe214a00} fill="white" fillRule="evenodd" />
          <path clipRule="evenodd" d={svgPaths2.p238c5000} fill="white" fillRule="evenodd" />
          <path clipRule="evenodd" d={svgPaths2.p31589440} fill="white" fillRule="evenodd" />
          <path d={svgPaths2.p2b10100} fill="#0351AA" />
          <path d={svgPaths2.p824ef00} fill="#0351AA" />
          <path d={svgPaths2.p388e1f00} fill="#0351AA" />
          <path d={svgPaths2.pa1e3b80} fill="#0351AA" />
          <path d={svgPaths2.p12959800} fill="white" />
          <path d={svgPaths2.p3baa180} fill="white" />
          <path d={svgPaths2.p2764d00} fill="white" />
          <path d={svgPaths2.p16436800} fill="white" />
          <path d={svgPaths2.p45b2a00} fill="white" />
          <path d={svgPaths2.p374630c0} fill="white" />
          <path d={svgPaths2.p2e0fd280} fill="white" />
          <path d={svgPaths2.p3f280200} fill="white" />
          <path d={svgPaths2.p29f72e00} fill="white" />
          <path d={svgPaths2.p31daf780} fill="white" />
          <path d={svgPaths2.p26e6c900} fill="white" />
          <path d={svgPaths2.p3a06c80} fill="white" />
          <path d={svgPaths2.pdd54c00} fill="white" />
          <path d={svgPaths2.p2933ba00} fill="white" />
          <path d={svgPaths2.p5389400} fill="white" />
          <path d={svgPaths2.p32142e80} fill="white" />
          <path d={svgPaths2.p3212f280} fill="white" />
          <path d={svgPaths2.p2761f000} fill="white" />
          <path d={svgPaths2.p41c580} fill="white" />
          <path d={svgPaths2.p3540d8f0} fill="white" />
          <path d={svgPaths2.p95c5500} fill="white" />
          <path d={svgPaths2.p174f2200} fill="white" />
          <path d={svgPaths2.p392b0580} fill="white" />
          <path d={svgPaths2.p3aff1da0} fill="white" />
          <path d={svgPaths2.p1d318980} fill="white" />
          <path d={svgPaths2.p3552000} fill="white" />
          <path d={svgPaths2.p12e74500} fill="white" />
          <path d={svgPaths2.p6320900} fill="white" />
          <path d={svgPaths2.p15954a00} fill="white" />
          <path d={svgPaths2.p1b30bf00} fill="white" />
          <path d={svgPaths2.pf169580} fill="white" />
        </g>
        <defs>
          <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="307.832" id="filter0_d" width="306.207" x="0" y="0">
            <feFlood floodOpacity="0" result="BackgroundImageFix" />
            <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
            <feOffset dy="8" />
            <feGaussianBlur stdDeviation="12" />
            <feComposite in2="hardAlpha" operator="out" />
            <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.35 0" />
            <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow" />
            <feBlend in="SourceGraphic" in2="effect1_dropShadow" mode="normal" result="shape" />
          </filter>
        </defs>
      </svg>
    </div>
  );
}

function CheckmarkIcon() {
  return (
    <svg className="w-[14px] h-[14px]" fill="none" viewBox="0 0 14 14">
      <path d={svgPaths2.p2cc61300} fill="#2F76BC" />
      <path d={svgPaths2.p1b68d100} fill="white" />
    </svg>
  );
}

function ThreeReasonsSection() {
  return (
    <div className="bg-[#eff6fd] py-12 sm:py-16">
      <div className="max-w-[1280px] mx-auto px-4">
        {/* Heading */}
        <h2 className="text-[24px] sm:text-[28px] md:text-[32px] leading-[32px] sm:leading-[38px] md:leading-[42px] text-center text-black mb-8 sm:mb-12">
          <span className="font-bold">3 top reasons</span>
          <span className="font-normal"> to choose Plymouth Rock for your insurance.</span>
        </h2>

        {/* Content Grid */}
        <div className="max-w-[1175px] mx-auto flex flex-col lg:flex-row gap-6 sm:gap-8">
          {/* Forbes Badge */}
          <div className="flex justify-center lg:w-[470px]">
            <ForbesBadge />
          </div>

          {/* Reasons Cards */}
          <div className="flex-1 space-y-4">
            {/* Reason 1 */}
            <div className="bg-white rounded-[30px] p-4 sm:p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex gap-4 sm:gap-6">
                <div className="bg-[#e9f2fc] rounded-full w-[40px] h-[40px] sm:w-[45px] sm:h-[45px] flex items-center justify-center flex-shrink-0">
                  <span className="text-[#0351aa] text-[24px] sm:text-[28px] font-bold">1</span>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-[16px] sm:text-[18px] font-bold text-black mb-2 sm:mb-3">
                    Services you won't find anywhere else.
                  </h3>
                  <div className="text-[14px] sm:text-[16px] text-black space-y-2">
                    <p className="break-words">
                      <a href="#" className="text-[#0078d6] underline hover:opacity-80">Crashbusters</a>
                      {" "}Tell us when and where you'd like us to meet you to inspect your damaged vehicle.<sup>1</sup>
                    </p>
                    <p className="break-words">
                      <a href="#" className="text-[#0078d6] underline hover:opacity-80">Door to Door Valet Service</a>
                      {" "}We handle the claims repair process for you.<sup>1</sup>
                    </p>
                    <p className="break-words">
                      <a href="#" className="text-[#0078d6] underline hover:opacity-80">Get Home Safe</a>
                      {" "}We pay for your taxi ride as a safer alternative to driving.<sup>2</sup>
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Reason 2 */}
            <div className="bg-white rounded-[30px] p-4 sm:p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex gap-4 sm:gap-6">
                <div className="bg-[#e9f2fc] rounded-full w-[40px] h-[40px] sm:w-[45px] sm:h-[45px] flex items-center justify-center flex-shrink-0">
                  <span className="text-[#0351aa] text-[24px] sm:text-[28px] font-bold">2</span>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-[16px] sm:text-[18px] font-bold text-black mb-2 sm:mb-3">
                    Smart coverage. Even smarter savings.
                  </h3>
                  <p className="text-[14px] sm:text-[16px] text-black break-words">
                    We offer{" "}
                    <a href="#" className="text-[#0078d6] underline hover:opacity-80">Auto Insurance</a>
                    {" "}and{" "}
                    <a href="#" className="text-[#0078d6] underline hover:opacity-80">Home Insurance</a>
                    {" "}to meet your needs, as well as{" "}
                    <a href="#" className="text-[#0078d6] underline hover:opacity-80">discounts</a>
                    {" "}and exclusive policyholder perks to help you save more.​
                  </p>
                </div>
              </div>
            </div>

            {/* Reason 3 */}
            <div className="bg-white rounded-[30px] p-4 sm:p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex gap-4 sm:gap-6">
                <div className="bg-[#e9f2fc] rounded-full w-[40px] h-[40px] sm:w-[45px] sm:h-[45px] flex items-center justify-center flex-shrink-0">
                  <span className="text-[#0351aa] text-[24px] sm:text-[28px] font-bold">3</span>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-[16px] sm:text-[18px] font-bold text-black mb-2 sm:mb-3">
                    Support that goes beyond insurance.
                  </h3>
                  <p className="text-[14px] sm:text-[16px] text-black break-words">
                    For more than 40 years, we've helped drivers across the Northeast with dependable support when it counts.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function GoMobileSection() {
  return (
    <div className="bg-white py-12 sm:py-16">
      <div className="max-w-[1280px] mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-8 sm:gap-12 items-center">
          {/* Left Content */}
          <div>
            <h2 className="text-[24px] sm:text-[28px] md:text-[32px] leading-[36px] sm:leading-[40px] md:leading-[45px] font-normal text-black mb-4 sm:mb-6">
              Go mobile.
            </h2>
            
            <h3 className="text-[14px] sm:text-[16px] font-bold text-black mb-3 sm:mb-4">
              Manage your insurance policy:
            </h3>

            <div className="space-y-2 sm:space-y-3 mb-6 sm:mb-8">
              <div className="flex items-center gap-2 sm:gap-3">
                <CheckmarkIcon />
                <span className="text-[14px] sm:text-[16px] text-black">View auto insurance ID cards</span>
              </div>
              <div className="flex items-center gap-2 sm:gap-3">
                <CheckmarkIcon />
                <span className="text-[14px] sm:text-[16px] text-black">Update your policy</span>
              </div>
              <div className="flex items-center gap-2 sm:gap-3">
                <CheckmarkIcon />
                <span className="text-[14px] sm:text-[16px] text-black">Schedule payments</span>
              </div>
              <div className="flex items-center gap-2 sm:gap-3">
                <CheckmarkIcon />
                <span className="text-[14px] sm:text-[16px] text-black">Manage claims</span>
              </div>
            </div>

            <div className="space-y-3 sm:space-y-4">
              <p className="text-[14px] sm:text-[16px] font-bold text-black">Download the app</p>
              <img src={imgQrCode} alt="QR Code" className="w-[80px] h-[80px] sm:w-[100px] sm:h-[100px]" />
            </div>
          </div>

          {/* Right - Phone Mockup */}
          <div className="flex justify-center">
            <div className="relative">
              <img src={imgComponent1} alt="Mobile App" className="w-full max-w-[280px] sm:max-w-[350px] md:max-w-[400px] drop-shadow-2xl" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SkylineCarSection() {
  return (
    <div className="bg-white w-full relative">
      {/* Skyline Background */}
      <div className="w-full">
        <img 
          src={imgSkyline} 
          alt="City skyline" 
          className="block w-full h-auto object-cover object-bottom"
        />
      </div>

      {/* Blue Car - Positioned at bottom aligned with skyline */}
      <div className="absolute bottom-0 left-[8%] sm:left-[10%] md:left-[13.28%] w-[180px] sm:w-[220px] md:w-[281px] h-auto z-10">
        <svg className="block w-full h-auto" fill="none" preserveAspectRatio="xMidYMax meet" viewBox="0 0 281.508 89.1846">
          <g>
            <path d={svgPaths3.p74e5200} fill="#0078D6" stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p3d973b00} fill="white" stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p6b7c800} fill="#FF6200" stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p79d3300} fill="white" stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p3d5fccf0} fill="white" stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p12e05900} fill="black" stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p13e7b500} fill="black" stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p15ab3f80} fill="black" stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p876f00} fill="#0078D6" stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p3b8f7100} stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p3de830f0} fill="white" stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p908d900} fill="white" stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p2101ab00} fill="black" />
            <path d={svgPaths3.p10f6c80} fill="#152448" />
            <path d={svgPaths3.p14087d80} fill="#F9FAF8" />
            <path d={svgPaths3.pdcdce00} fill="#152448" />
            <path d={svgPaths3.p23b26000} fill="#F9FAF8" />
            <path d={svgPaths3.p1515d600} fill="black" />
            <path d={svgPaths3.pb1bbb80} fill="#152448" />
            <path d={svgPaths3.p26f08f80} fill="#F9FAF8" />
            <path d={svgPaths3.pe210a80} fill="#152448" />
            <path d={svgPaths3.p3afc2380} fill="#F9FAF8" />
            <path d="M6.11628 88.6791H265.73" stroke="#BADBFF" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.01095" />
            <path d={svgPaths3.p1d248400} fill="white" stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p13a65300} stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.pa066700} stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p3a1a5a80} stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p16d34500} stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p29b59600} stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths3.p38fc9500} fill="white" stroke="black" strokeMiterlimit="10" strokeWidth="0.574852" />
          </g>
        </svg>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-white overflow-x-hidden">
      <Header />
      <main className="overflow-x-hidden">
        <HeroSection />
        <TestimonialsSection />
        <InsuranceQuestionsSection />
        <ThreeReasonsSection />
        <GoMobileSection />
        <SkylineCarSection />
        <PrSite />
        <PrSite6 />
      </main>
    </div>
  );
}
