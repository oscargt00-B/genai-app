import { CheckCircle2, Shield, Zap } from 'lucide-react';

export function ReasonsSection() {
  const reasons = [
    {
      icon: Shield,
      title: "Industry-best award winners 2021",
      description: "We've won multiple awards for our customer service and innovative approach to insurance. Our commitment to excellence means you get the best protection and support available."
    },
    {
      icon: Zap,
      title: "Fast, straight-forward claims service",
      description: "Our streamlined claims process means you can file a claim online in minutes. Our dedicated team works quickly to assess and settle your claim, often within 48 hours for simple cases."
    },
    {
      icon: CheckCircle2,
      title: "Highest rate positive reviews",
      description: "With over 95% positive reviews from our customers, we're proud to be one of the highest-rated insurance providers. Real customers consistently praise our transparent pricing and responsive support."
    }
  ];

  return (
    <section className="bg-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left - Badge */}
          <div className="flex justify-center">
            <div className="relative">
              <div className="w-64 h-64 bg-[#0B70E0] rounded-full flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="text-6xl font-bold">95%</div>
                  <div className="text-sm mt-2">POSITIVE</div>
                  <div className="text-xs mt-1">REVIEWS</div>
                </div>
              </div>
              <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-orange-500 text-white px-6 py-2 rounded-full text-sm font-bold whitespace-nowrap">
                Award Winner 2021
              </div>
            </div>
          </div>

          {/* Right - Reasons */}
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              3 top reasons to choose Insurent Bolt for your insurance
            </h2>
            
            <div className="space-y-8">
              {reasons.map((reason, index) => (
                <div key={index} className="flex gap-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <reason.icon className="w-6 h-6 text-[#0B70E0]" />
                    </div>
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 mb-2">{reason.title}</h3>
                    <p className="text-sm text-gray-600">{reason.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
