import { Car, Home, Briefcase, Heart, Bike, Users } from 'lucide-react';

export function HeroSection() {
  const categories = [
    { icon: Car, label: 'Car' },
    { icon: Home, label: 'Home' },
    { icon: Briefcase, label: 'Business' },
    { icon: Heart, label: 'Health' },
    { icon: Bike, label: 'Motorbike' },
    { icon: Users, label: 'Life' },
  ];

  return (
    <section className="bg-gradient-to-br from-blue-50 to-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Insurance built for<br />the informed.
            </h1>
            <p className="text-gray-600 mb-6">Make a smarter insurance choice</p>
            
            {/* Category Icons */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              {categories.map((category, index) => (
                <button
                  key={index}
                  className="flex flex-col items-center justify-center p-4 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow border border-gray-100"
                >
                  <category.icon className="w-8 h-8 text-[#0B70E0] mb-2" />
                  <span className="text-sm text-gray-700">{category.label}</span>
                </button>
              ))}
            </div>

            <a href="#learn-more" className="text-[#0B70E0] hover:underline text-sm">
              Get the news insurance experience →
            </a>
          </div>

          {/* Right Image */}
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1759369484704-fefd537878f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBob3VzZSUyMGRyaXZld2F5JTIwYmx1ZSUyMGNhcnxlbnwxfHx8fDE3Njg5MzI3NDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Modern house with blue car"
              className="rounded-lg shadow-xl w-full h-[400px] object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
