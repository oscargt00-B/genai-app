import { Check, CreditCard } from 'lucide-react';
import { Button } from '@/app/components/ui/button';

export function FlexibleSection() {
  const features = [
    "Bespoke Policies",
    "Multiple Policy Discounts",
    "Premium Payments"
  ];

  return (
    <section className="bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left - Features */}
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Get flexible.
            </h2>
            
            <div className="space-y-4 mb-8">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>

            <div className="flex gap-3">
              <Button className="bg-[#0B70E0] hover:bg-blue-700 text-white">
                Get My Quote
              </Button>
              <Button variant="outline" className="border-gray-300">
                Learn More
              </Button>
            </div>
          </div>

          {/* Right - App Preview */}
          <div className="flex justify-center">
            <div className="relative">
              {/* Phone Frame */}
              <div className="w-64 bg-[#0B70E0] rounded-[2.5rem] p-4 shadow-2xl">
                <div className="bg-white rounded-[2rem] p-6 h-[500px] flex flex-col">
                  <div className="text-center mb-6">
                    <h3 className="text-lg font-bold text-gray-900 mb-2">Get Your Quote</h3>
                    <p className="text-xs text-gray-500">Simple & Fast Process</p>
                  </div>

                  {/* Form Preview */}
                  <div className="space-y-4 flex-1">
                    <div className="bg-gray-100 rounded-lg p-3">
                      <div className="text-xs text-gray-500 mb-1">Vehicle Type</div>
                      <div className="text-sm font-medium">Car</div>
                    </div>
                    
                    <div className="bg-gray-100 rounded-lg p-3">
                      <div className="text-xs text-gray-500 mb-1">Coverage Level</div>
                      <div className="text-sm font-medium">Comprehensive</div>
                    </div>

                    <div className="bg-gray-100 rounded-lg p-3">
                      <div className="text-xs text-gray-500 mb-1">Estimated Premium</div>
                      <div className="text-2xl font-bold text-[#0B70E0]">$89/mo</div>
                    </div>
                  </div>

                  {/* CTA Button */}
                  <button className="w-full bg-orange-500 hover:bg-orange-600 text-white py-3 rounded-lg font-bold mt-4">
                    Continue
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
