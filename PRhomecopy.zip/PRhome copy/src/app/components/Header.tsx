import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { Button } from '@/app/components/ui/button';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-[#0B70E0] text-white">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-white rounded-sm flex items-center justify-center">
              <div className="w-3 h-3 bg-[#0B70E0] rotate-45"></div>
            </div>
            <span className="font-bold text-xl">Insurent Bolt</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="#insurance" className="hover:opacity-80 transition-opacity">Insurance</a>
            <a href="#claims" className="hover:opacity-80 transition-opacity">Claims</a>
            <a href="#help" className="hover:opacity-80 transition-opacity">Help and support</a>
            <a href="#about" className="hover:opacity-80 transition-opacity">About us</a>
          </nav>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center gap-4">
            <button className="text-white hover:opacity-80 transition-opacity">My Account</button>
            <Button className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-2 rounded">
              Get a quote
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 flex flex-col gap-4">
            <a href="#insurance" className="hover:opacity-80 transition-opacity">Insurance</a>
            <a href="#claims" className="hover:opacity-80 transition-opacity">Claims</a>
            <a href="#help" className="hover:opacity-80 transition-opacity">Help and support</a>
            <a href="#about" className="hover:opacity-80 transition-opacity">About us</a>
            <a href="#account" className="hover:opacity-80 transition-opacity">My Account</a>
            <Button className="bg-orange-500 hover:bg-orange-600 text-white w-full">
              Get a quote
            </Button>
          </nav>
        )}
      </div>
    </header>
  );
}
