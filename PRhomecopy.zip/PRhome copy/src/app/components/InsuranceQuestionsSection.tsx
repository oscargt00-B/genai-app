export function InsuranceQuestionsSection() {
  const questions = [
    {
      image: "https://images.unsplash.com/photo-1647292882945-d5c839432d7e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBhY2NpZGVudCUyMGRhbWFnZXxlbnwxfHx8fDE3Njg5MDYxMzV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      title: "Car insurance basics",
      description: "Learn about coverage types and what's right for you"
    },
    {
      image: "https://images.unsplash.com/photo-1618783129985-dd97dbe4ad99?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBtZWNoYW5pYyUyMHdvcmtzaG9wfGVufDF8fHx8MTc2ODg5NDkyMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      title: "Understanding car repairs",
      description: "How insurance covers different types of repairs"
    },
    {
      image: "https://images.unsplash.com/photo-1671362046019-239bd227a5fb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJzb24lMjBkcml2aW5nJTIwY2FyfGVufDF8fHx8MTc2ODkzMjc1MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      title: "Safer driving tips",
      description: "Tips to reduce your premium and stay safe"
    },
    {
      image: "https://images.unsplash.com/photo-1707999494560-f534cc79298c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjBpbnN1cmFuY2UlMjBkb2N1bWVudHN8ZW58MXx8fHwxNzY4OTI5ODQ2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      title: "Managing your policy",
      description: "How to update and optimize your coverage"
    }
  ];

  return (
    <section className="bg-[#0B70E0] py-16">
      <div className="container mx-auto px-4">
        <h2 className="text-white text-center text-3xl font-bold mb-12">
          Find answers to your insurance questions
        </h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {questions.map((question, index) => (
            <div 
              key={index} 
              className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow cursor-pointer group"
            >
              <div className="relative h-40 overflow-hidden">
                <img
                  src={question.image}
                  alt={question.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <div className="p-4">
                <h3 className="font-bold text-gray-900 mb-2">{question.title}</h3>
                <p className="text-sm text-gray-600">{question.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
