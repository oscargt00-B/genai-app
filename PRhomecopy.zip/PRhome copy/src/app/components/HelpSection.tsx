import { Phone, MessageCircle, Mail } from 'lucide-react';

export function HelpSection() {
  const contactMethods = [
    { icon: Phone, label: "Call us", value: "1-800-INSURENT" },
    { icon: MessageCircle, label: "Live Chat", value: "Available 24/7" },
    { icon: Mail, label: "Email", value: "support@insurentbolt.com" }
  ];

  return (
    <section className="bg-gradient-to-b from-blue-50 to-white py-16 relative overflow-hidden">
      {/* Decorative City Skyline */}
      <div className="absolute bottom-0 left-0 right-0 h-32 opacity-10">
        <svg viewBox="0 0 1200 100" className="w-full h-full">
          <rect x="50" y="40" width="80" height="60" fill="#0B70E0" />
          <rect x="150" y="20" width="60" height="80" fill="#0B70E0" />
          <rect x="230" y="50" width="70" height="50" fill="#0B70E0" />
          <rect x="320" y="30" width="90" height="70" fill="#0B70E0" />
          <rect x="430" y="45" width="65" height="55" fill="#0B70E0" />
          <rect x="520" y="25" width="75" height="75" fill="#0B70E0" />
          <rect x="620" y="40" width="80" height="60" fill="#0B70E0" />
          <rect x="720" y="35" width="70" height="65" fill="#0B70E0" />
          <rect x="810" y="50" width="60" height="50" fill="#0B70E0" />
          <rect x="890" y="30" width="85" height="70" fill="#0B70E0" />
          <rect x="1000" y="45" width="75" height="55" fill="#0B70E0" />
        </svg>
      </div>

      {/* Car Illustration */}
      <div className="absolute bottom-8 right-20 hidden lg:block">
        <svg width="120" height="60" viewBox="0 0 120 60" className="text-[#0B70E0]">
          <ellipse cx="30" cy="50" rx="12" ry="12" fill="currentColor" opacity="0.3" />
          <ellipse cx="90" cy="50" rx="12" ry="12" fill="currentColor" opacity="0.3" />
          <path d="M20 40 L25 25 L45 20 L70 20 L85 25 L100 40 Z" fill="currentColor" />
          <rect x="10" y="40" width="100" height="15" rx="3" fill="currentColor" />
          <circle cx="30" cy="50" r="8" fill="#333" />
          <circle cx="90" cy="50" r="8" fill="#333" />
          <circle cx="30" cy="50" r="4" fill="#666" />
          <circle cx="90" cy="50" r="4" fill="#666" />
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Need help? We're here for you.
          </h2>
          <p className="text-gray-600">
            Getting in touch is easy. Choose the method that works best for you.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {contactMethods.map((method, index) => (
            <button
              key={index}
              className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow text-center group"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4 group-hover:bg-[#0B70E0] transition-colors">
                <method.icon className="w-8 h-8 text-[#0B70E0] group-hover:text-white transition-colors" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">{method.label}</h3>
              <p className="text-sm text-gray-600">{method.value}</p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
