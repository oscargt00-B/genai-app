export function Footer() {
  const sections = [
    {
      title: "Insurance",
      links: ["Car Insurance", "Home Insurance", "Life Insurance", "Business Insurance"]
    },
    {
      title: "Resources",
      links: ["Claims", "Customer Support", "FAQ", "Blog"]
    },
    {
      title: "Our company",
      links: ["About Us", "Careers", "Press", "Partnerships"]
    },
    {
      title: "Legal",
      links: ["Privacy Policy", "Terms of Service", "Cookie Policy", "Disclaimers"]
    }
  ];

  return (
    <footer className="bg-[#0B70E0] text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8 mb-8">
          {/* Logo and tagline */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-6 h-6 bg-white rounded-sm flex items-center justify-center">
                <div className="w-3 h-3 bg-[#0B70E0] rotate-45"></div>
              </div>
              <span className="font-bold text-xl">Insurent Bolt</span>
            </div>
            <p className="text-sm text-blue-100">
              Insurance built for the informed.
            </p>
          </div>

          {/* Links */}
          {sections.map((section, index) => (
            <div key={index}>
              <h4 className="font-bold mb-4">{section.title}</h4>
              <ul className="space-y-2">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a href="#" className="text-sm text-blue-100 hover:text-white transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="border-t border-blue-400 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-blue-100">
          <p>© 2026 Insurent Bolt. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
