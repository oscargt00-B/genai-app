import { useState } from 'react';
import svgPaths from "../../imports/svg-80ndgpt766";

function LogoWithTagline() {
  return (
    <div className="h-[44.877px] relative shrink-0 w-[150.479px]" data-name="Logo with tagline">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 150.479 44.8775">
        <g clipPath="url(#clip0_2009_6264)" id="Logo with tagline">
          <path d={svgPaths.p318a8f80} fill="var(--fill-0, #0078D6)" id="Vector" />
          <path d={svgPaths.p19dd6a40} fill="var(--fill-0, #0078D6)" id="Vector_2" />
          <path d={svgPaths.p318a8f80} fill="var(--fill-0, #0078D6)" id="Vector_3" />
          <path d={svgPaths.p3e87a680} fill="var(--fill-0, #0078D6)" id="Vector_4" />
          <path d={svgPaths.pfc86a80} fill="var(--fill-0, #0078D6)" id="Vector_5" />
          <path d={svgPaths.p8f1e300} fill="var(--fill-0, #0078D6)" id="Vector_6" />
          <path d={svgPaths.p5cd6600} fill="var(--fill-0, #0078D6)" id="Vector_7" />
          <path d={svgPaths.p2dda5200} fill="var(--fill-0, #0078D6)" id="Vector_8" />
          <path d={svgPaths.p31d74600} fill="var(--fill-0, #0078D6)" id="Vector_9" />
          <path d={svgPaths.p2beae60} fill="var(--fill-0, #0078D6)" id="Vector_10" />
          <path d={svgPaths.p3d908300} fill="var(--fill-0, #0078D6)" id="Vector_11" />
          <path d={svgPaths.p10537600} fill="var(--fill-0, #0078D6)" id="Vector_12" />
          <path d={svgPaths.p19598100} fill="var(--fill-0, #0078D6)" id="Vector_13" />
          <path d={svgPaths.p89ac800} fill="var(--fill-0, #0078D6)" id="Vector_14" />
          <path d={svgPaths.p2396fb00} fill="var(--fill-0, #0078D6)" id="Vector_15" />
          <path d={svgPaths.p3fb44700} fill="var(--fill-0, #0078D6)" id="Vector_16" />
          <path d={svgPaths.p3bbd93f0} fill="var(--fill-0, #0078D6)" id="Vector_17" />
          <path d={svgPaths.p1d55e780} fill="var(--fill-0, #0078D6)" id="Vector_18" />
          <path d={svgPaths.pd9fac80} fill="var(--fill-0, #0078D6)" id="Vector_19" />
          <path d={svgPaths.p3b3fea80} fill="var(--fill-0, #0078D6)" id="Vector_20" />
          <path d={svgPaths.p19d0e680} fill="var(--fill-0, #0078D6)" id="Vector_21" />
          <path d={svgPaths.p1044ed80} fill="var(--fill-0, #0078D6)" id="Vector_22" />
          <path d={svgPaths.p37f5300} fill="var(--fill-0, #0078D6)" id="Vector_23" />
          <path d={svgPaths.p28601080} fill="var(--fill-0, #0078D6)" id="Vector_24" />
          <path d={svgPaths.p2acfda00} fill="var(--fill-0, #0078D6)" id="Vector_25" />
          <path d={svgPaths.p24faa380} fill="var(--fill-0, #0078D6)" id="Vector_26" />
          <path d={svgPaths.p274d2380} fill="var(--fill-0, #0078D6)" id="Vector_27" />
          <path d={svgPaths.p3f31f880} fill="var(--fill-0, #0078D6)" id="Vector_28" />
          <path d={svgPaths.p1b136700} fill="var(--fill-0, #0078D6)" id="Vector_29" />
          <path d={svgPaths.p1b68eb80} fill="var(--fill-0, #0078D6)" id="Vector_30" />
          <path d={svgPaths.p19a8d680} fill="var(--fill-0, #0078D6)" id="Vector_31" />
          <path d={svgPaths.p2e9b0600} fill="var(--fill-0, #0078D6)" id="Vector_32" />
          <path d={svgPaths.p185c8580} fill="var(--fill-0, #0078D6)" id="Vector_33" />
          <path d={svgPaths.pe4c3c80} fill="var(--fill-0, #0078D6)" id="Vector_34" />
          <path d={svgPaths.p6edda00} fill="var(--fill-0, #0078D6)" id="Vector_35" />
          <path d={svgPaths.p3f8bb480} fill="var(--fill-0, #0078D6)" id="Vector_36" />
          <path d={svgPaths.p3d0b2900} fill="var(--fill-0, #0078D6)" id="Vector_37" />
          <path d={svgPaths.p2839a280} fill="var(--fill-0, #0078D6)" id="Vector_38" />
          <path d={svgPaths.p36555b00} fill="var(--fill-0, #0078D6)" id="Vector_39" />
          <path d={svgPaths.p18e43080} fill="var(--fill-0, #0078D6)" id="Vector_40" />
          <path d={svgPaths.p44e3500} fill="var(--fill-0, #0078D6)" id="Vector_41" />
          <path d={svgPaths.p1b955c00} fill="var(--fill-0, #0078D6)" id="Vector_42" />
          <path d={svgPaths.p36cd6600} fill="var(--fill-0, #0078D6)" id="Vector_43" />
          <path d={svgPaths.p38a4ab00} fill="var(--fill-0, #0078D6)" id="Vector_44" />
          <path d={svgPaths.p31642e00} fill="var(--fill-0, #0078D6)" id="Vector_45" />
          <path d={svgPaths.p19934580} fill="var(--fill-0, #0078D6)" id="Vector_46" />
          <path d={svgPaths.p2dc42f00} fill="var(--fill-0, #0078D6)" id="Vector_47" />
          <path d={svgPaths.pf49fb00} fill="var(--fill-0, #0078D6)" id="Vector_48" />
        </g>
        <defs>
          <clipPath id="clip0_2009_6264">
            <rect fill="white" height="44.8775" width="150.479" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

export function AutoQuoteCard({ firstName }: { firstName?: string }) {
  const [selectedTab, setSelectedTab] = useState(0);
  
  const coverageOptions = [
    { name: 'Price Conscious', price: '$72/mo' },
    { name: 'Most Popular', price: '$80/mo' },
    { name: 'Superior Coverage', price: '$124/mo' }
  ];

  return (
    <div className="w-full border border-[#bec7d1] rounded-[30px] py-4 sm:py-6 bg-white">
      <div className="max-w-[580px] mx-auto">
      {/* Header */}
      <div className="px-3 sm:px-6 mb-4 sm:mb-6">
        <p className="font-['Manrope',sans-serif] text-[24px] sm:text-[32px] leading-[32px] sm:leading-[42px] text-[#0078d6] text-center">
          Hi {firstName || 'Joe'}, here's your auto quote
        </p>
        <div className="flex flex-col justify-end leading-[0] relative text-center mt-2">
          <p className="font-['Manrope',sans-serif] font-bold">
            <span className="text-[36px] sm:text-[48px] leading-[48px] sm:leading-[60px] text-[#0078d6]">$72</span>
            <span className="text-[20px] sm:text-[28px] leading-[28px] sm:leading-[38px] text-[#0078d6]">/mo.</span>
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-start justify-center mb-4 sm:mb-6 relative overflow-x-auto px-2">
        {coverageOptions.map((option, index) => (
          <button
            key={index}
            onClick={() => setSelectedTab(index)}
            className={`px-2 sm:px-4 py-2 text-center relative whitespace-nowrap flex-shrink-0 ${
              selectedTab === index
                ? 'font-["Open_Sans",sans-serif] font-bold text-[#0078d6]'
                : 'font-["Open_Sans",sans-serif] text-[rgba(0,0,0,0.6)]'
            }`}
          >
            <div className="text-[14px] sm:text-[16px] leading-[20px] sm:leading-[22px]">
              {option.name}
              <br />
              {option.price}
            </div>
            {selectedTab === index && (
              <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#0078d6]" />
            )}
          </button>
        ))}
      </div>

      {/* Liability Section */}
      <div className="px-3 sm:px-6 mb-4">
        <p className="font-['Manrope',sans-serif] text-[16px] sm:text-[20px] leading-[24px] sm:leading-[28px] text-[#0078d6] mb-2">
          Liability:
        </p>
        <div className="w-full overflow-x-auto">
          <div className="min-w-[300px]">
            {/* Header */}
            <div className="bg-[#f5faff] flex px-2 py-3">
              <p className="flex-1 font-['Open_Sans',sans-serif] font-bold text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black">Name</p>
              <p className="flex-1 font-['Open_Sans',sans-serif] font-bold text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black">Coverage</p>
              <p className="w-[50px] font-['Open_Sans',sans-serif] font-bold text-[10px] sm:text-[12px] leading-[14px] text-black text-right">Cost</p>
            </div>
            {/* Rows */}
            <div className="bg-white flex px-2 py-3">
              <p className="flex-1 font-['Open_Sans',sans-serif] text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black">Bodily injury liability</p>
              <p className="flex-1 font-['Open_Sans',sans-serif] text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black">$35,000/70,000</p>
              <p className="w-[50px] font-['Open_Sans',sans-serif] text-[10px] sm:text-[12px] leading-[14px] text-black text-right">$90</p>
            </div>
            <div className="bg-[#f8f8fa] flex px-2 py-3">
              <p className="flex-1 font-['Open_Sans',sans-serif] text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black">Property damage liability</p>
              <p className="flex-1 font-['Open_Sans',sans-serif] text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black">$25,000</p>
              <p className="w-[50px] font-['Open_Sans',sans-serif] text-[10px] sm:text-[12px] leading-[14px] text-black text-right">$88</p>
            </div>
          </div>
        </div>
      </div>

      {/* Personal Coverage Section */}
      <div className="px-3 sm:px-6 mb-4">
        <p className="font-['Manrope',sans-serif] text-[16px] sm:text-[20px] leading-[24px] sm:leading-[28px] text-[#0078d6] mb-2">
          Personal coverage:
        </p>
        <div className="w-full overflow-x-auto">
          <div className="min-w-[300px]">
            {/* Header */}
            <div className="bg-[#f5faff] flex px-2 py-3">
              <p className="flex-1 font-['Open_Sans',sans-serif] font-bold text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black">Name</p>
              <p className="flex-1 font-['Open_Sans',sans-serif] font-bold text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black">Coverage</p>
              <p className="w-[50px] font-['Open_Sans',sans-serif] font-bold text-[10px] sm:text-[12px] leading-[14px] text-black text-right">Cost</p>
            </div>
            {/* Rows */}
            <div className="bg-white flex px-2 py-3">
              <p className="flex-1 font-['Open_Sans',sans-serif] text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black">Personal injury protection limit</p>
              <p className="flex-1 font-['Open_Sans',sans-serif] text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black">$15,000</p>
              <p className="w-[50px] font-['Open_Sans',sans-serif] text-[10px] sm:text-[12px] leading-[14px] text-black text-right">$82</p>
            </div>
            <div className="bg-[#f8f8fa] flex px-2 py-3">
              <p className="flex-1 font-['Open_Sans',sans-serif] text-[11px] sm:text-[14px] leading-[16px] sm:leading-[22px] text-black">Extra personal injury protection package option</p>
              <p className="flex-1 font-['Open_Sans',sans-serif] text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black">Option 1</p>
              <p className="w-[50px] font-['Open_Sans',sans-serif] text-[10px] sm:text-[12px] leading-[14px] text-black text-right">$11</p>
            </div>
            <div className="bg-white flex px-2 py-3">
              <p className="flex-1 font-['Open_Sans',sans-serif] text-[11px] sm:text-[14px] leading-[16px] sm:leading-[22px] text-black">Uninsured/underinsured motorist bodily injury</p>
              <p className="flex-1 font-['Open_Sans',sans-serif] text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black">$35,000/70,000</p>
              <p className="w-[50px] font-['Open_Sans',sans-serif] text-[10px] sm:text-[12px] leading-[14px] text-black text-right">$77</p>
            </div>
            <div className="bg-[#f8f8fa] flex px-2 py-3">
              <p className="flex-1 font-['Open_Sans',sans-serif] text-[11px] sm:text-[14px] leading-[16px] sm:leading-[22px] text-black">Uninsured/underinsured motorist property damage</p>
              <p className="flex-1 font-['Open_Sans',sans-serif] text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black">$25,000</p>
              <p className="w-[50px] font-['Open_Sans',sans-serif] text-[10px] sm:text-[12px] leading-[14px] text-black text-right">$16</p>
            </div>
          </div>
        </div>
      </div>

      {/* Vehicle Coverage Section */}
      <div className="px-3 sm:px-6 mb-4">
        <p className="font-['Manrope',sans-serif] text-[16px] sm:text-[20px] leading-[24px] sm:leading-[28px] text-[#0078d6] mb-2">
          Vehicle coverage for
        </p>
        <div className="w-full overflow-x-auto">
          <div className="min-w-[300px]">
            <div className="bg-white flex px-2 py-3">
              <p className="flex-1 font-['Open_Sans',sans-serif] text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black">1984 BMW 325 E Sedan</p>
              <p className="flex-1 font-['Open_Sans',sans-serif] text-[12px] sm:text-[14px] leading-[18px] sm:leading-[22px] text-black text-right">None</p>
            </div>
          </div>
        </div>
        <p className="font-['Open_Sans',sans-serif] text-[10px] sm:text-[12px] leading-[14px] text-black mt-2 text-center">
          Quote Number: MAHQ0005151311
        </p>
      </div>

      {/* Footer */}
      <div className="px-3 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <LogoWithTagline />
        <button className="bg-[#0078d6] text-white font-['Open_Sans',sans-serif] text-[16px] sm:text-[18px] leading-[24px] sm:leading-[30px] px-5 py-3 rounded-[32px] hover:bg-[#0066bb] transition-colors">
          Continue to purchase
        </button>
      </div>
      </div>
    </div>
  );
}