import { Star } from 'lucide-react';

export function TestimonialsSection() {
  const testimonials = [
    {
      rating: 5,
      text: "Awesome service! I got my claim sorted within 2 weeks and the team was super helpful throughout the process.",
      author: "Sarah Johnson"
    },
    {
      rating: 5,
      text: "Best insurance experience I've had. The online portal is easy to use and customer support is always available.",
      author: "Mike Peters"
    },
    {
      rating: 5,
      text: "Great value for money. Switched from my old provider and saved over 30% on my premium with better coverage.",
      author: "Emily Chen"
    },
    {
      rating: 5,
      text: "The mobile app makes managing my policy so convenient. I can update my details and make payments easily.",
      author: "David Williams"
    }
  ];

  return (
    <section className="bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <p className="text-gray-700 mb-2">
            Trusted by customers for <span className="font-bold">40+ years.</span> Trusted by{' '}
            <span className="text-[#0B70E0] font-bold">Google</span>,{' '}
            <span className="text-yellow-500 font-bold">iOS</span>, reviews.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
              <div className="flex gap-1 mb-3">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-sm text-gray-700 mb-3">{testimonial.text}</p>
              <p className="text-xs text-gray-500">— {testimonial.author}</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <a href="#reviews" className="text-[#0B70E0] hover:underline">
            View All Reviews →
          </a>
        </div>
      </div>
    </section>
  );
}
