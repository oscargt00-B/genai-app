import { Car, Home, Heart, Briefcase, Users, Plane, Shield } from 'lucide-react';

export function InsuranceTypesSection() {
  const insuranceTypes = [
    { icon: Car, label: "Car Insurance" },
    { icon: Home, label: "Home Insurance" },
    { icon: Heart, label: "Health Insurance" },
    { icon: Briefcase, label: "Business Insurance" },
    { icon: Users, label: "Life Insurance" },
    { icon: Plane, label: "Travel Insurance" },
    { icon: Shield, label: "Pet Insurance" }
  ];

  return (
    <section className="bg-[#0B70E0] py-12">
      <div className="container mx-auto px-4">
        <h3 className="text-white text-center font-bold mb-8">
          Explore more insurance:
        </h3>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
          {insuranceTypes.map((type, index) => (
            <button
              key={index}
              className="bg-white bg-opacity-10 hover:bg-opacity-20 text-white p-6 rounded-lg transition-all hover:scale-105 flex flex-col items-center gap-3"
            >
              <type.icon className="w-8 h-8" />
              <span className="text-sm text-center">{type.label}</span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
