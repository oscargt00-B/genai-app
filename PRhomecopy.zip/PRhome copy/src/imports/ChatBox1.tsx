function Heading() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 1">
      <div className="css-g0mm18 flex flex-col font-['Manrope:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[48px] text-black">
        <p className="css-ew64yg leading-[60px]">Insurance built for the Northeast.</p>
      </div>
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex items-center min-h-[24px] min-w-[24px] overflow-clip relative shrink-0 w-full" data-name="Content">
      <p className="css-4hzbpn flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[24px] min-h-px min-w-px not-italic relative text-[16px] text-[rgba(0,0,0,0.38)] tracking-[0.15px]">How can we help you today?</p>
    </div>
  );
}

function Input() {
  return (
    <div className="relative rounded-[8px] shrink-0 w-full" data-name="Input">
      <div className="content-stretch flex flex-col items-start px-[20px] py-[12px] relative w-full">
        <Content />
      </div>
    </div>
  );
}

function TextField() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="<TextField>">
      <Input />
    </div>
  );
}

function Icon() {
  return (
    <div className="content-stretch flex items-start pb-px relative shrink-0 size-[20px]" data-name="<Icon>">
      <div className="flex flex-[1_0_0] flex-col font-['Font_Awesome_7_Pro:Regular',sans-serif] h-full justify-center leading-[0] min-h-px min-w-px not-italic relative text-[16px] text-black text-center">
        <p className="css-4hzbpn leading-[normal]"></p>
      </div>
    </div>
  );
}

function IconButton() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[5px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon />
    </div>
  );
}

function Icon1() {
  return (
    <div className="content-stretch flex items-start pb-px relative shrink-0 size-[20px]" data-name="<Icon>">
      <div className="flex flex-[1_0_0] flex-col font-['Font_Awesome_7_Pro:Light',sans-serif] h-full justify-center leading-[0] min-h-px min-w-px not-italic relative text-[20px] text-black text-center">
        <p className="css-4hzbpn leading-[normal]"></p>
      </div>
    </div>
  );
}

function IconButton1() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[5px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon1 />
    </div>
  );
}

function Icon2() {
  return (
    <div className="content-stretch flex items-start pb-px relative shrink-0 size-[24px]" data-name="<Icon>">
      <div className="flex flex-[1_0_0] flex-col font-['Font_Awesome_7_Pro:Light',sans-serif] h-full justify-center leading-[0] min-h-px min-w-px not-italic relative text-[20px] text-center text-white">
        <p className="css-4hzbpn leading-[normal]"></p>
      </div>
    </div>
  );
}

function IconButton2() {
  return (
    <div className="bg-[#0078d6] content-stretch flex flex-col items-center justify-center overflow-clip p-[8px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon2 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <IconButton />
      <IconButton1 />
      <IconButton2 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="relative rounded-[96px] shrink-0 w-full">
      <div aria-hidden="true" className="absolute border border-[#bec7d1] border-solid inset-0 pointer-events-none rounded-[96px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[8px] py-[6px] relative w-full">
          <TextField />
          <Frame />
        </div>
      </div>
    </div>
  );
}

function Margin() {
  return (
    <div className="bg-white flex-[1_0_0] min-h-px min-w-px relative rounded-[20px] w-full" data-name="Margin">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col gap-[24px] items-start justify-center pb-[60px] pt-[24px] px-[24px] relative size-full">
          <Heading />
          <Frame1 />
        </div>
      </div>
    </div>
  );
}

export default function ChatBox() {
  return (
    <div className="content-stretch flex flex-col items-start relative size-full" data-name="Chat Box 1">
      <Margin />
    </div>
  );
}