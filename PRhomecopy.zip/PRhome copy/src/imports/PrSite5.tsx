import svgPaths from "./svg-1z1uj7k8ut";
import imgVector from "figma:asset/01c9d9edba045c99fdffb4cb7f8ed8ce5b3db1a7.png";
import {
  imgGroup,
  imgGroup1,
  imgGroup2,
  imgGroup3,
  imgGroup4,
  imgGroup5,
  imgGroup6,
  imgGroup7,
  imgGroup8,
  imgGroup9,
  imgGroup10,
  imgGroup11,
  imgGroup12,
} from "./svg-xeoeq";

function Heading() {
  return (
    <div
      className="content-stretch flex flex-col items-center relative shrink-0 w-full"
      data-name="Heading 2"
    >
      <div className="css-g0mm18 flex flex-col font-['Manrope:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[32px] text-black text-center">
        <p className="css-ew64yg leading-[42px]">
          Need help? We’re here for you.
        </p>
      </div>
    </div>
  );
}

function Container() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full"
      data-name="Container"
    >
      <Heading />
    </div>
  );
}

function Margin() {
  return (
    <div
      className="content-stretch flex flex-col h-[48px] items-start justify-center pb-[6px] pt-0 px-0 relative shrink-0 w-full"
      data-name="Margin"
    >
      <Container />
    </div>
  );
}

function Container1() {
  return (
    <div
      className="content-stretch flex flex-col items-center relative shrink-0 w-full"
      data-name="Container"
    >
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[20px] text-black text-center">
        <p className="css-ew64yg leading-[28px]">
          Getting an auto insurance or home insurance quote is
          easy!
        </p>
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div
      className="content-stretch flex flex-col h-[63px] items-start relative shrink-0 w-full"
      data-name="Container"
    >
      <Container1 />
    </div>
  );
}

function Container3() {
  return (
    <div
      className="flex-[1_0_0] min-h-px min-w-px relative self-stretch"
      data-name="Container"
    >
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pb-0 pt-[30px] px-[20px] relative size-full">
          <Margin />
          <Container2 />
        </div>
      </div>
    </div>
  );
}

function Container4() {
  return (
    <div
      className="max-w-[1140px] relative shrink-0 w-full"
      data-name="Container"
    >
      <div className="flex flex-row justify-center max-w-[inherit] size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start justify-center max-w-[inherit] pl-0 pr-[10px] py-0 relative w-full">
          <Container3 />
        </div>
      </div>
    </div>
  );
}

function Section() {
  return (
    <div
      className="bg-[#e9f2fc] content-stretch flex flex-col items-start mb-[-1px] pb-0 pt-[46px] px-4 md:px-8 lg:px-16 xl:px-32 relative shrink-0 w-full"
      data-name="Section"
    >
      <div
        aria-hidden="true"
        className="absolute border-black border-solid border-t inset-0 pointer-events-none"
      />
      <Container4 />
    </div>
  );
}

function Container5() {
  return (
    <div
      className="content-stretch flex flex-col items-center relative shrink-0 w-full"
      data-name="Container"
    >
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black text-center">
        <p className="css-ew64yg leading-[26px]">Phone</p>
      </div>
    </div>
  );
}

function Container6() {
  return (
    <div
      className="flex-[1_0_0] h-full min-h-px min-w-px relative"
      data-name="Container"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container5 />
      </div>
    </div>
  );
}

function VerticalBorder() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] flex-wrap h-full items-start justify-center min-h-px min-w-px pb-[6px] pl-[4px] pr-0 pt-[7px] relative"
      data-name="VerticalBorder"
    >
      <div
        aria-hidden="true"
        className="absolute border-[#0351aa] border-l-4 border-solid inset-0 pointer-events-none"
      />
      <Container6 />
    </div>
  );
}

function Container7() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch"
      data-name="Container"
    >
      <VerticalBorder />
    </div>
  );
}

function Component() {
  return (
    <div
      className="h-[30.882px] relative shrink-0 w-[30px]"
      data-name="Component 1"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 30 30.8824"
      >
        <g id="Component 1">
          <path
            d={svgPaths.p2cc21400}
            fill="var(--fill-0, #0351AA)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function CellPhone2SvgFill() {
  return (
    <div
      className="content-stretch flex flex-col h-[32px] items-center justify-center overflow-clip px-0 py-[0.559px] relative shrink-0 w-[30px]"
      data-name="cell-phone-2.svg fill"
    >
      <Component />
    </div>
  );
}

function CellPhone() {
  return (
    <div
      className="content-stretch flex h-[32px] items-start max-w-[76.66000366210938px] overflow-clip relative shrink-0 w-[30px]"
      data-name="cell phone"
    >
      <CellPhone2SvgFill />
    </div>
  );
}

function Container8() {
  return (
    <div
      className="content-stretch flex flex-col items-start relative shrink-0 w-full"
      data-name="Container"
    >
      <CellPhone />
    </div>
  );
}

function Container9() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] flex-col h-[32px] items-start min-h-px min-w-px relative"
      data-name="Container"
    >
      <Container8 />
    </div>
  );
}

function Container10() {
  return (
    <div
      className="flex-[1_0_0] min-h-px min-w-px relative self-stretch"
      data-name="Container"
    >
      <div className="flex flex-row justify-center min-h-[inherit] size-full">
        <div className="content-stretch flex items-start justify-center min-h-[inherit] pl-[10px] pr-0 py-0 relative size-full">
          <Container9 />
        </div>
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div
      className="content-stretch flex items-start max-w-[1140px] relative shrink-0 w-full"
      data-name="Container"
    >
      <Container7 />
      <Container10 />
    </div>
  );
}

function Section1() {
  return (
    <div
      className="content-stretch flex flex-col h-[39px] items-start relative shrink-0 w-full"
      data-name="Section"
    >
      <Container11 />
    </div>
  );
}

function Component9() {
  return (
    <div
      className="content-stretch flex items-start relative shrink-0"
      data-name="Component 10"
    >
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px]">
        <p className="css-ew64yg decoration-solid leading-[26px] underline">
          800-516-9242
        </p>
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div
      className="content-stretch flex flex-col items-start relative shrink-0 w-[153.33px]"
      data-name="Container"
    >
      <Component9 />
    </div>
  );
}

function Container13() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px pb-0 pt-[10px] px-0 relative self-stretch"
      data-name="Container"
    >
      <Container12 />
    </div>
  );
}

function Container14() {
  return (
    <div
      className="content-stretch flex items-start justify-center max-w-[1140px] pb-[6px] pt-[7px] px-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Container13 />
    </div>
  );
}

function Section2() {
  return (
    <div
      className="content-stretch flex flex-col h-[49px] items-start relative shrink-0 w-full"
      data-name="Section"
    >
      <Container14 />
    </div>
  );
}

function Container15() {
  return (
    <div
      className="flex-[1_0_0] h-full min-h-px min-w-px relative"
      data-name="Container"
    >
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pb-[26px] pl-0 pr-[40px] pt-0 relative size-full">
          <Section1 />
          <Section2 />
        </div>
      </div>
    </div>
  );
}

function Container16() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch"
      data-name="Container"
    >
      <Container15 />
    </div>
  );
}

function Container17() {
  return (
    <div
      className="content-stretch flex flex-col items-center relative shrink-0 w-full"
      data-name="Container"
    >
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black text-center">
        <p className="css-ew64yg leading-[26px]">Online</p>
      </div>
    </div>
  );
}

function Container18() {
  return (
    <div
      className="flex-[1_0_0] h-full min-h-px min-w-px relative"
      data-name="Container"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-[6px] pt-[7px] px-0 relative size-full">
        <Container17 />
      </div>
    </div>
  );
}

function VerticalBorder1() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] flex-wrap h-full items-start justify-center min-h-px min-w-px pl-[4px] pr-0 py-0 relative"
      data-name="VerticalBorder"
    >
      <div
        aria-hidden="true"
        className="absolute border-[#0351aa] border-l-4 border-solid inset-0 pointer-events-none"
      />
      <Container18 />
    </div>
  );
}

function Container19() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px mr-[-0.01px] relative self-stretch"
      data-name="Container"
    >
      <VerticalBorder1 />
    </div>
  );
}

function Component1() {
  return (
    <div
      className="h-[22px] relative shrink-0 w-[25.667px]"
      data-name="Component 1"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 25.6667 22"
      >
        <g clipPath="url(#clip0_2_2876)" id="Component 1">
          <path
            d={svgPaths.p7c12500}
            fill="var(--fill-0, #0351AA)"
            id="Vector"
          />
        </g>
        <defs>
          <clipPath id="clip0_2_2876">
            <rect fill="white" height="22" width="25.6667" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Internet2SvgFill() {
  return (
    <div
      className="content-stretch flex flex-col h-[22px] items-center justify-center overflow-clip px-[3.167px] py-0 relative shrink-0 w-[32px]"
      data-name="internet-2.svg fill"
    >
      <Component1 />
    </div>
  );
}

function InternetIcon() {
  return (
    <div
      className="content-stretch flex h-[22px] items-start max-w-[76.66000366210938px] overflow-clip relative shrink-0 w-[32px]"
      data-name="internet icon"
    >
      <Internet2SvgFill />
    </div>
  );
}

function Container20() {
  return (
    <div
      className="content-stretch flex flex-col items-start pb-[0.28px] pt-[3.72px] px-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <InternetIcon />
    </div>
  );
}

function Container21() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] flex-col h-[26px] items-start min-h-px min-w-px relative"
      data-name="Container"
    >
      <Container20 />
    </div>
  );
}

function Container22() {
  return (
    <div
      className="flex-[1_0_0] min-h-px min-w-px mr-[-0.01px] relative self-stretch"
      data-name="Container"
    >
      <div className="flex flex-row justify-center min-h-[inherit] size-full">
        <div className="content-stretch flex items-start justify-center min-h-[inherit] pl-[10px] pr-0 py-0 relative size-full">
          <Container21 />
        </div>
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div
      className="content-stretch flex items-start max-w-[1140px] min-h-[39px] pl-0 pr-[0.01px] py-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Container19 />
      <Container22 />
    </div>
  );
}

function Section3() {
  return (
    <div
      className="content-stretch flex flex-col h-[39px] items-start relative shrink-0 w-full"
      data-name="Section"
    >
      <Container23 />
    </div>
  );
}

function Component11() {
  return (
    <div
      className="content-stretch flex items-start relative shrink-0"
      data-name="Component 10"
      id="auto"
    >
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a
          className="block css-ew64yg cursor-pointer decoration-solid leading-[26px] text-[16px] underline"
          href="https://www.plymouthrock.com/insurance/auto/"
        >
          Auto insurance
        </a>
      </div>
    </div>
  );
}

function Component12() {
  return (
    <div
      className="content-stretch flex items-start relative shrink-0"
      data-name="Component 10"
      id="home"
    >
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a
          className="block css-ew64yg cursor-pointer decoration-solid leading-[26px] text-[16px] underline"
          href="https://www.plymouthrock.com/insurance/home/"
        >
          Home insurance
        </a>
      </div>
    </div>
  );
}

function Container24() {
  return (
    <div
      className="content-stretch flex flex-col items-start relative shrink-0 w-full"
      data-name="Container"
    >
      <Component11 />
      <Component12 />
    </div>
  );
}

function Container25() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px pb-0 pt-[10px] px-0 relative self-stretch"
      data-name="Container"
    >
      <Container24 />
    </div>
  );
}

function Container26() {
  return (
    <div
      className="content-stretch flex items-start justify-center max-w-[1140px] pb-[6px] pt-[7px] px-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Container25 />
    </div>
  );
}

function Section4() {
  return (
    <div
      className="content-stretch flex flex-col h-[75px] items-start relative shrink-0 w-full"
      data-name="Section"
    >
      <Container26 />
    </div>
  );
}

function Container27() {
  return (
    <div
      className="flex-[1_0_0] h-full min-h-px min-w-px relative"
      data-name="Container"
    >
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pl-0 pr-[40px] py-0 relative size-full">
          <Section3 />
          <Section4 />
        </div>
      </div>
    </div>
  );
}

function Container28() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch"
      data-name="Container"
    >
      <Container27 />
    </div>
  );
}

function Container29() {
  return (
    <div
      className="content-stretch flex flex-col items-center relative shrink-0 w-full"
      data-name="Container"
    >
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black text-center">
        <p className="css-ew64yg leading-[26px]">Agent</p>
      </div>
    </div>
  );
}

function Container30() {
  return (
    <div
      className="flex-[1_0_0] h-full min-h-px min-w-px relative"
      data-name="Container"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-[6px] pt-[7px] px-0 relative size-full">
        <Container29 />
      </div>
    </div>
  );
}

function VerticalBorder2() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] flex-wrap h-full items-start justify-center min-h-px min-w-px pl-[4px] pr-0 py-0 relative"
      data-name="VerticalBorder"
    >
      <div
        aria-hidden="true"
        className="absolute border-[#0351aa] border-l-4 border-solid inset-0 pointer-events-none"
      />
      <Container30 />
    </div>
  );
}

function Container31() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px mr-[-0.01px] relative self-stretch"
      data-name="Container"
    >
      <VerticalBorder2 />
    </div>
  );
}

function Component2() {
  return (
    <div
      className="relative shrink-0 size-[30px]"
      data-name="Component 1"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 30 30"
      >
        <g clipPath="url(#clip0_2_3041)" id="Component 1">
          <path
            d={svgPaths.p2ec4d100}
            fill="var(--fill-0, #0351AA)"
            id="Vector"
          />
        </g>
        <defs>
          <clipPath id="clip0_2_3041">
            <rect fill="white" height="30" width="30" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Agent2SvgFill() {
  return (
    <div
      className="content-stretch flex flex-col h-[30px] items-center justify-center overflow-clip px-[0.5px] py-0 relative shrink-0 w-[31px]"
      data-name="agent-2.svg fill"
    >
      <Component2 />
    </div>
  );
}

function AgentIcon() {
  return (
    <div
      className="content-stretch flex h-[30px] items-start max-w-[76.66000366210938px] overflow-clip relative shrink-0 w-[31px]"
      data-name="agent icon"
    >
      <Agent2SvgFill />
    </div>
  );
}

function Container32() {
  return (
    <div
      className="content-stretch flex flex-col items-start relative shrink-0 w-full"
      data-name="Container"
    >
      <AgentIcon />
    </div>
  );
}

function Container33() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] flex-col h-[30px] items-start min-h-px min-w-px relative"
      data-name="Container"
    >
      <Container32 />
    </div>
  );
}

function Container34() {
  return (
    <div
      className="flex-[1_0_0] min-h-px min-w-px mr-[-0.01px] relative self-stretch"
      data-name="Container"
    >
      <div className="flex flex-row justify-center min-h-[inherit] size-full">
        <div className="content-stretch flex items-start justify-center min-h-[inherit] pl-[10px] pr-0 py-0 relative size-full">
          <Container33 />
        </div>
      </div>
    </div>
  );
}

function Container35() {
  return (
    <div
      className="content-stretch flex items-start max-w-[1140px] pl-0 pr-[0.01px] py-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Container31 />
      <Container34 />
    </div>
  );
}

function Section5() {
  return (
    <div
      className="content-stretch flex flex-col h-[39px] items-start relative shrink-0 w-full"
      data-name="Section"
    >
      <Container35 />
    </div>
  );
}

function Component13() {
  return (
    <div
      className="content-stretch flex items-start relative shrink-0 w-full"
      data-name="Component 10"
    >
      <div className="flex flex-[1_0_0] flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] min-h-px min-w-px not-italic relative text-[#0351aa] text-[0px]">
        <a
          className="block css-4hzbpn cursor-pointer decoration-solid leading-[26px] text-[16px] underline"
          href="https://www.plymouthrock.com/find-an-agent/"
        >
          Find an agent
        </a>
      </div>
    </div>
  );
}

function Container36() {
  return (
    <div
      className="relative shrink-0 w-full"
      data-name="Container"
    >
      <div className="content-stretch flex flex-col items-start pl-0 pr-[25px] py-0 relative w-full">
        <Component13 />
      </div>
    </div>
  );
}

function Container37() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px pb-0 pt-[10px] px-0 relative self-stretch"
      data-name="Container"
    >
      <Container36 />
    </div>
  );
}

function Container38() {
  return (
    <div
      className="content-stretch flex items-start justify-center max-w-[1140px] pb-[6px] pt-[7px] px-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Container37 />
    </div>
  );
}

function Section6() {
  return (
    <div
      className="content-stretch flex flex-col h-[49px] items-start relative shrink-0 w-full"
      data-name="Section"
    >
      <Container38 />
    </div>
  );
}

function Container39() {
  return (
    <div
      className="flex-[1_0_0] h-full min-h-px min-w-px relative"
      data-name="Container"
    >
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pb-[26px] pl-0 pr-[40px] pt-0 relative size-full">
          <Section5 />
          <Section6 />
        </div>
      </div>
    </div>
  );
}

function Container40() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch"
      data-name="Container"
    >
      <Container39 />
    </div>
  );
}

function Container41() {
  return (
    <div
      className="content-stretch flex items-start max-w-[640px] relative shrink-0 w-full"
      data-name="Container"
    >
      <Container16 />
      <Container28 />
      <Container40 />
    </div>
  );
}

function Section7() {
  return (
    <div
      className="bg-[#e9f2fc] content-stretch flex flex-col items-start mb-[-1px] pb-[100px] px-4 md:px-8 lg:px-16 xl:px-32 pt-0 relative shrink-0 w-full"
      data-name="Section"
    >
      <Container41 />
    </div>
  );
}

function Heading1() {
  return (
    <div
      className="content-stretch flex flex-col items-center relative shrink-0 w-full"
      data-name="Heading 2"
    >
      <div className="css-g0mm18 flex flex-col font-['Manrope:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[32px] text-center text-white">
        <p className="css-ew64yg leading-[42px]">
          Need more protection?
        </p>
      </div>
    </div>
  );
}

function Container42() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full"
      data-name="Container"
    >
      <Heading1 />
    </div>
  );
}

function Margin1() {
  return (
    <div
      className="content-stretch flex flex-col h-[78px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full"
      data-name="Margin"
    >
      <Container42 />
    </div>
  );
}

function Group() {
  return (
    <div
      className="absolute inset-[68.03%_20.04%_23.13%_59.96%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[29.4px_12.74px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup}')` }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 29.3996 12.741"
      >
        <g id="Group">
          <path
            d={svgPaths.p2e19aa00}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector"
          />
          <path
            d={svgPaths.p35b13dc0}
            fill="var(--fill-0, #CCF5C6)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p2c56c300}
            fill="var(--fill-0, #CCF5C6)"
            id="Vector_3"
          />
          <path
            d={svgPaths.pf628400}
            fill="var(--fill-0, #0078D6)"
            id="Vector_4"
          />
          <path
            d={svgPaths.p3183f200}
            fill="var(--fill-0, #0078D6)"
            id="Vector_5"
          />
          <path
            d={svgPaths.pb388b00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_6"
          />
          <path
            d={svgPaths.p28684200}
            fill="var(--fill-0, #0078D6)"
            id="Vector_7"
          />
          <path
            d={svgPaths.p1cab1700}
            fill="var(--fill-0, #0078D6)"
            id="Vector_8"
          />
          <path
            d={svgPaths.p2b32a000}
            fill="var(--fill-0, #0078D6)"
            id="Vector_9"
          />
          <path
            d={svgPaths.p6fb0d00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_10"
          />
          <path
            d={svgPaths.p15ecee00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_11"
          />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup() {
  return (
    <div
      className="absolute contents inset-[68.03%_20.04%_23.13%_59.96%]"
      data-name="Clip path group"
    >
      <Group />
    </div>
  );
}

function Group1() {
  return (
    <div
      className="absolute inset-[51.82%_66.71%_23.13%_7.96%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-10.778px_-0.175px] mask-size-[48.02px_36.26px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup1}')` }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 37.2432 36.0849"
      >
        <g id="Group">
          <path
            d={svgPaths.p7f9b600}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector"
          />
          <path
            d={svgPaths.p2a751f0}
            fill="var(--fill-0, #CCF5C6)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p144f8200}
            fill="var(--fill-0, #0078D6)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p2f2df100}
            fill="var(--fill-0, #0078D6)"
            id="Vector_4"
          />
          <path
            d={svgPaths.p2b5fb900}
            fill="var(--fill-0, #0078D6)"
            id="Vector_5"
          />
          <path
            d={svgPaths.pd0ccbc0}
            fill="var(--fill-0, #0078D6)"
            id="Vector_6"
          />
          <path
            d={svgPaths.p3c884d00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_7"
          />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup1() {
  return (
    <div
      className="absolute contents inset-[51.7%_66.71%_23.13%_0.62%]"
      data-name="Clip path group"
    >
      <Group1 />
    </div>
  );
}

function Component3() {
  return (
    <div
      className="h-[144.06px] overflow-clip relative shrink-0 w-[147px]"
      data-name="Component 1"
    >
      <ClipPathGroup />
      <ClipPathGroup1 />
      <div
        className="absolute inset-[57.14%_18.71%_38.78%_71.29%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 14.7 5.88001"
          >
            <path
              d={svgPaths.pb196480}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[38.78%_58.04%_55.78%_28.62%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 19.6 7.83999"
          >
            <path
              d={svgPaths.p1198b600}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div className="absolute flex inset-[76.99%_0.04%_0.67%_0.67%] items-center justify-center">
        <div className="flex-none h-[32.18px] scale-y-[-100%] w-[145.957px]">
          <div
            className="relative size-full"
            data-name="Vector"
          >
            <div
              className="absolute inset-0"
              style={
                {
                  "--fill-0": "rgba(233, 242, 252, 1)",
                } as React.CSSProperties
              }
            >
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 145.957 32.1797"
              >
                <path
                  d={svgPaths.p38987d00}
                  fill="var(--fill-0, #E9F2FC)"
                  id="Vector"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div
        className="absolute inset-[54.08%_34%_34.01%_33%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(255, 255, 255, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 48.51 17.15"
          >
            <path
              d={svgPaths.p9aabc80}
              fill="var(--fill-0, white)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[52.67%_28.69%_19.83%_27.91%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-[-1.86%_-1.15%]"
          style={
            {
              "--fill-0": "rgba(211, 229, 249, 1)",
              "--stroke-0": "rgba(3, 81, 170, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 65.2566 41.0804"
          >
            <path
              d={svgPaths.p3552aa40}
              fill="var(--fill-0, #D3E5F9)"
              id="Vector"
              stroke="var(--stroke-2, #0351AA)"
              strokeMiterlimit="10"
              strokeWidth="1.47"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[60.38%_39.2%_35.89%_53.47%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-[-13.66%_-6.83%]"
          style={
            {
              "--stroke-0": "rgba(3, 81, 170, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 12.232 6.85098"
          >
            <path
              d={svgPaths.p15671900}
              id="Vector"
              stroke="var(--stroke-0, #0351AA)"
              strokeMiterlimit="10"
              strokeWidth="1.47"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[80.12%_32.01%_15.73%_31.23%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-[-12.3%_-1.37%_-12.3%_-1.36%]"
          style={
            {
              "--fill-0": "rgba(167, 202, 242, 1)",
              "--stroke-0": "rgba(3, 81, 170, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 55.52 7.44604"
          >
            <path
              d={svgPaths.p2badb340}
              fill="var(--fill-0, #A7CAF2)"
              id="Vector"
              stroke="var(--stroke-2, #0351AA)"
              strokeMiterlimit="10"
              strokeWidth="1.47"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[71.27%_60.96%_23.94%_31.93%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-[-10.65%_-7.03%]"
          style={
            {
              "--fill-0": "rgba(255, 255, 255, 1)",
              "--stroke-0": "rgba(3, 81, 170, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 11.9274 8.37312"
          >
            <path
              d={svgPaths.p27006700}
              fill="var(--fill-0, white)"
              id="Vector"
              stroke="var(--stroke-2, #0351AA)"
              strokeMiterlimit="10"
              strokeWidth="1.47"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[71.27%_32.52%_23.94%_60.36%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-[-10.65%_-7.03%]"
          style={
            {
              "--fill-0": "rgba(255, 255, 255, 1)",
              "--stroke-0": "rgba(3, 81, 170, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 11.9271 8.37312"
          >
            <path
              d={svgPaths.p32d96300}
              fill="var(--fill-0, white)"
              id="Vector"
              stroke="var(--stroke-2, #0351AA)"
              strokeMiterlimit="10"
              strokeWidth="1.47"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[75.21%_43.46%_24.79%_43.67%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-[-0.74px_-3.88%]"
          style={
            {
              "--stroke-0": "rgba(3, 81, 170, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 20.3977 1.47"
          >
            <path
              d="M0.735 0.735H19.6627"
              id="Vector"
              stroke="var(--stroke-0, #0351AA)"
              strokeLinecap="round"
              strokeMiterlimit="10"
              strokeWidth="1.47"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[72.09%_43.46%_27.91%_43.67%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-[-0.74px_-3.88%]"
          style={
            {
              "--stroke-0": "rgba(3, 81, 170, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 20.3977 1.47"
          >
            <path
              d="M0.735 0.735H19.6627"
              id="Vector"
              stroke="var(--stroke-0, #0351AA)"
              strokeLinecap="round"
              strokeMiterlimit="10"
              strokeWidth="1.47"
            />
          </svg>
        </div>
      </div>
    </div>
  );
}

function AutoIcon41SvgFill() {
  return (
    <div
      className="content-stretch flex flex-col h-[144px] items-center justify-center overflow-clip relative shrink-0 w-[147px]"
      data-name="auto-icon4-1.svg fill"
    >
      <Component3 />
    </div>
  );
}

function CarIllustrationIcon() {
  return (
    <div
      className="flex-[1_0_0] h-[144px] min-h-px min-w-px relative rounded-[20px]"
      data-name="car illustration icon"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <AutoIcon41SvgFill />
      </div>
    </div>
  );
}

function Container43() {
  return (
    <div
      className="content-stretch flex flex-col items-center relative shrink-0"
      data-name="Container"
    >
      <div
        className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[14px] text-center"
        role="link"
        tabIndex="0"
      >
        <p className="css-ew64yg cursor-pointer leading-[14px]">
          
        </p>
      </div>
    </div>
  );
}

function Margin2() {
  return (
    <div
      className="content-stretch flex flex-col items-start pl-[8px] pr-0 py-0 relative shrink-0"
      data-name="Margin"
    >
      <Container43 />
    </div>
  );
}

function Container44() {
  return (
    <div
      className="absolute left-[31.1%] right-[31.11%] top-[23px]"
      data-name="Container"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative w-full">
        <div
          className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px] text-center"
          role="link"
          tabIndex="0"
        >
          <p className="css-ew64yg cursor-pointer leading-[26px]">
            Auto
          </p>
        </div>
        <Margin2 />
      </div>
    </div>
  );
}

function Component10() {
  return (
    <a
      className="bg-white h-[146px] relative rounded-[20px] shrink-0 w-[149px]"
      data-name="Component 11"
      href="https://www.plymouthrock.com/insurance/auto"
    >
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">
        <CarIllustrationIcon />
        <Container44 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]"
      />
    </a>
  );
}

function Group2() {
  return (
    <div
      className="absolute inset-[68.03%_20.04%_23.13%_59.96%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[29.4px_12.74px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup}')` }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 29.3996 12.741"
      >
        <g id="Group">
          <path
            d={svgPaths.p2e19aa00}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector"
          />
          <path
            d={svgPaths.p305a4400}
            fill="var(--fill-0, #CCF5C6)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p2c56c300}
            fill="var(--fill-0, #CCF5C6)"
            id="Vector_3"
          />
          <path
            d={svgPaths.pc646d00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_4"
          />
          <path
            d={svgPaths.p3183f200}
            fill="var(--fill-0, #0078D6)"
            id="Vector_5"
          />
          <path
            d={svgPaths.pb388b00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_6"
          />
          <path
            d={svgPaths.p3ff57680}
            fill="var(--fill-0, #0078D6)"
            id="Vector_7"
          />
          <path
            d={svgPaths.p14944000}
            fill="var(--fill-0, #0078D6)"
            id="Vector_8"
          />
          <path
            d={svgPaths.p1b3e4a80}
            fill="var(--fill-0, #0078D6)"
            id="Vector_9"
          />
          <path
            d={svgPaths.p2b426700}
            fill="var(--fill-0, #0078D6)"
            id="Vector_10"
          />
          <path
            d={svgPaths.p142bc480}
            fill="var(--fill-0, #0078D6)"
            id="Vector_11"
          />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup2() {
  return (
    <div
      className="absolute contents inset-[68.03%_20.04%_23.13%_59.96%]"
      data-name="Clip path group"
    >
      <Group2 />
    </div>
  );
}

function Group3() {
  return (
    <div
      className="absolute inset-[51.82%_66.71%_23.13%_7.96%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-10.778px_-0.175px] mask-size-[48.02px_36.26px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup1}')` }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 37.2429 36.0849"
      >
        <g id="Group">
          <path
            d={svgPaths.p9549480}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector"
          />
          <path
            d={svgPaths.p2beb22f0}
            fill="var(--fill-0, #CCF5C6)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p31c60e00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p251c2180}
            fill="var(--fill-0, #0078D6)"
            id="Vector_4"
          />
          <path
            d={svgPaths.pfd95400}
            fill="var(--fill-0, #0078D6)"
            id="Vector_5"
          />
          <path
            d={svgPaths.p222c3e00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_6"
          />
          <path
            d={svgPaths.p31c64300}
            fill="var(--fill-0, #0078D6)"
            id="Vector_7"
          />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup3() {
  return (
    <div
      className="absolute contents inset-[51.7%_66.71%_23.13%_0.62%]"
      data-name="Clip path group"
    >
      <Group3 />
    </div>
  );
}

function Group4() {
  return (
    <div
      className="absolute inset-[45.38%_29.28%_12.72%_28.36%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-0.711px_-0.69px] mask-size-[63.7px_61.74px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup2}')` }}
    >
      <div className="absolute inset-[-1.22%_-1.18%]">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 63.7473 61.8303"
        >
          <g id="Group">
            <path
              d={svgPaths.p1abebb00}
              fill="var(--fill-0, #D3E5F9)"
              id="Vector"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              d={svgPaths.p26bde280}
              fill="var(--fill-0, white)"
              id="Vector_2"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              d={svgPaths.p253f9500}
              fill="var(--fill-0, white)"
              id="Vector_3"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              d={svgPaths.p7249a00}
              fill="var(--fill-0, white)"
              id="Vector_4"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              d={svgPaths.pcab8800}
              fill="var(--fill-0, #BADBFF)"
              id="Vector_5"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              d={svgPaths.p3c41d8c0}
              fill="var(--fill-0, #BADBFF)"
              id="Vector_6"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ClipPathGroup4() {
  return (
    <div
      className="absolute contents inset-[44.9%_28.8%_12.24%_27.87%]"
      data-name="Clip path group"
    >
      <Group4 />
    </div>
  );
}

function Component4() {
  return (
    <div
      className="h-[144.06px] overflow-clip relative shrink-0 w-[147px]"
      data-name="Component 1"
    >
      <ClipPathGroup2 />
      <ClipPathGroup3 />
      <div
        className="absolute inset-[57.14%_18.71%_38.78%_71.29%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 14.7 5.88001"
          >
            <path
              d={svgPaths.pb196480}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[38.78%_58.04%_55.78%_28.62%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 19.6 7.83999"
          >
            <path
              d={svgPaths.p1198b600}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div className="absolute flex inset-[76.99%_0.04%_0.67%_0.67%] items-center justify-center">
        <div className="flex-none h-[32.18px] scale-y-[-100%] w-[145.957px]">
          <div
            className="relative size-full"
            data-name="Vector"
          >
            <div
              className="absolute inset-0"
              style={
                {
                  "--fill-0": "rgba(233, 242, 252, 1)",
                } as React.CSSProperties
              }
            >
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 145.957 32.1797"
              >
                <path
                  d={svgPaths.p38987d00}
                  fill="var(--fill-0, #E9F2FC)"
                  id="Vector"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <ClipPathGroup4 />
    </div>
  );
}

function HomeIconSvgFill() {
  return (
    <div
      className="content-stretch flex flex-col h-[144px] items-center justify-center overflow-clip relative shrink-0 w-[147px]"
      data-name="home-icon.svg fill"
    >
      <Component4 />
    </div>
  );
}

function HomeIllustrationIcon() {
  return (
    <div
      className="flex-[1_0_0] h-[144px] min-h-px min-w-px relative rounded-[20px]"
      data-name="home illustration icon"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <HomeIconSvgFill />
      </div>
    </div>
  );
}

function Container45() {
  return (
    <div
      className="content-stretch flex flex-col items-center relative shrink-0"
      data-name="Container"
    >
      <div
        className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[14px] text-center"
        role="link"
        tabIndex="0"
      >
        <p className="css-ew64yg cursor-pointer leading-[14px]">
          
        </p>
      </div>
    </div>
  );
}

function Margin3() {
  return (
    <div
      className="content-stretch flex flex-col items-start pl-[8px] pr-0 py-0 relative shrink-0"
      data-name="Margin"
    >
      <Container45 />
    </div>
  );
}

function Container46() {
  return (
    <div
      className="absolute left-[27.85%] right-[27.85%] top-[23px]"
      data-name="Container"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative w-full">
        <div
          className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px] text-center"
          role="link"
          tabIndex="0"
        >
          <p className="css-ew64yg cursor-pointer leading-[26px]">
            Home
          </p>
        </div>
        <Margin3 />
      </div>
    </div>
  );
}

function Component14() {
  return (
    <a
      className="bg-white h-[146px] relative rounded-[20px] shrink-0 w-[149px]"
      data-name="Component 11"
      href="https://www.plymouthrock.com/insurance/home"
    >
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">
        <HomeIllustrationIcon />
        <Container46 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]"
      />
    </a>
  );
}

function Group5() {
  return (
    <div
      className="absolute inset-[65.31%_15.44%_23.13%_59.06%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-0.001px_0px] mask-size-[37.49px_16.772px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup3}')` }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 37.4894 16.7728"
      >
        <g id="Group">
          <path
            d={svgPaths.p1a574cc0}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector"
          />
          <path
            d={svgPaths.p2304eb00}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p3d21bf00}
            fill="var(--fill-0, #CCF5C6)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p13953280}
            fill="var(--fill-0, #0078D6)"
            id="Vector_4"
          />
          <path
            d={svgPaths.p3caf9f00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_5"
          />
          <path
            d={svgPaths.p27c1b780}
            fill="var(--fill-0, #0078D6)"
            id="Vector_6"
          />
          <path
            d={svgPaths.p3034f800}
            fill="var(--fill-0, #0078D6)"
            id="Vector_7"
          />
          <path
            d={svgPaths.pd705200}
            fill="var(--fill-0, #0078D6)"
            id="Vector_8"
          />
          <path
            d={svgPaths.p3684ea80}
            fill="var(--fill-0, #0078D6)"
            id="Vector_9"
          />
          <path
            d={svgPaths.p1b453480}
            fill="var(--fill-0, #0078D6)"
            id="Vector_10"
          />
          <path
            d={svgPaths.p159bba00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_11"
          />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup5() {
  return (
    <div
      className="absolute contents inset-[65.31%_15.44%_23.13%_59.06%]"
      data-name="Clip path group"
    >
      <Group5 />
    </div>
  );
}

function Group6() {
  return (
    <div
      className="absolute inset-[63.95%_72.61%_23.13%_15.94%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-15.538px_0px] mask-size-[43.409px_18.745px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup4}')` }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16.831 18.7445"
      >
        <g id="Group">
          <path
            d={svgPaths.p1ec5d900}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector"
          />
          <path
            d={svgPaths.p3b8f7f00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p33f61e00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p3aa1b900}
            fill="var(--fill-0, #0078D6)"
            id="Vector_4"
          />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup6() {
  return (
    <div
      className="absolute contents inset-[63.95%_65.1%_23.13%_5.37%]"
      data-name="Clip path group"
    >
      <Group6 />
    </div>
  );
}

function Group7() {
  return (
    <div
      className="absolute inset-[40.67%_26.7%_12.1%_26.7%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-0.779px_-0.78px] mask-size-[70.047px_70.047px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup5}')` }}
    >
      <div className="absolute inset-[-1.08%]">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 69.9691 69.9666"
        >
          <g id="Group">
            <path
              d={svgPaths.p2de4a800}
              fill="var(--fill-0, #D3E5F9)"
              id="Vector"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p36503300}
              fill="var(--fill-0, #D3E5F9)"
              id="Vector_2"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p32fee5f0}
              fill="var(--fill-0, white)"
              id="Vector_3"
              stroke="var(--stroke-1, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.pb380c00}
              fill="var(--fill-0, white)"
              id="Vector_4"
              stroke="var(--stroke-1, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p1e528f00}
              fill="var(--fill-0, white)"
              id="Vector_5"
              stroke="var(--stroke-1, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p8be6f80}
              fill="var(--fill-0, #BADBFF)"
              id="Vector_6"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p32279400}
              fill="var(--fill-0, #BADBFF)"
              id="Vector_7"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p312a6f80}
              fill="var(--fill-0, #BADBFF)"
              id="Vector_8"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p17f0d7f1}
              fill="var(--fill-0, #BADBFF)"
              id="Vector_9"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ClipPathGroup7() {
  return (
    <div
      className="absolute contents inset-[40.14%_26.17%_11.56%_26.17%]"
      data-name="Clip path group"
    >
      <Group7 />
    </div>
  );
}

function Component5() {
  return (
    <div
      className="absolute h-[145.027px] left-1/2 overflow-clip top-1/2 translate-x-[-50%] translate-y-[-50%] w-[147px]"
      data-name="Component 1"
    >
      <ClipPathGroup5 />
      <ClipPathGroup6 />
      <div className="absolute flex inset-[76.99%_0.04%_0.67%_0] items-center justify-center">
        <div className="flex-none h-[32.396px] scale-y-[-100%] w-[146.937px]">
          <div
            className="relative size-full"
            data-name="Vector"
          >
            <div
              className="absolute inset-0"
              style={
                {
                  "--fill-0": "rgba(233, 242, 252, 1)",
                } as React.CSSProperties
              }
            >
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 146.937 32.3956"
              >
                <path
                  d={svgPaths.p21a3fa00}
                  fill="var(--fill-0, #E9F2FC)"
                  id="Vector"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div
        className="absolute inset-[39.46%_59.9%_55.1%_26.68%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 19.7315 7.89261"
          >
            <path
              d={svgPaths.p21ba2880}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[44.9%_86.08%_51.02%_3.86%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 14.7987 5.91948"
          >
            <path
              d={svgPaths.p38799800}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[44.9%_8.9%_48.3%_74.33%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 24.6644 9.86579"
          >
            <path
              d={svgPaths.pd7d2b00}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <ClipPathGroup7 />
    </div>
  );
}

function CondoIconSvgFill() {
  return (
    <div
      className="h-[144px] overflow-clip relative shrink-0 w-[147px]"
      data-name="condo-icon.svg fill"
    >
      <Component5 />
    </div>
  );
}

function CondoIllustrationIcon() {
  return (
    <div
      className="flex-[1_0_0] h-[144px] min-h-px min-w-px relative rounded-[20px]"
      data-name="condo illustration icon"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <CondoIconSvgFill />
      </div>
    </div>
  );
}

function Container47() {
  return (
    <div
      className="content-stretch flex flex-col items-center relative shrink-0"
      data-name="Container"
    >
      <div
        className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[14px] text-center"
        role="link"
        tabIndex="0"
      >
        <p className="css-ew64yg cursor-pointer leading-[14px]">
          
        </p>
      </div>
    </div>
  );
}

function Margin4() {
  return (
    <div
      className="content-stretch flex flex-col items-start pl-[8px] pr-0 py-0 relative shrink-0"
      data-name="Margin"
    >
      <Container47 />
    </div>
  );
}

function Container48() {
  return (
    <div
      className="absolute left-[26.64%] right-[26.63%] top-[23px]"
      data-name="Container"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative w-full">
        <div
          className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px] text-center"
          role="link"
          tabIndex="0"
        >
          <p className="css-ew64yg cursor-pointer leading-[26px]">
            Condo
          </p>
        </div>
        <Margin4 />
      </div>
    </div>
  );
}

function Component15() {
  return (
    <a
      className="bg-white h-[146px] relative rounded-[20px] shrink-0 w-[149px]"
      data-name="Component 11"
      href="https://www.plymouthrock.com/insurance/condo"
    >
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">
        <CondoIllustrationIcon />
        <Container48 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]"
      />
    </a>
  );
}

function Group8() {
  return (
    <div
      className="absolute inset-[51.02%_68.41%_23.13%_15.48%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[23.678px_37.49px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup6}')` }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 23.6786 37.4899"
      >
        <g id="Group">
          <path
            d={svgPaths.p2306d500}
            fill="var(--fill-0, #CCF5C6)"
            id="Vector"
          />
          <path
            d={svgPaths.p1be280}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p273a2c40}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p381c2180}
            fill="var(--fill-0, #0078D6)"
            id="Vector_4"
          />
          <path
            d={svgPaths.p21e8bc00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_5"
          />
          <path
            d={svgPaths.p1cd81680}
            fill="var(--fill-0, #0078D6)"
            id="Vector_6"
          />
          <path
            d={svgPaths.p2957f200}
            fill="var(--fill-0, #0078D6)"
            id="Vector_7"
          />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup8() {
  return (
    <div
      className="absolute contents inset-[51.02%_68.41%_23.13%_15.48%]"
      data-name="Clip path group"
    >
      <Group8 />
    </div>
  );
}

function Group9() {
  return (
    <div
      className="absolute inset-[45.39%_27.89%_11.38%_29.48%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-0.719px_-0.719px] mask-size-[64.128px_64.128px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup7}')` }}
    >
      <div className="absolute inset-[-1.18%]">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 64.1552 64.1687"
        >
          <g id="Group">
            <path
              d={svgPaths.p3ed8ec0}
              fill="var(--fill-0, #D3E5F9)"
              id="Vector"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p145eda00}
              fill="var(--fill-0, #D3E5F9)"
              id="Vector_2"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p3cfa30f0}
              fill="var(--fill-0, #D3E5F9)"
              id="Vector_3"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p363adc00}
              fill="var(--fill-0, white)"
              id="Vector_4"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p1a57f930}
              fill="var(--fill-0, white)"
              id="Vector_5"
              stroke="var(--stroke-1, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p3d089a10}
              fill="var(--fill-0, white)"
              id="Vector_6"
              stroke="var(--stroke-1, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p19819b00}
              fill="var(--fill-0, white)"
              id="Vector_7"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p24299300}
              fill="var(--fill-0, white)"
              id="Vector_8"
              stroke="var(--stroke-1, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p164200}
              fill="var(--fill-0, white)"
              id="Vector_9"
              stroke="var(--stroke-1, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p16bad00}
              fill="var(--fill-0, #BADBFF)"
              id="Vector_10"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.pd577c00}
              fill="var(--fill-0, #BADBFF)"
              id="Vector_11"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p2be31b00}
              fill="var(--fill-0, white)"
              id="Vector_12"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p7a2ce00}
              fill="var(--fill-0, white)"
              id="Vector_13"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p2265e270}
              fill="var(--fill-0, white)"
              id="Vector_14"
              stroke="var(--stroke-1, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p15d0f080}
              fill="var(--fill-0, white)"
              id="Vector_15"
              stroke="var(--stroke-1, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p2e4a180}
              fill="var(--fill-0, white)"
              id="Vector_16"
              stroke="var(--stroke-1, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
            <path
              d={svgPaths.p2aa2d800}
              fill="var(--fill-0, white)"
              id="Vector_17"
              stroke="var(--stroke-1, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47987"
            />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ClipPathGroup9() {
  return (
    <div
      className="absolute contents inset-[44.9%_27.39%_10.88%_28.99%]"
      data-name="Clip path group"
    >
      <Group9 />
    </div>
  );
}

function Component6() {
  return (
    <div
      className="absolute h-[145.027px] left-1/2 overflow-clip top-1/2 translate-x-[-50%] translate-y-[-50%] w-[147px]"
      data-name="Component 1"
    >
      <div
        className="absolute inset-[65.31%_16.06%_20.41%_69.17%]"
        data-name="Vector"
      >
        <img
          alt=""
          className="block max-w-none size-full"
          height="20.718"
          src={imgVector}
          width="21.705"
        />
      </div>
      <ClipPathGroup8 />
      <div
        className="absolute inset-[36.05%_75.8%_57.14%_7.43%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 24.6644 9.86579"
          >
            <path
              d={svgPaths.p27826400}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[44.22%_7.34%_51.7%_82.59%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 14.7986 5.91948"
          >
            <path
              d={svgPaths.p19514300}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[34.69%_35.53%_61.22%_54.41%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 14.7987 5.91947"
          >
            <path
              d={svgPaths.p24443300}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div className="absolute flex inset-[76.99%_0.04%_0.67%_0] items-center justify-center">
        <div className="flex-none h-[32.396px] scale-y-[-100%] w-[146.937px]">
          <div
            className="relative size-full"
            data-name="Vector"
          >
            <div
              className="absolute inset-0"
              style={
                {
                  "--fill-0": "rgba(233, 242, 252, 1)",
                } as React.CSSProperties
              }
            >
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 146.937 32.3956"
              >
                <path
                  d={svgPaths.p21a3fa00}
                  fill="var(--fill-0, #E9F2FC)"
                  id="Vector"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <ClipPathGroup9 />
    </div>
  );
}

function RentersIconSvgFill() {
  return (
    <div
      className="h-[144px] overflow-clip relative shrink-0 w-[147px]"
      data-name="renters-icon.svg fill"
    >
      <Component6 />
    </div>
  );
}

function RentersIllustrationIcon() {
  return (
    <div
      className="flex-[1_0_0] h-[144px] min-h-px min-w-px relative rounded-[20px]"
      data-name="renters illustration icon"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <RentersIconSvgFill />
      </div>
    </div>
  );
}

function Container49() {
  return (
    <div
      className="content-stretch flex flex-col items-center relative shrink-0"
      data-name="Container"
    >
      <div
        className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[14px] text-center"
        role="link"
        tabIndex="0"
      >
        <p className="css-ew64yg cursor-pointer leading-[14px]">
          
        </p>
      </div>
    </div>
  );
}

function Margin5() {
  return (
    <div
      className="content-stretch flex flex-col items-start pl-[8px] pr-0 py-0 relative shrink-0"
      data-name="Margin"
    >
      <Container49 />
    </div>
  );
}

function Container50() {
  return (
    <div
      className="absolute left-[23.51%] right-[23.51%] top-[23px]"
      data-name="Container"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative w-full">
        <div
          className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px] text-center"
          role="link"
          tabIndex="0"
        >
          <p className="css-ew64yg cursor-pointer leading-[26px]">
            Renters
          </p>
        </div>
        <Margin5 />
      </div>
    </div>
  );
}

function Component16() {
  return (
    <a
      className="bg-white h-[146px] relative rounded-[20px] shrink-0 w-[149px]"
      data-name="Component 11"
      href="https://www.plymouthrock.com/insurance/renters"
    >
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">
        <RentersIllustrationIcon />
        <Container50 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]"
      />
    </a>
  );
}

function Group10() {
  return (
    <div
      className="absolute inset-[50.34%_73.6%_23.81%_10.61%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0.001px_0px] mask-size-[23.51px_37.224px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup8}')` }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 23.5109 37.2245"
      >
        <g id="Group">
          <path
            d={svgPaths.p37abd80}
            fill="var(--fill-0, #CCF5C6)"
            id="Vector"
          />
          <path
            d={svgPaths.p25d32300}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p35939080}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p6b6b270}
            fill="var(--fill-0, #0078D6)"
            id="Vector_4"
          />
          <path
            d={svgPaths.p1c0fdf00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_5"
          />
          <path
            d={svgPaths.p2d00e680}
            fill="var(--fill-0, #0078D6)"
            id="Vector_6"
          />
          <path
            d={svgPaths.p37dcb590}
            fill="var(--fill-0, #0078D6)"
            id="Vector_7"
          />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup10() {
  return (
    <div
      className="absolute contents inset-[50.34%_73.6%_23.81%_10.61%]"
      data-name="Clip path group"
    >
      <Group10 />
    </div>
  );
}

function Group11() {
  return (
    <div
      className="absolute inset-[61.22%_9.94%_22.45%_75.77%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-19.636px_-0.001px] mask-size-[54.857px_23.51px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup9}')` }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 21.2697 23.5095"
      >
        <g id="Group">
          <path
            d={svgPaths.p2c16ea00}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector"
          />
          <path
            d={svgPaths.p353f0200}
            fill="var(--fill-0, #0078D6)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p293b57c0}
            fill="var(--fill-0, #0078D6)"
            id="Vector_3"
          />
          <path
            d={svgPaths.pe8f2c00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_4"
          />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup11() {
  return (
    <div
      className="absolute contents inset-[61.22%_0.57%_22.45%_62.58%]"
      data-name="Clip path group"
    >
      <Group11 />
    </div>
  );
}

function Group12() {
  return (
    <div
      className="absolute inset-[51.7%_22.38%_12.93%_19.74%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-0.981px_-0.974px] mask-size-[88.163px_52.898px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup10}')` }}
    >
      <div className="absolute inset-[-1.44%_-0.85%]">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 87.6535 52.4008"
        >
          <g id="Group">
            <path
              d={svgPaths.p1ee8fd00}
              fill="var(--fill-0, #BADBFF)"
              id="Vector"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              d={svgPaths.p15d76500}
              fill="var(--fill-0, #BADBFF)"
              id="Vector_2"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              d={svgPaths.p152e2e00}
              id="Vector_3"
              stroke="var(--stroke-0, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              d={svgPaths.p1ee93780}
              fill="var(--fill-0, #0351AA)"
              id="Vector_4"
            />
            <path
              clipRule="evenodd"
              d={svgPaths.p2b23ec00}
              fill="var(--fill-0, white)"
              fillRule="evenodd"
              id="Vector_5"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              clipRule="evenodd"
              d={svgPaths.p1e7fdbf0}
              fill="var(--fill-0, white)"
              fillRule="evenodd"
              id="Vector_6"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              clipRule="evenodd"
              d={svgPaths.p1c054800}
              fillRule="evenodd"
              id="Vector_7"
              stroke="var(--stroke-0, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              clipRule="evenodd"
              d={svgPaths.p342de700}
              fillRule="evenodd"
              id="Vector_8"
              stroke="var(--stroke-0, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              clipRule="evenodd"
              d={svgPaths.p2e0e3900}
              fill="var(--fill-0, #D3E5F9)"
              fillRule="evenodd"
              id="Vector_9"
            />
            <path
              d={svgPaths.p2e0e3900}
              id="Vector_10"
              stroke="var(--stroke-0, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              clipRule="evenodd"
              d={svgPaths.p8d29380}
              fill="var(--fill-0, #D3E5F9)"
              fillRule="evenodd"
              id="Vector_11"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              d={svgPaths.p38252100}
              fill="var(--fill-0, #D3E5F9)"
              id="Vector_12"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
            <path
              d={svgPaths.p25a6a500}
              fill="var(--fill-0, white)"
              id="Vector_13"
              stroke="var(--stroke-2, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ClipPathGroup12() {
  return (
    <div
      className="absolute contents inset-[51.02%_21.71%_12.24%_19.08%]"
      data-name="Clip path group"
    >
      <Group12 />
    </div>
  );
}

function Component7() {
  return (
    <div
      className="h-[144px] overflow-clip relative shrink-0 w-[148.898px]"
      data-name="Component 1"
    >
      <div
        className="absolute inset-[38.1%_68.34%_55.1%_15.22%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 24.4898 9.79594"
          >
            <path
              d={svgPaths.p1010c700}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[42.18%_19%_53.74%_69.82%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 16.6531 5.87756"
          >
            <path
              d={svgPaths.p60c4b80}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <ClipPathGroup10 />
      <ClipPathGroup11 />
      <div className="absolute flex inset-[76.87%_2.63%_1.36%_0.66%] items-center justify-center">
        <div className="flex-none h-[31.347px] scale-y-[-100%] w-[144px]">
          <div
            className="relative size-full"
            data-name="Vector"
          >
            <div
              className="absolute inset-0"
              style={
                {
                  "--fill-0": "rgba(233, 242, 252, 1)",
                } as React.CSSProperties
              }
            >
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 144 31.3469"
              >
                <path
                  d="M144 0H0V31.3469H144V0Z"
                  fill="var(--fill-0, #E9F2FC)"
                  id="Vector"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <ClipPathGroup12 />
    </div>
  );
}

function MotorcycleIconSvgFill() {
  return (
    <div
      className="content-stretch flex flex-col h-[144px] items-center justify-center overflow-clip relative shrink-0 w-[147px]"
      data-name="motorcycle-icon.svg fill"
    >
      <Component7 />
    </div>
  );
}

function MotorcycleIllustrationIcon() {
  return (
    <div
      className="flex-[1_0_0] h-[144px] min-h-px min-w-px relative rounded-[20px]"
      data-name="motorcycle illustration icon"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <MotorcycleIconSvgFill />
      </div>
    </div>
  );
}

function Container51() {
  return (
    <div
      className="content-stretch flex flex-col items-center relative shrink-0"
      data-name="Container"
    >
      <div
        className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[14px] text-center"
        role="link"
        tabIndex="0"
      >
        <p className="css-ew64yg cursor-pointer leading-[14px]">
          
        </p>
      </div>
    </div>
  );
}

function Margin6() {
  return (
    <div
      className="content-stretch flex flex-col items-start pl-[8px] pr-0 py-0 relative shrink-0"
      data-name="Margin"
    >
      <Container51 />
    </div>
  );
}

function Container52() {
  return (
    <div
      className="absolute left-[15.04%] right-[15.03%] top-[23px]"
      data-name="Container"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative w-full">
        <div
          className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px] text-center"
          role="link"
          tabIndex="0"
        >
          <p className="css-ew64yg cursor-pointer leading-[26px]">
            Motorcycle
          </p>
        </div>
        <Margin6 />
      </div>
    </div>
  );
}

function Component17() {
  return (
    <a
      className="bg-white h-[146px] relative rounded-[20px] shrink-0 w-[149px]"
      data-name="Component 11"
      href="https://www.plymouthrock.com/insurance/motorcycle"
    >
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">
        <MotorcycleIllustrationIcon />
        <Container52 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]"
      />
    </a>
  );
}

function Group13() {
  return (
    <div
      className="absolute inset-[51.02%_73.56%_23.13%_10.65%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[23.51px_37.224px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup8}')` }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 23.5103 37.2245"
      >
        <g id="Group">
          <path
            d={svgPaths.p2899ea00}
            fill="var(--fill-0, #CCF5C6)"
            id="Vector"
          />
          <path
            d={svgPaths.padd0b80}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p1351ad70}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p6bcce00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_4"
          />
          <path
            d={svgPaths.p10391a00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_5"
          />
          <path
            d={svgPaths.p3da17700}
            fill="var(--fill-0, #0078D6)"
            id="Vector_6"
          />
          <path
            d={svgPaths.p6dffb80}
            fill="var(--fill-0, #0078D6)"
            id="Vector_7"
          />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup13() {
  return (
    <div
      className="absolute contents inset-[51.02%_73.56%_23.13%_10.65%]"
      data-name="Clip path group"
    >
      <Group13 />
    </div>
  );
}

function Component8() {
  return (
    <div
      className="h-[144px] overflow-clip relative shrink-0 w-[148.898px]"
      data-name="Component 1"
    >
      <div
        className="absolute inset-[38.1%_68.3%_55.1%_15.26%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 24.4898 9.79594"
          >
            <path
              d={svgPaths.p1010c700}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[42.18%_18.95%_53.74%_69.86%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 16.6531 5.87756"
          >
            <path
              d={svgPaths.p358ba100}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <ClipPathGroup13 />
      <div
        className="absolute inset-[61.22%_9.9%_22.45%_75.81%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(165, 225, 215, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 21.2691 23.5097"
          >
            <path
              d={svgPaths.p25655940}
              fill="var(--fill-0, #A5E1D7)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[63.55%_16.53%_22.51%_82.43%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(0, 120, 214, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 1.55373 20.075"
          >
            <path
              d={svgPaths.p80ae580}
              fill="var(--fill-0, #0078D6)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[69.94%_15.38%_22.47%_83.88%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(0, 120, 214, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 1.09001 10.9301"
          >
            <path
              d={svgPaths.p1f528e00}
              fill="var(--fill-0, #0078D6)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[66.01%_17.56%_22.51%_80.48%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(0, 120, 214, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 2.91414 16.5359"
          >
            <path
              d={svgPaths.p3012a400}
              fill="var(--fill-0, #0078D6)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[46.94%_29.93%_39.46%_32.24%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(255, 255, 255, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 56.3265 19.5918"
          >
            <path
              d={svgPaths.p349ebc00}
              fill="var(--fill-0, white)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div className="absolute flex inset-[76.87%_2.63%_1.36%_0.66%] items-center justify-center">
        <div className="flex-none h-[31.347px] scale-y-[-100%] w-[144px]">
          <div
            className="relative size-full"
            data-name="Vector"
          >
            <div
              className="absolute inset-0"
              style={
                {
                  "--fill-0": "rgba(233, 242, 252, 1)",
                } as React.CSSProperties
              }
            >
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 144 31.3469"
              >
                <path
                  d="M144 0H0V31.3469H144V0Z"
                  fill="var(--fill-0, #E9F2FC)"
                  id="Vector"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div
        className="absolute inset-[82.99%_42.06%_13.61%_44.78%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(186, 219, 255, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 19.5918 4.89796"
          >
            <path
              d={svgPaths.p3d7bbb80}
              fill="var(--fill-0, #BADBFF)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[45.06%_30.21%_15.69%_32.14%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(186, 219, 255, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 56.0603 56.5193"
          >
            <path
              d={svgPaths.p38aecb00}
              fill="var(--fill-0, #BADBFF)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[45.06%_30.21%_15.69%_32.14%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-[-1.3%_-1.31%]"
          style={
            {
              "--stroke-0": "rgba(3, 81, 170, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 57.5305 57.9894"
          >
            <path
              d={svgPaths.p1a2a2900}
              id="Vector"
              stroke="var(--stroke-0, #0351AA)"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.47"
            />
          </svg>
        </div>
      </div>
    </div>
  );
}

function UmbrellaIcon21SvgFill() {
  return (
    <div
      className="content-stretch flex flex-col h-[144px] items-center justify-center overflow-clip relative shrink-0 w-[147px]"
      data-name="umbrella-icon2-1.svg fill"
    >
      <Component8 />
    </div>
  );
}

function UmbrellaIllustrationIcon() {
  return (
    <div
      className="flex-[1_0_0] h-[144px] min-h-px min-w-px relative rounded-[20px]"
      data-name="umbrella illustration icon"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <UmbrellaIcon21SvgFill />
      </div>
    </div>
  );
}

function Container53() {
  return (
    <div
      className="content-stretch flex flex-col items-center relative shrink-0"
      data-name="Container"
    >
      <div
        className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[14px] text-center"
        role="link"
        tabIndex="0"
      >
        <p className="css-ew64yg cursor-pointer leading-[14px]">
          
        </p>
      </div>
    </div>
  );
}

function Margin7() {
  return (
    <div
      className="content-stretch flex flex-col items-start pl-[8px] pr-0 py-0 relative shrink-0"
      data-name="Margin"
    >
      <Container53 />
    </div>
  );
}

function Container54() {
  return (
    <div
      className="absolute left-[19.68%] right-[19.68%] top-[23px]"
      data-name="Container"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative w-full">
        <div
          className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px] text-center"
          role="link"
          tabIndex="0"
        >
          <p className="css-ew64yg cursor-pointer leading-[26px]">
            Umbrella
          </p>
        </div>
        <Margin7 />
      </div>
    </div>
  );
}

function Component18() {
  return (
    <a
      className="bg-white h-[146px] relative rounded-[20px] shrink-0 w-[149px]"
      data-name="Component 11"
      href="https://www.plymouthrock.com/insurance/umbrella"
    >
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">
        <UmbrellaIllustrationIcon />
        <Container54 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]"
      />
    </a>
  );
}

function Group14() {
  return (
    <div
      className="absolute inset-[50.8%_67.04%_23.81%_4.83%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_-5.606px] mask-size-[49.329px_42.423px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup11}')` }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 41.3506 36.817"
      >
        <g id="Group">
          <path
            d={svgPaths.p4e96c00}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector"
          />
          <path
            d={svgPaths.p3ccef3b0}
            fill="var(--fill-0, #CCF5C6)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p3a08a380}
            fill="var(--fill-0, #CCF5C6)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p159ef900}
            fill="var(--fill-0, #A5E1D7)"
            id="Vector_4"
          />
          <path
            d={svgPaths.p36ea2700}
            fill="var(--fill-0, #0078D6)"
            id="Vector_5"
          />
          <path
            d={svgPaths.pc308f00}
            fill="var(--fill-0, #0078D6)"
            id="Vector_6"
          />
          <path
            d={svgPaths.p17e3a8c0}
            fill="var(--fill-0, #0078D6)"
            id="Vector_7"
          />
          <path
            d={svgPaths.p1017cf50}
            fill="var(--fill-0, #0078D6)"
            id="Vector_8"
          />
          <path
            d={svgPaths.ped7fe80}
            fill="var(--fill-0, #0078D6)"
            id="Vector_9"
          />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup14() {
  return (
    <div
      className="absolute contents inset-[46.94%_61.62%_23.81%_4.83%]"
      data-name="Clip path group"
    >
      <Group14 />
    </div>
  );
}

function Group15() {
  return (
    <div
      className="absolute inset-[42.86%_22.99%_13.6%_26.68%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-0.002px_0.002px] mask-size-[73.993px_63.141px]"
      data-name="Group"
      style={{ maskImage: `url('${imgGroup12}')` }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 73.9916 63.1437"
      >
        <g id="Group">
          <path
            d={svgPaths.p231d1500}
            fill="var(--fill-0, #0351AA)"
            id="Vector"
          />
          <path
            d={svgPaths.p18149500}
            fill="var(--fill-0, #E9F2FC)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p12986b00}
            fill="var(--fill-0, #BADBFF)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p2b58d900}
            fill="var(--fill-0, #E9F2FC)"
            id="Vector_4"
          />
          <path
            d={svgPaths.p21a986f0}
            fill="var(--fill-0, #D3E3F6)"
            id="Vector_5"
          />
          <path
            d={svgPaths.p8a5a880}
            fill="var(--fill-0, #E9F2FC)"
            id="Vector_6"
          />
          <path
            d={svgPaths.p8722800}
            fill="var(--fill-0, #E9F2FC)"
            id="Vector_7"
          />
          <path
            d={svgPaths.p3fc1a00}
            fill="var(--fill-0, #E9F2FC)"
            id="Vector_8"
          />
          <path
            d={svgPaths.p2ce68f00}
            fill="var(--fill-0, #E9F2FC)"
            id="Vector_9"
          />
          <path
            d={svgPaths.p695d280}
            fill="var(--fill-0, #0351AA)"
            id="Vector_10"
          />
          <path
            d={svgPaths.p283e7ec0}
            fill="var(--fill-0, #0351AA)"
            id="Vector_11"
          />
          <path
            d={svgPaths.p21223780}
            fill="var(--fill-0, #0351AA)"
            id="Vector_12"
          />
          <path
            d={svgPaths.p15bffc40}
            fill="var(--fill-0, #0351AA)"
            id="Vector_13"
          />
          <path
            d={svgPaths.p1c13b980}
            fill="var(--fill-0, #0351AA)"
            id="Vector_14"
          />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup15() {
  return (
    <div
      className="absolute contents inset-[42.86%_22.99%_13.61%_26.68%]"
      data-name="Clip path group"
    >
      <Group15 />
    </div>
  );
}

function Component19() {
  return (
    <div
      className="absolute h-[145.027px] left-1/2 overflow-clip top-1/2 translate-x-[-50%] translate-y-[-50%] w-[147px]"
      data-name="Component 1"
    >
      <ClipPathGroup14 />
      <div className="absolute flex inset-[76.99%_0.04%_0.67%_0] items-center justify-center">
        <div className="flex-none h-[32.396px] scale-y-[-100%] w-[146.937px]">
          <div
            className="relative size-full"
            data-name="Vector"
          >
            <div
              className="absolute inset-0"
              style={
                {
                  "--fill-0": "rgba(233, 242, 252, 1)",
                } as React.CSSProperties
              }
            >
              <svg
                className="block size-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 146.937 32.3956"
              >
                <path
                  d={svgPaths.p21a3fa00}
                  fill="var(--fill-0, #E9F2FC)"
                  id="Vector"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div
        className="absolute inset-[30.61%_7.3%_63.27%_75.92%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 24.6644 8.8792"
          >
            <path
              d={svgPaths.p3cd76280}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[36.05%_46.22%_59.86%_42.37%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 16.7718 5.91947"
          >
            <path
              d={svgPaths.p39308540}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <div
        className="absolute inset-[38.78%_75.75%_55.1%_6.13%]"
        data-name="Vector"
      >
        <div
          className="absolute inset-0"
          style={
            {
              "--fill-0": "rgba(225, 245, 254, 1)",
            } as React.CSSProperties
          }
        >
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 26.6375 8.8792"
          >
            <path
              d={svgPaths.p2e232060}
              fill="var(--fill-0, #E1F5FE)"
              id="Vector"
            />
          </svg>
        </div>
      </div>
      <ClipPathGroup15 />
    </div>
  );
}

function PetsIconSvgFill() {
  return (
    <div
      className="h-[144px] overflow-clip relative shrink-0 w-[147px]"
      data-name="pets-icon.svg fill"
    >
      <Component19 />
    </div>
  );
}

function PetIllustrationIcon() {
  return (
    <div
      className="flex-[1_0_0] h-[144px] min-h-px min-w-px relative rounded-[20px]"
      data-name="pet illustration icon"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <PetsIconSvgFill />
      </div>
    </div>
  );
}

function Container55() {
  return (
    <div
      className="content-stretch flex flex-col items-center relative shrink-0"
      data-name="Container"
    >
      <div
        className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[14px] text-center"
        role="link"
        tabIndex="0"
      >
        <p className="css-ew64yg cursor-pointer leading-[14px]">
          
        </p>
      </div>
    </div>
  );
}

function Margin8() {
  return (
    <div
      className="content-stretch flex flex-col items-start pl-[8px] pr-0 py-0 relative shrink-0"
      data-name="Margin"
    >
      <Container55 />
    </div>
  );
}

function Container56() {
  return (
    <div
      className="absolute left-[34.87%] right-[34.86%] top-[23px]"
      data-name="Container"
    >
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative w-full">
        <div
          className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px] text-center"
          role="link"
          tabIndex="0"
        >
          <p className="css-ew64yg cursor-pointer leading-[26px]">
            Pet
          </p>
        </div>
        <Margin8 />
      </div>
    </div>
  );
}

function Component20() {
  return (
    <a
      className="bg-white h-[146px] relative rounded-[20px] shrink-0 w-[149px]"
      data-name="Component 11"
      href="https://www.plymouthrock.com/insurance/pets"
    >
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">
        <PetIllustrationIcon />
        <Container56 />
      </div>
      <div
        aria-hidden="true"
        className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]"
      />
    </a>
  );
}

function Container57() {
  return (
    <div
      className="content-center cursor-pointer flex flex-wrap gap-[0px_24px] items-center justify-center relative shrink-0 w-full"
      data-name="Container"
    >
      <Component10 />
      <Component14 />
      <Component15 />
      <Component16 />
      <Component17 />
      <Component18 />
      <Component20 />
    </div>
  );
}

function Container58() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full"
      data-name="Container"
    >
      <Container57 />
    </div>
  );
}

function Margin9() {
  return (
    <div
      className="content-stretch flex flex-col h-[162px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full"
      data-name="Margin"
    >
      <Container58 />
    </div>
  );
}

function Container59() {
  return (
    <div
      className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative self-stretch"
      data-name="Container"
    >
      <Margin1 />
      <Margin9 />
    </div>
  );
}

function Container60() {
  return (
    <div
      className="content-stretch flex items-start justify-center max-w-[1280px] relative shrink-0 w-full"
      data-name="Container"
    >
      <Container59 />
    </div>
  );
}

function Section8() {
  return (
    <div
      className="bg-[#0351aa] content-stretch flex flex-col items-start mb-[-1px] pb-[100px] pt-[75px] px-4 md:px-8 lg:px-16 xl:px-32 relative shrink-0 w-full"
      data-name="Section"
    >
      <Container60 />
    </div>
  );
}

function PlymouthRockSite() {
  return (
    <div
      className="absolute bg-white content-stretch flex flex-col min-h-[814px] items-center left-0 w-full pb-px pt-0 px-0 right-0 top-0"
      data-name="PlymouthRock-site"
    >
      <Section />
      <Section7 />
      <Section8 />
    </div>
  );
}

export default function PrSite() {
  return (
    <div className="relative size-full" data-name="PR-site 5">
      <PlymouthRockSite />
    </div>
  );
}