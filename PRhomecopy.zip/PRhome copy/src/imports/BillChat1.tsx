function Frame4() {
  return (
    <div className="bg-[#eff1f3] content-stretch flex items-center justify-center max-w-[536px] px-[16px] py-[12px] relative rounded-[16px] shrink-0">
      <p className="css-4hzbpn flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[26px] min-h-px min-w-px not-italic relative text-[16px] text-black">I would like to make a payment</p>
    </div>
  );
}

function Frame7() {
  return (
    <div className="content-stretch flex flex-col items-end relative shrink-0 w-full">
      <Frame4 />
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-full">
      <p className="css-4hzbpn flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[26px] min-h-px min-w-px not-italic relative text-[16px] text-black">Hi Joe! Sure, I checked your account and found this billing statement:</p>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col font-['Manrope:Regular',sans-serif] items-start not-italic relative shrink-0 text-black text-center">
      <p className="css-4hzbpn leading-[56px] relative shrink-0 text-[44px] w-[696px]">$252.00</p>
      <p className="css-4hzbpn leading-[28px] relative shrink-0 text-[20px] w-[696px]">Is due on 04/14/2026</p>
    </div>
  );
}

function Base() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="css-ew64yg font-['Open_Sans:Regular',sans-serif] leading-[30px] not-italic relative shrink-0 text-[18px] text-white">Pay Now</p>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#0078d6] content-stretch flex flex-col items-center justify-center overflow-clip px-[20px] py-[12px] relative rounded-[32px] shrink-0 w-[244px]" data-name="<Button>">
      <Base />
    </div>
  );
}

function Base1() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="css-ew64yg font-['Open_Sans:Regular',sans-serif] leading-[30px] not-italic relative shrink-0 text-[#0078d6] text-[18px]">Enable automatic payments</p>
    </div>
  );
}

function Button1() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip px-[11px] py-[8px] relative rounded-[6px] shrink-0" data-name="<Button>">
      <Base1 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-center relative shrink-0">
      <Button />
      <Button1 />
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex flex-col gap-[36px] items-center py-[36px] relative rounded-[30px] shrink-0 w-full">
      <div aria-hidden="true" className="absolute border-[#bec7d1] border-[1.013px] border-solid inset-0 pointer-events-none rounded-[30px]" />
      <p className="css-4hzbpn font-['Manrope:Regular',sans-serif] leading-[42px] min-w-full not-italic relative shrink-0 text-[#0078d6] text-[32px] text-center w-[min-content]">Your nex payment</p>
      <Frame />
      <Frame1 />
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full">
      <Frame2 />
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex flex-col gap-[20px] items-start relative shrink-0 w-full">
      <Frame3 />
      <p className="css-4hzbpn font-['Open_Sans:Regular',sans-serif] leading-[26px] not-italic relative shrink-0 text-[16px] text-black w-full">Would you like to make a payment today?</p>
    </div>
  );
}

function Frame10() {
  return (
    <div className="bg-[#eff1f3] content-stretch flex items-center justify-center max-w-[536px] px-[16px] py-[12px] relative rounded-[16px] shrink-0">
      <p className="css-4hzbpn flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[26px] min-h-px min-w-px not-italic relative text-[16px] text-black">Yes, use my bank account on file</p>
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex flex-col items-end relative shrink-0 w-full">
      <Frame10 />
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-full">
      <div className="flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[0] min-h-px min-w-px not-italic relative text-[0px] text-[16px] text-black">
        <p className="css-4hzbpn leading-[26px] mb-0">Great, I went ahead and charged your account.</p>
        <p className="css-4hzbpn">
          <span className="leading-[26px]">
            <br aria-hidden="true" />
            {`Your current bill of `}
          </span>
          <span className="font-['Open_Sans:Bold',sans-serif] leading-[26px] not-italic">{`$252.00 `}</span>
          <span className="leading-[26px]">{`was payed with your bank account ending on `}</span>
          <span className="font-['Open_Sans:Bold',sans-serif] leading-[26px] not-italic">*2345</span>
          <span className="leading-[26px]">{`. I also sent a receipt to your email. Can I assist you with anything else? `}</span>
        </p>
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full" data-name="Heading 1">
      <Frame6 />
      <Frame8 />
      <Frame5 />
      <Frame9 />
    </div>
  );
}

function ChatBody() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-center relative shrink-0 w-full" data-name="Chat Body">
      <Frame7 />
      <Heading />
    </div>
  );
}

function Heading1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 1">
      <ChatBody />
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex items-center min-h-[24px] min-w-[24px] overflow-clip relative shrink-0 w-full" data-name="Content">
      <p className="css-4hzbpn flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[24px] min-h-px min-w-px not-italic relative text-[16px] text-[rgba(0,0,0,0.38)] tracking-[0.15px]">How can we help you today?</p>
    </div>
  );
}

function Input() {
  return (
    <div className="relative rounded-[8px] shrink-0 w-full" data-name="Input">
      <div className="content-stretch flex flex-col items-start px-[20px] py-[12px] relative w-full">
        <Content />
      </div>
    </div>
  );
}

function TextField() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="<TextField>">
      <Input />
    </div>
  );
}

function Icon() {
  return (
    <div className="content-stretch flex items-start pb-px relative shrink-0 size-[20px]" data-name="<Icon>">
      <div className="flex flex-[1_0_0] flex-col font-['Font_Awesome_7_Pro:Regular',sans-serif] h-full justify-center leading-[0] min-h-px min-w-px not-italic relative text-[16px] text-black text-center">
        <p className="css-4hzbpn leading-[normal]"></p>
      </div>
    </div>
  );
}

function IconButton() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[5px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon />
    </div>
  );
}

function Icon1() {
  return (
    <div className="content-stretch flex items-start pb-px relative shrink-0 size-[20px]" data-name="<Icon>">
      <div className="flex flex-[1_0_0] flex-col font-['Font_Awesome_7_Pro:Light',sans-serif] h-full justify-center leading-[0] min-h-px min-w-px not-italic relative text-[20px] text-black text-center">
        <p className="css-4hzbpn leading-[normal]"></p>
      </div>
    </div>
  );
}

function IconButton1() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[5px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon1 />
    </div>
  );
}

function Icon2() {
  return (
    <div className="content-stretch flex items-start pb-px relative shrink-0 size-[24px]" data-name="<Icon>">
      <div className="flex flex-[1_0_0] flex-col font-['Font_Awesome_7_Pro:Light',sans-serif] h-full justify-center leading-[0] min-h-px min-w-px not-italic relative text-[20px] text-center text-white">
        <p className="css-4hzbpn leading-[normal]"></p>
      </div>
    </div>
  );
}

function IconButton2() {
  return (
    <div className="bg-[#0078d6] content-stretch flex flex-col items-center justify-center overflow-clip p-[8px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon2 />
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <IconButton />
      <IconButton1 />
      <IconButton2 />
    </div>
  );
}

function Frame12() {
  return (
    <div className="relative rounded-[96px] shrink-0 w-full">
      <div aria-hidden="true" className="absolute border border-[#bec7d1] border-solid inset-0 pointer-events-none rounded-[96px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[8px] py-[6px] relative w-full">
          <TextField />
          <Frame11 />
        </div>
      </div>
    </div>
  );
}

function Margin() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[960px] items-start justify-between left-0 max-w-[768px] pb-[60px] pt-[24px] px-[36px] rounded-[20px] top-0 w-[768px]" data-name="Margin">
      <Heading1 />
      <Frame12 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-0 top-0">
      <Margin />
    </div>
  );
}

export default function BillChat() {
  return (
    <div className="relative size-full" data-name="Bill Chat 1">
      <Group />
    </div>
  );
}