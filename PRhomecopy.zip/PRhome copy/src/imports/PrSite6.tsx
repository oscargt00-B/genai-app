import svgPaths from "./svg-xis9z5ee3x";
import { imgGroup } from "./svg-21at7";

function Heading() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Heading 2">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black text-center">
        <p className="css-ew64yg leading-[18px]">Insurance by state</p>
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0 w-[1100px]" data-name="Container">
      <Heading />
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1140px] relative shrink-0 w-full" data-name="Container">
      <Container />
    </div>
  );
}

function Section() {
  return (
    <div className="bg-[#eff6fd] content-stretch flex flex-col items-center mb-[-1px] pb-0 pt-[32px] px-4 md:px-8 lg:px-16 xl:px-32 relative shrink-0 w-full" data-name="Section">
      <Container1 />
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[20px]">Connecticut</p>
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container2 />
    </div>
  );
}

function Margin() {
  return (
    <div className="content-stretch flex flex-col h-[36px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container3 />
    </div>
  );
}

function Component9() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/auto/ct">
          Car Insurance
        </a>
      </div>
    </div>
  );
}

function Component10() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/home/ct">
          Home Insurance
        </a>
      </div>
    </div>
  );
}

function Container4() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Component9 />
      <Component10 />
    </div>
  );
}

function Container5() {
  return (
    <div className="content-stretch flex flex-col h-[56px] items-start relative shrink-0 w-full" data-name="Container">
      <Container4 />
    </div>
  );
}

function Container6() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-full items-start justify-center min-h-px min-w-px pb-[30px] pt-0 px-0 relative" data-name="Container">
      <Margin />
      <Container5 />
    </div>
  );
}

function Container7() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container6 />
    </div>
  );
}

function Container8() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[20px]">Massachusetts</p>
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container8 />
    </div>
  );
}

function Margin1() {
  return (
    <div className="content-stretch flex flex-col h-[36px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container9 />
    </div>
  );
}

function Component13() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/auto/ma">
          Car Insurance
        </a>
      </div>
    </div>
  );
}

function Component14() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/home/ma">
          Home Insurance
        </a>
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Component13 />
      <Component14 />
    </div>
  );
}

function Container11() {
  return (
    <div className="content-stretch flex flex-col h-[56px] items-start relative shrink-0 w-full" data-name="Container">
      <Container10 />
    </div>
  );
}

function Container12() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-full items-start justify-center min-h-px min-w-px pb-[30px] pt-0 px-0 relative" data-name="Container">
      <Margin1 />
      <Container11 />
    </div>
  );
}

function Container13() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container12 />
    </div>
  );
}

function Container14() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[20px]">New Hampshire</p>
      </div>
    </div>
  );
}

function Container15() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container14 />
    </div>
  );
}

function Margin2() {
  return (
    <div className="content-stretch flex flex-col h-[36px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container15 />
    </div>
  );
}

function Component15() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/auto/nh">
          Car Insurance
        </a>
      </div>
    </div>
  );
}

function Component16() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/home/nh">
          Home Insurance
        </a>
      </div>
    </div>
  );
}

function Container16() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Component15 />
      <Component16 />
    </div>
  );
}

function Container17() {
  return (
    <div className="content-stretch flex flex-col h-[56px] items-start relative shrink-0 w-full" data-name="Container">
      <Container16 />
    </div>
  );
}

function Container18() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-full items-start justify-center min-h-px min-w-px pb-[30px] pt-0 px-0 relative" data-name="Container">
      <Margin2 />
      <Container17 />
    </div>
  );
}

function Container19() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container18 />
    </div>
  );
}

function Container20() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[20px]">New Jersey</p>
      </div>
    </div>
  );
}

function Container21() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container20 />
    </div>
  );
}

function Margin3() {
  return (
    <div className="content-stretch flex flex-col h-[36px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container21 />
    </div>
  );
}

function Component17() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/auto/nj">
          Car Insurance
        </a>
      </div>
    </div>
  );
}

function Component18() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/home/nj">
          Home Insurance
        </a>
      </div>
    </div>
  );
}

function Container22() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Component17 />
      <Component18 />
    </div>
  );
}

function Container23() {
  return (
    <div className="content-stretch flex flex-col h-[56px] items-start relative shrink-0 w-full" data-name="Container">
      <Container22 />
    </div>
  );
}

function Container24() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-full items-start justify-center min-h-px min-w-px pb-[30px] pt-0 px-0 relative" data-name="Container">
      <Margin3 />
      <Container23 />
    </div>
  );
}

function Container25() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container24 />
    </div>
  );
}

function Container26() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[20px]">New York</p>
      </div>
    </div>
  );
}

function Container27() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container26 />
    </div>
  );
}

function Margin4() {
  return (
    <div className="content-stretch flex flex-col h-[36px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container27 />
    </div>
  );
}

function Component19() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/auto/ny">
          Car Insurance
        </a>
      </div>
    </div>
  );
}

function Component20() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/home/ny">
          Home Insurance
        </a>
      </div>
    </div>
  );
}

function Container28() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Component19 />
      <Component20 />
    </div>
  );
}

function Container29() {
  return (
    <div className="content-stretch flex flex-col h-[56px] items-start relative shrink-0 w-full" data-name="Container">
      <Container28 />
    </div>
  );
}

function Container30() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-full items-start justify-center min-h-px min-w-px pb-[30px] pt-0 px-0 relative" data-name="Container">
      <Margin4 />
      <Container29 />
    </div>
  );
}

function Container31() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container30 />
    </div>
  );
}

function Container32() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[20px]">Pennsylvania</p>
      </div>
    </div>
  );
}

function Container33() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container32 />
    </div>
  );
}

function Margin5() {
  return (
    <div className="content-stretch flex flex-col h-[36px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container33 />
    </div>
  );
}

function Component21() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/auto/pa">
          Car Insurance
        </a>
      </div>
    </div>
  );
}

function Component22() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/home/pa">
          Home Insurance
        </a>
      </div>
    </div>
  );
}

function Container34() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Component21 />
      <Component22 />
    </div>
  );
}

function Container35() {
  return (
    <div className="content-stretch flex flex-col h-[56px] items-start relative shrink-0 w-full" data-name="Container">
      <Container34 />
    </div>
  );
}

function Container36() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-full items-start justify-center min-h-px min-w-px pb-[30px] pt-0 px-0 relative" data-name="Container">
      <Margin5 />
      <Container35 />
    </div>
  );
}

function Container37() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container36 />
    </div>
  );
}

function Container38() {
  return (
    <div className="content-stretch flex items-start max-w-[816px] relative shrink-0 w-full" data-name="Container">
      <Container7 />
      <Container13 />
      <Container19 />
      <Container25 />
      <Container31 />
      <Container37 />
    </div>
  );
}

function Section1() {
  return (
    <div className="bg-[#eff6fd] content-stretch flex flex-col items-center mb-[-1px] pb-0 pt-[20px] px-4 md:px-8 lg:px-16 xl:px-32 relative shrink-0 w-full" data-name="Section">
      <Container38 />
      <div className="absolute bottom-0 h-[2px] left-[15px] right-[15px]" data-name="Horizontal Divider">
        <div aria-hidden="true" className="absolute border-[#d3e5f9] border-b-2 border-solid inset-0 pointer-events-none" />
      </div>
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[0_0.01%_0_0] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[196px_57.638px]" data-name="Group" style={{ maskImage: `url('${imgGroup}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 195.989 57.6379">
        <g id="Group">
          <path d={svgPaths.p2a8139e0} fill="var(--fill-0, #0351AA)" id="Vector" />
          <path d={svgPaths.pcb03200} fill="var(--fill-0, #0351AA)" id="Vector_2" />
          <path d={svgPaths.p17e2db00} fill="var(--fill-0, #0351AA)" id="Vector_3" />
          <path d={svgPaths.p3d48fa00} fill="var(--fill-0, #0351AA)" id="Vector_4" />
          <path d={svgPaths.pe463f80} fill="var(--fill-0, #0351AA)" id="Vector_5" />
          <path d={svgPaths.p323d58c0} fill="var(--fill-0, #0351AA)" id="Vector_6" />
          <path d={svgPaths.p27ea5f00} fill="var(--fill-0, #0351AA)" id="Vector_7" />
          <path d={svgPaths.p7033200} fill="var(--fill-0, #0351AA)" id="Vector_8" />
          <path d={svgPaths.p1b856300} fill="var(--fill-0, #0351AA)" id="Vector_9" />
          <path d={svgPaths.pb568270} fill="var(--fill-0, #0351AA)" id="Vector_10" />
          <path d={svgPaths.p23c9b800} fill="var(--fill-0, #0351AA)" id="Vector_11" />
          <path d={svgPaths.p4432f00} fill="var(--fill-0, #0351AA)" id="Vector_12" />
          <path d={svgPaths.pb1dd800} fill="var(--fill-0, #0351AA)" id="Vector_13" />
          <path d={svgPaths.p2e4c9100} fill="var(--fill-0, #0351AA)" id="Vector_14" />
          <path d={svgPaths.p2bfa400} fill="var(--fill-0, #0351AA)" id="Vector_15" />
          <path d={svgPaths.p73e3c00} fill="var(--fill-0, #0351AA)" id="Vector_16" />
          <path d={svgPaths.p1f8d900} fill="var(--fill-0, #0351AA)" id="Vector_17" />
          <path d={svgPaths.p3b691280} fill="var(--fill-0, #0351AA)" id="Vector_18" />
          <path d={svgPaths.p26739c80} fill="var(--fill-0, #0351AA)" id="Vector_19" />
          <path d={svgPaths.p1fd96100} fill="var(--fill-0, #0351AA)" id="Vector_20" />
          <path d={svgPaths.p1f938400} fill="var(--fill-0, #0351AA)" id="Vector_21" />
          <path d={svgPaths.p22b13400} fill="var(--fill-0, #0351AA)" id="Vector_22" />
          <path d={svgPaths.p1a022500} fill="var(--fill-0, #0351AA)" id="Vector_23" />
          <path d={svgPaths.p263f7300} fill="var(--fill-0, #0351AA)" id="Vector_24" />
          <path d={svgPaths.p3cad3a00} fill="var(--fill-0, #0351AA)" id="Vector_25" />
          <path d={svgPaths.p22029d80} fill="var(--fill-0, #0351AA)" id="Vector_26" />
          <path d={svgPaths.p22115080} fill="var(--fill-0, #0351AA)" id="Vector_27" />
          <path d={svgPaths.p1fd2b100} fill="var(--fill-0, #0351AA)" id="Vector_28" />
          <path d={svgPaths.p35585200} fill="var(--fill-0, #0351AA)" id="Vector_29" />
          <path d={svgPaths.pa809b80} fill="var(--fill-0, #0351AA)" id="Vector_30" />
          <path d={svgPaths.p2f95e680} fill="var(--fill-0, #0351AA)" id="Vector_31" />
          <path d={svgPaths.p15023680} fill="var(--fill-0, #0351AA)" id="Vector_32" />
          <path d={svgPaths.p1e889e00} fill="var(--fill-0, #0351AA)" id="Vector_33" />
          <path d={svgPaths.p34a41600} fill="var(--fill-0, #0351AA)" id="Vector_34" />
          <path d={svgPaths.p54ba180} fill="var(--fill-0, #0351AA)" id="Vector_35" />
          <path d={svgPaths.p36531730} fill="var(--fill-0, #0351AA)" id="Vector_36" />
          <path d={svgPaths.p546acf0} fill="var(--fill-0, #0351AA)" id="Vector_37" />
          <path d={svgPaths.p1fdf8e00} fill="var(--fill-0, #0351AA)" id="Vector_38" />
          <path d={svgPaths.p56e7c00} fill="var(--fill-0, #0351AA)" id="Vector_39" />
          <path d={svgPaths.p6dd4f00} fill="var(--fill-0, #0351AA)" id="Vector_40" />
          <path d={svgPaths.p25887000} fill="var(--fill-0, #0351AA)" id="Vector_41" />
          <path d={svgPaths.pd1a1900} fill="var(--fill-0, #0351AA)" id="Vector_42" />
          <path d={svgPaths.p2d44b200} fill="var(--fill-0, #0351AA)" id="Vector_43" />
          <path d={svgPaths.p8ca2700} fill="var(--fill-0, #0351AA)" id="Vector_44" />
          <path d={svgPaths.p2a147800} fill="var(--fill-0, #0351AA)" id="Vector_45" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup() {
  return (
    <div className="absolute contents inset-0" data-name="Clip path group">
      <Group />
    </div>
  );
}

function Component() {
  return (
    <div className="h-[57.638px] overflow-clip relative shrink-0 w-[196px]" data-name="Component 1">
      <ClipPathGroup />
    </div>
  );
}

function LogoTaglineContrastblueSvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[58px] items-center justify-center overflow-clip px-0 py-[0.181px] relative shrink-0 w-[196px]" data-name="logo_tagline_contrastblue.svg fill">
      <Component />
    </div>
  );
}

function PlymouthRockLogoWithMoreThanJustInsuranceTagline() {
  return (
    <div className="content-stretch flex h-[58px] items-start max-w-[196px] overflow-clip relative shrink-0 w-[196px]" data-name="Plymouth Rock logo with More than just insurance tagline">
      <LogoTaglineContrastblueSvgFill />
    </div>
  );
}

function Container39() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <PlymouthRockLogoWithMoreThanJustInsuranceTagline />
    </div>
  );
}

function Container40() {
  return (
    <div className="content-stretch flex flex-col items-start pb-0 pt-[40px] px-0 relative self-stretch shrink-0 w-[1220px]" data-name="Container">
      <Container39 />
    </div>
  );
}

function Container41() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1240px] px-0 py-[10px] relative shrink-0 w-full" data-name="Container">
      <Container40 />
    </div>
  );
}

function Section2() {
  return (
    <div className="h-[118px] relative shrink-0 w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[330px] py-0 relative size-full">
        <Container41 />
      </div>
    </div>
  );
}

function Component3() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-center relative shrink-0" data-name="Component 4">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px] text-center">
        <p className="css-ew64yg decoration-solid leading-[20px] text-[14px] underline">Home</p>
      </div>
    </div>
  );
}

function Component4() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-center relative shrink-0" data-name="Component 4">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px] text-center">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[20px] text-[14px] underline" href="https://www.plymouthrock.com/contact">
          Contact Us
        </a>
      </div>
    </div>
  );
}

function Component5() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-center relative shrink-0" data-name="Component 4">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px] text-center">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[20px] text-[14px] underline" href="https://www.plymouthrock.com/privacy-policy">{`Privacy & Security`}</a>
      </div>
    </div>
  );
}

function Component6() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-center relative shrink-0" data-name="Component 4">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px] text-center">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[20px] text-[14px] underline" href="https://www.plymouthrock.com/internet-policy">{`Terms & Conditions`}</a>
      </div>
    </div>
  );
}

function Component7() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-center relative shrink-0" data-name="Component 4">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px] text-center">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[20px] text-[14px] underline" href="https://www.plymouthrock.com/states-licensed-disclaimers">{`States Licensed & Disclaimers`}</a>
      </div>
    </div>
  );
}

function Component8() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-center relative shrink-0" data-name="Component 4">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px] text-center">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[20px] text-[14px] underline" href="https://www.plymouthrock.com/sitemap">
          Site Map
        </a>
      </div>
    </div>
  );
}

function Container42() {
  return (
    <div className="content-start flex flex-wrap gap-[0px_15px] items-start justify-center relative shrink-0 w-full" data-name="Container">
      <Component3 />
      <Component4 />
      <Component5 />
      <Component6 />
      <Component7 />
      <Component8 />
    </div>
  );
}

function Container43() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Container">
      <Container42 />
    </div>
  );
}

function Container44() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative self-stretch" data-name="Container">
      <div className="flex flex-row items-end justify-center size-full">
        <div className="content-end flex flex-wrap items-end justify-center pb-0 pt-[10px] px-[15px] relative size-full">
          <Container43 />
        </div>
      </div>
    </div>
  );
}

function Container45() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1155px] relative shrink-0 w-full" data-name="Container">
      <Container44 />
    </div>
  );
}

function Section3() {
  return (
    <div className="h-[90px] relative shrink-0 w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start pb-[50px] pt-[10px] px-[372.5px] relative size-full">
        <Container45 />
      </div>
    </div>
  );
}

function Container46() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Section2 />
      <Section3 />
    </div>
  );
}

function Container47() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0 w-full" data-name="Container">
      <Container46 />
    </div>
  );
}

function Footer() {
  return (
    <div className="bg-[#eff6fd] content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Footer">
      <Container47 />
    </div>
  );
}

function Component1() {
  return (
    <div className="h-[19.95px] relative shrink-0 w-[19px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 19.95">
        <g clipPath="url(#clip0_4_1272)" id="Component 1">
          <path d={svgPaths.p318b4380} fill="var(--fill-0, white)" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_4_1272">
            <rect fill="white" height="19.95" width="19" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function FooterMobileSvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[19.94px] items-center justify-center overflow-clip relative shrink-0 w-[19px]" data-name="footer-mobile.svg fill">
      <Component1 />
    </div>
  );
}

function PhoneIcon() {
  return (
    <div className="aspect-[19/19.940000534057617] content-stretch flex flex-col items-start max-w-[615px] overflow-clip relative shrink-0" data-name="Phone Icon">
      <FooterMobileSvgFill />
    </div>
  );
}

function Component23() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-white">
        <p className="css-ew64yg decoration-solid leading-[32px] underline">800-516-9242</p>
      </div>
    </div>
  );
}

function Strong() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Strong">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-white">
        <p className="css-ew64yg leading-[32px]">{`Call for a quote `}</p>
      </div>
      <Component23 />
    </div>
  );
}

function Container48() {
  return (
    <div className="content-stretch flex gap-[10px] items-center relative shrink-0 w-full" data-name="Container">
      <PhoneIcon />
      <Strong />
    </div>
  );
}

function Container49() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Container">
      <Container48 />
    </div>
  );
}

function Container50() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-center flex flex-wrap items-center justify-center pl-[20px] pr-0 py-0 relative size-full">
          <Container49 />
        </div>
      </div>
    </div>
  );
}

function Container51() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container50 />
    </div>
  );
}

function Component2() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Component 1">
          <path d={svgPaths.p179e6280} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Component11() {
  return (
    <a className="content-stretch flex items-center justify-center p-0 relative rounded-[5px] shrink-0 w-[18px]" data-name="Component 12" href="https://www.facebook.com/PlymouthRockAssurance">
      <Component2 />
    </a>
  );
}

function Component24() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Component 1">
          <path d={svgPaths.p30681400} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Component25() {
  return (
    <a className="content-stretch flex items-center justify-center p-0 relative rounded-[5px] shrink-0 w-[18px]" data-name="Component 12" href="https://twitter.com/plymouthrock">
      <Component24 />
    </a>
  );
}

function Component26() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Component 1">
          <path d={svgPaths.p15f11900} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Component27() {
  return (
    <a className="content-stretch flex items-center justify-center p-0 relative rounded-[5px] shrink-0 w-[18px]" data-name="Component 12" href="https://www.instagram.com/plymouthrockassurance">
      <Component26 />
    </a>
  );
}

function Component28() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Component 1">
          <path d={svgPaths.p24287c00} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Component29() {
  return (
    <a className="content-stretch flex items-center justify-center p-0 relative rounded-[5px] shrink-0 w-[18px]" data-name="Component 12" href="https://www.linkedin.com/company/plymouth-rock-assurance">
      <Component28 />
    </a>
  );
}

function List() {
  return (
    <div className="content-stretch cursor-pointer flex gap-[24px] items-start justify-end relative shrink-0 w-full" data-name="List">
      <Component11 />
      <Component25 />
      <Component27 />
      <Component29 />
    </div>
  );
}

function Container52() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Container">
      <List />
    </div>
  );
}

function Container53() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-center flex flex-wrap items-center justify-center pl-0 pr-[20px] py-0 relative size-full">
          <Container52 />
        </div>
      </div>
    </div>
  );
}

function Container54() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container53 />
    </div>
  );
}

function Container55() {
  return (
    <div className="content-stretch flex items-start max-w-[1270px] relative shrink-0 w-full" data-name="Container">
      <Container51 />
      <Container54 />
    </div>
  );
}

function Section4() {
  return (
    <div className="bg-[#0078d6] relative shrink-0 w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-center pb-[11px] pt-[13px] px-4 md:px-8 lg:px-16 xl:px-32 relative w-full">
        <Container55 />
      </div>
    </div>
  );
}

function Component12() {
  return (
    <div className="absolute content-stretch flex items-start left-[587.48px] top-[18px]" data-name="Component 13">
      <a className="css-g0mm18 flex flex-col font-['Open_Sans_Hebrew_Condensed:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-white" href="https://www.plymouthrock.com/states-licensed-disclaimers">
        <p className="css-ew64yg cursor-pointer decoration-solid leading-[18px] underline">{`states licensed & disclaimers page`}</p>
      </a>
    </div>
  );
}

function Container56() {
  return (
    <div className="h-[90px] relative shrink-0 w-full" data-name="Container">
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-0 not-italic text-[12px] text-white top-[8.5px] translate-y-[-50%] w-[98.081px]">
        <p className="css-4hzbpn leading-[18px]">Plymouth Rock Assurance</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-[97.73px] not-italic text-[9px] text-white top-[5px] translate-y-[-50%] w-[7.862px]">
        <p className="css-4hzbpn leading-[18px]">®</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-[105.23px] not-italic text-[12px] text-white top-[8.5px] translate-y-[-50%] w-[76.427px]">
        <p className="css-4hzbpn leading-[18px]">{` and Plymouth Rock`}</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-[181.34px] not-italic text-[9px] text-white top-[5px] translate-y-[-50%] w-[7.862px]">
        <p className="css-4hzbpn leading-[18px]">®</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-[188.84px] not-italic text-[12px] text-white top-[8.5px] translate-y-[-50%] w-[1043.926px]">
        <p className="css-4hzbpn leading-[18px]">{` are brand names and service marks used by separate underwriting, managed insurance, and management companies that offer property and casualty insurance in multiple states pursuant to licensing agreements. Each underwriting and managed insurance company is a`}</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-0 not-italic text-[12px] text-white top-[26.5px] translate-y-[-50%] w-[587.795px]">
        <p className="css-4hzbpn leading-[18px]">{`separate legal entity that is financially responsible only for its own insurance products. A full list of underwriting companies by state can be found on our `}</p>
      </div>
      <Component12 />
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-[727.36px] not-italic text-[12px] text-white top-[26.5px] translate-y-[-50%] w-[508.046px]">
        <p className="css-4hzbpn leading-[18px]">. Actual coverage is subject to the language of the policy as issued. Some discounts, coverages, payment plans, features and benefits</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-0 not-italic text-[0px] text-white top-[44.5px] translate-y-[-50%] w-[887.359px]">
        <p className="css-4hzbpn text-[12px]">
          <span className="leading-[18px]">{`are not available in all states and companies, and premiums may vary by purchase method. PA Residents: `}</span>
          <span className="leading-[18px] uppercase">we reserve the right to refuse to quote any individual a premium rate for the insurance advertised herein</span>
          <span className="leading-[18px]">.</span>
        </p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-0 not-italic text-[9px] text-white top-[59px] translate-y-[-50%] w-[3.941px]">
        <p className="css-4hzbpn leading-[18px]">1</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-[3.61px] not-italic text-[12px] text-white top-[62.5px] translate-y-[-50%] w-[315.683px]">
        <p className="css-4hzbpn leading-[18px]">{` Available to customers who have purchased comprehensive or collision coverage.`}</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-0 not-italic text-[9px] text-white top-[77px] translate-y-[-50%] w-[3.941px]">
        <p className="css-4hzbpn leading-[18px]">2</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-[3.61px] not-italic text-[12px] text-white top-[80.5px] translate-y-[-50%] w-[1188.589px]">
        <p className="css-4hzbpn leading-[18px]">{` Personal auto insurance policyholders may be reimbursed up to $50 of taxi fees once per year for a one-way ride if they find themselves in a situation where it ould be unsafe to operate their vehicle (not applicable to mechanical breakdown). Original receipt must be submitted with the reimbursement form.`}</p>
      </div>
    </div>
  );
}

function Container57() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container56 />
    </div>
  );
}

function Margin6() {
  return (
    <div className="content-stretch flex flex-col h-[106px] items-start justify-center mb-[-5px] pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container57 />
    </div>
  );
}

function Container58() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-white w-full">
        <p className="css-4hzbpn leading-[18px]">© 2026 Plymouth Rock Assurance. All Rights Reserved.</p>
      </div>
    </div>
  );
}

function Container59() {
  return (
    <div className="content-stretch flex flex-col h-[18px] items-start mb-[-5px] relative shrink-0 w-full" data-name="Container">
      <Container58 />
    </div>
  );
}

function Container60() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative self-stretch" data-name="Container">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pb-[40px] pt-[35px] px-[10px] relative size-full">
          <Margin6 />
          <Container59 />
        </div>
      </div>
    </div>
  );
}

function Container61() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1260px] relative shrink-0 w-full" data-name="Container">
      <Container60 />
    </div>
  );
}

function Section5() {
  return (
    <div className="bg-[#0351aa] relative shrink-0 w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[320px] py-0 relative w-full">
        <Container61 />
      </div>
    </div>
  );
}

function Footer1() {
  return (
    <div className="content-stretch flex flex-col items-start mb-[-1px] pb-0 pt-px px-0 relative shrink-0 w-full" data-name="Footer">
      <Footer />
      <Section4 />
      <Section5 />
    </div>
  );
}

function PlymouthRockSite() {
  return (
    <div className="relative bg-white content-stretch flex flex-col items-center w-full pb-px pt-0 px-0" data-name="PlymouthRock-site">
      <Section />
      <Section1 />
      <Footer1 />
    </div>
  );
}

export default function PrSite() {
  return (
    <div className="relative size-full" data-name="PR-site 6">
      <PlymouthRockSite />
    </div>
  );
}