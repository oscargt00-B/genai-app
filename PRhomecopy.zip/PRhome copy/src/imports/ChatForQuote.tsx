function Headline() {
  return (
    <div className="content-stretch flex items-center justify-center pb-[36px] pt-[12px] relative shrink-0 w-full" data-name="Headline">
      <div className="flex flex-col font-['Manrope:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[44px] text-black w-[696px]">
        <p className="css-4hzbpn leading-[56px]">Insurance built for the Northeast.</p>
      </div>
    </div>
  );
}

function Frame1() {
  return (
    <div className="bg-[#eff1f3] content-stretch flex items-center justify-center max-w-[536px] px-[16px] py-[12px] relative rounded-[16px] shrink-0">
      <p className="css-4hzbpn flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[26px] min-h-px min-w-px not-italic relative text-[16px] text-black">I would like a home insurance quote</p>
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-col items-end relative shrink-0 w-full">
      <Frame1 />
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-full">
      <div className="flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[0] min-h-px min-w-px not-italic relative text-[0px] text-black">
        <p className="css-4hzbpn leading-[26px] mb-0 text-[16px]">Sure, I will need some information to get your quote. Can you please tell me the following:</p>
        <ul className="list-disc">
          <li className="css-4hzbpn mb-0 ms-[calc(var(--list-marker-font-size,0)*1.5*1)]">
            <span className="font-['Open_Sans:Bold',sans-serif] leading-[26px] not-italic text-[16px]">{`Full address of your house `}</span>
          </li>
          <li className="css-4hzbpn mb-0 ms-[calc(var(--list-marker-font-size,0)*1.5*1)]">
            <span className="font-['Open_Sans:Bold',sans-serif] leading-[26px] not-italic text-[16px]">your first and last name</span>
          </li>
          <li className="css-4hzbpn ms-[calc(var(--list-marker-font-size,0)*1.5*1)]">
            <span className="font-['Open_Sans:Bold',sans-serif] leading-[26px] not-italic text-[16px]">You date of birth, month, day, year</span>
          </li>
        </ul>
      </div>
    </div>
  );
}

function ChatBody() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-center relative shrink-0 w-full" data-name="Chat Body">
      <Frame3 />
      <Frame4 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="bg-[#eff1f3] content-stretch flex items-center justify-center max-w-[536px] px-[16px] py-[12px] relative rounded-[16px] shrink-0">
      <p className="css-4hzbpn flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[26px] min-h-px min-w-px not-italic relative text-[16px] text-black">Sure, my name is Oscar Torres, 01/02/1960, address is 31 Marion St, Natick, MA 01760</p>
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex flex-col items-end relative shrink-0 w-full">
      <Frame5 />
    </div>
  );
}

function Heading() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full" data-name="Heading 1">
      <Headline />
      <ChatBody />
      <Frame2 />
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex items-center min-h-[24px] min-w-[24px] overflow-clip relative shrink-0 w-full" data-name="Content">
      <p className="css-4hzbpn flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[24px] min-h-px min-w-px not-italic relative text-[16px] text-[rgba(0,0,0,0.38)] tracking-[0.15px]">How can we help you today?</p>
    </div>
  );
}

function Input() {
  return (
    <div className="relative rounded-[8px] shrink-0 w-full" data-name="Input">
      <div className="content-stretch flex flex-col items-start px-[20px] py-[12px] relative w-full">
        <Content />
      </div>
    </div>
  );
}

function TextField() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="<TextField>">
      <Input />
    </div>
  );
}

function Icon() {
  return (
    <div className="content-stretch flex items-start pb-px relative shrink-0 size-[20px]" data-name="<Icon>">
      <div className="flex flex-[1_0_0] flex-col font-['Font_Awesome_7_Pro:Regular',sans-serif] h-full justify-center leading-[0] min-h-px min-w-px not-italic relative text-[16px] text-black text-center">
        <p className="css-4hzbpn leading-[normal]"></p>
      </div>
    </div>
  );
}

function IconButton() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[5px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon />
    </div>
  );
}

function Icon1() {
  return (
    <div className="content-stretch flex items-start pb-px relative shrink-0 size-[20px]" data-name="<Icon>">
      <div className="flex flex-[1_0_0] flex-col font-['Font_Awesome_7_Pro:Light',sans-serif] h-full justify-center leading-[0] min-h-px min-w-px not-italic relative text-[20px] text-black text-center">
        <p className="css-4hzbpn leading-[normal]"></p>
      </div>
    </div>
  );
}

function IconButton1() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[5px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon1 />
    </div>
  );
}

function Icon2() {
  return (
    <div className="content-stretch flex items-start pb-px relative shrink-0 size-[24px]" data-name="<Icon>">
      <div className="flex flex-[1_0_0] flex-col font-['Font_Awesome_7_Pro:Light',sans-serif] h-full justify-center leading-[0] min-h-px min-w-px not-italic relative text-[20px] text-center text-white">
        <p className="css-4hzbpn leading-[normal]"></p>
      </div>
    </div>
  );
}

function IconButton2() {
  return (
    <div className="bg-[#0078d6] content-stretch flex flex-col items-center justify-center overflow-clip p-[8px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon2 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <IconButton />
      <IconButton1 />
      <IconButton2 />
    </div>
  );
}

function Frame6() {
  return (
    <div className="relative rounded-[96px] shrink-0 w-full">
      <div aria-hidden="true" className="absolute border border-[#bec7d1] border-solid inset-0 pointer-events-none rounded-[96px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[8px] py-[6px] relative w-full">
          <TextField />
          <Frame />
        </div>
      </div>
    </div>
  );
}

function Margin() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[854px] items-start justify-between left-0 max-w-[768px] pb-[60px] pt-[24px] px-[36px] rounded-[20px] top-0 w-[768px]" data-name="Margin">
      <Heading />
      <Frame6 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-0 top-0">
      <Margin />
    </div>
  );
}

export default function ChatForQuote() {
  return (
    <div className="relative size-full" data-name="Chat for Quote">
      <Group />
    </div>
  );
}