import svgPaths from "./svg-pubmwjii9z";

function Skyline() {
  return (
    <div className="col-1 h-[226.054px] ml-0 mt-0 relative row-1 w-[1920.001px]" data-name="Skyline">
      <div className="absolute inset-[0_-0.02%_-0.17%_-0.02%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1920.6 226.442">
          <g id="Skyline">
            <path d={svgPaths.pa455300} fill="var(--fill-0, #E9F2FC)" id="Vector" />
            <path d={svgPaths.p3162fa00} fill="var(--fill-0, #E9F2FC)" id="Vector_2" />
            <path d={svgPaths.p109af00} fill="var(--fill-0, #E9F2FC)" id="Vector_3" />
            <path d={svgPaths.p9833800} fill="var(--fill-0, white)" id="Vector_4" />
            <path d={svgPaths.p22b4f900} fill="var(--fill-0, white)" id="Vector_5" />
            <path d={svgPaths.p3c956040} fill="var(--fill-0, white)" id="Vector_6" />
            <path d={svgPaths.p2197ec30} fill="var(--fill-0, #E9F2FC)" id="Vector_7" />
            <path d={svgPaths.p2932f000} fill="var(--fill-0, #E9F2FC)" id="Vector_8" />
            <path d={svgPaths.p3b73ae00} fill="var(--fill-0, white)" id="Vector_9" />
            <path d={svgPaths.p209adb00} fill="var(--fill-0, #CFE1F5)" id="Vector_10" />
            <path d={svgPaths.p37de2f80} fill="var(--fill-0, white)" id="Vector_11" />
            <path d={svgPaths.pbc6bb00} fill="var(--fill-0, #CFE1F5)" id="Vector_12" />
            <path d={svgPaths.p32ac9e00} fill="var(--fill-0, #CFE1F5)" id="Vector_13" />
            <path d={svgPaths.p2f5ba820} fill="var(--fill-0, #CFE1F5)" id="Vector_14" />
            <path d={svgPaths.p2d7fe240} fill="var(--fill-0, #CFE1F5)" id="Vector_15" />
            <path d={svgPaths.p19d16a40} fill="var(--fill-0, #CFE1F5)" id="Vector_16" />
            <path d={svgPaths.p3902e980} fill="var(--fill-0, white)" id="Vector_17" />
            <path d={svgPaths.p205d1f00} fill="var(--fill-0, white)" id="Vector_18" />
            <path d="M1624.41 62.9275V225.766" id="Vector_19" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
            <path d={svgPaths.p2a9ea400} fill="var(--fill-0, #E9F2FC)" id="Vector_20" />
            <path d={svgPaths.p1a72a930} fill="var(--fill-0, #E9F2FC)" id="Vector_21" />
            <path d={svgPaths.p1cd12a80} fill="var(--fill-0, white)" id="Vector_22" />
            <path d={svgPaths.p19cbea00} fill="var(--fill-0, white)" id="Vector_23" />
            <path d={svgPaths.p23376a80} fill="var(--fill-0, white)" id="Vector_24" />
            <path d={svgPaths.pe641900} fill="var(--fill-0, white)" id="Vector_25" />
            <path d={svgPaths.p275f29c0} fill="var(--fill-0, #E9F2FC)" id="Vector_26" />
            <path d={svgPaths.p1529ea80} fill="var(--fill-0, #E9F2FC)" id="Vector_27" />
            <path d={svgPaths.p3c3aeb00} fill="var(--fill-0, white)" id="Vector_28" />
            <path d={svgPaths.p2edcb800} fill="var(--fill-0, white)" id="Vector_29" />
            <path d={svgPaths.p11df0100} fill="var(--fill-0, white)" id="Vector_30" />
            <path d={svgPaths.p230ccef0} fill="var(--fill-0, #CFE1F5)" id="Vector_31" />
            <path d={svgPaths.p2f722000} fill="var(--fill-0, white)" id="Vector_32" />
            <path d={svgPaths.p15de1600} fill="var(--fill-0, white)" id="Vector_33" />
            <path d={svgPaths.p34cee800} fill="var(--fill-0, white)" id="Vector_34" />
            <path d={svgPaths.p192b6100} fill="var(--fill-0, white)" id="Vector_35" />
            <path d={svgPaths.p2a703400} fill="var(--fill-0, #E9F2FC)" id="Vector_36" />
            <path d={svgPaths.p352f6700} fill="var(--fill-0, #E9F2FC)" id="Vector_37" />
            <path d={svgPaths.p1937b080} fill="var(--fill-0, #E9F2FC)" id="Vector_38" />
            <path d={svgPaths.p160c7750} fill="var(--fill-0, #CFE1F5)" id="Vector_39" />
            <path d={svgPaths.p7233580} fill="var(--fill-0, white)" id="Vector_40" />
            <path d={svgPaths.pc13bc00} fill="var(--fill-0, #CFE1F5)" id="Vector_41" />
            <path d={svgPaths.p1641e80} fill="var(--fill-0, #CFE1F5)" id="Vector_42" />
            <path d={svgPaths.p141e4b40} fill="var(--fill-0, #CFE1F5)" id="Vector_43" />
            <path d={svgPaths.p9413270} fill="var(--fill-0, #CFE1F5)" id="Vector_44" />
            <path d={svgPaths.p2252f780} fill="var(--fill-0, #CFE1F5)" id="Vector_45" />
            <path d={svgPaths.pfeafa00} fill="var(--fill-0, #CFE1F5)" id="Vector_46" />
            <path d={svgPaths.p2b94d580} fill="var(--fill-0, white)" id="Vector_47" />
            <path d={svgPaths.p1ca97200} fill="var(--fill-0, white)" id="Vector_48" />
            <path d={svgPaths.p31d4d500} fill="var(--fill-0, white)" id="Vector_49" />
            <path d={svgPaths.p3707800} fill="var(--fill-0, white)" id="Vector_50" />
            <path d="M396.818 45.5999V225.996" id="Vector_51" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
            <path d={svgPaths.p2d932680} fill="var(--fill-0, #CFE1F5)" id="Vector_52" />
            <path d={svgPaths.p1b307d80} fill="var(--fill-0, white)" id="Vector_53" />
            <path d={svgPaths.p100319a0} fill="var(--fill-0, #CFE1F5)" id="Vector_54" />
            <path d={svgPaths.p2ac26400} fill="var(--fill-0, #CFE1F5)" id="Vector_55" />
            <path d={svgPaths.pd11bd80} fill="var(--fill-0, #CFE1F5)" id="Vector_56" />
            <path d={svgPaths.p7f3f200} fill="var(--fill-0, #CFE1F5)" id="Vector_57" />
            <path d={svgPaths.p1e181f80} fill="var(--fill-0, white)" id="Vector_58" />
            <path d={svgPaths.p11075a00} fill="var(--fill-0, white)" id="Vector_59" />
            <path d={svgPaths.p300f4300} fill="var(--fill-0, white)" id="Vector_60" />
            <path d={svgPaths.p60e6000} fill="var(--fill-0, white)" id="Vector_61" />
            <path d="M731.701 96.9534V225.766" id="Vector_62" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.325089" />
            <path d={svgPaths.p2c725020} fill="var(--fill-0, #EFF4FF)" id="Vector_63" />
            <path d={svgPaths.p1b3f1300} fill="var(--fill-0, #EFF4FF)" id="Vector_64" />
            <path d={svgPaths.p26c2e1c0} fill="var(--fill-0, #EFF4FF)" id="Vector_65" />
            <path d={svgPaths.p1a5e2cf0} fill="var(--fill-0, #EFF4FF)" id="Vector_66" />
            <path d={svgPaths.p2a27aa00} fill="var(--fill-0, #E9F2FC)" id="Vector_67" />
            <path d={svgPaths.paeeaf70} fill="var(--fill-0, #CFE1F5)" id="Vector_68" />
            <path d={svgPaths.p30a8bb00} fill="var(--fill-0, #CFE1F5)" id="Vector_69" />
            <path d={svgPaths.p30615400} fill="var(--fill-0, #CFE1F5)" id="Vector_70" />
            <path d={svgPaths.p23ebc480} fill="var(--fill-0, #CFE1F5)" id="Vector_71" />
            <path d={svgPaths.p7ee0f80} fill="var(--fill-0, #CFE1F5)" id="Vector_72" />
            <path d={svgPaths.p1ccaf100} fill="var(--fill-0, white)" id="Vector_73" />
            <path d={svgPaths.p30c2ec00} fill="var(--fill-0, white)" id="Vector_74" />
            <path d={svgPaths.p3ecea8f0} fill="var(--fill-0, white)" id="Vector_75" />
            <path d={svgPaths.p32462380} fill="var(--fill-0, white)" id="Vector_76" />
            <path d={svgPaths.pd37b200} fill="var(--fill-0, #E9F2FC)" id="Vector_77" />
            <path d={svgPaths.p5a38d00} fill="var(--fill-0, #CFE1F5)" id="Vector_78" />
            <path d={svgPaths.p2609d500} fill="var(--fill-0, #CFE1F5)" id="Vector_79" />
            <path d={svgPaths.p2f01c680} fill="var(--fill-0, #E9F2FC)" id="Vector_80" />
            <path d={svgPaths.pc103af0} fill="var(--fill-0, #E9F2FC)" id="Vector_81" />
            <path d={svgPaths.p11207f80} fill="var(--fill-0, white)" id="Vector_82" />
            <path d={svgPaths.p1b48700} fill="var(--fill-0, #E9F2FC)" id="Vector_83" />
            <path d={svgPaths.p3c368c80} fill="var(--fill-0, #E9F2FC)" id="Vector_84" />
            <path d={svgPaths.p35906080} fill="var(--fill-0, #E9F2FC)" id="Vector_85" />
            <path d={svgPaths.p21609300} fill="var(--fill-0, #E9F2FC)" id="Vector_86" />
            <path d={svgPaths.p33457700} fill="var(--fill-0, #E9F2FC)" id="Vector_87" />
            <path d={svgPaths.p17535f00} fill="var(--fill-0, #E9F2FC)" id="Vector_88" />
            <path d={svgPaths.p1971be00} fill="var(--fill-0, white)" id="Vector_89" />
            <path d={svgPaths.p367ce380} fill="var(--fill-0, #E9F2FC)" id="Vector_90" />
            <path d={svgPaths.p30982600} fill="var(--fill-0, #E9F2FC)" id="Vector_91" />
            <path d={svgPaths.p1533eb80} fill="var(--fill-0, white)" id="Vector_92" />
            <path d={svgPaths.p14cab580} fill="var(--fill-0, #E9F2FC)" id="Vector_93" />
            <path d="M307.909 115.821V130.495" id="Vector_94" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
            <path d="M342.995 130.438V225.574" id="Vector_95" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
            <path d={svgPaths.p31d29400} fill="var(--fill-0, #E9F2FC)" id="Vector_96" />
            <path d={svgPaths.p3540a100} fill="var(--fill-0, white)" id="Vector_97" />
            <path d={svgPaths.p221c2100} fill="var(--fill-0, #E9F2FC)" id="Vector_98" />
            <path d={svgPaths.pe1eab00} fill="var(--fill-0, #E9F2FC)" id="Vector_99" />
            <path d={svgPaths.p1a71c580} fill="var(--fill-0, #E9F2FC)" id="Vector_100" />
            <path d={svgPaths.p2cc31100} fill="var(--fill-0, #E9F2FC)" id="Vector_101" />
            <path d={svgPaths.p14227400} fill="var(--fill-0, #E9F2FC)" id="Vector_102" />
            <path d={svgPaths.p3a9a5100} fill="var(--fill-0, #E9F2FC)" id="Vector_103" />
            <path d={svgPaths.p220a8c80} fill="var(--fill-0, #E9F2FC)" id="Vector_104" />
            <path d={svgPaths.p1ee3ee00} fill="var(--fill-0, #E9F2FC)" id="Vector_105" />
            <path d={svgPaths.p19f9b000} fill="var(--fill-0, #E9F2FC)" id="Vector_106" />
            <path d={svgPaths.p131cef80} fill="var(--fill-0, #E9F2FC)" id="Vector_107" />
            <path d={svgPaths.p3a9a5100} fill="var(--fill-0, #E9F2FC)" id="Vector_108" />
            <path d={svgPaths.p3f381100} fill="var(--fill-0, #E9F2FC)" id="Vector_109" />
            <path d={svgPaths.p2274cd00} fill="var(--fill-0, #E9F2FC)" id="Vector_110" />
            <path d={svgPaths.p615a500} fill="var(--fill-0, #E9F2FC)" id="Vector_111" />
            <path d={svgPaths.p2725ca00} fill="var(--fill-0, #E9F2FC)" id="Vector_112" />
            <path d={svgPaths.pa3f9300} fill="var(--fill-0, #E9F2FC)" id="Vector_113" />
            <path d={svgPaths.pe09e280} fill="var(--fill-0, #E9F2FC)" id="Vector_114" />
            <path d={svgPaths.p27d7ad00} fill="var(--fill-0, #E9F2FC)" id="Vector_115" />
            <path d={svgPaths.p213d9300} fill="var(--fill-0, #E9F2FC)" id="Vector_116" />
            <path d={svgPaths.p1a9a7f00} fill="var(--fill-0, #E9F2FC)" id="Vector_117" />
            <path d="M582.626 124.756V170.235" id="Vector_118" stroke="var(--stroke-0, #CFE1F5)" strokeLinejoin="round" strokeWidth="0.360769" />
            <path d={svgPaths.p3f232e00} fill="var(--fill-0, #E9F2FC)" id="Vector_119" />
            <path d={svgPaths.p5686600} fill="var(--fill-0, #E9F2FC)" id="Vector_120" />
            <path d={svgPaths.p3f3edb00} fill="var(--fill-0, white)" id="Vector_121" />
            <path d={svgPaths.p14f43f00} fill="var(--fill-0, #CFE1F5)" id="Vector_122" />
            <path d={svgPaths.p2c027000} fill="var(--fill-0, #CFE1F5)" id="Vector_123" />
            <path d={svgPaths.p14f24800} fill="var(--fill-0, #CFE1F5)" id="Vector_124" />
            <path d={svgPaths.p309e6080} fill="var(--fill-0, #CFE1F5)" id="Vector_125" />
            <path d={svgPaths.pd3c2400} fill="var(--fill-0, #CFE1F5)" id="Vector_126" />
            <path d={svgPaths.p2af74e00} fill="var(--fill-0, #CFE1F5)" id="Vector_127" />
            <path d={svgPaths.p3102a900} fill="var(--fill-0, white)" id="Vector_128" />
            <path d={svgPaths.p33297080} fill="var(--fill-0, #CFE1F5)" id="Vector_129" />
            <path d={svgPaths.p2b6be180} fill="var(--fill-0, #CFE1F5)" id="Vector_130" />
            <path d={svgPaths.pdaaff00} fill="var(--fill-0, #CFE1F5)" id="Vector_131" />
            <path d={svgPaths.p317e5a80} fill="var(--fill-0, #CFE1F5)" id="Vector_132" />
            <path d={svgPaths.p3a0d7d00} fill="var(--fill-0, #CFE1F5)" id="Vector_133" />
            <path d={svgPaths.p34c1bc80} fill="var(--fill-0, #CFE1F5)" id="Vector_134" />
            <path d={svgPaths.p2fd7dc00} fill="var(--fill-0, white)" id="Vector_135" />
            <path d={svgPaths.p747d00} fill="var(--fill-0, white)" id="Vector_136" />
            <path d={svgPaths.pa159900} fill="var(--fill-0, white)" id="Vector_137" />
            <path d={svgPaths.p39f2b800} fill="var(--fill-0, white)" id="Vector_138" />
            <path d="M892.831 45.3657V225.766" id="Vector_139" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
            <path d={svgPaths.p2e2b160} fill="var(--fill-0, #CFE1F5)" id="Vector_140" />
            <path d={svgPaths.p1b4f3f80} fill="var(--fill-0, #E9F2FC)" id="Vector_141" />
            <path d={svgPaths.p30c6b600} fill="var(--fill-0, #E9F2FC)" id="Vector_142" />
            <path d={svgPaths.p2eb27100} fill="var(--fill-0, #CFE1F5)" id="Vector_143" />
            <path d={svgPaths.p1ae5b100} fill="var(--fill-0, white)" id="Vector_144" />
            <path d={svgPaths.p331ba680} fill="var(--fill-0, #E9F2FC)" id="Vector_145" />
            <path d={svgPaths.pbfa6d00} fill="var(--fill-0, #E9F2FC)" id="Vector_146" />
            <path d={svgPaths.p36352300} fill="var(--fill-0, #E9F2FC)" id="Vector_147" />
            <path d={svgPaths.p28dfddf2} fill="var(--fill-0, #E9F2FC)" id="Vector_148" />
            <path d={svgPaths.p1f20e500} fill="var(--fill-0, #E9F2FC)" id="Vector_149" />
            <path d={svgPaths.p5bb0980} fill="var(--fill-0, #E9F2FC)" id="Vector_150" />
            <path d={svgPaths.p1ad99100} fill="var(--fill-0, white)" id="Vector_151" />
            <path d={svgPaths.p1358af00} fill="var(--fill-0, white)" id="Vector_152" />
            <path d="M1483.83 138.884H1556.85" id="Vector_153" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
            <path d="M1532.32 138.884V129.798" id="Vector_154" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
            <path d={svgPaths.p7568c00} fill="var(--fill-0, white)" id="Vector_155" />
            <path d={svgPaths.p3d137900} fill="var(--fill-0, #E9F2FC)" id="Vector_156" />
            <path d={svgPaths.p41e6880} fill="var(--fill-0, #E9F2FC)" id="Vector_157" />
            <path d={svgPaths.p79f7100} fill="var(--fill-0, #E9F2FC)" id="Vector_158" />
            <path d={svgPaths.p14e27700} fill="var(--fill-0, #E9F2FC)" id="Vector_159" />
            <path d={svgPaths.p1cc3c80} fill="var(--fill-0, #E9F2FC)" id="Vector_160" />
            <path d={svgPaths.p26f9c200} fill="var(--fill-0, white)" id="Vector_161" />
            <path d={svgPaths.p33ea1180} fill="var(--fill-0, #E9F2FC)" id="Vector_162" />
            <path d={svgPaths.p1b098e00} fill="var(--fill-0, #E9F2FC)" id="Vector_163" />
            <path d={svgPaths.p2dc8f2f0} fill="var(--fill-0, white)" id="Vector_164" />
            <path d={svgPaths.p22994200} fill="var(--fill-0, #E9F2FC)" id="Vector_165" />
            <path d="M1842.44 134.242V148.916" id="Vector_166" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
            <path d={svgPaths.p2df2b600} fill="var(--fill-0, #92D4BC)" id="Vector_167" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p185cc740} id="Vector_168" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p133d5200} id="Vector_169" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p33c61030} fill="var(--fill-0, #92D4BC)" id="Vector_170" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d="M79.2814 159.553V225.964" id="Vector_171" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p2186f440} id="Vector_172" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.pbfe5fd0} id="Vector_173" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p1d5a000} fill="var(--fill-0, #92D4BC)" id="Vector_174" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d="M375.627 177.353V225.657" id="Vector_175" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.pf823a40} id="Vector_176" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p26fb7c00} id="Vector_177" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p3730bd00} fill="var(--fill-0, #92D4BC)" id="Vector_178" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d="M1650.01 184.065V225.829" id="Vector_179" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p2d188a00} id="Vector_180" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p97ed360} id="Vector_181" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p28c8df00} fill="var(--fill-0, #92D4BC)" id="Vector_182" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d="M1894.68 163.299V226.038" id="Vector_183" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p190b3800} id="Vector_184" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p12db9d80} id="Vector_185" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.pb0e6500} fill="var(--fill-0, #92D4BC)" id="Vector_186" stroke="var(--stroke-2, #045437)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d="M828.34 178.305V226.036" id="Vector_187" stroke="var(--stroke-0, #045437)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p1885ea80} id="Vector_188" stroke="var(--stroke-0, #045437)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.pdf06e80} id="Vector_189" stroke="var(--stroke-0, #045437)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p34323c00} id="Vector_190" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.808757" />
            <path d={svgPaths.pd580100} fill="var(--fill-0, #92D4BC)" id="Vector_191" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.pfc85e60} id="Vector_192" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p1e7ebc80} id="Vector_193" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p11f01080} id="Vector_194" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p10aec380} fill="var(--fill-0, #92D4BC)" id="Vector_195" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p106bf400} fill="var(--fill-0, #92D4BC)" id="Vector_196" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p2feb9000} fill="var(--fill-0, #92D4BC)" id="Vector_197" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.5" />
            <path d={svgPaths.p176b180} id="Vector_198" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.5" />
            <path d={svgPaths.p10d97a80} id="Vector_199" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.5" />
            <path d={svgPaths.p2c3cd080} id="Vector_200" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.5" />
            <path d={svgPaths.p26bd8600} fill="var(--fill-0, #92D4BC)" id="Vector_201" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p1c9abb00} id="Vector_202" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p2a9e1780} fill="var(--fill-0, #92D4BC)" id="Vector_203" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p15d2a340} id="Vector_204" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p188f7a00} id="Vector_205" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
            <path d={svgPaths.p143a1500} fill="var(--fill-0, #E9F2FC)" id="Vector_206" />
            <path d={svgPaths.p3d186b80} fill="var(--fill-0, white)" id="Vector_207" />
            <path d={svgPaths.p17ee5680} fill="var(--fill-0, white)" id="Vector_208" />
            <path d={svgPaths.p3dcf0a00} fill="var(--fill-0, #E9F2FC)" id="Vector_209" />
            <path d={svgPaths.p24c06400} fill="var(--fill-0, white)" id="Vector_210" />
            <path d={svgPaths.pe9b4890} fill="var(--fill-0, #E9F2FC)" id="Vector_211" />
            <path d={svgPaths.p2c337080} fill="var(--fill-0, #E9F2FC)" id="Vector_212" />
            <path d="M189.609 198.223V224.752" id="Vector_213" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
            <path d={svgPaths.p352e290} fill="var(--fill-0, #92D4BC)" id="Vector_214" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group() {
  return (
    <div className="col-1 h-[88.396px] ml-[13.28%] mt-[60.96%] relative row-1 w-[280.934px]">
      <div className="absolute inset-[-0.33%_-0.1%_-0.57%_-0.1%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 281.508 89.1846">
          <g id="Group 1">
            <path d={svgPaths.p74e5200} fill="var(--fill-0, #0078D6)" id="Vector" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p3d973b00} fill="var(--fill-0, white)" id="Vector_2" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p6b7c800} fill="var(--fill-0, #FF6200)" id="Vector_3" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p79d3300} fill="var(--fill-0, white)" id="Vector_4" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p3d5fccf0} fill="var(--fill-0, white)" id="Vector_5" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p12e05900} fill="var(--fill-0, black)" id="Vector_6" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p13e7b500} fill="var(--fill-0, black)" id="Vector_7" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p15ab3f80} fill="var(--fill-0, black)" id="Vector_8" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p876f00} fill="var(--fill-0, #0078D6)" id="Vector_9" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p3b8f7100} id="Vector_10" stroke="var(--stroke-0, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p3de830f0} fill="var(--fill-0, white)" id="Vector_11" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p908d900} fill="var(--fill-0, white)" id="Vector_12" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p2101ab00} fill="var(--fill-0, black)" id="Vector_13" />
            <path d={svgPaths.p10f6c80} fill="var(--fill-0, #152448)" id="Vector_14" />
            <path d={svgPaths.p14087d80} fill="var(--fill-0, #F9FAF8)" id="Vector_15" />
            <path d={svgPaths.pdcdce00} fill="var(--fill-0, #152448)" id="Vector_16" />
            <path d={svgPaths.p23b26000} fill="var(--fill-0, #F9FAF8)" id="Vector_17" />
            <path d={svgPaths.p1515d600} fill="var(--fill-0, black)" id="Vector_18" />
            <path d={svgPaths.pb1bbb80} fill="var(--fill-0, #152448)" id="Vector_19" />
            <path d={svgPaths.p26f08f80} fill="var(--fill-0, #F9FAF8)" id="Vector_20" />
            <path d={svgPaths.pe210a80} fill="var(--fill-0, #152448)" id="Vector_21" />
            <path d={svgPaths.p3afc2380} fill="var(--fill-0, #F9FAF8)" id="Vector_22" />
            <path d="M6.11628 88.6791H265.73" id="Vector_23" stroke="var(--stroke-0, #BADBFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.01095" />
            <path d={svgPaths.p1d248400} fill="var(--fill-0, white)" id="Vector_24" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p13a65300} id="Vector_25" stroke="var(--stroke-0, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.pa066700} id="Vector_26" stroke="var(--stroke-0, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p3a1a5a80} id="Vector_27" stroke="var(--stroke-0, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p16d34500} id="Vector_28" stroke="var(--stroke-0, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p29b59600} id="Vector_29" stroke="var(--stroke-0, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
            <path d={svgPaths.p38fc9500} fill="var(--fill-0, white)" id="Vector_30" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Section() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid items-[start] justify-items-[start] leading-[0] relative shrink-0" data-name="Section">
      <Skyline />
      <Group />
    </div>
  );
}

function PlymouthRockSite() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[226px] items-center left-0 max-w-[1920px] min-w-[1920px] right-0 top-0" data-name="PlymouthRock-site">
      <Section />
    </div>
  );
}

export default function PrSite() {
  return (
    <div className="relative size-full" data-name="PR-site 4">
      <PlymouthRockSite />
    </div>
  );
}