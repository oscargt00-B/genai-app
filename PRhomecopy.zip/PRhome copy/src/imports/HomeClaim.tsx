function Frame3() {
  return (
    <div className="bg-[#eff1f3] content-stretch flex items-center justify-center max-w-[536px] px-[16px] py-[12px] relative rounded-[16px] shrink-0">
      <p className="flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[26px] min-h-px min-w-px not-italic relative text-[16px] text-black whitespace-pre-wrap">I would like to file a claim</p>
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex flex-col items-end relative shrink-0 w-full">
      <Frame3 />
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-full">
      <p className="flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[0] min-h-px min-w-px not-italic relative text-[16px] text-black whitespace-pre-wrap">
        <span className="leading-[26px]">
          {`Hi Joe! Sure, I can help you. First make sure you are in a safe place. `}
          <br aria-hidden="true" />
          {`If you need medical attention or emergency services (ambulance, fire, etc.) please `}
        </span>
        <span className="leading-[26px] text-[#0078d6]">
          call 911.
          <br aria-hidden="true" />
        </span>
        <span className="leading-[26px]">
          <br aria-hidden="true" />
          Is this the home you would like to make a claim for?
        </span>
      </p>
    </div>
  );
}

function Frame() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative">
      <div className="content-stretch flex flex-col gap-[6px] items-start leading-[0] not-italic pr-[12px] relative text-[0px] text-[16px] text-black w-full">
        <p className="font-['Open_Sans:Bold',sans-serif] relative shrink-0">
          <span className="leading-[22px]">{`Policy# `}</span>
          <span className="font-['Open_Sans:Regular',sans-serif] leading-[22px]">MAH00008014258</span>
        </p>
        <p className="font-['Open_Sans:Regular',sans-serif] h-[25px] relative shrink-0 w-full whitespace-pre-wrap">
          <span className="font-['Open_Sans:Bold',sans-serif] leading-[25px]">{`Home Address: `}</span>
          <span className="leading-[25px]">30 Main St, Boston, MA 02130</span>
        </p>
      </div>
    </div>
  );
}

function VehicleCard() {
  return (
    <div className="bg-[#f5faff] relative rounded-[12px] shrink-0 w-full" data-name="Vehicle Card">
      <div aria-hidden="true" className="absolute border border-[#0078d6] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[48px] py-[20px] relative w-full">
          <Frame />
        </div>
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <div className="bg-[#eff1f3] content-stretch flex items-center justify-center max-w-[536px] px-[16px] py-[12px] relative rounded-[16px] shrink-0">
      <p className="flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[26px] min-h-px min-w-px not-italic relative text-[16px] text-black whitespace-pre-wrap">Yes</p>
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex flex-col items-end relative shrink-0 w-full">
      <Frame6 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-full">
      <p className="flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[26px] min-h-px min-w-px not-italic relative text-[16px] text-black whitespace-pre-wrap">Got it, please tell me what happened?</p>
    </div>
  );
}

function Heading1() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full" data-name="Heading 1">
      <Frame4 />
      <VehicleCard />
      <Frame5 />
      <Frame7 />
    </div>
  );
}

function ChatBody() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-center relative shrink-0 w-full" data-name="Chat Body">
      <Frame2 />
      <Heading1 />
    </div>
  );
}

function Heading() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 1">
      <ChatBody />
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex items-center min-h-[24px] min-w-[24px] overflow-clip relative shrink-0 w-full" data-name="Content">
      <p className="flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[24px] min-h-px min-w-px not-italic relative text-[16px] text-[rgba(0,0,0,0.38)] tracking-[0.15px] whitespace-pre-wrap">How can we help you today?</p>
    </div>
  );
}

function Input() {
  return (
    <div className="relative rounded-[8px] shrink-0 w-full" data-name="Input">
      <div className="content-stretch flex flex-col items-start px-[20px] py-[12px] relative w-full">
        <Content />
      </div>
    </div>
  );
}

function TextField() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="<TextField>">
      <Input />
    </div>
  );
}

function AFontawesome() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="A-Fontawesome">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Font_Awesome_7_Pro:Light',sans-serif] justify-center leading-[0] left-1/2 not-italic text-[16px] text-[rgba(0,0,0,0.56)] text-center top-1/2 whitespace-nowrap">
        <p className="leading-[normal]"></p>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="content-stretch flex items-center justify-center pb-px relative shrink-0 size-[20px]" data-name="<Icon>">
      <AFontawesome />
    </div>
  );
}

function IconButton() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[5px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon />
    </div>
  );
}

function AFontawesome1() {
  return (
    <div className="overflow-clip relative shrink-0 size-[20px]" data-name="A-Fontawesome">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Font_Awesome_7_Pro:Light',sans-serif] justify-center leading-[0] left-1/2 not-italic text-[16px] text-[rgba(0,0,0,0.56)] text-center top-1/2 whitespace-nowrap">
        <p className="leading-[normal]"></p>
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="content-stretch flex items-center justify-center pb-px relative shrink-0 size-[20px]" data-name="<Icon>">
      <AFontawesome1 />
    </div>
  );
}

function IconButton1() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[5px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon1 />
    </div>
  );
}

function AFontawesome2() {
  return (
    <div className="overflow-clip relative shrink-0 size-[24px]" data-name="A-Fontawesome">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Font_Awesome_7_Pro:Light',sans-serif] justify-center leading-[0] left-[calc(50%+0.5px)] not-italic text-[20px] text-center text-white top-1/2 whitespace-nowrap">
        <p className="leading-[normal]"></p>
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 size-[24px]" data-name="<Icon>">
      <AFontawesome2 />
    </div>
  );
}

function IconButton2() {
  return (
    <div className="bg-[#0078d6] content-stretch flex flex-col items-center justify-center overflow-clip p-[8px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon2 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <IconButton />
      <IconButton1 />
      <IconButton2 />
    </div>
  );
}

function ChatInput() {
  return (
    <div className="content-stretch flex items-center justify-between px-[8px] py-[6px] relative rounded-[96px] shrink-0 w-[696px]" data-name="Chat input">
      <div aria-hidden="true" className="absolute border border-[#bec7d1] border-solid inset-0 pointer-events-none rounded-[96px]" />
      <TextField />
      <Frame1 />
    </div>
  );
}

function Margin() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[1086px] items-start justify-between left-0 max-w-[768px] pb-[60px] pt-[24px] px-[36px] rounded-[20px] top-0 w-[768px]" data-name="Margin">
      <Heading />
      <ChatInput />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-0 top-0">
      <Margin />
    </div>
  );
}

export default function HomeClaim() {
  return (
    <div className="relative size-full" data-name="Home claim">
      <Group />
    </div>
  );
}