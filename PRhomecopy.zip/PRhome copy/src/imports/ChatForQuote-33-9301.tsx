function Headline() {
  return (
    <div className="content-stretch flex items-center justify-center pb-[36px] pt-[12px] relative shrink-0 w-full" data-name="Headline">
      <div className="flex flex-col font-['Manrope:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[44px] text-black w-[696px]">
        <p className="css-4hzbpn leading-[56px]">Insurance built for the Northeast.</p>
      </div>
    </div>
  );
}

function Frame7() {
  return (
    <div className="bg-[#eff1f3] content-stretch flex items-center justify-center max-w-[536px] px-[16px] py-[12px] relative rounded-[16px] shrink-0">
      <p className="css-4hzbpn flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[26px] min-h-px min-w-px not-italic relative text-[16px] text-black">I would like a home insurance quote</p>
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex flex-col items-end relative shrink-0 w-full">
      <Frame7 />
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-full">
      <div className="flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[0] min-h-px min-w-px not-italic relative text-[0px] text-black">
        <p className="css-4hzbpn leading-[26px] mb-0 text-[16px]">Sure, I will need some information to get your quote. Can you please tell me the following:</p>
        <ul className="list-disc">
          <li className="css-4hzbpn mb-0 ms-[calc(var(--list-marker-font-size,0)*1.5*1)]">
            <span className="font-['Open_Sans:Bold',sans-serif] leading-[26px] not-italic text-[16px]">{`Full address of your house `}</span>
          </li>
          <li className="css-4hzbpn mb-0 ms-[calc(var(--list-marker-font-size,0)*1.5*1)]">
            <span className="font-['Open_Sans:Bold',sans-serif] leading-[26px] not-italic text-[16px]">your first and last name</span>
          </li>
          <li className="css-4hzbpn ms-[calc(var(--list-marker-font-size,0)*1.5*1)]">
            <span className="font-['Open_Sans:Bold',sans-serif] leading-[26px] not-italic text-[16px]">You date of birth, month, day, year</span>
          </li>
        </ul>
      </div>
    </div>
  );
}

function ChatBody() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-center relative shrink-0 w-full" data-name="Chat Body">
      <Frame10 />
      <Frame13 />
    </div>
  );
}

function Frame14() {
  return (
    <div className="bg-[#eff1f3] content-stretch flex items-center justify-center max-w-[536px] px-[16px] py-[12px] relative rounded-[16px] shrink-0">
      <p className="css-4hzbpn flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[26px] min-h-px min-w-px not-italic relative text-[16px] text-black">Sure, my name is Oscar Torres, 01/02/1960, address is 31 Marion St, Natick, MA 01760</p>
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-full">
      <p className="css-4hzbpn flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[0] min-h-px min-w-px not-italic relative text-[0px] text-[16px] text-black">
        <span className="leading-[26px]">Thank you, I got a quote for you from</span>
        <span className="font-['Open_Sans:Bold',sans-serif] leading-[26px]">{` Plymouth Rock Assurance`}</span>
      </p>
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] py-[9px] relative shrink-0" data-name="Container">
      <p className="css-ew64yg font-['Open_Sans:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#0078d6] text-[16px] text-center">
        {`Good Coverage `}
        <br aria-hidden="true" />
        $232/mo
      </p>
    </div>
  );
}

function Tab() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0" data-name="<Tab>">
      <Container />
      <div className="absolute bottom-[22px] flex h-0 items-center justify-center left-[-36px] right-[60px]">
        <div className="flex-none h-px rotate-[180deg] scale-y-[-100%] w-[132px]">
          <div className="relative size-full" data-name="Line">
            <div className="absolute inset-[-2px_0_0_0]" style={{ "--stroke-0": "rgba(0, 120, 214, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 132 2">
                <line id="Line" stroke="var(--stroke-0, #0078D6)" strokeWidth="2" x2="132" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] py-[9px] relative shrink-0" data-name="Container">
      <p className="css-ew64yg font-['Open_Sans:Regular',sans-serif] leading-[22px] not-italic relative shrink-0 text-[16px] text-[rgba(0,0,0,0.6)] text-center">
        {`Better Coverage `}
        <br aria-hidden="true" />
        $291/mo
      </p>
    </div>
  );
}

function Tab1() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0" data-name="<Tab>">
      <Container1 />
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] py-[9px] relative shrink-0" data-name="Container">
      <p className="css-ew64yg font-['Open_Sans:Regular',sans-serif] leading-[22px] not-italic relative shrink-0 text-[16px] text-[rgba(0,0,0,0.6)] text-center">
        {`Best Coverage `}
        <br aria-hidden="true" />
        $358/mo
      </p>
    </div>
  );
}

function Tab2() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center relative shrink-0" data-name="<Tab>">
      <Container2 />
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Container">
      <Tab />
      <Tab1 />
      <Tab2 />
    </div>
  );
}

function Tabs() {
  return (
    <div className="content-stretch flex flex-col items-center overflow-clip relative shrink-0 w-full" data-name="<Tabs>">
      <Container3 />
    </div>
  );
}

function ChevronRightFilled() {
  return <div className="h-[31px] overflow-clip w-[24px]" data-name="ChevronRightFilled" />;
}

function Frame() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[276px]">
      <p className="css-4hzbpn font-['Open_Sans:Regular',sans-serif] leading-[26px] not-italic relative shrink-0 text-[16px] text-black w-[246px]">Dwelling</p>
      <div className="flex h-[24px] items-center justify-center relative shrink-0 w-[31px]" style={{ "--transform-inner-width": "0", "--transform-inner-height": "418" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <ChevronRightFilled />
        </div>
      </div>
    </div>
  );
}

function AccordianWhite() {
  return (
    <div className="bg-white content-stretch flex items-center justify-between py-[6px] relative shrink-0 w-[447.842px]" data-name="<Accordian White>">
      <Frame />
      <p className="css-4hzbpn font-['Open_Sans:Regular',sans-serif] leading-[26px] not-italic relative shrink-0 text-[16px] text-black text-center w-[109px]">$439,000</p>
    </div>
  );
}

function ChevronRightFilled1() {
  return <div className="h-[31px] overflow-clip w-[24px]" data-name="ChevronRightFilled" />;
}

function Frame1() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[276px]">
      <p className="css-4hzbpn font-['Open_Sans:Regular',sans-serif] leading-[26px] not-italic relative shrink-0 text-[16px] text-black w-[246px]">Personal Property - Increased Limits</p>
      <div className="flex h-[24px] items-center justify-center relative shrink-0 w-[31px]" style={{ "--transform-inner-width": "0", "--transform-inner-height": "418" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <ChevronRightFilled1 />
        </div>
      </div>
    </div>
  );
}

function AccordianGray() {
  return (
    <div className="bg-[#f8f8fa] content-stretch flex items-center justify-between py-[6px] relative shrink-0 w-[447.842px]" data-name="<Accordian Gray>">
      <Frame1 />
      <p className="css-4hzbpn font-['Open_Sans:Regular',sans-serif] leading-[26px] not-italic relative shrink-0 text-[16px] text-black text-center w-[109px]">$219,500</p>
    </div>
  );
}

function ChevronRightFilled2() {
  return <div className="h-[31px] overflow-clip w-[24px]" data-name="ChevronRightFilled" />;
}

function Frame2() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[276px]">
      <p className="css-4hzbpn font-['Open_Sans:Regular',sans-serif] leading-[26px] not-italic relative shrink-0 text-[16px] text-black w-[246px]">Personal Liability</p>
      <div className="flex h-[24px] items-center justify-center relative shrink-0 w-[31px]" style={{ "--transform-inner-width": "0", "--transform-inner-height": "418" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <ChevronRightFilled2 />
        </div>
      </div>
    </div>
  );
}

function AccordianWhite1() {
  return (
    <div className="bg-white content-stretch flex items-center justify-between py-[6px] relative shrink-0 w-[447.842px]" data-name="<Accordian White>">
      <Frame2 />
      <p className="css-4hzbpn font-['Open_Sans:Regular',sans-serif] leading-[26px] not-italic relative shrink-0 text-[16px] text-black text-center w-[109px]">$300,000</p>
    </div>
  );
}

function ChevronRightFilled3() {
  return <div className="h-[31px] overflow-clip w-[24px]" data-name="ChevronRightFilled" />;
}

function Frame3() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[276px]">
      <p className="css-4hzbpn font-['Open_Sans:Regular',sans-serif] leading-[26px] not-italic relative shrink-0 text-[16px] text-black w-[246px]">Medical Payments</p>
      <div className="flex h-[24px] items-center justify-center relative shrink-0 w-[31px]" style={{ "--transform-inner-width": "0", "--transform-inner-height": "418" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <ChevronRightFilled3 />
        </div>
      </div>
    </div>
  );
}

function AccordianGray1() {
  return (
    <div className="bg-[#f8f8fa] content-stretch flex items-center justify-between py-[6px] relative shrink-0 w-[447.842px]" data-name="<Accordian Gray>">
      <Frame3 />
      <p className="css-4hzbpn font-['Open_Sans:Regular',sans-serif] leading-[26px] not-italic relative shrink-0 text-[16px] text-black text-center w-[109px]">$1,000</p>
    </div>
  );
}

function ChevronRightFilled4() {
  return <div className="h-[31px] overflow-clip w-[24px]" data-name="ChevronRightFilled" />;
}

function Frame4() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[276px]">
      <p className="css-4hzbpn font-['Open_Sans:Regular',sans-serif] leading-[26px] not-italic relative shrink-0 text-[16px] text-black w-[246px]">Policy Deductible</p>
      <div className="flex h-[24px] items-center justify-center relative shrink-0 w-[31px]" style={{ "--transform-inner-width": "0", "--transform-inner-height": "418" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <ChevronRightFilled4 />
        </div>
      </div>
    </div>
  );
}

function AccordianWhite2() {
  return (
    <div className="bg-white content-stretch flex items-center justify-between py-[6px] relative shrink-0 w-[447.842px]" data-name="<Accordian White>">
      <Frame4 />
      <p className="css-4hzbpn font-['Open_Sans:Regular',sans-serif] leading-[26px] not-italic relative shrink-0 text-[16px] text-black text-center w-[109px]">$2,500</p>
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-[450px]">
      <AccordianWhite />
      <AccordianGray />
      <AccordianWhite1 />
      <AccordianGray1 />
      <AccordianWhite2 />
      <p className="css-ew64yg font-['Open_Sans:Regular',sans-serif] leading-[14px] not-italic relative shrink-0 text-[12px] text-black">Quote Number: MAHQ0005151311</p>
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
      <p className="css-4hzbpn font-['Manrope:Regular',sans-serif] leading-[28px] min-w-full not-italic relative shrink-0 text-[20px] text-black text-center w-[min-content]">Good Coverage includes:</p>
      <Frame12 />
    </div>
  );
}

function Base() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="css-ew64yg font-['Open_Sans:Regular',sans-serif] leading-[30px] not-italic relative shrink-0 text-[18px] text-white">Continue to purchase</p>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#0078d6] content-stretch flex flex-col items-center justify-center overflow-clip px-[20px] py-[12px] relative rounded-[32px] shrink-0" data-name="<Button>">
      <Base />
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex flex-col gap-[22px] items-center py-[24px] relative rounded-[30px] shrink-0 w-full">
      <div aria-hidden="true" className="absolute border-[#bec7d1] border-[1.013px] border-solid inset-0 pointer-events-none rounded-[30px]" />
      <p className="css-4hzbpn font-['Manrope:Regular',sans-serif] leading-[0] min-w-full not-italic relative shrink-0 text-[#0078d6] text-[0px] text-center w-[min-content]">
        <span className="leading-[42px] text-[32px]">Here’s your home quote for</span>
        <span className="leading-[32px] text-[24px]">
          <br aria-hidden="true" />
        </span>
        <span className="leading-[28px] text-[20px] text-[rgba(0,0,0,0.6)]">31 Marion St, Natick, MA 01760</span>
      </p>
      <Tabs />
      <Frame16 />
      <Button />
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex flex-col gap-[9px] items-start relative shrink-0 w-full">
      <Frame5 />
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex flex-col gap-[20px] items-start relative shrink-0 w-full">
      <Frame6 />
      <p className="css-4hzbpn font-['Open_Sans:Regular',sans-serif] leading-[0] not-italic relative shrink-0 text-[0px] text-[16px] text-black w-full">
        <span className="leading-[26px]">{`Here is your quote, you can continue to buy your policy. Would you like me to go over any details with you? For example, you can ask me `}</span>
        <span className="font-['Open_Sans:Bold',sans-serif] leading-[26px]">What does Dwelling mean?</span>
      </p>
    </div>
  );
}

function Heading() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full" data-name="Heading 1">
      <Frame9 />
      <Frame11 />
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] items-end relative shrink-0 w-full">
      <Frame14 />
      <Heading />
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex items-center min-h-[24px] min-w-[24px] overflow-clip relative shrink-0 w-full" data-name="Content">
      <p className="css-4hzbpn flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[24px] min-h-px min-w-px not-italic relative text-[16px] text-[rgba(0,0,0,0.38)] tracking-[0.15px]">How can we help you today?</p>
    </div>
  );
}

function Input() {
  return (
    <div className="relative rounded-[8px] shrink-0 w-full" data-name="Input">
      <div className="content-stretch flex flex-col items-start px-[20px] py-[12px] relative w-full">
        <Content />
      </div>
    </div>
  );
}

function TextField() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="<TextField>">
      <Input />
    </div>
  );
}

function Icon() {
  return (
    <div className="content-stretch flex items-start pb-px relative shrink-0 size-[20px]" data-name="<Icon>">
      <div className="flex flex-[1_0_0] flex-col font-['Font_Awesome_7_Pro:Regular',sans-serif] h-full justify-center leading-[0] min-h-px min-w-px not-italic relative text-[16px] text-black text-center">
        <p className="css-4hzbpn leading-[normal]"></p>
      </div>
    </div>
  );
}

function IconButton() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[5px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon />
    </div>
  );
}

function Icon1() {
  return (
    <div className="content-stretch flex items-start pb-px relative shrink-0 size-[20px]" data-name="<Icon>">
      <div className="flex flex-[1_0_0] flex-col font-['Font_Awesome_7_Pro:Light',sans-serif] h-full justify-center leading-[0] min-h-px min-w-px not-italic relative text-[20px] text-black text-center">
        <p className="css-4hzbpn leading-[normal]"></p>
      </div>
    </div>
  );
}

function IconButton1() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip p-[5px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon1 />
    </div>
  );
}

function Icon2() {
  return (
    <div className="content-stretch flex items-start pb-px relative shrink-0 size-[24px]" data-name="<Icon>">
      <div className="flex flex-[1_0_0] flex-col font-['Font_Awesome_7_Pro:Light',sans-serif] h-full justify-center leading-[0] min-h-px min-w-px not-italic relative text-[20px] text-center text-white">
        <p className="css-4hzbpn leading-[normal]"></p>
      </div>
    </div>
  );
}

function IconButton2() {
  return (
    <div className="bg-[#0078d6] content-stretch flex flex-col items-center justify-center overflow-clip p-[8px] relative rounded-[100px] shrink-0" data-name="<IconButton>">
      <Icon2 />
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <IconButton />
      <IconButton1 />
      <IconButton2 />
    </div>
  );
}

function Frame17() {
  return (
    <div className="relative rounded-[96px] shrink-0 w-full">
      <div aria-hidden="true" className="absolute border border-[#bec7d1] border-solid inset-0 pointer-events-none rounded-[96px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[8px] py-[6px] relative w-full">
          <TextField />
          <Frame15 />
        </div>
      </div>
    </div>
  );
}

function Heading1() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-start relative shrink-0 w-full" data-name="Heading 1">
      <Headline />
      <ChatBody />
      <Frame8 />
      <Frame17 />
    </div>
  );
}

function Margin() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[1243px] items-start justify-between left-0 max-w-[768px] pb-[60px] pt-[24px] px-[36px] rounded-[20px] top-0 w-[768px]" data-name="Margin">
      <Heading1 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-0 top-0">
      <Margin />
    </div>
  );
}

export default function ChatForQuote() {
  return (
    <div className="relative size-full" data-name="Chat for Quote">
      <Group />
    </div>
  );
}