import svgPaths from "./svg-j13ig5jkrp";
import imgQrCode from "figma:asset/ba7531f1548862274299a2f807225786071f163e.png";
import imgComponent1 from "figma:asset/434cffd530251e01e0484e78b2055415bdc6c51d.png";
import imgVector from "figma:asset/01c9d9edba045c99fdffb4cb7f8ed8ce5b3db1a7.png";
import { imgGroup, imgGroup1, imgGroup2, imgGroup3, imgGroup4, imgGroup5, imgGroup6, imgGroup7, imgGroup8, imgGroup9, imgGroup10, imgGroup11, imgGroup12, imgGroup13 } from "./svg-dyqrd";

function Heading() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Heading 2">
      <div className="css-g0mm18 flex flex-col font-['Manrope:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[0px] text-black text-center">
        <p className="css-ew64yg text-[32px]">
          <span className="font-['Manrope:Bold',sans-serif] leading-[42px]">3 top reasons</span>
          <span className="font-['Manrope:Regular',sans-serif] leading-[42px]">{` to choose Plymouth Rock for your insurance.`}</span>
        </p>
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative" data-name="Container">
      <div className="content-stretch flex flex-col items-start px-[15px] py-0 relative w-full">
        <Heading />
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="content-center flex flex-[1_0_0] flex-wrap items-center justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container />
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0 w-full" data-name="Container">
      <Container1 />
    </div>
  );
}

function Section() {
  return (
    <div className="bg-[#eff6fd] content-stretch flex flex-col items-start mb-[-1px] pb-[38px] pt-[60px] px-0 relative shrink-0 w-[1920px]" data-name="Section">
      <Container2 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[1.72%_4.75%_8.06%_4.75%]" data-name="Group">
      <div className="absolute inset-[-6.16%_-9.29%_-12.32%_-9.29%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 306.207 307.832">
          <g id="Group">
            <path d={svgPaths.p1321e800} fill="var(--fill-0, #0351AA)" id="Vector" />
            <g filter="url(#filter0_d_1_4605)" id="Vector_2">
              <path d={svgPaths.p2cebd500} fill="white" />
            </g>
            <path d={svgPaths.p28fb7700} fill="var(--fill-0, white)" id="Vector_3" />
            <path d={svgPaths.pc3036f0} fill="var(--fill-0, white)" id="Vector_4" />
            <path d={svgPaths.p2acc3c00} fill="var(--fill-0, white)" id="Vector_5" />
            <path d={svgPaths.p37e27680} fill="var(--fill-0, white)" id="Vector_6" />
            <path d={svgPaths.p390ab100} fill="var(--fill-0, white)" id="Vector_7" />
            <path d={svgPaths.p3a4c9c00} fill="var(--fill-0, white)" id="Vector_8" />
            <path d={svgPaths.p201a6bc0} fill="var(--fill-0, white)" id="Vector_9" />
            <path d={svgPaths.p27f8da00} fill="var(--fill-0, white)" id="Vector_10" />
            <path d={svgPaths.pb83ec00} fill="var(--fill-0, white)" id="Vector_11" />
            <path d={svgPaths.p228ee180} fill="var(--fill-0, white)" id="Vector_12" />
            <path d={svgPaths.p311e0900} fill="var(--fill-0, white)" id="Vector_13" />
            <path d={svgPaths.p3a2e3400} fill="var(--fill-0, white)" id="Vector_14" />
            <path d={svgPaths.pcd2f7c0} fill="var(--fill-0, white)" id="Vector_15" />
            <path d={svgPaths.p3fbdb200} fill="var(--fill-0, white)" id="Vector_16" />
            <path d={svgPaths.p94b1900} fill="var(--fill-0, white)" id="Vector_17" />
            <path d={svgPaths.p24904500} fill="var(--fill-0, white)" id="Vector_18" />
            <path d={svgPaths.p215a38f0} fill="var(--fill-0, white)" id="Vector_19" />
            <path d={svgPaths.p33956500} fill="var(--fill-0, white)" id="Vector_20" />
            <path d={svgPaths.p1805e5f0} fill="var(--fill-0, white)" id="Vector_21" />
            <path clipRule="evenodd" d={svgPaths.p2ed69c00} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector_22" />
            <path clipRule="evenodd" d={svgPaths.p3248f80} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector_23" />
            <path clipRule="evenodd" d={svgPaths.p2027acd1} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector_24" />
            <path clipRule="evenodd" d={svgPaths.pe214a00} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector_25" />
            <path clipRule="evenodd" d={svgPaths.p238c5000} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector_26" />
            <path clipRule="evenodd" d={svgPaths.p31589440} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector_27" />
            <path d={svgPaths.p2b10100} fill="var(--fill-0, #0351AA)" id="Vector_28" />
            <path d={svgPaths.p824ef00} fill="var(--fill-0, #0351AA)" id="Vector_29" />
            <path d={svgPaths.p388e1f00} fill="var(--fill-0, #0351AA)" id="Vector_30" />
            <path d={svgPaths.pa1e3b80} fill="var(--fill-0, #0351AA)" id="Vector_31" />
            <path d={svgPaths.p12959800} fill="var(--fill-0, white)" id="Vector_32" />
            <path d={svgPaths.p3baa180} fill="var(--fill-0, white)" id="Vector_33" />
            <path d={svgPaths.p2764d00} fill="var(--fill-0, white)" id="Vector_34" />
            <path d={svgPaths.p16436800} fill="var(--fill-0, white)" id="Vector_35" />
            <path d={svgPaths.p45b2a00} fill="var(--fill-0, white)" id="Vector_36" />
            <path d={svgPaths.p374630c0} fill="var(--fill-0, white)" id="Vector_37" />
            <path d={svgPaths.p2e0fd280} fill="var(--fill-0, white)" id="Vector_38" />
            <path d={svgPaths.p3f280200} fill="var(--fill-0, white)" id="Vector_39" />
            <path d={svgPaths.p29f72e00} fill="var(--fill-0, white)" id="Vector_40" />
            <path d={svgPaths.p31daf780} fill="var(--fill-0, white)" id="Vector_41" />
            <path d={svgPaths.p26e6c900} fill="var(--fill-0, white)" id="Vector_42" />
            <path d={svgPaths.p3a06c80} fill="var(--fill-0, white)" id="Vector_43" />
            <path d={svgPaths.pdd54c00} fill="var(--fill-0, white)" id="Vector_44" />
            <path d={svgPaths.p2933ba00} fill="var(--fill-0, white)" id="Vector_45" />
            <path d={svgPaths.p5389400} fill="var(--fill-0, white)" id="Vector_46" />
            <path d={svgPaths.p32142e80} fill="var(--fill-0, white)" id="Vector_47" />
            <path d={svgPaths.p3212f280} fill="var(--fill-0, white)" id="Vector_48" />
            <path d={svgPaths.p2761f000} fill="var(--fill-0, white)" id="Vector_49" />
            <path d={svgPaths.p41c580} fill="var(--fill-0, white)" id="Vector_50" />
            <path d={svgPaths.p3540d8f0} fill="var(--fill-0, white)" id="Vector_51" />
            <path d={svgPaths.p95c5500} fill="var(--fill-0, white)" id="Vector_52" />
            <path d={svgPaths.p174f2200} fill="var(--fill-0, white)" id="Vector_53" />
            <path d={svgPaths.p392b0580} fill="var(--fill-0, white)" id="Vector_54" />
            <path d={svgPaths.p3aff1da0} fill="var(--fill-0, white)" id="Vector_55" />
            <path d={svgPaths.p1d318980} fill="var(--fill-0, white)" id="Vector_56" />
            <path d={svgPaths.p3552000} fill="var(--fill-0, white)" id="Vector_57" />
            <path d={svgPaths.p12e74500} fill="var(--fill-0, white)" id="Vector_58" />
            <path d={svgPaths.p6320900} fill="var(--fill-0, white)" id="Vector_59" />
            <path d={svgPaths.p15954a00} fill="var(--fill-0, white)" id="Vector_60" />
            <path d={svgPaths.p1b30bf00} fill="var(--fill-0, white)" id="Vector_61" />
            <path d={svgPaths.pf169580} fill="var(--fill-0, white)" id="Vector_62" />
          </g>
          <defs>
            <filter colorInterpolationFilters="sRGB" filterUnits="userSpaceOnUse" height="307.832" id="filter0_d_1_4605" width="306.207" x="0" y="0">
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
              <feOffset dy="8" />
              <feGaussianBlur stdDeviation="12" />
              <feComposite in2="hardAlpha" operator="out" />
              <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.35 0" />
              <feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_4605" />
              <feBlend in="SourceGraphic" in2="effect1_dropShadow_1_4605" mode="normal" result="shape" />
            </filter>
          </defs>
        </svg>
      </div>
    </div>
  );
}

function Component() {
  return (
    <div className="h-[288px] relative shrink-0 w-[285.292px]" data-name="Component 1">
      <Group />
    </div>
  );
}

function ForbesBadge2SvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[288px] items-center justify-center px-[0.354px] py-0 relative shrink-0 w-[286px]" data-name="forbes-badge2.svg fill">
      <Component />
    </div>
  );
}

function ForbesBadge2Svg() {
  return (
    <div className="content-stretch flex h-[288px] items-start max-w-[370px] relative shrink-0 w-[286px]" data-name="forbes-badge2.svg">
      <ForbesBadge2SvgFill />
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <ForbesBadge2Svg />
    </div>
  );
}

function Container4() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Container">
      <Container3 />
    </div>
  );
}

function Container5() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-center flex flex-wrap items-center justify-center pl-0 pr-[100px] py-0 relative size-full">
          <Container4 />
        </div>
      </div>
    </div>
  );
}

function Container6() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px relative self-stretch shrink-0 w-[470px]" data-name="Container">
      <Container5 />
    </div>
  );
}

function Container7() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Manrope:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[28px] text-center">
        <p className="css-ew64yg leading-[38px]">1</p>
      </div>
    </div>
  );
}

function Background() {
  return (
    <div className="bg-[#e9f2fc] content-stretch flex flex-[1_0_0] flex-col h-[45px] items-start max-h-[45px] max-w-[45px] min-h-px min-w-px pb-0 pt-[3px] px-0 relative rounded-[25px]" data-name="Background">
      <Container7 />
    </div>
  );
}

function Container8() {
  return (
    <div className="content-start flex flex-[1_0_0] flex-wrap h-full items-start justify-center min-h-px min-w-px relative" data-name="Container">
      <Background />
    </div>
  );
}

function Container9() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px relative self-stretch shrink-0 w-[44.02px]" data-name="Container">
      <Container8 />
    </div>
  );
}

function Container10() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-black w-full">
        <p className="css-4hzbpn leading-[24px]">{`Services you won’t find anywhere else. `}</p>
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container10 />
    </div>
  );
}

function Margin() {
  return (
    <div className="content-stretch flex flex-col h-[29px] items-start justify-center pb-[5px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container11 />
    </div>
  );
}

function Component9() {
  return (
    <a className="absolute content-stretch cursor-pointer flex items-start left-0 pl-0 pr-[9.99px] py-0 top-0" data-name="Component 10" href="https://www.plymouthrock.com/claims/services/crashbusters">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0078d6] text-[16px] text-left" role="link" tabIndex="0">
        <p className="css-ew64yg cursor-pointer decoration-solid leading-[24px] underline">Crashbusters</p>
      </div>
    </a>
  );
}

function Component13() {
  return (
    <a className="absolute content-stretch cursor-pointer flex items-start left-0 pl-0 pr-[9.99px] py-0 top-[48px]" data-name="Component 10" href="https://www.plymouthrock.com/claims/services/door-to-door-valet-claim-service">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0078d6] text-[0px] text-left" role="link" tabIndex="0">
        <p className="css-ew64yg cursor-pointer decoration-solid leading-[24px] text-[16px] underline" role="link" tabIndex="0">
          Door to Door Valet Service
        </p>
      </div>
    </a>
  );
}

function Component14() {
  return (
    <a className="absolute content-stretch cursor-pointer flex items-start left-0 pl-0 pr-[9.99px] py-0 top-[72px]" data-name="Component 10" href="https://www.plymouthrock.com/insurance/auto/discounts-benefits/get-home-safe">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0078d6] text-[0px] text-left" role="link" tabIndex="0">
        <p className="css-ew64yg cursor-pointer decoration-solid leading-[24px] text-[16px] underline" role="link" tabIndex="0">
          Get Home Safe
        </p>
      </div>
    </a>
  );
}

function Container12() {
  return (
    <div className="h-[96px] relative shrink-0 w-full" data-name="Container">
      <Component9 />
      <div className="absolute flex flex-col font-['Open_Sans:Regular',sans-serif] h-[24px] justify-center leading-[0] left-[109.01px] not-italic text-[16px] text-black top-[12px] translate-y-[-50%] w-[389.212px]">
        <p className="css-4hzbpn leading-[24px]">{` Tell us when and where you’d like us to meet you to`}</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans:Regular',sans-serif] h-[24px] justify-center leading-[0] left-0 not-italic text-[16px] text-black top-[36px] translate-y-[-50%] w-[226.016px]">
        <p className="css-4hzbpn leading-[24px]">inspect your damaged vehicle.</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans:Regular',sans-serif] h-[24px] justify-center leading-[0] left-[225.64px] not-italic text-[10px] text-black top-[30px] translate-y-[-50%] w-[6.038px]">
        <p className="css-4hzbpn leading-[24px]">1</p>
      </div>
      <Component13 />
      <div className="absolute flex flex-col font-['Open_Sans:Regular',sans-serif] h-[24px] justify-center leading-[0] left-[206.87px] not-italic text-[16px] text-black top-[60px] translate-y-[-50%] w-[336.081px]">
        <p className="css-4hzbpn leading-[24px]">{` We handle the claims repair process for you.`}</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans:Regular',sans-serif] h-[24px] justify-center leading-[0] left-[542.62px] not-italic text-[10px] text-black top-[54px] translate-y-[-50%] w-[6.038px]">
        <p className="css-4hzbpn leading-[24px]">1</p>
      </div>
      <Component14 />
      <div className="absolute flex flex-col font-['Open_Sans:Regular',sans-serif] h-[24px] justify-center leading-[0] left-[121.87px] not-italic text-[16px] text-black top-[84px] translate-y-[-50%] w-[425.426px]">
        <p className="css-4hzbpn leading-[24px]">{` We pay for your taxi ride as a safer alternative to driving.`}</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans:Regular',sans-serif] h-[24px] justify-center leading-[0] left-[546.93px] not-italic text-[10px] text-black top-[78px] translate-y-[-50%] w-[6.038px]">
        <p className="css-4hzbpn leading-[24px]">2</p>
      </div>
    </div>
  );
}

function Container13() {
  return (
    <div className="content-stretch flex flex-col h-[96px] items-start relative shrink-0 w-full" data-name="Container">
      <Container12 />
    </div>
  );
}

function Container14() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pl-[30px] pr-0 py-0 relative size-full">
          <Margin />
          <Container13 />
        </div>
      </div>
    </div>
  );
}

function Container15() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px relative self-stretch shrink-0 w-[584.97px]" data-name="Container">
      <Container14 />
    </div>
  );
}

function Container16() {
  return (
    <div className="content-stretch flex items-start max-w-[1140px] relative shrink-0 w-full" data-name="Container">
      <Container9 />
      <Container15 />
    </div>
  );
}

function Section1() {
  return (
    <div className="bg-white relative rounded-[30px] shrink-0 w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[28px] py-[23px] relative w-full">
        <Container16 />
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Manrope:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[28px] text-center">
        <p className="css-ew64yg leading-[38px]">2</p>
      </div>
    </div>
  );
}

function Background1() {
  return (
    <div className="bg-[#e9f2fc] content-stretch flex flex-[1_0_0] flex-col h-[45px] items-start max-h-[45px] max-w-[45px] min-h-px min-w-px pb-0 pt-[3px] px-0 relative rounded-[25px]" data-name="Background">
      <Container17 />
    </div>
  );
}

function Container18() {
  return (
    <div className="content-start flex flex-[1_0_0] flex-wrap h-full items-start justify-center min-h-px min-w-px relative" data-name="Container">
      <Background1 />
    </div>
  );
}

function Container19() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px relative self-stretch shrink-0 w-[44.02px]" data-name="Container">
      <Container18 />
    </div>
  );
}

function Container20() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-black w-full">
        <p className="css-4hzbpn leading-[24px]">Smart coverage. Even smarter savings.</p>
      </div>
    </div>
  );
}

function Container21() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container20 />
    </div>
  );
}

function Margin1() {
  return (
    <div className="content-stretch flex flex-col h-[29px] items-start justify-center pb-[5px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container21 />
    </div>
  );
}

function Component15() {
  return (
    <div className="absolute content-stretch flex items-start left-[67.98px] pl-0 pr-[9.99px] py-0 top-0" data-name="Component 10">
      <a className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0078d6] text-[0px]" href="https://www.plymouthrock.com/claims/services/crashbusters">
        <p className="css-ew64yg cursor-pointer decoration-solid leading-[24px] text-[16px] underline" role="link" tabIndex="0">
          Auto Insurance
        </p>
      </a>
    </div>
  );
}

function Component16() {
  return (
    <div className="absolute content-stretch flex items-start left-[217.82px] pl-0 pr-[9.99px] py-0 top-0" data-name="Component 10">
      <a className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0078d6] text-[0px]" href="https://www.plymouthrock.com/claims/services/crashbusters">
        <p className="css-ew64yg cursor-pointer decoration-solid leading-[24px] text-[16px] underline" role="link" tabIndex="0">
          Home Insurance
        </p>
      </a>
    </div>
  );
}

function Component17() {
  return (
    <div className="absolute content-stretch flex items-start left-[20.67px] pl-0 pr-[9.99px] py-0 top-[24px]" data-name="Component 10">
      <a className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0078d6] text-[0px]" href="https://www.plymouthrock.com/claims/services/crashbusters">
        <p className="css-ew64yg cursor-pointer decoration-solid leading-[24px] text-[16px] underline" role="link" tabIndex="0">
          discounts
        </p>
      </a>
    </div>
  );
}

function Container22() {
  return (
    <div className="h-[48px] relative shrink-0 w-full" data-name="Container">
      <div className="absolute flex flex-col font-['Open_Sans:Regular',sans-serif] h-[24px] justify-center leading-[0] left-0 not-italic text-[16px] text-black top-[12px] translate-y-[-50%] w-[68.285px]">
        <p className="css-4hzbpn leading-[24px]">{`We offer `}</p>
      </div>
      <Component15 />
      <div className="absolute flex flex-col font-['Open_Sans:Regular',sans-serif] h-[24px] justify-center leading-[0] left-[181.01px] not-italic text-[16px] text-black top-[12px] translate-y-[-50%] w-[37.122px]">
        <p className="css-4hzbpn leading-[24px]">{` and `}</p>
      </div>
      <Component16 />
      <div className="absolute flex flex-col font-['Open_Sans:Regular',sans-serif] h-[24px] justify-center leading-[0] left-[340.81px] not-italic text-[16px] text-black top-[12px] translate-y-[-50%] w-[208.422px]">
        <p className="css-4hzbpn leading-[24px]">{` to meet your needs, as well`}</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans:Regular',sans-serif] h-[24px] justify-center leading-[0] left-0 not-italic text-[16px] text-black top-[36px] translate-y-[-50%] w-[20.993px]">
        <p className="css-4hzbpn leading-[24px]">{`as `}</p>
      </div>
      <Component17 />
      <div className="absolute flex flex-col font-['Open_Sans:Regular',sans-serif] h-[24px] justify-center leading-[0] left-[92.37px] not-italic text-[16px] text-black top-[36px] translate-y-[-50%] w-[420.144px]">
        <p className="css-4hzbpn leading-[24px]">{` and exclusive policyholder perks to help you save more.​`}</p>
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div className="content-stretch flex flex-col h-[48px] items-start relative shrink-0 w-full" data-name="Container">
      <Container22 />
    </div>
  );
}

function Container24() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pl-[25px] pr-0 py-0 relative size-full">
          <Margin1 />
          <Container23 />
        </div>
      </div>
    </div>
  );
}

function Container25() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px relative self-stretch shrink-0 w-[584.97px]" data-name="Container">
      <Container24 />
    </div>
  );
}

function Container26() {
  return (
    <div className="content-stretch flex items-start max-w-[1140px] relative shrink-0 w-full" data-name="Container">
      <Container19 />
      <Container25 />
    </div>
  );
}

function Section2() {
  return (
    <div className="bg-white relative rounded-[30px] shrink-0 w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[28px] py-[23px] relative w-full">
        <Container26 />
      </div>
    </div>
  );
}

function SectionMargin() {
  return (
    <div className="content-stretch flex flex-col items-start px-0 py-[18px] relative shrink-0 w-full" data-name="Section:margin">
      <Section2 />
    </div>
  );
}

function Container27() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Manrope:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[28px] text-center">
        <p className="css-ew64yg leading-[38px]">3</p>
      </div>
    </div>
  );
}

function Background2() {
  return (
    <div className="bg-[#e9f2fc] content-stretch flex flex-[1_0_0] flex-col h-[45px] items-start max-h-[45px] max-w-[45px] min-h-px min-w-px pb-0 pt-[3px] px-0 relative rounded-[25px]" data-name="Background">
      <Container27 />
    </div>
  );
}

function Container28() {
  return (
    <div className="content-start flex flex-[1_0_0] flex-wrap h-full items-start justify-center min-h-px min-w-px relative" data-name="Container">
      <Background2 />
    </div>
  );
}

function Container29() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px relative self-stretch shrink-0 w-[44.02px]" data-name="Container">
      <Container28 />
    </div>
  );
}

function Container30() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-black w-full">
        <p className="css-4hzbpn leading-[24px]">Support that goes beyond insurance.</p>
      </div>
    </div>
  );
}

function Container31() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container30 />
    </div>
  );
}

function Margin2() {
  return (
    <div className="content-stretch flex flex-col h-[29px] items-start justify-center pb-[5px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container31 />
    </div>
  );
}

function Container32() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[24px] not-italic relative shrink-0 text-[16px] text-black w-full">
        <p className="css-4hzbpn mb-0">For more than 40 years, we’ve helped drivers across the Northeast with</p>
        <p className="css-4hzbpn">dependable support when it counts.</p>
      </div>
    </div>
  );
}

function Container33() {
  return (
    <div className="content-stretch flex flex-col h-[48px] items-start relative shrink-0 w-full" data-name="Container">
      <Container32 />
    </div>
  );
}

function Container34() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pl-[25px] pr-0 py-0 relative size-full">
          <Margin2 />
          <Container33 />
        </div>
      </div>
    </div>
  );
}

function Container35() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px relative self-stretch shrink-0 w-[584.97px]" data-name="Container">
      <Container34 />
    </div>
  );
}

function Container36() {
  return (
    <div className="content-stretch flex items-start max-w-[1140px] relative shrink-0 w-full" data-name="Container">
      <Container29 />
      <Container35 />
    </div>
  );
}

function Section3() {
  return (
    <div className="bg-white relative rounded-[30px] shrink-0 w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[28px] py-[23px] relative w-full">
        <Container36 />
      </div>
    </div>
  );
}

function Container37() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-full items-center justify-center min-h-px min-w-px relative" data-name="Container">
      <Section1 />
      <SectionMargin />
      <Section3 />
    </div>
  );
}

function Container38() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px pl-0 pr-[20px] py-0 relative self-stretch shrink-0 w-[705px]" data-name="Container">
      <Container37 />
    </div>
  );
}

function Container39() {
  return (
    <div className="content-stretch flex items-start max-w-[1175px] relative shrink-0 w-full" data-name="Container">
      <Container6 />
      <Container38 />
    </div>
  );
}

function Section4() {
  return (
    <div className="bg-[#eff6fd] content-stretch flex flex-col items-start mb-[-1px] pb-[80px] pt-0 px-[362.5px] relative shrink-0 w-[1920px]" data-name="Section">
      <Container39 />
    </div>
  );
}

function Heading1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 2">
      <div className="flex flex-col font-['Manrope:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[32px] text-black w-full">
        <p className="css-4hzbpn leading-[45px]">Go mobile.</p>
      </div>
    </div>
  );
}

function Container40() {
  return (
    <div className="absolute content-stretch flex flex-col inset-[-1px_0_16px_0] items-start" data-name="Container">
      <Heading1 />
    </div>
  );
}

function Margin3() {
  return (
    <div className="absolute inset-[30px_0_328.98px_20px]" data-name="Margin">
      <Container40 />
    </div>
  );
}

function Container41() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black w-full">
        <p className="css-4hzbpn leading-[26px]">Manage your insurance policy:</p>
      </div>
    </div>
  );
}

function Container42() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container41 />
    </div>
  );
}

function Margin4() {
  return (
    <div className="absolute content-stretch flex flex-col inset-[101.02px_0_271.98px_20px] items-start justify-center pb-[16px] pt-0 px-0" data-name="Margin">
      <Container42 />
    </div>
  );
}

function Component1() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Component 1">
          <path d={svgPaths.p2cc61300} fill="var(--fill-0, #2F76BC)" id="Vector" />
          <path d={svgPaths.p1b68d100} fill="var(--fill-0, white)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Container43() {
  return (
    <div className="content-stretch flex items-start pl-0 pr-[3.5px] py-0 relative shrink-0 z-[2]" data-name="Container">
      <Component1 />
    </div>
  );
}

function Container44() {
  return (
    <div className="content-stretch flex flex-col items-start pl-[5px] pr-0 py-0 relative shrink-0 z-[1]" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black">
        <p className="css-ew64yg leading-[28.8px]">View auto insurance ID cards</p>
      </div>
    </div>
  );
}

function Item() {
  return (
    <div className="content-stretch flex isolate items-center relative shrink-0 w-full" data-name="Item">
      <Container43 />
      <Container44 />
    </div>
  );
}

function Component2() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Component 1">
          <path d={svgPaths.p2cc61300} fill="var(--fill-0, #2F76BC)" id="Vector" />
          <path d={svgPaths.p1b68d100} fill="var(--fill-0, white)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Container45() {
  return (
    <div className="content-stretch flex items-start pl-0 pr-[3.5px] py-0 relative shrink-0 z-[2]" data-name="Container">
      <Component2 />
    </div>
  );
}

function Container46() {
  return (
    <div className="content-stretch flex flex-col items-start pl-[5px] pr-0 py-0 relative shrink-0 z-[1]" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black">
        <p className="css-ew64yg leading-[28.8px]">Update your policy</p>
      </div>
    </div>
  );
}

function Item1() {
  return (
    <div className="content-stretch flex isolate items-center relative shrink-0 w-full" data-name="Item">
      <Container45 />
      <Container46 />
    </div>
  );
}

function Component4() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Component 1">
          <path d={svgPaths.p2cc61300} fill="var(--fill-0, #2F76BC)" id="Vector" />
          <path d={svgPaths.p1b68d100} fill="var(--fill-0, white)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Container47() {
  return (
    <div className="content-stretch flex items-start pl-0 pr-[3.5px] py-0 relative shrink-0 z-[2]" data-name="Container">
      <Component4 />
    </div>
  );
}

function Container48() {
  return (
    <div className="content-stretch flex flex-col items-start pl-[5px] pr-0 py-0 relative shrink-0 z-[1]" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black">
        <p className="css-ew64yg leading-[28.8px]">Schedule payments</p>
      </div>
    </div>
  );
}

function Item2() {
  return (
    <div className="content-stretch flex isolate items-center relative shrink-0 w-full" data-name="Item">
      <Container47 />
      <Container48 />
    </div>
  );
}

function Component5() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Component 1">
          <path d={svgPaths.p2cc61300} fill="var(--fill-0, #2F76BC)" id="Vector" />
          <path d={svgPaths.p1b68d100} fill="var(--fill-0, white)" id="Vector_2" />
        </g>
      </svg>
    </div>
  );
}

function Container49() {
  return (
    <div className="content-stretch flex items-start pl-0 pr-[3.5px] py-0 relative shrink-0 z-[2]" data-name="Container">
      <Component5 />
    </div>
  );
}

function Container50() {
  return (
    <div className="content-stretch flex flex-col items-start pl-[5px] pr-0 py-0 relative shrink-0 z-[1]" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black">
        <p className="css-ew64yg leading-[28.8px]">Manage claims</p>
      </div>
    </div>
  );
}

function Item3() {
  return (
    <div className="content-stretch flex isolate items-center relative shrink-0 w-full" data-name="Item">
      <Container49 />
      <Container50 />
    </div>
  );
}

function List() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="List">
      <Item />
      <Item1 />
      <Item2 />
      <Item3 />
    </div>
  );
}

function Container51() {
  return (
    <div className="absolute content-stretch flex flex-col inset-[-20px_0_16px_0] items-start" data-name="Container">
      <List />
    </div>
  );
}

function Margin5() {
  return (
    <div className="absolute inset-[158.02px_0_150.79px_20px]" data-name="Margin">
      <Container51 />
    </div>
  );
}

function QrCode() {
  return (
    <div className="h-[96px] max-w-[340px] relative shrink-0 w-[94px]" data-name="QR code">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute left-0 max-w-none size-full top-0" src={imgQrCode} />
      </div>
    </div>
  );
}

function Container52() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <QrCode />
    </div>
  );
}

function Container53() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container52 />
    </div>
  );
}

function Margin6() {
  return (
    <div className="absolute content-stretch flex flex-col inset-[279.2px_0_38.8px_20px] items-start justify-center pb-[16px] pt-0 px-0" data-name="Margin">
      <Container53 />
    </div>
  );
}

function Container54() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans_Hebrew_Condensed:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[26px]">Download the app</p>
      </div>
    </div>
  );
}

function Container55() {
  return (
    <div className="absolute content-stretch flex flex-col inset-[386.2px_0_2.8px_20px] items-start" data-name="Container">
      <Container54 />
    </div>
  );
}

function Container56() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <Margin3 />
      <Margin4 />
      <Margin5 />
      <Margin6 />
      <Container55 />
    </div>
  );
}

function Container57() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px relative self-stretch shrink-0 w-[360px]" data-name="Container">
      <Container56 />
    </div>
  );
}

function Component6() {
  return (
    <div className="h-[430px] overflow-clip relative shrink-0 w-[399px]" data-name="Component 1">
      <img alt="" className="block max-w-none size-full" height="430" src={imgComponent1} width="399" />
    </div>
  );
}

function MobileAppSvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[430px] items-center justify-center overflow-clip relative shrink-0 w-[399px]" data-name="mobile-app.svg fill">
      <Component6 />
    </div>
  );
}

function MobileApp() {
  return (
    <div className="content-stretch flex h-[430px] items-start max-w-[420px] overflow-clip relative shrink-0 w-[399px]" data-name="mobile app">
      <MobileAppSvgFill />
    </div>
  );
}

function Container58() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <MobileApp />
    </div>
  );
}

function Container59() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-full items-start min-h-px min-w-px relative" data-name="Container">
      <Container58 />
    </div>
  );
}

function Container60() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px pl-0 pr-[20px] py-0 relative self-stretch shrink-0 w-[440px]" data-name="Container">
      <Container59 />
    </div>
  );
}

function Section5() {
  return (
    <div className="content-stretch flex items-start max-w-[800px] mb-[-1px] relative shrink-0 w-[800px]" data-name="Section">
      <Container57 />
      <Container60 />
    </div>
  );
}

function Component7() {
  return (
    <div className="absolute h-[168px] left-0 top-0 w-[1408px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1408 168">
        <g clipPath="url(#clip0_1_4355)" id="Component 1">
          <path d={svgPaths.p2cbff080} fill="var(--fill-0, #E9F2FC)" id="Vector" />
          <path d={svgPaths.p2eb48000} fill="var(--fill-0, #E9F2FC)" id="Vector_2" />
          <path d={svgPaths.p33d03700} fill="var(--fill-0, #E9F2FC)" id="Vector_3" />
          <path d={svgPaths.p33e53800} fill="var(--fill-0, white)" id="Vector_4" />
          <path d={svgPaths.p1a40ef00} fill="var(--fill-0, white)" id="Vector_5" />
          <path d={svgPaths.p2e3d0d80} fill="var(--fill-0, white)" id="Vector_6" />
          <path d={svgPaths.p1f1e8800} fill="var(--fill-0, #E9F2FC)" id="Vector_7" />
          <path d={svgPaths.p1831fd00} fill="var(--fill-0, #E9F2FC)" id="Vector_8" />
          <path d={svgPaths.p281abb00} fill="var(--fill-0, white)" id="Vector_9" />
          <path d={svgPaths.p68fd700} fill="var(--fill-0, #CFE1F5)" id="Vector_10" />
          <path d={svgPaths.p1ed9d500} fill="var(--fill-0, white)" id="Vector_11" />
          <path d={svgPaths.p3d0a600} fill="var(--fill-0, #CFE1F5)" id="Vector_12" />
          <path d={svgPaths.p3d69d580} fill="var(--fill-0, #CFE1F5)" id="Vector_13" />
          <path d={svgPaths.p3534200} fill="var(--fill-0, #CFE1F5)" id="Vector_14" />
          <path d={svgPaths.p1f030c80} fill="var(--fill-0, #CFE1F5)" id="Vector_15" />
          <path d={svgPaths.p3cee4a00} fill="var(--fill-0, #CFE1F5)" id="Vector_16" />
          <path d={svgPaths.p11cd7500} fill="var(--fill-0, white)" id="Vector_17" />
          <path d={svgPaths.p19140f00} fill="var(--fill-0, white)" id="Vector_18" />
          <path d="M1190.17 47.1182V166.556" id="Vector_19" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
          <path d={svgPaths.pf0cbd00} fill="var(--fill-0, #E9F2FC)" id="Vector_20" />
          <path d={svgPaths.pc033980} fill="var(--fill-0, #E9F2FC)" id="Vector_21" />
          <path d={svgPaths.p115a9000} fill="var(--fill-0, white)" id="Vector_22" />
          <path d={svgPaths.p498a600} fill="var(--fill-0, white)" id="Vector_23" />
          <path d={svgPaths.p13a26e00} fill="var(--fill-0, white)" id="Vector_24" />
          <path d={svgPaths.p3e46d200} fill="var(--fill-0, white)" id="Vector_25" />
          <path d={svgPaths.p3ad0c880} fill="var(--fill-0, #E9F2FC)" id="Vector_26" />
          <path d={svgPaths.p1182d740} fill="var(--fill-0, #E9F2FC)" id="Vector_27" />
          <path d={svgPaths.p1ea8e480} fill="var(--fill-0, white)" id="Vector_28" />
          <path d={svgPaths.p21b6b70} fill="var(--fill-0, white)" id="Vector_29" />
          <path d={svgPaths.p106d9300} fill="var(--fill-0, white)" id="Vector_30" />
          <path d={svgPaths.pd8c3e80} fill="var(--fill-0, #CFE1F5)" id="Vector_31" />
          <path d={svgPaths.p39e6f000} fill="var(--fill-0, white)" id="Vector_32" />
          <path d={svgPaths.p35132700} fill="var(--fill-0, white)" id="Vector_33" />
          <path d={svgPaths.p200b7c80} fill="var(--fill-0, white)" id="Vector_34" />
          <path d={svgPaths.p1ad842f0} fill="var(--fill-0, white)" id="Vector_35" />
          <path d={svgPaths.p2ea128c0} fill="var(--fill-0, #E9F2FC)" id="Vector_36" />
          <path d={svgPaths.p25cb9f00} fill="var(--fill-0, #E9F2FC)" id="Vector_37" />
          <path d={svgPaths.p25cc9800} fill="var(--fill-0, #E9F2FC)" id="Vector_38" />
          <path d={svgPaths.p1cad7900} fill="var(--fill-0, #CFE1F5)" id="Vector_39" />
          <path d={svgPaths.p29cea480} fill="var(--fill-0, white)" id="Vector_40" />
          <path d={svgPaths.p2849cbf0} fill="var(--fill-0, #CFE1F5)" id="Vector_41" />
          <path d={svgPaths.p267b2c00} fill="var(--fill-0, #CFE1F5)" id="Vector_42" />
          <path d={svgPaths.p356235c0} fill="var(--fill-0, #CFE1F5)" id="Vector_43" />
          <path d={svgPaths.p28137900} fill="var(--fill-0, #CFE1F5)" id="Vector_44" />
          <path d={svgPaths.p3a98f180} fill="var(--fill-0, #CFE1F5)" id="Vector_45" />
          <path d={svgPaths.p3124dfc0} fill="var(--fill-0, #CFE1F5)" id="Vector_46" />
          <path d={svgPaths.pf32800} fill="var(--fill-0, white)" id="Vector_47" />
          <path d={svgPaths.p11ceee80} fill="var(--fill-0, white)" id="Vector_48" />
          <path d={svgPaths.p34633000} fill="var(--fill-0, white)" id="Vector_49" />
          <path d={svgPaths.p1fe9f00} fill="var(--fill-0, white)" id="Vector_50" />
          <path d="M289.768 34.4089V166.724" id="Vector_51" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
          <path d={svgPaths.p314ce080} fill="var(--fill-0, #CFE1F5)" id="Vector_52" />
          <path d={svgPaths.p2fc7ad00} fill="var(--fill-0, white)" id="Vector_53" />
          <path d={svgPaths.p2400000} fill="var(--fill-0, #CFE1F5)" id="Vector_54" />
          <path d={svgPaths.p1d19380} fill="var(--fill-0, #CFE1F5)" id="Vector_55" />
          <path d={svgPaths.p3e55e140} fill="var(--fill-0, #CFE1F5)" id="Vector_56" />
          <path d={svgPaths.p3ee2b4a0} fill="var(--fill-0, #CFE1F5)" id="Vector_57" />
          <path d={svgPaths.p3b8249c0} fill="var(--fill-0, white)" id="Vector_58" />
          <path d={svgPaths.pe7c82f0} fill="var(--fill-0, white)" id="Vector_59" />
          <path d={svgPaths.p126dd600} fill="var(--fill-0, white)" id="Vector_60" />
          <path d={svgPaths.p2b16ed00} fill="var(--fill-0, white)" id="Vector_61" />
          <path d="M535.396 72.0752V166.556" id="Vector_62" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.325089" />
          <path d={svgPaths.p37e2b240} fill="var(--fill-0, #EFF4FF)" id="Vector_63" />
          <path d={svgPaths.p300c9480} fill="var(--fill-0, #EFF4FF)" id="Vector_64" />
          <path d={svgPaths.p9253300} fill="var(--fill-0, #EFF4FF)" id="Vector_65" />
          <path d={svgPaths.p36ad2400} fill="var(--fill-0, #EFF4FF)" id="Vector_66" />
          <path d={svgPaths.p1b7bc500} fill="var(--fill-0, #E9F2FC)" id="Vector_67" />
          <path d={svgPaths.p82f100} fill="var(--fill-0, #CFE1F5)" id="Vector_68" />
          <path d={svgPaths.p3f86b100} fill="var(--fill-0, #CFE1F5)" id="Vector_69" />
          <path d={svgPaths.p269ef600} fill="var(--fill-0, #CFE1F5)" id="Vector_70" />
          <path d={svgPaths.p395e5900} fill="var(--fill-0, #CFE1F5)" id="Vector_71" />
          <path d={svgPaths.p24c25a00} fill="var(--fill-0, #CFE1F5)" id="Vector_72" />
          <path d={svgPaths.p2992a10} fill="var(--fill-0, white)" id="Vector_73" />
          <path d={svgPaths.p3609ab80} fill="var(--fill-0, white)" id="Vector_74" />
          <path d={svgPaths.p2f292c80} fill="var(--fill-0, white)" id="Vector_75" />
          <path d={svgPaths.p213d3800} fill="var(--fill-0, white)" id="Vector_76" />
          <path d={svgPaths.p26311c00} fill="var(--fill-0, #E9F2FC)" id="Vector_77" />
          <path d={svgPaths.p216b0f80} fill="var(--fill-0, #CFE1F5)" id="Vector_78" />
          <path d={svgPaths.p9fa9b00} fill="var(--fill-0, #CFE1F5)" id="Vector_79" />
          <path d={svgPaths.p39438e80} fill="var(--fill-0, #E9F2FC)" id="Vector_80" />
          <path d={svgPaths.p14665280} fill="var(--fill-0, #E9F2FC)" id="Vector_81" />
          <path d={svgPaths.p2ea7e300} fill="var(--fill-0, white)" id="Vector_82" />
          <path d={svgPaths.p298b040} fill="var(--fill-0, #E9F2FC)" id="Vector_83" />
          <path d={svgPaths.p38cec600} fill="var(--fill-0, #E9F2FC)" id="Vector_84" />
          <path d={svgPaths.p38bc48e0} fill="var(--fill-0, #E9F2FC)" id="Vector_85" />
          <path d={svgPaths.p1bc26b80} fill="var(--fill-0, #E9F2FC)" id="Vector_86" />
          <path d={svgPaths.p2831c800} fill="var(--fill-0, #E9F2FC)" id="Vector_87" />
          <path d={svgPaths.p273effc0} fill="var(--fill-0, #E9F2FC)" id="Vector_88" />
          <path d={svgPaths.p7d36d80} fill="var(--fill-0, white)" id="Vector_89" />
          <path d={svgPaths.p284db400} fill="var(--fill-0, #E9F2FC)" id="Vector_90" />
          <path d={svgPaths.p11620c00} fill="var(--fill-0, #E9F2FC)" id="Vector_91" />
          <path d={svgPaths.p169e4480} fill="var(--fill-0, white)" id="Vector_92" />
          <path d={svgPaths.p23a50980} fill="var(--fill-0, #E9F2FC)" id="Vector_93" />
          <path d="M224.556 85.9143V96.6772" id="Vector_94" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
          <path d="M250.291 96.6355V166.415" id="Vector_95" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
          <path d={svgPaths.p5f87780} fill="var(--fill-0, #E9F2FC)" id="Vector_96" />
          <path d={svgPaths.p3ad30cc0} fill="var(--fill-0, white)" id="Vector_97" />
          <path d={svgPaths.p3054ba00} fill="var(--fill-0, #E9F2FC)" id="Vector_98" />
          <path d={svgPaths.p32d40a00} fill="var(--fill-0, #E9F2FC)" id="Vector_99" />
          <path d={svgPaths.p1f0d4400} fill="var(--fill-0, #E9F2FC)" id="Vector_100" />
          <path d={svgPaths.p32927c00} fill="var(--fill-0, #E9F2FC)" id="Vector_101" />
          <path d={svgPaths.p33e14400} fill="var(--fill-0, #E9F2FC)" id="Vector_102" />
          <path d={svgPaths.p2621a880} fill="var(--fill-0, #E9F2FC)" id="Vector_103" />
          <path d={svgPaths.p568a900} fill="var(--fill-0, #E9F2FC)" id="Vector_104" />
          <path d={svgPaths.p2475fcc0} fill="var(--fill-0, #E9F2FC)" id="Vector_105" />
          <path d={svgPaths.pd90d5f0} fill="var(--fill-0, #E9F2FC)" id="Vector_106" />
          <path d={svgPaths.p12439800} fill="var(--fill-0, #E9F2FC)" id="Vector_107" />
          <path d={svgPaths.p2621a880} fill="var(--fill-0, #E9F2FC)" id="Vector_108" />
          <path d={svgPaths.p425e900} fill="var(--fill-0, #E9F2FC)" id="Vector_109" />
          <path d={svgPaths.p27e18c00} fill="var(--fill-0, #E9F2FC)" id="Vector_110" />
          <path d={svgPaths.pcd4ba80} fill="var(--fill-0, #E9F2FC)" id="Vector_111" />
          <path d={svgPaths.p1fca7f00} fill="var(--fill-0, #E9F2FC)" id="Vector_112" />
          <path d={svgPaths.p24a7acf0} fill="var(--fill-0, #E9F2FC)" id="Vector_113" />
          <path d={svgPaths.p1909c680} fill="var(--fill-0, #E9F2FC)" id="Vector_114" />
          <path d={svgPaths.p1748bd80} fill="var(--fill-0, #E9F2FC)" id="Vector_115" />
          <path d={svgPaths.p2c2bb200} fill="var(--fill-0, #E9F2FC)" id="Vector_116" />
          <path d={svgPaths.p593fd00} fill="var(--fill-0, #E9F2FC)" id="Vector_117" />
          <path d="M426.053 92.4675V125.825" id="Vector_118" stroke="var(--stroke-0, #CFE1F5)" strokeLinejoin="round" strokeWidth="0.360769" />
          <path d={svgPaths.p2ea900f0} fill="var(--fill-0, #E9F2FC)" id="Vector_119" />
          <path d={svgPaths.p1e34d2f0} fill="var(--fill-0, #E9F2FC)" id="Vector_120" />
          <path d={svgPaths.pb913b00} fill="var(--fill-0, white)" id="Vector_121" />
          <path d={svgPaths.p259e6980} fill="var(--fill-0, #CFE1F5)" id="Vector_122" />
          <path d={svgPaths.p316ba3c0} fill="var(--fill-0, #CFE1F5)" id="Vector_123" />
          <path d={svgPaths.p1e738f00} fill="var(--fill-0, #CFE1F5)" id="Vector_124" />
          <path d={svgPaths.p31f5eb00} fill="var(--fill-0, #CFE1F5)" id="Vector_125" />
          <path d={svgPaths.p23caeb00} fill="var(--fill-0, #CFE1F5)" id="Vector_126" />
          <path d={svgPaths.p33f7d200} fill="var(--fill-0, #CFE1F5)" id="Vector_127" />
          <path d={svgPaths.p1ef61e00} fill="var(--fill-0, white)" id="Vector_128" />
          <path d={svgPaths.p33993580} fill="var(--fill-0, #CFE1F5)" id="Vector_129" />
          <path d={svgPaths.p3204a00} fill="var(--fill-0, #CFE1F5)" id="Vector_130" />
          <path d={svgPaths.pd406ff0} fill="var(--fill-0, #CFE1F5)" id="Vector_131" />
          <path d={svgPaths.p264e7571} fill="var(--fill-0, #CFE1F5)" id="Vector_132" />
          <path d={svgPaths.p3f089a00} fill="var(--fill-0, #CFE1F5)" id="Vector_133" />
          <path d={svgPaths.p1480e6f0} fill="var(--fill-0, #CFE1F5)" id="Vector_134" />
          <path d={svgPaths.p2f6def00} fill="var(--fill-0, white)" id="Vector_135" />
          <path d={svgPaths.p3f073080} fill="var(--fill-0, white)" id="Vector_136" />
          <path d={svgPaths.p276ae300} fill="var(--fill-0, white)" id="Vector_137" />
          <path d={svgPaths.pd307c00} fill="var(--fill-0, white)" id="Vector_138" />
          <path d="M653.58 34.2371V166.556" id="Vector_139" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
          <path d={svgPaths.p2cd4200} fill="var(--fill-0, #CFE1F5)" id="Vector_140" />
          <path d={svgPaths.p2af8d980} fill="var(--fill-0, #E9F2FC)" id="Vector_141" />
          <path d={svgPaths.p29593c00} fill="var(--fill-0, #E9F2FC)" id="Vector_142" />
          <path d={svgPaths.p25344880} fill="var(--fill-0, #CFE1F5)" id="Vector_143" />
          <path d={svgPaths.p198c1a00} fill="var(--fill-0, white)" id="Vector_144" />
          <path d={svgPaths.p101b8100} fill="var(--fill-0, #E9F2FC)" id="Vector_145" />
          <path d={svgPaths.pb33af00} fill="var(--fill-0, #E9F2FC)" id="Vector_146" />
          <path d={svgPaths.p1517ac00} fill="var(--fill-0, #E9F2FC)" id="Vector_147" />
          <path d={svgPaths.p14979d80} fill="var(--fill-0, #E9F2FC)" id="Vector_148" />
          <path d={svgPaths.p1f0f3200} fill="var(--fill-0, #E9F2FC)" id="Vector_149" />
          <path d={svgPaths.p136e38f0} fill="var(--fill-0, #E9F2FC)" id="Vector_150" />
          <path d={svgPaths.p143c2580} fill="var(--fill-0, white)" id="Vector_151" />
          <path d={svgPaths.p15b43580} fill="var(--fill-0, white)" id="Vector_152" />
          <path d="M1087.06 102.83H1140.62" id="Vector_153" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
          <path d="M1122.63 102.83V96.166" id="Vector_154" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
          <path d={svgPaths.p3dcce480} fill="var(--fill-0, white)" id="Vector_155" />
          <path d={svgPaths.p8900900} fill="var(--fill-0, #E9F2FC)" id="Vector_156" />
          <path d={svgPaths.p1f88b580} fill="var(--fill-0, #E9F2FC)" id="Vector_157" />
          <path d={svgPaths.p5b06070} fill="var(--fill-0, #E9F2FC)" id="Vector_158" />
          <path d={svgPaths.p11893200} fill="var(--fill-0, #E9F2FC)" id="Vector_159" />
          <path d={svgPaths.p45b8600} fill="var(--fill-0, #E9F2FC)" id="Vector_160" />
          <path d={svgPaths.p20aa500} fill="var(--fill-0, white)" id="Vector_161" />
          <path d={svgPaths.p3445e00} fill="var(--fill-0, #E9F2FC)" id="Vector_162" />
          <path d={svgPaths.p2476de80} fill="var(--fill-0, #E9F2FC)" id="Vector_163" />
          <path d={svgPaths.p2c406e70} fill="var(--fill-0, white)" id="Vector_164" />
          <path d={svgPaths.p25a60800} fill="var(--fill-0, #E9F2FC)" id="Vector_165" />
          <path d="M1350.09 99.4253V110.188" id="Vector_166" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
          <path d={svgPaths.pae34400} fill="var(--fill-0, #92D4BC)" id="Vector_167" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p172d8600} id="Vector_168" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p10957900} id="Vector_169" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p1c8aa300} fill="var(--fill-0, #92D4BC)" id="Vector_170" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d="M56.8643 117.99V166.701" id="Vector_171" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p2fdfa700} id="Vector_172" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p1bef2000} id="Vector_173" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p185fee72} fill="var(--fill-0, #92D4BC)" id="Vector_174" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d="M274.225 131.046V166.476" id="Vector_175" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p33b729c0} id="Vector_176" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p38d48c00} id="Vector_177" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p10504580} fill="var(--fill-0, #92D4BC)" id="Vector_178" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d="M1208.95 135.969V166.602" id="Vector_179" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p1e31c700} id="Vector_180" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p23b0d00} id="Vector_181" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p28818f00} fill="var(--fill-0, #92D4BC)" id="Vector_182" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d="M1388.41 120.738V166.755" id="Vector_183" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p3f3dba00} id="Vector_184" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.pcf1200} id="Vector_185" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p9eb000} fill="var(--fill-0, #92D4BC)" id="Vector_186" stroke="var(--stroke-2, #045437)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d="M606.278 131.744V166.754" id="Vector_187" stroke="var(--stroke-0, #045437)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p7024500} id="Vector_188" stroke="var(--stroke-0, #045437)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p17449c60} id="Vector_189" stroke="var(--stroke-0, #045437)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p1d464400} id="Vector_190" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.808757" />
          <path d={svgPaths.p8866800} fill="var(--fill-0, #92D4BC)" id="Vector_191" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p3312d080} id="Vector_192" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p29ceb880} id="Vector_193" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p16b97580} id="Vector_194" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p1966af00} fill="var(--fill-0, #92D4BC)" id="Vector_195" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p35272472} fill="var(--fill-0, #92D4BC)" id="Vector_196" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p283f1a00} fill="var(--fill-0, #92D4BC)" id="Vector_197" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.5" />
          <path d={svgPaths.p38411e80} id="Vector_198" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.5" />
          <path d={svgPaths.p19bfdb00} id="Vector_199" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.5" />
          <path d={svgPaths.p1659ca00} id="Vector_200" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.5" />
          <path d={svgPaths.p1a7aed00} fill="var(--fill-0, #92D4BC)" id="Vector_201" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p2a186380} id="Vector_202" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p1cf0fc00} fill="var(--fill-0, #92D4BC)" id="Vector_203" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p1dcc5d00} id="Vector_204" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.pc1e1a00} id="Vector_205" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
          <path d={svgPaths.p21888700} fill="var(--fill-0, #E9F2FC)" id="Vector_206" />
          <path d={svgPaths.p39de3c00} fill="var(--fill-0, white)" id="Vector_207" />
          <path d={svgPaths.p9fd8b00} fill="var(--fill-0, white)" id="Vector_208" />
          <path d={svgPaths.p11b48400} fill="var(--fill-0, #E9F2FC)" id="Vector_209" />
          <path d={svgPaths.pb923480} fill="var(--fill-0, white)" id="Vector_210" />
          <path d={svgPaths.p225522c0} fill="var(--fill-0, #E9F2FC)" id="Vector_211" />
          <path d={svgPaths.pc2f1e70} fill="var(--fill-0, #E9F2FC)" id="Vector_212" />
          <path d="M137.786 146.354V165.812" id="Vector_213" stroke="var(--stroke-0, #CFE1F5)" strokeMiterlimit="10" strokeWidth="0.360769" />
          <path d={svgPaths.p15d25e80} fill="var(--fill-0, #92D4BC)" id="Vector_214" stroke="var(--stroke-2, black)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.6" />
        </g>
        <defs>
          <clipPath id="clip0_1_4355">
            <rect fill="white" height="168" width="1408" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Skyline1SvgFill() {
  return (
    <div className="absolute h-[166px] left-0 overflow-clip top-0 w-[1900px]" data-name="skyline-1.svg fill">
      <Component7 />
    </div>
  );
}

function Component8() {
  return (
    <div className="h-[90px] relative shrink-0 w-[282.5px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 282.5 90">
        <g id="Component 1">
          <path d={svgPaths.p8d6b00} fill="var(--fill-0, #0078D6)" id="Vector" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p2cfbb800} fill="var(--fill-0, white)" id="Vector_2" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p2a7fe500} fill="var(--fill-0, #FF6200)" id="Vector_3" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p34350e00} fill="var(--fill-0, white)" id="Vector_4" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p3d337500} fill="var(--fill-0, white)" id="Vector_5" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p31713580} fill="var(--fill-0, black)" id="Vector_6" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p11622e00} fill="var(--fill-0, black)" id="Vector_7" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p30a28700} fill="var(--fill-0, black)" id="Vector_8" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p2cab4940} fill="var(--fill-0, #0078D6)" id="Vector_9" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p2d8b4980} id="Vector_10" stroke="var(--stroke-0, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p4449600} fill="var(--fill-0, white)" id="Vector_11" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p3dff1200} fill="var(--fill-0, white)" id="Vector_12" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p1020c600} fill="var(--fill-0, black)" id="Vector_13" />
          <path d={svgPaths.p31e1a780} fill="var(--fill-0, #152448)" id="Vector_14" />
          <path d={svgPaths.p7cd0200} fill="var(--fill-0, #F9FAF8)" id="Vector_15" />
          <path d={svgPaths.p125fe000} fill="var(--fill-0, #152448)" id="Vector_16" />
          <path d={svgPaths.p13fa5300} fill="var(--fill-0, #F9FAF8)" id="Vector_17" />
          <path d={svgPaths.p83a2300} fill="var(--fill-0, black)" id="Vector_18" />
          <path d={svgPaths.p838c400} fill="var(--fill-0, #152448)" id="Vector_19" />
          <path d={svgPaths.p2d6a8e80} fill="var(--fill-0, #F9FAF8)" id="Vector_20" />
          <path d={svgPaths.p3182b780} fill="var(--fill-0, #152448)" id="Vector_21" />
          <path d={svgPaths.pc5c7c00} fill="var(--fill-0, #F9FAF8)" id="Vector_22" />
          <path d="M6.35864 89.234H265.972" id="Vector_23" stroke="var(--stroke-0, #BADBFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.01095" />
          <path d={svgPaths.p9eb48b0} fill="var(--fill-0, white)" id="Vector_24" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p385b800} id="Vector_25" stroke="var(--stroke-0, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p28c40900} id="Vector_26" stroke="var(--stroke-0, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p246a9680} id="Vector_27" stroke="var(--stroke-0, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p19618ec0} id="Vector_28" stroke="var(--stroke-0, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p3697e240} id="Vector_29" stroke="var(--stroke-0, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
          <path d={svgPaths.p2af69300} fill="var(--fill-0, white)" id="Vector_30" stroke="var(--stroke-2, black)" strokeMiterlimit="10" strokeWidth="0.574852" />
        </g>
      </svg>
    </div>
  );
}

function BlueCar1SvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[90px] items-center justify-center overflow-clip px-[258.75px] py-0 relative shrink-0 w-[800px]" data-name="blue-car-1.svg fill">
      <Component8 />
    </div>
  );
}

function BlueCar() {
  return (
    <div className="content-stretch flex h-[90px] items-start max-w-[1900px] overflow-clip relative shrink-0 w-[800px]" data-name="blue car">
      <BlueCar1SvgFill />
    </div>
  );
}

function Container61() {
  return (
    <div className="absolute content-stretch flex h-[167px] items-end left-0 min-h-[140px] right-0 top-0" data-name="Container">
      <BlueCar />
    </div>
  );
}

function Section6() {
  return (
    <div className="h-[166px] mb-[-1px] relative shrink-0 w-[1920px]" data-name="Section">
      <Skyline1SvgFill />
      <Container61 />
    </div>
  );
}

function Heading2() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Heading 2">
      <div className="css-g0mm18 flex flex-col font-['Manrope:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[32px] text-black text-center">
        <p className="css-ew64yg leading-[42px]">Need help? We’re here for you.</p>
      </div>
    </div>
  );
}

function Container62() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Heading2 />
    </div>
  );
}

function Margin7() {
  return (
    <div className="content-stretch flex flex-col h-[48px] items-start justify-center pb-[6px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container62 />
    </div>
  );
}

function Container63() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[20px] text-black text-center">
        <p className="css-ew64yg leading-[28px]">Getting an auto insurance or home insurance quote is easy!</p>
      </div>
    </div>
  );
}

function Container64() {
  return (
    <div className="content-stretch flex flex-col h-[63px] items-start relative shrink-0 w-full" data-name="Container">
      <Container63 />
    </div>
  );
}

function Container65() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative self-stretch" data-name="Container">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pb-0 pt-[30px] px-[20px] relative size-full">
          <Margin7 />
          <Container64 />
        </div>
      </div>
    </div>
  );
}

function Container66() {
  return (
    <div className="max-w-[1140px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row justify-center max-w-[inherit] size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start justify-center max-w-[inherit] pl-0 pr-[10px] py-0 relative w-full">
          <Container65 />
        </div>
      </div>
    </div>
  );
}

function Section7() {
  return (
    <div className="bg-[#e9f2fc] content-stretch flex flex-col items-start mb-[-1px] pb-0 pt-[46px] px-[380px] relative shrink-0 w-[1920px]" data-name="Section">
      <div aria-hidden="true" className="absolute border-black border-solid border-t inset-0 pointer-events-none" />
      <Container66 />
    </div>
  );
}

function Container67() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black text-center">
        <p className="css-ew64yg leading-[26px]">Phone</p>
      </div>
    </div>
  );
}

function Container68() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container67 />
      </div>
    </div>
  );
}

function VerticalBorder() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-wrap h-full items-start justify-center min-h-px min-w-px pb-[6px] pl-[4px] pr-0 pt-[7px] relative" data-name="VerticalBorder">
      <div aria-hidden="true" className="absolute border-[#0351aa] border-l-4 border-solid inset-0 pointer-events-none" />
      <Container68 />
    </div>
  );
}

function Container69() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <VerticalBorder />
    </div>
  );
}

function Component18() {
  return (
    <div className="h-[30.882px] relative shrink-0 w-[30px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30.8824">
        <g id="Component 1">
          <path d={svgPaths.p2cc21400} fill="var(--fill-0, #0351AA)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function CellPhone2SvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[32px] items-center justify-center overflow-clip px-0 py-[0.559px] relative shrink-0 w-[30px]" data-name="cell-phone-2.svg fill">
      <Component18 />
    </div>
  );
}

function CellPhone() {
  return (
    <div className="content-stretch flex h-[32px] items-start max-w-[76.66000366210938px] overflow-clip relative shrink-0 w-[30px]" data-name="cell phone">
      <CellPhone2SvgFill />
    </div>
  );
}

function Container70() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <CellPhone />
    </div>
  );
}

function Container71() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-[32px] items-start min-h-px min-w-px relative" data-name="Container">
      <Container70 />
    </div>
  );
}

function Container72() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative self-stretch" data-name="Container">
      <div className="flex flex-row justify-center min-h-[inherit] size-full">
        <div className="content-stretch flex items-start justify-center min-h-[inherit] pl-[10px] pr-0 py-0 relative size-full">
          <Container71 />
        </div>
      </div>
    </div>
  );
}

function Container73() {
  return (
    <div className="content-stretch flex items-start max-w-[1140px] relative shrink-0 w-full" data-name="Container">
      <Container69 />
      <Container72 />
    </div>
  );
}

function Section8() {
  return (
    <div className="content-stretch flex flex-col h-[39px] items-start relative shrink-0 w-full" data-name="Section">
      <Container73 />
    </div>
  );
}

function Component19() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px]">
        <p className="css-ew64yg decoration-solid leading-[26px] underline">800-516-9242</p>
      </div>
    </div>
  );
}

function Container74() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[153.33px]" data-name="Container">
      <Component19 />
    </div>
  );
}

function Container75() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px pb-0 pt-[10px] px-0 relative self-stretch" data-name="Container">
      <Container74 />
    </div>
  );
}

function Container76() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1140px] pb-[6px] pt-[7px] px-0 relative shrink-0 w-full" data-name="Container">
      <Container75 />
    </div>
  );
}

function Section9() {
  return (
    <div className="content-stretch flex flex-col h-[49px] items-start relative shrink-0 w-full" data-name="Section">
      <Container76 />
    </div>
  );
}

function Container77() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pb-[26px] pl-0 pr-[40px] pt-0 relative size-full">
          <Section8 />
          <Section9 />
        </div>
      </div>
    </div>
  );
}

function Container78() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container77 />
    </div>
  );
}

function Container79() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black text-center">
        <p className="css-ew64yg leading-[26px]">Online</p>
      </div>
    </div>
  );
}

function Container80() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-[6px] pt-[7px] px-0 relative size-full">
        <Container79 />
      </div>
    </div>
  );
}

function VerticalBorder1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-wrap h-full items-start justify-center min-h-px min-w-px pl-[4px] pr-0 py-0 relative" data-name="VerticalBorder">
      <div aria-hidden="true" className="absolute border-[#0351aa] border-l-4 border-solid inset-0 pointer-events-none" />
      <Container80 />
    </div>
  );
}

function Container81() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px mr-[-0.01px] relative self-stretch" data-name="Container">
      <VerticalBorder1 />
    </div>
  );
}

function Component20() {
  return (
    <div className="h-[22px] relative shrink-0 w-[25.667px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25.6667 22">
        <g clipPath="url(#clip0_1_4941)" id="Component 1">
          <path d={svgPaths.p7c12500} fill="var(--fill-0, #0351AA)" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_1_4941">
            <rect fill="white" height="22" width="25.6667" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Internet2SvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[22px] items-center justify-center overflow-clip px-[3.167px] py-0 relative shrink-0 w-[32px]" data-name="internet-2.svg fill">
      <Component20 />
    </div>
  );
}

function InternetIcon() {
  return (
    <div className="content-stretch flex h-[22px] items-start max-w-[76.66000366210938px] overflow-clip relative shrink-0 w-[32px]" data-name="internet icon">
      <Internet2SvgFill />
    </div>
  );
}

function Container82() {
  return (
    <div className="content-stretch flex flex-col items-start pb-[0.28px] pt-[3.72px] px-0 relative shrink-0 w-full" data-name="Container">
      <InternetIcon />
    </div>
  );
}

function Container83() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-[26px] items-start min-h-px min-w-px relative" data-name="Container">
      <Container82 />
    </div>
  );
}

function Container84() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px mr-[-0.01px] relative self-stretch" data-name="Container">
      <div className="flex flex-row justify-center min-h-[inherit] size-full">
        <div className="content-stretch flex items-start justify-center min-h-[inherit] pl-[10px] pr-0 py-0 relative size-full">
          <Container83 />
        </div>
      </div>
    </div>
  );
}

function Container85() {
  return (
    <div className="content-stretch flex items-start max-w-[1140px] min-h-[39px] pl-0 pr-[0.01px] py-0 relative shrink-0 w-full" data-name="Container">
      <Container81 />
      <Container84 />
    </div>
  );
}

function Section10() {
  return (
    <div className="content-stretch flex flex-col h-[39px] items-start relative shrink-0 w-full" data-name="Section">
      <Container85 />
    </div>
  );
}

function Component21() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[26px] text-[16px] underline" href="https://www.plymouthrock.com/insurance/auto/">
          Auto insurance
        </a>
      </div>
    </div>
  );
}

function Component22() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[26px] text-[16px] underline" href="https://www.plymouthrock.com/insurance/home/">
          Home insurance
        </a>
      </div>
    </div>
  );
}

function Container86() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Component21 />
      <Component22 />
    </div>
  );
}

function Container87() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px pb-0 pt-[10px] px-0 relative self-stretch" data-name="Container">
      <Container86 />
    </div>
  );
}

function Container88() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1140px] pb-[6px] pt-[7px] px-0 relative shrink-0 w-full" data-name="Container">
      <Container87 />
    </div>
  );
}

function Section11() {
  return (
    <div className="content-stretch flex flex-col h-[75px] items-start relative shrink-0 w-full" data-name="Section">
      <Container88 />
    </div>
  );
}

function Container89() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pl-0 pr-[40px] py-0 relative size-full">
          <Section10 />
          <Section11 />
        </div>
      </div>
    </div>
  );
}

function Container90() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container89 />
    </div>
  );
}

function Container91() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black text-center">
        <p className="css-ew64yg leading-[26px]">Agent</p>
      </div>
    </div>
  );
}

function Container92() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-[6px] pt-[7px] px-0 relative size-full">
        <Container91 />
      </div>
    </div>
  );
}

function VerticalBorder2() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-wrap h-full items-start justify-center min-h-px min-w-px pl-[4px] pr-0 py-0 relative" data-name="VerticalBorder">
      <div aria-hidden="true" className="absolute border-[#0351aa] border-l-4 border-solid inset-0 pointer-events-none" />
      <Container92 />
    </div>
  );
}

function Container93() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px mr-[-0.01px] relative self-stretch" data-name="Container">
      <VerticalBorder2 />
    </div>
  );
}

function Component23() {
  return (
    <div className="relative shrink-0 size-[30px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 30 30">
        <g clipPath="url(#clip0_1_4716)" id="Component 1">
          <path d={svgPaths.p2ec4d100} fill="var(--fill-0, #0351AA)" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_1_4716">
            <rect fill="white" height="30" width="30" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Agent2SvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[30px] items-center justify-center overflow-clip px-[0.5px] py-0 relative shrink-0 w-[31px]" data-name="agent-2.svg fill">
      <Component23 />
    </div>
  );
}

function AgentIcon() {
  return (
    <div className="content-stretch flex h-[30px] items-start max-w-[76.66000366210938px] overflow-clip relative shrink-0 w-[31px]" data-name="agent icon">
      <Agent2SvgFill />
    </div>
  );
}

function Container94() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <AgentIcon />
    </div>
  );
}

function Container95() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-[30px] items-start min-h-px min-w-px relative" data-name="Container">
      <Container94 />
    </div>
  );
}

function Container96() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px mr-[-0.01px] relative self-stretch" data-name="Container">
      <div className="flex flex-row justify-center min-h-[inherit] size-full">
        <div className="content-stretch flex items-start justify-center min-h-[inherit] pl-[10px] pr-0 py-0 relative size-full">
          <Container95 />
        </div>
      </div>
    </div>
  );
}

function Container97() {
  return (
    <div className="content-stretch flex items-start max-w-[1140px] pl-0 pr-[0.01px] py-0 relative shrink-0 w-full" data-name="Container">
      <Container93 />
      <Container96 />
    </div>
  );
}

function Section12() {
  return (
    <div className="content-stretch flex flex-col h-[39px] items-start relative shrink-0 w-full" data-name="Section">
      <Container97 />
    </div>
  );
}

function Component24() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-full" data-name="Component 10">
      <div className="flex flex-[1_0_0] flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] min-h-px min-w-px not-italic relative text-[#0351aa] text-[0px]">
        <a className="block css-4hzbpn cursor-pointer decoration-solid leading-[26px] text-[16px] underline" href="https://www.plymouthrock.com/find-an-agent/">
          Find an agent
        </a>
      </div>
    </div>
  );
}

function Container98() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex flex-col items-start pl-0 pr-[25px] py-0 relative w-full">
        <Component24 />
      </div>
    </div>
  );
}

function Container99() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px pb-0 pt-[10px] px-0 relative self-stretch" data-name="Container">
      <Container98 />
    </div>
  );
}

function Container100() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1140px] pb-[6px] pt-[7px] px-0 relative shrink-0 w-full" data-name="Container">
      <Container99 />
    </div>
  );
}

function Section13() {
  return (
    <div className="content-stretch flex flex-col h-[49px] items-start relative shrink-0 w-full" data-name="Section">
      <Container100 />
    </div>
  );
}

function Container101() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pb-[26px] pl-0 pr-[40px] pt-0 relative size-full">
          <Section12 />
          <Section13 />
        </div>
      </div>
    </div>
  );
}

function Container102() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container101 />
    </div>
  );
}

function Container103() {
  return (
    <div className="content-stretch flex items-start max-w-[640px] relative shrink-0 w-full" data-name="Container">
      <Container78 />
      <Container90 />
      <Container102 />
    </div>
  );
}

function Section14() {
  return (
    <div className="bg-[#e9f2fc] content-stretch flex flex-col items-start mb-[-1px] pb-[100px] pl-[670px] pr-[590px] pt-0 relative shrink-0 w-[1920px]" data-name="Section">
      <Container103 />
    </div>
  );
}

function Heading3() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Heading 2">
      <div className="css-g0mm18 flex flex-col font-['Manrope:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[32px] text-center text-white">
        <p className="css-ew64yg leading-[42px]">Need more protection?</p>
      </div>
    </div>
  );
}

function Container104() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Heading3 />
    </div>
  );
}

function Margin8() {
  return (
    <div className="content-stretch flex flex-col h-[78px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container104 />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute inset-[68.03%_20.04%_23.13%_59.96%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[29.4px_12.74px]" data-name="Group" style={{ maskImage: `url('${imgGroup}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.3996 12.741">
        <g id="Group">
          <path d={svgPaths.p2e19aa00} fill="var(--fill-0, #A5E1D7)" id="Vector" />
          <path d={svgPaths.p35b13dc0} fill="var(--fill-0, #CCF5C6)" id="Vector_2" />
          <path d={svgPaths.p2c56c300} fill="var(--fill-0, #CCF5C6)" id="Vector_3" />
          <path d={svgPaths.pf628400} fill="var(--fill-0, #0078D6)" id="Vector_4" />
          <path d={svgPaths.p3183f200} fill="var(--fill-0, #0078D6)" id="Vector_5" />
          <path d={svgPaths.pb388b00} fill="var(--fill-0, #0078D6)" id="Vector_6" />
          <path d={svgPaths.p28684200} fill="var(--fill-0, #0078D6)" id="Vector_7" />
          <path d={svgPaths.p1cab1700} fill="var(--fill-0, #0078D6)" id="Vector_8" />
          <path d={svgPaths.p2b32a000} fill="var(--fill-0, #0078D6)" id="Vector_9" />
          <path d={svgPaths.p6fb0d00} fill="var(--fill-0, #0078D6)" id="Vector_10" />
          <path d={svgPaths.p15ecee00} fill="var(--fill-0, #0078D6)" id="Vector_11" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup() {
  return (
    <div className="absolute contents inset-[68.03%_20.04%_23.13%_59.96%]" data-name="Clip path group">
      <Group1 />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute inset-[51.82%_66.71%_23.13%_7.96%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-10.778px_-0.175px] mask-size-[48.02px_36.26px]" data-name="Group" style={{ maskImage: `url('${imgGroup1}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 37.2432 36.0849">
        <g id="Group">
          <path d={svgPaths.p7f9b600} fill="var(--fill-0, #A5E1D7)" id="Vector" />
          <path d={svgPaths.p2a751f0} fill="var(--fill-0, #CCF5C6)" id="Vector_2" />
          <path d={svgPaths.p144f8200} fill="var(--fill-0, #0078D6)" id="Vector_3" />
          <path d={svgPaths.p2f2df100} fill="var(--fill-0, #0078D6)" id="Vector_4" />
          <path d={svgPaths.p2b5fb900} fill="var(--fill-0, #0078D6)" id="Vector_5" />
          <path d={svgPaths.pd0ccbc0} fill="var(--fill-0, #0078D6)" id="Vector_6" />
          <path d={svgPaths.p3c884d00} fill="var(--fill-0, #0078D6)" id="Vector_7" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup1() {
  return (
    <div className="absolute contents inset-[51.7%_66.71%_23.13%_0.62%]" data-name="Clip path group">
      <Group2 />
    </div>
  );
}

function Component25() {
  return (
    <div className="h-[144.06px] overflow-clip relative shrink-0 w-[147px]" data-name="Component 1">
      <ClipPathGroup />
      <ClipPathGroup1 />
      <div className="absolute inset-[57.14%_18.71%_38.78%_71.29%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.7 5.88001">
            <path d={svgPaths.pb196480} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[38.78%_58.04%_55.78%_28.62%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.6 7.83999">
            <path d={svgPaths.p1198b600} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute flex inset-[76.99%_0.04%_0.67%_0.67%] items-center justify-center">
        <div className="flex-none h-[32.18px] scale-y-[-100%] w-[145.957px]">
          <div className="relative size-full" data-name="Vector">
            <div className="absolute inset-0" style={{ "--fill-0": "rgba(233, 242, 252, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 145.957 32.1797">
                <path d={svgPaths.p38987d00} fill="var(--fill-0, #E9F2FC)" id="Vector" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute inset-[54.08%_34%_34.01%_33%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(255, 255, 255, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48.51 17.15">
            <path d={svgPaths.p9aabc80} fill="var(--fill-0, white)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[52.67%_28.69%_19.83%_27.91%]" data-name="Vector">
        <div className="absolute inset-[-1.86%_-1.15%]" style={{ "--fill-0": "rgba(211, 229, 249, 1)", "--stroke-0": "rgba(3, 81, 170, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 65.2566 41.0804">
            <path d={svgPaths.p3552aa40} fill="var(--fill-0, #D3E5F9)" id="Vector" stroke="var(--stroke-2, #0351AA)" strokeMiterlimit="10" strokeWidth="1.47" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[60.38%_39.2%_35.89%_53.47%]" data-name="Vector">
        <div className="absolute inset-[-13.66%_-6.83%]" style={{ "--stroke-0": "rgba(3, 81, 170, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.232 6.85098">
            <path d={svgPaths.p15671900} id="Vector" stroke="var(--stroke-0, #0351AA)" strokeMiterlimit="10" strokeWidth="1.47" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[80.12%_32.01%_15.73%_31.23%]" data-name="Vector">
        <div className="absolute inset-[-12.3%_-1.37%_-12.3%_-1.36%]" style={{ "--fill-0": "rgba(167, 202, 242, 1)", "--stroke-0": "rgba(3, 81, 170, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 55.52 7.44604">
            <path d={svgPaths.p2badb340} fill="var(--fill-0, #A7CAF2)" id="Vector" stroke="var(--stroke-2, #0351AA)" strokeMiterlimit="10" strokeWidth="1.47" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[71.27%_60.96%_23.94%_31.93%]" data-name="Vector">
        <div className="absolute inset-[-10.65%_-7.03%]" style={{ "--fill-0": "rgba(255, 255, 255, 1)", "--stroke-0": "rgba(3, 81, 170, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9274 8.37312">
            <path d={svgPaths.p27006700} fill="var(--fill-0, white)" id="Vector" stroke="var(--stroke-2, #0351AA)" strokeMiterlimit="10" strokeWidth="1.47" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[71.27%_32.52%_23.94%_60.36%]" data-name="Vector">
        <div className="absolute inset-[-10.65%_-7.03%]" style={{ "--fill-0": "rgba(255, 255, 255, 1)", "--stroke-0": "rgba(3, 81, 170, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9271 8.37312">
            <path d={svgPaths.p32d96300} fill="var(--fill-0, white)" id="Vector" stroke="var(--stroke-2, #0351AA)" strokeMiterlimit="10" strokeWidth="1.47" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[75.21%_43.46%_24.79%_43.67%]" data-name="Vector">
        <div className="absolute inset-[-0.74px_-3.88%]" style={{ "--stroke-0": "rgba(3, 81, 170, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.3977 1.47">
            <path d="M0.735 0.735H19.6627" id="Vector" stroke="var(--stroke-0, #0351AA)" strokeLinecap="round" strokeMiterlimit="10" strokeWidth="1.47" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[72.09%_43.46%_27.91%_43.67%]" data-name="Vector">
        <div className="absolute inset-[-0.74px_-3.88%]" style={{ "--stroke-0": "rgba(3, 81, 170, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.3977 1.47">
            <path d="M0.735 0.735H19.6627" id="Vector" stroke="var(--stroke-0, #0351AA)" strokeLinecap="round" strokeMiterlimit="10" strokeWidth="1.47" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function AutoIcon41SvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[144px] items-center justify-center overflow-clip relative shrink-0 w-[147px]" data-name="auto-icon4-1.svg fill">
      <Component25 />
    </div>
  );
}

function CarIllustrationIcon() {
  return (
    <div className="flex-[1_0_0] h-[144px] min-h-px min-w-px relative rounded-[20px]" data-name="car illustration icon">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <AutoIcon41SvgFill />
      </div>
    </div>
  );
}

function Container105() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[14px] text-center" role="link" tabIndex="0">
        <p className="css-ew64yg cursor-pointer leading-[14px]"></p>
      </div>
    </div>
  );
}

function Margin9() {
  return (
    <div className="content-stretch flex flex-col items-start pl-[8px] pr-0 py-0 relative shrink-0" data-name="Margin">
      <Container105 />
    </div>
  );
}

function Container106() {
  return (
    <div className="absolute left-[31.1%] right-[31.11%] top-[23px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative w-full">
        <div className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px] text-center" role="link" tabIndex="0">
          <p className="css-ew64yg cursor-pointer leading-[26px]">Auto</p>
        </div>
        <Margin9 />
      </div>
    </div>
  );
}

function Component10() {
  return (
    <a className="bg-white h-[146px] relative rounded-[20px] shrink-0 w-[149px]" data-name="Component 11" href="https://www.plymouthrock.com/insurance/auto">
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">
        <CarIllustrationIcon />
        <Container106 />
      </div>
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]" />
    </a>
  );
}

function Group3() {
  return (
    <div className="absolute inset-[68.03%_20.04%_23.13%_59.96%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[29.4px_12.74px]" data-name="Group" style={{ maskImage: `url('${imgGroup}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29.3996 12.741">
        <g id="Group">
          <path d={svgPaths.p2e19aa00} fill="var(--fill-0, #A5E1D7)" id="Vector" />
          <path d={svgPaths.p305a4400} fill="var(--fill-0, #CCF5C6)" id="Vector_2" />
          <path d={svgPaths.p2c56c300} fill="var(--fill-0, #CCF5C6)" id="Vector_3" />
          <path d={svgPaths.pc646d00} fill="var(--fill-0, #0078D6)" id="Vector_4" />
          <path d={svgPaths.p3183f200} fill="var(--fill-0, #0078D6)" id="Vector_5" />
          <path d={svgPaths.pb388b00} fill="var(--fill-0, #0078D6)" id="Vector_6" />
          <path d={svgPaths.p3ff57680} fill="var(--fill-0, #0078D6)" id="Vector_7" />
          <path d={svgPaths.p14944000} fill="var(--fill-0, #0078D6)" id="Vector_8" />
          <path d={svgPaths.p1b3e4a80} fill="var(--fill-0, #0078D6)" id="Vector_9" />
          <path d={svgPaths.p2b426700} fill="var(--fill-0, #0078D6)" id="Vector_10" />
          <path d={svgPaths.p142bc480} fill="var(--fill-0, #0078D6)" id="Vector_11" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup2() {
  return (
    <div className="absolute contents inset-[68.03%_20.04%_23.13%_59.96%]" data-name="Clip path group">
      <Group3 />
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute inset-[51.82%_66.71%_23.13%_7.96%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-10.778px_-0.175px] mask-size-[48.02px_36.26px]" data-name="Group" style={{ maskImage: `url('${imgGroup1}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 37.2429 36.0849">
        <g id="Group">
          <path d={svgPaths.p9549480} fill="var(--fill-0, #A5E1D7)" id="Vector" />
          <path d={svgPaths.p2beb22f0} fill="var(--fill-0, #CCF5C6)" id="Vector_2" />
          <path d={svgPaths.p31c60e00} fill="var(--fill-0, #0078D6)" id="Vector_3" />
          <path d={svgPaths.p251c2180} fill="var(--fill-0, #0078D6)" id="Vector_4" />
          <path d={svgPaths.pfd95400} fill="var(--fill-0, #0078D6)" id="Vector_5" />
          <path d={svgPaths.p222c3e00} fill="var(--fill-0, #0078D6)" id="Vector_6" />
          <path d={svgPaths.p31c64300} fill="var(--fill-0, #0078D6)" id="Vector_7" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup3() {
  return (
    <div className="absolute contents inset-[51.7%_66.71%_23.13%_0.62%]" data-name="Clip path group">
      <Group4 />
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute inset-[45.38%_29.28%_12.72%_28.36%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-0.712px_-0.69px] mask-size-[63.7px_61.74px]" data-name="Group" style={{ maskImage: `url('${imgGroup2}')` }}>
      <div className="absolute inset-[-1.22%_-1.18%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 63.7473 61.8303">
          <g id="Group">
            <path d={svgPaths.p1abebb00} fill="var(--fill-0, #D3E5F9)" id="Vector" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path d={svgPaths.p26bde280} fill="var(--fill-0, white)" id="Vector_2" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path d={svgPaths.p253f9500} fill="var(--fill-0, white)" id="Vector_3" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path d={svgPaths.p7249a00} fill="var(--fill-0, white)" id="Vector_4" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path d={svgPaths.pcab8800} fill="var(--fill-0, #BADBFF)" id="Vector_5" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path d={svgPaths.p3c41d8c0} fill="var(--fill-0, #BADBFF)" id="Vector_6" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ClipPathGroup4() {
  return (
    <div className="absolute contents inset-[44.9%_28.8%_12.24%_27.87%]" data-name="Clip path group">
      <Group5 />
    </div>
  );
}

function Component26() {
  return (
    <div className="h-[144.06px] overflow-clip relative shrink-0 w-[147px]" data-name="Component 1">
      <ClipPathGroup2 />
      <ClipPathGroup3 />
      <div className="absolute inset-[57.14%_18.71%_38.78%_71.29%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.7 5.88001">
            <path d={svgPaths.pb196480} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[38.78%_58.04%_55.78%_28.62%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.6 7.83999">
            <path d={svgPaths.p1198b600} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute flex inset-[76.99%_0.04%_0.67%_0.67%] items-center justify-center">
        <div className="flex-none h-[32.18px] scale-y-[-100%] w-[145.957px]">
          <div className="relative size-full" data-name="Vector">
            <div className="absolute inset-0" style={{ "--fill-0": "rgba(233, 242, 252, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 145.957 32.1797">
                <path d={svgPaths.p38987d00} fill="var(--fill-0, #E9F2FC)" id="Vector" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <ClipPathGroup4 />
    </div>
  );
}

function HomeIconSvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[144px] items-center justify-center overflow-clip relative shrink-0 w-[147px]" data-name="home-icon.svg fill">
      <Component26 />
    </div>
  );
}

function HomeIllustrationIcon() {
  return (
    <div className="flex-[1_0_0] h-[144px] min-h-px min-w-px relative rounded-[20px]" data-name="home illustration icon">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <HomeIconSvgFill />
      </div>
    </div>
  );
}

function Container107() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[14px] text-center" role="link" tabIndex="0">
        <p className="css-ew64yg cursor-pointer leading-[14px]"></p>
      </div>
    </div>
  );
}

function Margin10() {
  return (
    <div className="content-stretch flex flex-col items-start pl-[8px] pr-0 py-0 relative shrink-0" data-name="Margin">
      <Container107 />
    </div>
  );
}

function Container108() {
  return (
    <div className="absolute left-[27.85%] right-[27.85%] top-[23px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative w-full">
        <div className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px] text-center" role="link" tabIndex="0">
          <p className="css-ew64yg cursor-pointer leading-[26px]">Home</p>
        </div>
        <Margin10 />
      </div>
    </div>
  );
}

function Component27() {
  return (
    <a className="bg-white h-[146px] relative rounded-[20px] shrink-0 w-[149px]" data-name="Component 11" href="https://www.plymouthrock.com/insurance/home">
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">
        <HomeIllustrationIcon />
        <Container108 />
      </div>
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]" />
    </a>
  );
}

function Group6() {
  return (
    <div className="absolute inset-[65.31%_15.44%_23.13%_59.06%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-0.001px_0px] mask-size-[37.49px_16.772px]" data-name="Group" style={{ maskImage: `url('${imgGroup3}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 37.4894 16.7728">
        <g id="Group">
          <path d={svgPaths.p1a574cc0} fill="var(--fill-0, #A5E1D7)" id="Vector" />
          <path d={svgPaths.p2304eb00} fill="var(--fill-0, #A5E1D7)" id="Vector_2" />
          <path d={svgPaths.p3d21bf00} fill="var(--fill-0, #CCF5C6)" id="Vector_3" />
          <path d={svgPaths.p13953280} fill="var(--fill-0, #0078D6)" id="Vector_4" />
          <path d={svgPaths.p3caf9f00} fill="var(--fill-0, #0078D6)" id="Vector_5" />
          <path d={svgPaths.p27c1b780} fill="var(--fill-0, #0078D6)" id="Vector_6" />
          <path d={svgPaths.p3034f800} fill="var(--fill-0, #0078D6)" id="Vector_7" />
          <path d={svgPaths.pd705200} fill="var(--fill-0, #0078D6)" id="Vector_8" />
          <path d={svgPaths.p3684ea80} fill="var(--fill-0, #0078D6)" id="Vector_9" />
          <path d={svgPaths.p1b453480} fill="var(--fill-0, #0078D6)" id="Vector_10" />
          <path d={svgPaths.p159bba00} fill="var(--fill-0, #0078D6)" id="Vector_11" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup5() {
  return (
    <div className="absolute contents inset-[65.31%_15.44%_23.13%_59.06%]" data-name="Clip path group">
      <Group6 />
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute inset-[63.95%_72.61%_23.13%_15.94%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-15.538px_0px] mask-size-[43.409px_18.745px]" data-name="Group" style={{ maskImage: `url('${imgGroup4}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.831 18.7445">
        <g id="Group">
          <path d={svgPaths.p1ec5d900} fill="var(--fill-0, #A5E1D7)" id="Vector" />
          <path d={svgPaths.p3b8f7f00} fill="var(--fill-0, #0078D6)" id="Vector_2" />
          <path d={svgPaths.p33f61e00} fill="var(--fill-0, #0078D6)" id="Vector_3" />
          <path d={svgPaths.p3aa1b900} fill="var(--fill-0, #0078D6)" id="Vector_4" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup6() {
  return (
    <div className="absolute contents inset-[63.95%_65.1%_23.13%_5.37%]" data-name="Clip path group">
      <Group7 />
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute inset-[40.67%_26.7%_12.1%_26.7%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-0.779px_-0.78px] mask-size-[70.047px_70.047px]" data-name="Group" style={{ maskImage: `url('${imgGroup5}')` }}>
      <div className="absolute inset-[-1.08%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 69.9691 69.9666">
          <g id="Group">
            <path d={svgPaths.p2de4a800} fill="var(--fill-0, #D3E5F9)" id="Vector" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p36503300} fill="var(--fill-0, #D3E5F9)" id="Vector_2" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p32fee5f0} fill="var(--fill-0, white)" id="Vector_3" stroke="var(--stroke-1, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.pb380c00} fill="var(--fill-0, white)" id="Vector_4" stroke="var(--stroke-1, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p1e528f00} fill="var(--fill-0, white)" id="Vector_5" stroke="var(--stroke-1, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p8be6f80} fill="var(--fill-0, #BADBFF)" id="Vector_6" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p32279400} fill="var(--fill-0, #BADBFF)" id="Vector_7" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p312a6f80} fill="var(--fill-0, #BADBFF)" id="Vector_8" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p17f0d7f1} fill="var(--fill-0, #BADBFF)" id="Vector_9" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ClipPathGroup7() {
  return (
    <div className="absolute contents inset-[40.14%_26.17%_11.56%_26.17%]" data-name="Clip path group">
      <Group8 />
    </div>
  );
}

function Component28() {
  return (
    <div className="absolute h-[145.027px] left-1/2 overflow-clip top-1/2 translate-x-[-50%] translate-y-[-50%] w-[147px]" data-name="Component 1">
      <ClipPathGroup5 />
      <ClipPathGroup6 />
      <div className="absolute flex inset-[76.99%_0.04%_0.67%_0] items-center justify-center">
        <div className="flex-none h-[32.396px] scale-y-[-100%] w-[146.937px]">
          <div className="relative size-full" data-name="Vector">
            <div className="absolute inset-0" style={{ "--fill-0": "rgba(233, 242, 252, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 146.937 32.3956">
                <path d={svgPaths.p21a3fa00} fill="var(--fill-0, #E9F2FC)" id="Vector" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute inset-[39.46%_59.9%_55.1%_26.68%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.7315 7.89261">
            <path d={svgPaths.p21ba2880} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[44.9%_86.08%_51.02%_3.86%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.7987 5.91948">
            <path d={svgPaths.p38799800} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[44.9%_8.9%_48.3%_74.33%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.6644 9.86579">
            <path d={svgPaths.pd7d2b00} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <ClipPathGroup7 />
    </div>
  );
}

function CondoIconSvgFill() {
  return (
    <div className="h-[144px] overflow-clip relative shrink-0 w-[147px]" data-name="condo-icon.svg fill">
      <Component28 />
    </div>
  );
}

function CondoIllustrationIcon() {
  return (
    <div className="flex-[1_0_0] h-[144px] min-h-px min-w-px relative rounded-[20px]" data-name="condo illustration icon">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <CondoIconSvgFill />
      </div>
    </div>
  );
}

function Container109() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[14px] text-center" role="link" tabIndex="0">
        <p className="css-ew64yg cursor-pointer leading-[14px]"></p>
      </div>
    </div>
  );
}

function Margin11() {
  return (
    <div className="content-stretch flex flex-col items-start pl-[8px] pr-0 py-0 relative shrink-0" data-name="Margin">
      <Container109 />
    </div>
  );
}

function Container110() {
  return (
    <div className="absolute left-[26.64%] right-[26.63%] top-[23px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative w-full">
        <div className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px] text-center" role="link" tabIndex="0">
          <p className="css-ew64yg cursor-pointer leading-[26px]">Condo</p>
        </div>
        <Margin11 />
      </div>
    </div>
  );
}

function Component29() {
  return (
    <a className="bg-white h-[146px] relative rounded-[20px] shrink-0 w-[149px]" data-name="Component 11" href="https://www.plymouthrock.com/insurance/condo">
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">
        <CondoIllustrationIcon />
        <Container110 />
      </div>
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]" />
    </a>
  );
}

function Group9() {
  return (
    <div className="absolute inset-[51.02%_68.41%_23.13%_15.48%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[23.678px_37.49px]" data-name="Group" style={{ maskImage: `url('${imgGroup6}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.6786 37.4899">
        <g id="Group">
          <path d={svgPaths.p2306d500} fill="var(--fill-0, #CCF5C6)" id="Vector" />
          <path d={svgPaths.p1be280} fill="var(--fill-0, #A5E1D7)" id="Vector_2" />
          <path d={svgPaths.p273a2c40} fill="var(--fill-0, #A5E1D7)" id="Vector_3" />
          <path d={svgPaths.p381c2180} fill="var(--fill-0, #0078D6)" id="Vector_4" />
          <path d={svgPaths.p21e8bc00} fill="var(--fill-0, #0078D6)" id="Vector_5" />
          <path d={svgPaths.p1cd81680} fill="var(--fill-0, #0078D6)" id="Vector_6" />
          <path d={svgPaths.p2957f200} fill="var(--fill-0, #0078D6)" id="Vector_7" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup8() {
  return (
    <div className="absolute contents inset-[51.02%_68.41%_23.13%_15.48%]" data-name="Clip path group">
      <Group9 />
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute inset-[45.39%_27.89%_11.38%_29.48%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-0.719px_-0.719px] mask-size-[64.128px_64.128px]" data-name="Group" style={{ maskImage: `url('${imgGroup7}')` }}>
      <div className="absolute inset-[-1.18%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 64.1552 64.1687">
          <g id="Group">
            <path d={svgPaths.p3ed8ec0} fill="var(--fill-0, #D3E5F9)" id="Vector" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p145eda00} fill="var(--fill-0, #D3E5F9)" id="Vector_2" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p3cfa30f0} fill="var(--fill-0, #D3E5F9)" id="Vector_3" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p363adc00} fill="var(--fill-0, white)" id="Vector_4" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p1a57f930} fill="var(--fill-0, white)" id="Vector_5" stroke="var(--stroke-1, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p3d089a10} fill="var(--fill-0, white)" id="Vector_6" stroke="var(--stroke-1, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p19819b00} fill="var(--fill-0, white)" id="Vector_7" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p24299300} fill="var(--fill-0, white)" id="Vector_8" stroke="var(--stroke-1, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p164200} fill="var(--fill-0, white)" id="Vector_9" stroke="var(--stroke-1, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p16bad00} fill="var(--fill-0, #BADBFF)" id="Vector_10" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.pd577c00} fill="var(--fill-0, #BADBFF)" id="Vector_11" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p2be31b00} fill="var(--fill-0, white)" id="Vector_12" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p7a2ce00} fill="var(--fill-0, white)" id="Vector_13" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p2265e270} fill="var(--fill-0, white)" id="Vector_14" stroke="var(--stroke-1, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p15d0f080} fill="var(--fill-0, white)" id="Vector_15" stroke="var(--stroke-1, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p2e4a180} fill="var(--fill-0, white)" id="Vector_16" stroke="var(--stroke-1, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
            <path d={svgPaths.p2aa2d800} fill="var(--fill-0, white)" id="Vector_17" stroke="var(--stroke-1, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47987" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ClipPathGroup9() {
  return (
    <div className="absolute contents inset-[44.9%_27.39%_10.88%_28.99%]" data-name="Clip path group">
      <Group10 />
    </div>
  );
}

function Component30() {
  return (
    <div className="absolute h-[145.027px] left-1/2 overflow-clip top-1/2 translate-x-[-50%] translate-y-[-50%] w-[147px]" data-name="Component 1">
      <div className="absolute inset-[65.31%_16.06%_20.41%_69.17%]" data-name="Vector">
        <img alt="" className="block max-w-none size-full" height="20.718" src={imgVector} width="21.705" />
      </div>
      <ClipPathGroup8 />
      <div className="absolute inset-[36.05%_75.8%_57.14%_7.43%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.6644 9.86579">
            <path d={svgPaths.p27826400} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[44.22%_7.34%_51.7%_82.59%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.7986 5.91948">
            <path d={svgPaths.p19514300} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[34.69%_35.53%_61.22%_54.41%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.7987 5.91947">
            <path d={svgPaths.p24443300} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute flex inset-[76.99%_0.04%_0.67%_0] items-center justify-center">
        <div className="flex-none h-[32.396px] scale-y-[-100%] w-[146.937px]">
          <div className="relative size-full" data-name="Vector">
            <div className="absolute inset-0" style={{ "--fill-0": "rgba(233, 242, 252, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 146.937 32.3956">
                <path d={svgPaths.p21a3fa00} fill="var(--fill-0, #E9F2FC)" id="Vector" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <ClipPathGroup9 />
    </div>
  );
}

function RentersIconSvgFill() {
  return (
    <div className="h-[144px] overflow-clip relative shrink-0 w-[147px]" data-name="renters-icon.svg fill">
      <Component30 />
    </div>
  );
}

function RentersIllustrationIcon() {
  return (
    <div className="flex-[1_0_0] h-[144px] min-h-px min-w-px relative rounded-[20px]" data-name="renters illustration icon">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <RentersIconSvgFill />
      </div>
    </div>
  );
}

function Container111() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[14px] text-center" role="link" tabIndex="0">
        <p className="css-ew64yg cursor-pointer leading-[14px]"></p>
      </div>
    </div>
  );
}

function Margin12() {
  return (
    <div className="content-stretch flex flex-col items-start pl-[8px] pr-0 py-0 relative shrink-0" data-name="Margin">
      <Container111 />
    </div>
  );
}

function Container112() {
  return (
    <div className="absolute left-[23.51%] right-[23.51%] top-[23px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative w-full">
        <div className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px] text-center" role="link" tabIndex="0">
          <p className="css-ew64yg cursor-pointer leading-[26px]">Renters</p>
        </div>
        <Margin12 />
      </div>
    </div>
  );
}

function Component31() {
  return (
    <a className="bg-white h-[146px] relative rounded-[20px] shrink-0 w-[149px]" data-name="Component 11" href="https://www.plymouthrock.com/insurance/renters">
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">
        <RentersIllustrationIcon />
        <Container112 />
      </div>
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]" />
    </a>
  );
}

function Group11() {
  return (
    <div className="absolute inset-[50.34%_73.6%_23.81%_10.61%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[23.51px_37.224px]" data-name="Group" style={{ maskImage: `url('${imgGroup8}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.5109 37.2245">
        <g id="Group">
          <path d={svgPaths.p37abd80} fill="var(--fill-0, #CCF5C6)" id="Vector" />
          <path d={svgPaths.p25d32300} fill="var(--fill-0, #A5E1D7)" id="Vector_2" />
          <path d={svgPaths.p35939080} fill="var(--fill-0, #A5E1D7)" id="Vector_3" />
          <path d={svgPaths.p6b6b270} fill="var(--fill-0, #0078D6)" id="Vector_4" />
          <path d={svgPaths.p1c0fdf00} fill="var(--fill-0, #0078D6)" id="Vector_5" />
          <path d={svgPaths.p2d00e680} fill="var(--fill-0, #0078D6)" id="Vector_6" />
          <path d={svgPaths.p37dcb590} fill="var(--fill-0, #0078D6)" id="Vector_7" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup10() {
  return (
    <div className="absolute contents inset-[50.34%_73.6%_23.81%_10.61%]" data-name="Clip path group">
      <Group11 />
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute inset-[61.22%_9.94%_22.45%_75.77%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-19.635px_-0.001px] mask-size-[54.857px_23.51px]" data-name="Group" style={{ maskImage: `url('${imgGroup9}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.2697 23.5095">
        <g id="Group">
          <path d={svgPaths.p2c16ea00} fill="var(--fill-0, #A5E1D7)" id="Vector" />
          <path d={svgPaths.p353f0200} fill="var(--fill-0, #0078D6)" id="Vector_2" />
          <path d={svgPaths.p293b57c0} fill="var(--fill-0, #0078D6)" id="Vector_3" />
          <path d={svgPaths.pe8f2c00} fill="var(--fill-0, #0078D6)" id="Vector_4" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup11() {
  return (
    <div className="absolute contents inset-[61.22%_0.57%_22.45%_62.58%]" data-name="Clip path group">
      <Group12 />
    </div>
  );
}

function Group13() {
  return (
    <div className="absolute inset-[51.7%_22.38%_12.93%_19.74%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-0.981px_-0.974px] mask-size-[88.163px_52.898px]" data-name="Group" style={{ maskImage: `url('${imgGroup10}')` }}>
      <div className="absolute inset-[-1.44%_-0.85%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 87.6535 52.4008">
          <g id="Group">
            <path d={svgPaths.p1ee8fd00} fill="var(--fill-0, #BADBFF)" id="Vector" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path d={svgPaths.p15d76500} fill="var(--fill-0, #BADBFF)" id="Vector_2" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path d={svgPaths.p152e2e00} id="Vector_3" stroke="var(--stroke-0, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path d={svgPaths.p1ee93780} fill="var(--fill-0, #0351AA)" id="Vector_4" />
            <path clipRule="evenodd" d={svgPaths.p2b23ec00} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector_5" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path clipRule="evenodd" d={svgPaths.p1e7fdbf0} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector_6" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path clipRule="evenodd" d={svgPaths.p1c054800} fillRule="evenodd" id="Vector_7" stroke="var(--stroke-0, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path clipRule="evenodd" d={svgPaths.p342de700} fillRule="evenodd" id="Vector_8" stroke="var(--stroke-0, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path clipRule="evenodd" d={svgPaths.p2e0e3900} fill="var(--fill-0, #D3E5F9)" fillRule="evenodd" id="Vector_9" />
            <path d={svgPaths.p2e0e3900} id="Vector_10" stroke="var(--stroke-0, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path clipRule="evenodd" d={svgPaths.p8d29380} fill="var(--fill-0, #D3E5F9)" fillRule="evenodd" id="Vector_11" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path d={svgPaths.p38252100} fill="var(--fill-0, #D3E5F9)" id="Vector_12" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
            <path d={svgPaths.p25a6a500} fill="var(--fill-0, white)" id="Vector_13" stroke="var(--stroke-2, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function ClipPathGroup12() {
  return (
    <div className="absolute contents inset-[51.02%_21.71%_12.24%_19.08%]" data-name="Clip path group">
      <Group13 />
    </div>
  );
}

function Component32() {
  return (
    <div className="h-[144px] overflow-clip relative shrink-0 w-[148.898px]" data-name="Component 1">
      <div className="absolute inset-[38.1%_68.34%_55.1%_15.22%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.4898 9.79594">
            <path d={svgPaths.p1010c700} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[42.18%_19%_53.74%_69.82%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.6531 5.87756">
            <path d={svgPaths.p60c4b80} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <ClipPathGroup10 />
      <ClipPathGroup11 />
      <div className="absolute flex inset-[76.87%_2.63%_1.36%_0.66%] items-center justify-center">
        <div className="flex-none h-[31.347px] scale-y-[-100%] w-[144px]">
          <div className="relative size-full" data-name="Vector">
            <div className="absolute inset-0" style={{ "--fill-0": "rgba(233, 242, 252, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 144 31.3469">
                <path d="M144 0H0V31.3469H144V0Z" fill="var(--fill-0, #E9F2FC)" id="Vector" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <ClipPathGroup12 />
    </div>
  );
}

function MotorcycleIconSvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[144px] items-center justify-center overflow-clip relative shrink-0 w-[147px]" data-name="motorcycle-icon.svg fill">
      <Component32 />
    </div>
  );
}

function MotorcycleIllustrationIcon() {
  return (
    <div className="flex-[1_0_0] h-[144px] min-h-px min-w-px relative rounded-[20px]" data-name="motorcycle illustration icon">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <MotorcycleIconSvgFill />
      </div>
    </div>
  );
}

function Container113() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[14px] text-center" role="link" tabIndex="0">
        <p className="css-ew64yg cursor-pointer leading-[14px]"></p>
      </div>
    </div>
  );
}

function Margin13() {
  return (
    <div className="content-stretch flex flex-col items-start pl-[8px] pr-0 py-0 relative shrink-0" data-name="Margin">
      <Container113 />
    </div>
  );
}

function Container114() {
  return (
    <div className="absolute left-[15.04%] right-[15.03%] top-[23px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative w-full">
        <div className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px] text-center" role="link" tabIndex="0">
          <p className="css-ew64yg cursor-pointer leading-[26px]">Motorcycle</p>
        </div>
        <Margin13 />
      </div>
    </div>
  );
}

function Component33() {
  return (
    <a className="bg-white h-[146px] relative rounded-[20px] shrink-0 w-[149px]" data-name="Component 11" href="https://www.plymouthrock.com/insurance/motorcycle">
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">
        <MotorcycleIllustrationIcon />
        <Container114 />
      </div>
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]" />
    </a>
  );
}

function Group14() {
  return (
    <div className="absolute inset-[51.02%_73.56%_23.13%_10.65%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[23.51px_37.224px]" data-name="Group" style={{ maskImage: `url('${imgGroup8}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.5103 37.2245">
        <g id="Group">
          <path d={svgPaths.p2899ea00} fill="var(--fill-0, #CCF5C6)" id="Vector" />
          <path d={svgPaths.padd0b80} fill="var(--fill-0, #A5E1D7)" id="Vector_2" />
          <path d={svgPaths.p1351ad70} fill="var(--fill-0, #A5E1D7)" id="Vector_3" />
          <path d={svgPaths.p6bcce00} fill="var(--fill-0, #0078D6)" id="Vector_4" />
          <path d={svgPaths.p10391a00} fill="var(--fill-0, #0078D6)" id="Vector_5" />
          <path d={svgPaths.p3da17700} fill="var(--fill-0, #0078D6)" id="Vector_6" />
          <path d={svgPaths.p6dffb80} fill="var(--fill-0, #0078D6)" id="Vector_7" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup13() {
  return (
    <div className="absolute contents inset-[51.02%_73.56%_23.13%_10.65%]" data-name="Clip path group">
      <Group14 />
    </div>
  );
}

function Component34() {
  return (
    <div className="h-[144px] overflow-clip relative shrink-0 w-[148.898px]" data-name="Component 1">
      <div className="absolute inset-[38.1%_68.3%_55.1%_15.26%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.4898 9.79594">
            <path d={svgPaths.p1010c700} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[42.18%_18.95%_53.74%_69.86%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.6531 5.87756">
            <path d={svgPaths.p358ba100} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <ClipPathGroup13 />
      <div className="absolute inset-[61.22%_9.9%_22.45%_75.81%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(165, 225, 215, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.2691 23.5097">
            <path d={svgPaths.p25655940} fill="var(--fill-0, #A5E1D7)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[63.55%_16.53%_22.51%_82.43%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(0, 120, 214, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.55373 20.075">
            <path d={svgPaths.p80ae580} fill="var(--fill-0, #0078D6)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[69.94%_15.38%_22.47%_83.88%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(0, 120, 214, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1.09001 10.9301">
            <path d={svgPaths.p1f528e00} fill="var(--fill-0, #0078D6)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[66.01%_17.56%_22.51%_80.48%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(0, 120, 214, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 2.91414 16.5359">
            <path d={svgPaths.p3012a400} fill="var(--fill-0, #0078D6)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[46.94%_29.93%_39.46%_32.24%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(255, 255, 255, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 56.3265 19.5918">
            <path d={svgPaths.p349ebc00} fill="var(--fill-0, white)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute flex inset-[76.87%_2.63%_1.36%_0.66%] items-center justify-center">
        <div className="flex-none h-[31.347px] scale-y-[-100%] w-[144px]">
          <div className="relative size-full" data-name="Vector">
            <div className="absolute inset-0" style={{ "--fill-0": "rgba(233, 242, 252, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 144 31.3469">
                <path d="M144 0H0V31.3469H144V0Z" fill="var(--fill-0, #E9F2FC)" id="Vector" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute inset-[82.99%_42.06%_13.61%_44.78%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(186, 219, 255, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19.5918 4.89796">
            <path d={svgPaths.p3d7bbb80} fill="var(--fill-0, #BADBFF)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[45.06%_30.21%_15.69%_32.14%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(186, 219, 255, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 56.0603 56.5193">
            <path d={svgPaths.p38aecb00} fill="var(--fill-0, #BADBFF)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[45.06%_30.21%_15.69%_32.14%]" data-name="Vector">
        <div className="absolute inset-[-1.3%_-1.31%]" style={{ "--stroke-0": "rgba(3, 81, 170, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 57.5305 57.9894">
            <path d={svgPaths.p1a2a2900} id="Vector" stroke="var(--stroke-0, #0351AA)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.47" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function UmbrellaIcon21SvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[144px] items-center justify-center overflow-clip relative shrink-0 w-[147px]" data-name="umbrella-icon2-1.svg fill">
      <Component34 />
    </div>
  );
}

function UmbrellaIllustrationIcon() {
  return (
    <div className="flex-[1_0_0] h-[144px] min-h-px min-w-px relative rounded-[20px]" data-name="umbrella illustration icon">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <UmbrellaIcon21SvgFill />
      </div>
    </div>
  );
}

function Container115() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[14px] text-center" role="link" tabIndex="0">
        <p className="css-ew64yg cursor-pointer leading-[14px]"></p>
      </div>
    </div>
  );
}

function Margin14() {
  return (
    <div className="content-stretch flex flex-col items-start pl-[8px] pr-0 py-0 relative shrink-0" data-name="Margin">
      <Container115 />
    </div>
  );
}

function Container116() {
  return (
    <div className="absolute left-[19.68%] right-[19.68%] top-[23px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative w-full">
        <div className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px] text-center" role="link" tabIndex="0">
          <p className="css-ew64yg cursor-pointer leading-[26px]">Umbrella</p>
        </div>
        <Margin14 />
      </div>
    </div>
  );
}

function Component35() {
  return (
    <a className="bg-white h-[146px] relative rounded-[20px] shrink-0 w-[149px]" data-name="Component 11" href="https://www.plymouthrock.com/insurance/umbrella">
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">
        <UmbrellaIllustrationIcon />
        <Container116 />
      </div>
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]" />
    </a>
  );
}

function Group15() {
  return (
    <div className="absolute inset-[50.8%_67.04%_23.81%_4.83%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_-5.606px] mask-size-[49.329px_42.423px]" data-name="Group" style={{ maskImage: `url('${imgGroup11}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 41.3506 36.817">
        <g id="Group">
          <path d={svgPaths.p4e96c00} fill="var(--fill-0, #A5E1D7)" id="Vector" />
          <path d={svgPaths.p3ccef3b0} fill="var(--fill-0, #CCF5C6)" id="Vector_2" />
          <path d={svgPaths.p3a08a380} fill="var(--fill-0, #CCF5C6)" id="Vector_3" />
          <path d={svgPaths.p159ef900} fill="var(--fill-0, #A5E1D7)" id="Vector_4" />
          <path d={svgPaths.p36ea2700} fill="var(--fill-0, #0078D6)" id="Vector_5" />
          <path d={svgPaths.pc308f00} fill="var(--fill-0, #0078D6)" id="Vector_6" />
          <path d={svgPaths.p17e3a8c0} fill="var(--fill-0, #0078D6)" id="Vector_7" />
          <path d={svgPaths.p1017cf50} fill="var(--fill-0, #0078D6)" id="Vector_8" />
          <path d={svgPaths.ped7fe80} fill="var(--fill-0, #0078D6)" id="Vector_9" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup14() {
  return (
    <div className="absolute contents inset-[46.94%_61.62%_23.81%_4.83%]" data-name="Clip path group">
      <Group15 />
    </div>
  );
}

function Group16() {
  return (
    <div className="absolute inset-[42.86%_22.99%_13.6%_26.68%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[-0.002px_0.002px] mask-size-[73.993px_63.141px]" data-name="Group" style={{ maskImage: `url('${imgGroup12}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 73.9916 63.1437">
        <g id="Group">
          <path d={svgPaths.p231d1500} fill="var(--fill-0, #0351AA)" id="Vector" />
          <path d={svgPaths.p18149500} fill="var(--fill-0, #E9F2FC)" id="Vector_2" />
          <path d={svgPaths.p12986b00} fill="var(--fill-0, #BADBFF)" id="Vector_3" />
          <path d={svgPaths.p2b58d900} fill="var(--fill-0, #E9F2FC)" id="Vector_4" />
          <path d={svgPaths.p21a986f0} fill="var(--fill-0, #D3E3F6)" id="Vector_5" />
          <path d={svgPaths.p8a5a880} fill="var(--fill-0, #E9F2FC)" id="Vector_6" />
          <path d={svgPaths.p8722800} fill="var(--fill-0, #E9F2FC)" id="Vector_7" />
          <path d={svgPaths.p3fc1a00} fill="var(--fill-0, #E9F2FC)" id="Vector_8" />
          <path d={svgPaths.p2ce68f00} fill="var(--fill-0, #E9F2FC)" id="Vector_9" />
          <path d={svgPaths.p695d280} fill="var(--fill-0, #0351AA)" id="Vector_10" />
          <path d={svgPaths.p283e7ec0} fill="var(--fill-0, #0351AA)" id="Vector_11" />
          <path d={svgPaths.p21223780} fill="var(--fill-0, #0351AA)" id="Vector_12" />
          <path d={svgPaths.p15bffc40} fill="var(--fill-0, #0351AA)" id="Vector_13" />
          <path d={svgPaths.p1c13b980} fill="var(--fill-0, #0351AA)" id="Vector_14" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup15() {
  return (
    <div className="absolute contents inset-[42.86%_22.99%_13.61%_26.68%]" data-name="Clip path group">
      <Group16 />
    </div>
  );
}

function Component36() {
  return (
    <div className="absolute h-[145.027px] left-1/2 overflow-clip top-1/2 translate-x-[-50%] translate-y-[-50%] w-[147px]" data-name="Component 1">
      <ClipPathGroup14 />
      <div className="absolute flex inset-[76.99%_0.04%_0.67%_0] items-center justify-center">
        <div className="flex-none h-[32.396px] scale-y-[-100%] w-[146.937px]">
          <div className="relative size-full" data-name="Vector">
            <div className="absolute inset-0" style={{ "--fill-0": "rgba(233, 242, 252, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 146.937 32.3956">
                <path d={svgPaths.p21a3fa00} fill="var(--fill-0, #E9F2FC)" id="Vector" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute inset-[30.61%_7.3%_63.27%_75.92%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24.6644 8.8792">
            <path d={svgPaths.p3cd76280} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[36.05%_46.22%_59.86%_42.37%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.7718 5.91947">
            <path d={svgPaths.p39308540} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="absolute inset-[38.78%_75.75%_55.1%_6.13%]" data-name="Vector">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(225, 245, 254, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 26.6375 8.8792">
            <path d={svgPaths.p2e232060} fill="var(--fill-0, #E1F5FE)" id="Vector" />
          </svg>
        </div>
      </div>
      <ClipPathGroup15 />
    </div>
  );
}

function PetsIconSvgFill() {
  return (
    <div className="h-[144px] overflow-clip relative shrink-0 w-[147px]" data-name="pets-icon.svg fill">
      <Component36 />
    </div>
  );
}

function PetIllustrationIcon() {
  return (
    <div className="flex-[1_0_0] h-[144px] min-h-px min-w-px relative rounded-[20px]" data-name="pet illustration icon">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <PetsIconSvgFill />
      </div>
    </div>
  );
}

function Container117() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[14px] text-center" role="link" tabIndex="0">
        <p className="css-ew64yg cursor-pointer leading-[14px]"></p>
      </div>
    </div>
  );
}

function Margin15() {
  return (
    <div className="content-stretch flex flex-col items-start pl-[8px] pr-0 py-0 relative shrink-0" data-name="Margin">
      <Container117 />
    </div>
  );
}

function Container118() {
  return (
    <div className="absolute left-[34.87%] right-[34.86%] top-[23px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center relative w-full">
        <div className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[16px] text-center" role="link" tabIndex="0">
          <p className="css-ew64yg cursor-pointer leading-[26px]">Pet</p>
        </div>
        <Margin15 />
      </div>
    </div>
  );
}

function Component37() {
  return (
    <a className="bg-white h-[146px] relative rounded-[20px] shrink-0 w-[149px]" data-name="Component 11" href="https://www.plymouthrock.com/insurance/pets">
      <div className="content-stretch flex items-center justify-center overflow-clip p-px relative rounded-[inherit] size-full">
        <PetIllustrationIcon />
        <Container118 />
      </div>
      <div aria-hidden="true" className="absolute border border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]" />
    </a>
  );
}

function Container119() {
  return (
    <div className="content-center cursor-pointer flex flex-wrap gap-[0px_24px] items-center justify-center relative shrink-0 w-full" data-name="Container">
      <Component10 />
      <Component27 />
      <Component29 />
      <Component31 />
      <Component33 />
      <Component35 />
      <Component37 />
    </div>
  );
}

function Container120() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container119 />
    </div>
  );
}

function Margin16() {
  return (
    <div className="content-stretch flex flex-col h-[162px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container120 />
    </div>
  );
}

function Container121() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Margin8 />
      <Margin16 />
    </div>
  );
}

function Container122() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1280px] relative shrink-0 w-full" data-name="Container">
      <Container121 />
    </div>
  );
}

function Section15() {
  return (
    <div className="bg-[#0351aa] content-stretch flex flex-col items-start mb-[-1px] pb-[100px] pt-[75px] px-[310px] relative shrink-0 w-[1920px]" data-name="Section">
      <Container122 />
    </div>
  );
}

function Heading4() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Heading 2">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-black text-center">
        <p className="css-ew64yg leading-[18px]">Insurance by state</p>
      </div>
    </div>
  );
}

function Container123() {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0 w-[1100px]" data-name="Container">
      <Heading4 />
    </div>
  );
}

function Container124() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1140px] relative shrink-0 w-full" data-name="Container">
      <Container123 />
    </div>
  );
}

function Section16() {
  return (
    <div className="bg-[#eff6fd] content-stretch flex flex-col items-start mb-[-1px] pb-0 pt-[32px] px-[390px] relative shrink-0 w-[1920px]" data-name="Section">
      <Container124 />
    </div>
  );
}

function Container125() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[20px]">Connecticut</p>
      </div>
    </div>
  );
}

function Container126() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container125 />
    </div>
  );
}

function Margin17() {
  return (
    <div className="content-stretch flex flex-col h-[36px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container126 />
    </div>
  );
}

function Component38() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/auto/ct">
          Car Insurance
        </a>
      </div>
    </div>
  );
}

function Component39() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/home/ct">
          Home Insurance
        </a>
      </div>
    </div>
  );
}

function Container127() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Component38 />
      <Component39 />
    </div>
  );
}

function Container128() {
  return (
    <div className="content-stretch flex flex-col h-[56px] items-start relative shrink-0 w-full" data-name="Container">
      <Container127 />
    </div>
  );
}

function Container129() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-full items-start justify-center min-h-px min-w-px pb-[30px] pt-0 px-0 relative" data-name="Container">
      <Margin17 />
      <Container128 />
    </div>
  );
}

function Container130() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container129 />
    </div>
  );
}

function Container131() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[20px]">Massachusetts</p>
      </div>
    </div>
  );
}

function Container132() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container131 />
    </div>
  );
}

function Margin18() {
  return (
    <div className="content-stretch flex flex-col h-[36px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container132 />
    </div>
  );
}

function Component40() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/auto/ma">
          Car Insurance
        </a>
      </div>
    </div>
  );
}

function Component41() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/home/ma">
          Home Insurance
        </a>
      </div>
    </div>
  );
}

function Container133() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Component40 />
      <Component41 />
    </div>
  );
}

function Container134() {
  return (
    <div className="content-stretch flex flex-col h-[56px] items-start relative shrink-0 w-full" data-name="Container">
      <Container133 />
    </div>
  );
}

function Container135() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-full items-start justify-center min-h-px min-w-px pb-[30px] pt-0 px-0 relative" data-name="Container">
      <Margin18 />
      <Container134 />
    </div>
  );
}

function Container136() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container135 />
    </div>
  );
}

function Container137() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[20px]">New Hampshire</p>
      </div>
    </div>
  );
}

function Container138() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container137 />
    </div>
  );
}

function Margin19() {
  return (
    <div className="content-stretch flex flex-col h-[36px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container138 />
    </div>
  );
}

function Component42() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/auto/nh">
          Car Insurance
        </a>
      </div>
    </div>
  );
}

function Component43() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/home/nh">
          Home Insurance
        </a>
      </div>
    </div>
  );
}

function Container139() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Component42 />
      <Component43 />
    </div>
  );
}

function Container140() {
  return (
    <div className="content-stretch flex flex-col h-[56px] items-start relative shrink-0 w-full" data-name="Container">
      <Container139 />
    </div>
  );
}

function Container141() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-full items-start justify-center min-h-px min-w-px pb-[30px] pt-0 px-0 relative" data-name="Container">
      <Margin19 />
      <Container140 />
    </div>
  );
}

function Container142() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container141 />
    </div>
  );
}

function Container143() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[20px]">New Jersey</p>
      </div>
    </div>
  );
}

function Container144() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container143 />
    </div>
  );
}

function Margin20() {
  return (
    <div className="content-stretch flex flex-col h-[36px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container144 />
    </div>
  );
}

function Component44() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/auto/nj">
          Car Insurance
        </a>
      </div>
    </div>
  );
}

function Component45() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/home/nj">
          Home Insurance
        </a>
      </div>
    </div>
  );
}

function Container145() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Component44 />
      <Component45 />
    </div>
  );
}

function Container146() {
  return (
    <div className="content-stretch flex flex-col h-[56px] items-start relative shrink-0 w-full" data-name="Container">
      <Container145 />
    </div>
  );
}

function Container147() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-full items-start justify-center min-h-px min-w-px pb-[30px] pt-0 px-0 relative" data-name="Container">
      <Margin20 />
      <Container146 />
    </div>
  );
}

function Container148() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container147 />
    </div>
  );
}

function Container149() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[20px]">New York</p>
      </div>
    </div>
  );
}

function Container150() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container149 />
    </div>
  );
}

function Margin21() {
  return (
    <div className="content-stretch flex flex-col h-[36px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container150 />
    </div>
  );
}

function Component46() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/auto/ny">
          Car Insurance
        </a>
      </div>
    </div>
  );
}

function Component47() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/home/ny">
          Home Insurance
        </a>
      </div>
    </div>
  );
}

function Container151() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Component46 />
      <Component47 />
    </div>
  );
}

function Container152() {
  return (
    <div className="content-stretch flex flex-col h-[56px] items-start relative shrink-0 w-full" data-name="Container">
      <Container151 />
    </div>
  );
}

function Container153() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-full items-start justify-center min-h-px min-w-px pb-[30px] pt-0 px-0 relative" data-name="Container">
      <Margin21 />
      <Container152 />
    </div>
  );
}

function Container154() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container153 />
    </div>
  );
}

function Container155() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[20px]">Pennsylvania</p>
      </div>
    </div>
  );
}

function Container156() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container155 />
    </div>
  );
}

function Margin22() {
  return (
    <div className="content-stretch flex flex-col h-[36px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container156 />
    </div>
  );
}

function Component48() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/auto/pa">
          Car Insurance
        </a>
      </div>
    </div>
  );
}

function Component49() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px]">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[28px] text-[14px] underline" href="https://www.plymouthrock.com/insurance/home/pa">
          Home Insurance
        </a>
      </div>
    </div>
  );
}

function Container157() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <Component48 />
      <Component49 />
    </div>
  );
}

function Container158() {
  return (
    <div className="content-stretch flex flex-col h-[56px] items-start relative shrink-0 w-full" data-name="Container">
      <Container157 />
    </div>
  );
}

function Container159() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-full items-start justify-center min-h-px min-w-px pb-[30px] pt-0 px-0 relative" data-name="Container">
      <Margin22 />
      <Container158 />
    </div>
  );
}

function Container160() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container159 />
    </div>
  );
}

function Container161() {
  return (
    <div className="content-stretch flex items-start max-w-[816px] relative shrink-0 w-full" data-name="Container">
      <Container130 />
      <Container136 />
      <Container142 />
      <Container148 />
      <Container154 />
      <Container160 />
    </div>
  );
}

function Section17() {
  return (
    <div className="bg-[#eff6fd] content-stretch flex flex-col items-start mb-[-1px] pb-0 pt-[20px] px-[552px] relative shrink-0 w-[1920px]" data-name="Section">
      <Container161 />
      <div className="absolute bottom-0 h-[2px] left-[15px] right-[15px]" data-name="Horizontal Divider">
        <div aria-hidden="true" className="absolute border-[#d3e5f9] border-b-2 border-solid inset-0 pointer-events-none" />
      </div>
    </div>
  );
}

function Group17() {
  return (
    <div className="absolute inset-[0_0.01%_0_0] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[196px_57.638px]" data-name="Group" style={{ maskImage: `url('${imgGroup13}')` }}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 195.989 57.6379">
        <g id="Group">
          <path d={svgPaths.p2a8139e0} fill="var(--fill-0, #0351AA)" id="Vector" />
          <path d={svgPaths.pcb03200} fill="var(--fill-0, #0351AA)" id="Vector_2" />
          <path d={svgPaths.p17e2db00} fill="var(--fill-0, #0351AA)" id="Vector_3" />
          <path d={svgPaths.p3d48fa00} fill="var(--fill-0, #0351AA)" id="Vector_4" />
          <path d={svgPaths.pe463f80} fill="var(--fill-0, #0351AA)" id="Vector_5" />
          <path d={svgPaths.p323d58c0} fill="var(--fill-0, #0351AA)" id="Vector_6" />
          <path d={svgPaths.p27ea5f00} fill="var(--fill-0, #0351AA)" id="Vector_7" />
          <path d={svgPaths.p7033200} fill="var(--fill-0, #0351AA)" id="Vector_8" />
          <path d={svgPaths.p1b856300} fill="var(--fill-0, #0351AA)" id="Vector_9" />
          <path d={svgPaths.pb568270} fill="var(--fill-0, #0351AA)" id="Vector_10" />
          <path d={svgPaths.p23c9b800} fill="var(--fill-0, #0351AA)" id="Vector_11" />
          <path d={svgPaths.p4432f00} fill="var(--fill-0, #0351AA)" id="Vector_12" />
          <path d={svgPaths.pb1dd800} fill="var(--fill-0, #0351AA)" id="Vector_13" />
          <path d={svgPaths.p2e4c9100} fill="var(--fill-0, #0351AA)" id="Vector_14" />
          <path d={svgPaths.p2bfa400} fill="var(--fill-0, #0351AA)" id="Vector_15" />
          <path d={svgPaths.p73e3c00} fill="var(--fill-0, #0351AA)" id="Vector_16" />
          <path d={svgPaths.p1f8d900} fill="var(--fill-0, #0351AA)" id="Vector_17" />
          <path d={svgPaths.p3b691280} fill="var(--fill-0, #0351AA)" id="Vector_18" />
          <path d={svgPaths.p26739c80} fill="var(--fill-0, #0351AA)" id="Vector_19" />
          <path d={svgPaths.p1fd96100} fill="var(--fill-0, #0351AA)" id="Vector_20" />
          <path d={svgPaths.p1f938400} fill="var(--fill-0, #0351AA)" id="Vector_21" />
          <path d={svgPaths.p22b13400} fill="var(--fill-0, #0351AA)" id="Vector_22" />
          <path d={svgPaths.p1a022500} fill="var(--fill-0, #0351AA)" id="Vector_23" />
          <path d={svgPaths.p263f7300} fill="var(--fill-0, #0351AA)" id="Vector_24" />
          <path d={svgPaths.p3cad3a00} fill="var(--fill-0, #0351AA)" id="Vector_25" />
          <path d={svgPaths.p22029d80} fill="var(--fill-0, #0351AA)" id="Vector_26" />
          <path d={svgPaths.p22115080} fill="var(--fill-0, #0351AA)" id="Vector_27" />
          <path d={svgPaths.p1fd2b100} fill="var(--fill-0, #0351AA)" id="Vector_28" />
          <path d={svgPaths.p35585200} fill="var(--fill-0, #0351AA)" id="Vector_29" />
          <path d={svgPaths.pa809b80} fill="var(--fill-0, #0351AA)" id="Vector_30" />
          <path d={svgPaths.p2f95e680} fill="var(--fill-0, #0351AA)" id="Vector_31" />
          <path d={svgPaths.p15023680} fill="var(--fill-0, #0351AA)" id="Vector_32" />
          <path d={svgPaths.p1e889e00} fill="var(--fill-0, #0351AA)" id="Vector_33" />
          <path d={svgPaths.p34a41600} fill="var(--fill-0, #0351AA)" id="Vector_34" />
          <path d={svgPaths.p54ba180} fill="var(--fill-0, #0351AA)" id="Vector_35" />
          <path d={svgPaths.p36531730} fill="var(--fill-0, #0351AA)" id="Vector_36" />
          <path d={svgPaths.p546acf0} fill="var(--fill-0, #0351AA)" id="Vector_37" />
          <path d={svgPaths.p1fdf8e00} fill="var(--fill-0, #0351AA)" id="Vector_38" />
          <path d={svgPaths.p56e7c00} fill="var(--fill-0, #0351AA)" id="Vector_39" />
          <path d={svgPaths.p6dd4f00} fill="var(--fill-0, #0351AA)" id="Vector_40" />
          <path d={svgPaths.p25887000} fill="var(--fill-0, #0351AA)" id="Vector_41" />
          <path d={svgPaths.pd1a1900} fill="var(--fill-0, #0351AA)" id="Vector_42" />
          <path d={svgPaths.p2d44b200} fill="var(--fill-0, #0351AA)" id="Vector_43" />
          <path d={svgPaths.p8ca2700} fill="var(--fill-0, #0351AA)" id="Vector_44" />
          <path d={svgPaths.p2a147800} fill="var(--fill-0, #0351AA)" id="Vector_45" />
        </g>
      </svg>
    </div>
  );
}

function ClipPathGroup16() {
  return (
    <div className="absolute contents inset-0" data-name="Clip path group">
      <Group17 />
    </div>
  );
}

function Component50() {
  return (
    <div className="h-[57.638px] overflow-clip relative shrink-0 w-[196px]" data-name="Component 1">
      <ClipPathGroup16 />
    </div>
  );
}

function LogoTaglineContrastblueSvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[58px] items-center justify-center overflow-clip px-0 py-[0.181px] relative shrink-0 w-[196px]" data-name="logo_tagline_contrastblue.svg fill">
      <Component50 />
    </div>
  );
}

function PlymouthRockLogoWithMoreThanJustInsuranceTagline() {
  return (
    <div className="content-stretch flex h-[58px] items-start max-w-[196px] overflow-clip relative shrink-0 w-[196px]" data-name="Plymouth Rock logo with More than just insurance tagline">
      <LogoTaglineContrastblueSvgFill />
    </div>
  );
}

function Container162() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <PlymouthRockLogoWithMoreThanJustInsuranceTagline />
    </div>
  );
}

function Container163() {
  return (
    <div className="content-stretch flex flex-col items-start pb-0 pt-[40px] px-0 relative self-stretch shrink-0 w-[1220px]" data-name="Container">
      <Container162 />
    </div>
  );
}

function Container164() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1240px] px-0 py-[10px] relative shrink-0 w-full" data-name="Container">
      <Container163 />
    </div>
  );
}

function Section18() {
  return (
    <div className="h-[118px] relative shrink-0 w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[330px] py-0 relative size-full">
        <Container164 />
      </div>
    </div>
  );
}

function Component3() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-center relative shrink-0" data-name="Component 4">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px] text-center">
        <p className="css-ew64yg decoration-solid leading-[20px] text-[14px] underline">Home</p>
      </div>
    </div>
  );
}

function Component51() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-center relative shrink-0" data-name="Component 4">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px] text-center">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[20px] text-[14px] underline" href="https://www.plymouthrock.com/contact">
          Contact Us
        </a>
      </div>
    </div>
  );
}

function Component52() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-center relative shrink-0" data-name="Component 4">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px] text-center">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[20px] text-[14px] underline" href="https://www.plymouthrock.com/privacy-policy">{`Privacy & Security`}</a>
      </div>
    </div>
  );
}

function Component53() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-center relative shrink-0" data-name="Component 4">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px] text-center">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[20px] text-[14px] underline" href="https://www.plymouthrock.com/internet-policy">{`Terms & Conditions`}</a>
      </div>
    </div>
  );
}

function Component54() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-center relative shrink-0" data-name="Component 4">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px] text-center">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[20px] text-[14px] underline" href="https://www.plymouthrock.com/states-licensed-disclaimers">{`States Licensed & Disclaimers`}</a>
      </div>
    </div>
  );
}

function Component55() {
  return (
    <div className="content-stretch flex flex-col h-[20px] items-center relative shrink-0" data-name="Component 4">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0351aa] text-[0px] text-center">
        <a className="block css-ew64yg cursor-pointer decoration-solid leading-[20px] text-[14px] underline" href="https://www.plymouthrock.com/sitemap">
          Site Map
        </a>
      </div>
    </div>
  );
}

function Container165() {
  return (
    <div className="content-start flex flex-wrap gap-[0px_15px] items-start justify-center relative shrink-0 w-full" data-name="Container">
      <Component3 />
      <Component51 />
      <Component52 />
      <Component53 />
      <Component54 />
      <Component55 />
    </div>
  );
}

function Container166() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Container">
      <Container165 />
    </div>
  );
}

function Container167() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative self-stretch" data-name="Container">
      <div className="flex flex-row items-end justify-center size-full">
        <div className="content-end flex flex-wrap items-end justify-center pb-0 pt-[10px] px-[15px] relative size-full">
          <Container166 />
        </div>
      </div>
    </div>
  );
}

function Container168() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1155px] relative shrink-0 w-full" data-name="Container">
      <Container167 />
    </div>
  );
}

function Section19() {
  return (
    <div className="h-[90px] relative shrink-0 w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start pb-[50px] pt-[10px] px-[372.5px] relative size-full">
        <Container168 />
      </div>
    </div>
  );
}

function Container169() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Section18 />
      <Section19 />
    </div>
  );
}

function Container170() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0 w-full" data-name="Container">
      <Container169 />
    </div>
  );
}

function Footer() {
  return (
    <div className="bg-[#eff6fd] content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Footer">
      <Container170 />
    </div>
  );
}

function Component56() {
  return (
    <div className="h-[19.95px] relative shrink-0 w-[19px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 19.95">
        <g clipPath="url(#clip0_1_5030)" id="Component 1">
          <path d={svgPaths.p318b4380} fill="var(--fill-0, white)" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_1_5030">
            <rect fill="white" height="19.95" width="19" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function FooterMobileSvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[19.94px] items-center justify-center overflow-clip relative shrink-0 w-[19px]" data-name="footer-mobile.svg fill">
      <Component56 />
    </div>
  );
}

function PhoneIcon() {
  return (
    <div className="aspect-[19/19.940000534057617] content-stretch flex flex-col items-start max-w-[615px] overflow-clip relative shrink-0" data-name="Phone Icon">
      <FooterMobileSvgFill />
    </div>
  );
}

function Component57() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Component 10">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-white">
        <p className="css-ew64yg decoration-solid leading-[32px] underline">800-516-9242</p>
      </div>
    </div>
  );
}

function Strong() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Strong">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[18px] text-white">
        <p className="css-ew64yg leading-[32px]">{`Call for a quote `}</p>
      </div>
      <Component57 />
    </div>
  );
}

function Container171() {
  return (
    <div className="content-stretch flex gap-[10px] items-center relative shrink-0 w-full" data-name="Container">
      <PhoneIcon />
      <Strong />
    </div>
  );
}

function Container172() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Container">
      <Container171 />
    </div>
  );
}

function Container173() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-center flex flex-wrap items-center justify-center pl-[20px] pr-0 py-0 relative size-full">
          <Container172 />
        </div>
      </div>
    </div>
  );
}

function Container174() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container173 />
    </div>
  );
}

function Component58() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Component 1">
          <path d={svgPaths.p179e6280} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Component11() {
  return (
    <a className="content-stretch flex items-center justify-center p-0 relative rounded-[5px] shrink-0 w-[18px]" data-name="Component 12" href="https://www.facebook.com/PlymouthRockAssurance">
      <Component58 />
    </a>
  );
}

function Component59() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Component 1">
          <path d={svgPaths.p30681400} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Component60() {
  return (
    <a className="content-stretch flex items-center justify-center p-0 relative rounded-[5px] shrink-0 w-[18px]" data-name="Component 12" href="https://twitter.com/plymouthrock">
      <Component59 />
    </a>
  );
}

function Component61() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Component 1">
          <path d={svgPaths.p15f11900} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Component62() {
  return (
    <a className="content-stretch flex items-center justify-center p-0 relative rounded-[5px] shrink-0 w-[18px]" data-name="Component 12" href="https://www.instagram.com/plymouthrockassurance">
      <Component61 />
    </a>
  );
}

function Component63() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 18">
        <g id="Component 1">
          <path d={svgPaths.p24287c00} fill="var(--fill-0, white)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Component64() {
  return (
    <a className="content-stretch flex items-center justify-center p-0 relative rounded-[5px] shrink-0 w-[18px]" data-name="Component 12" href="https://www.linkedin.com/company/plymouth-rock-assurance">
      <Component63 />
    </a>
  );
}

function List1() {
  return (
    <div className="content-stretch cursor-pointer flex gap-[24px] items-start justify-end relative shrink-0 w-full" data-name="List">
      <Component11 />
      <Component60 />
      <Component62 />
      <Component64 />
    </div>
  );
}

function Container175() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Container">
      <List1 />
    </div>
  );
}

function Container176() {
  return (
    <div className="flex-[1_0_0] h-full min-h-px min-w-px relative" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-center flex flex-wrap items-center justify-center pl-0 pr-[20px] py-0 relative size-full">
          <Container175 />
        </div>
      </div>
    </div>
  );
}

function Container177() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container176 />
    </div>
  );
}

function Container178() {
  return (
    <div className="content-stretch flex items-start max-w-[1270px] relative shrink-0 w-full" data-name="Container">
      <Container174 />
      <Container177 />
    </div>
  );
}

function Section20() {
  return (
    <div className="bg-[#0078d6] relative shrink-0 w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start pb-[11px] pt-[13px] px-[315px] relative w-full">
        <Container178 />
      </div>
    </div>
  );
}

function Component12() {
  return (
    <div className="absolute content-stretch flex items-start left-[587.48px] top-[18px]" data-name="Component 13">
      <a className="css-g0mm18 flex flex-col font-['Open_Sans_Hebrew_Condensed:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-white" href="https://www.plymouthrock.com/states-licensed-disclaimers">
        <p className="css-ew64yg cursor-pointer decoration-solid leading-[18px] underline">{`states licensed & disclaimers page`}</p>
      </a>
    </div>
  );
}

function Container179() {
  return (
    <div className="h-[90px] relative shrink-0 w-full" data-name="Container">
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-0 not-italic text-[12px] text-white top-[8.5px] translate-y-[-50%] w-[98.081px]">
        <p className="css-4hzbpn leading-[18px]">Plymouth Rock Assurance</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-[97.73px] not-italic text-[9px] text-white top-[5px] translate-y-[-50%] w-[7.862px]">
        <p className="css-4hzbpn leading-[18px]">®</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-[105.23px] not-italic text-[12px] text-white top-[8.5px] translate-y-[-50%] w-[76.427px]">
        <p className="css-4hzbpn leading-[18px]">{` and Plymouth Rock`}</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-[181.34px] not-italic text-[9px] text-white top-[5px] translate-y-[-50%] w-[7.862px]">
        <p className="css-4hzbpn leading-[18px]">®</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-[188.84px] not-italic text-[12px] text-white top-[8.5px] translate-y-[-50%] w-[1043.926px]">
        <p className="css-4hzbpn leading-[18px]">{` are brand names and service marks used by separate underwriting, managed insurance, and management companies that offer property and casualty insurance in multiple states pursuant to licensing agreements. Each underwriting and managed insurance company is a`}</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-0 not-italic text-[12px] text-white top-[26.5px] translate-y-[-50%] w-[587.795px]">
        <p className="css-4hzbpn leading-[18px]">{`separate legal entity that is financially responsible only for its own insurance products. A full list of underwriting companies by state can be found on our `}</p>
      </div>
      <Component12 />
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-[727.36px] not-italic text-[12px] text-white top-[26.5px] translate-y-[-50%] w-[508.046px]">
        <p className="css-4hzbpn leading-[18px]">. Actual coverage is subject to the language of the policy as issued. Some discounts, coverages, payment plans, features and benefits</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-0 not-italic text-[0px] text-white top-[44.5px] translate-y-[-50%] w-[887.359px]">
        <p className="css-4hzbpn text-[12px]">
          <span className="leading-[18px]">{`are not available in all states and companies, and premiums may vary by purchase method. PA Residents: `}</span>
          <span className="leading-[18px] uppercase">we reserve the right to refuse to quote any individual a premium rate for the insurance advertised herein</span>
          <span className="leading-[18px]">.</span>
        </p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-0 not-italic text-[9px] text-white top-[59px] translate-y-[-50%] w-[3.941px]">
        <p className="css-4hzbpn leading-[18px]">1</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-[3.61px] not-italic text-[12px] text-white top-[62.5px] translate-y-[-50%] w-[315.683px]">
        <p className="css-4hzbpn leading-[18px]">{` Available to customers who have purchased comprehensive or collision coverage.`}</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-0 not-italic text-[9px] text-white top-[77px] translate-y-[-50%] w-[3.941px]">
        <p className="css-4hzbpn leading-[18px]">2</p>
      </div>
      <div className="absolute flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] h-[18px] justify-center leading-[0] left-[3.61px] not-italic text-[12px] text-white top-[80.5px] translate-y-[-50%] w-[1188.589px]">
        <p className="css-4hzbpn leading-[18px]">{` Personal auto insurance policyholders may be reimbursed up to $50 of taxi fees once per year for a one-way ride if they find themselves in a situation where it ould be unsafe to operate their vehicle (not applicable to mechanical breakdown). Original receipt must be submitted with the reimbursement form.`}</p>
      </div>
    </div>
  );
}

function Container180() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Container179 />
    </div>
  );
}

function Margin23() {
  return (
    <div className="content-stretch flex flex-col h-[106px] items-start justify-center mb-[-5px] pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container180 />
    </div>
  );
}

function Container181() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans_Hebrew_Condensed:Light',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-white w-full">
        <p className="css-4hzbpn leading-[18px]">© 2026 Plymouth Rock Assurance. All Rights Reserved.</p>
      </div>
    </div>
  );
}

function Container182() {
  return (
    <div className="content-stretch flex flex-col h-[18px] items-start mb-[-5px] relative shrink-0 w-full" data-name="Container">
      <Container181 />
    </div>
  );
}

function Container183() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative self-stretch" data-name="Container">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pb-[40px] pt-[35px] px-[10px] relative size-full">
          <Margin23 />
          <Container182 />
        </div>
      </div>
    </div>
  );
}

function Container184() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1260px] relative shrink-0 w-full" data-name="Container">
      <Container183 />
    </div>
  );
}

function Section21() {
  return (
    <div className="bg-[#0351aa] relative shrink-0 w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[320px] py-0 relative w-full">
        <Container184 />
      </div>
    </div>
  );
}

function Footer1() {
  return (
    <div className="content-stretch flex flex-col items-start mb-[-1px] pb-0 pt-px px-0 relative shrink-0 w-full" data-name="Footer">
      <Footer />
      <Section20 />
      <Section21 />
    </div>
  );
}

function PlymouthRockSite() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[2722px] items-center left-0 max-w-[1920px] min-w-[1920px] pb-px pt-0 px-0 right-0 top-0" data-name="PlymouthRock-site">
      <Section />
      <Section4 />
      <Section5 />
      <Section6 />
      <Section7 />
      <Section14 />
      <Section15 />
      <Section16 />
      <Section17 />
      <Footer1 />
    </div>
  );
}

export default function PrSite() {
  return (
    <div className="relative size-full" data-name="PR-site 3">
      <PlymouthRockSite />
    </div>
  );
}