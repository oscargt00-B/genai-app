import svgPaths from "./svg-80ndgpt766";

function Frame2() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-full">
      <p className="flex-[1_0_0] font-['Open_Sans:Regular',sans-serif] leading-[0] min-h-px min-w-px not-italic relative text-[0px] text-[16px] text-black">
        <span className="leading-[26px]">Thank you, I got a quote for you from</span>
        <span className="font-['Open_Sans:Bold',sans-serif] leading-[26px]">{` Plymouth Rock Assurance`}</span>
      </p>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex flex-col font-['Manrope:Regular',sans-serif] gap-[8px] items-center not-italic relative shrink-0 text-[#0078d6] text-center">
      <p className="leading-[42px] relative shrink-0 text-[32px] whitespace-nowrap">Hi Joe, here’s your auto quote for</p>
      <div className="flex flex-col justify-end leading-[0] relative shrink-0 text-[0px] w-[782px]">
        <p className="font-['Manrope:Bold',sans-serif]">
          <span className="leading-[60px] text-[48px]">$72.37</span>
          <span className="leading-[38px] text-[28px]">/mo.</span>
        </p>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] py-[9px] relative shrink-0" data-name="Container">
      <p className="font-['Open_Sans:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#0078d6] text-[16px] text-center whitespace-nowrap">
        Price Conscious
        <br aria-hidden="true" />
        $72/mo
      </p>
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] py-[9px] relative shrink-0" data-name="Container">
      <div className="font-['Open_Sans:Regular',sans-serif] leading-[0] not-italic relative shrink-0 text-[16px] text-[rgba(0,0,0,0.6)] text-center whitespace-nowrap">
        <p className="leading-[22px] mb-0">Most Popular</p>
        <p>
          <span className="font-['Open_Sans:Regular',sans-serif] leading-[22px] not-italic">$</span>
          <span className="leading-[22px]">80</span>
          <span className="font-['Open_Sans:Regular',sans-serif] leading-[22px] not-italic">/mo</span>
        </p>
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] py-[9px] relative shrink-0" data-name="Container">
      <div className="font-['Open_Sans:Regular',sans-serif] leading-[22px] not-italic relative shrink-0 text-[16px] text-[rgba(0,0,0,0.6)] text-center whitespace-nowrap">
        <p className="mb-0">Superior Coverage</p>
        <p>$124/mo</p>
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="Container">
      <div className="content-stretch flex flex-col items-center justify-center relative shrink-0" data-name="<Tab>">
        <Container1 />
        <div className="absolute bottom-0 h-0 left-0 right-0" data-name="Line">
          <div className="absolute inset-[-2px_0_0_0]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 157 2">
              <line id="Line" stroke="var(--stroke-0, #0078D6)" strokeWidth="2" x2="157" y1="1" y2="1" />
            </svg>
          </div>
        </div>
      </div>
      <div className="content-stretch flex flex-col items-center justify-center relative shrink-0" data-name="<Tab>">
        <Container2 />
      </div>
      <div className="content-stretch flex flex-col items-center justify-center relative shrink-0" data-name="<Tab>">
        <Container3 />
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-full">
      <p className="font-['Manrope:Regular',sans-serif] leading-[28px] max-w-[450px] not-italic relative shrink-0 text-[#0078d6] text-[20px] w-[450px]">Liability:</p>
    </div>
  );
}

function AccordianGray() {
  return (
    <div className="bg-[#f5faff] relative shrink-0 w-full" data-name="<Accordian Gray>">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex font-['Open_Sans:Bold',sans-serif] items-center justify-between not-italic px-[8px] py-[12px] relative text-black w-full">
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-[248px] relative text-[14px]">Name</p>
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-px relative text-[14px]">Coverage</p>
          <p className="flex-[1_0_0] leading-[14px] max-w-[50px] min-h-px min-w-px relative text-[12px] text-right">Cost</p>
        </div>
      </div>
    </div>
  );
}

function AccordianWhite() {
  return (
    <div className="bg-white relative shrink-0 w-full" data-name="<Accordian White>">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex font-['Open_Sans:Regular',sans-serif] gap-[4px] items-center not-italic px-[8px] py-[12px] relative text-black w-full">
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-[248px] relative text-[14px]">Bodily injury liability</p>
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-px relative text-[14px]">$35,000/70,000</p>
          <p className="flex-[1_0_0] leading-[14px] max-w-[50px] min-h-px min-w-px relative text-[12px] text-right">$90</p>
        </div>
      </div>
    </div>
  );
}

function AccordianGray1() {
  return (
    <div className="bg-[#f8f8fa] relative shrink-0 w-full" data-name="<Accordian Gray>">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex font-['Open_Sans:Regular',sans-serif] items-center justify-between not-italic px-[8px] py-[12px] relative text-black w-full">
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-[248px] relative text-[14px]">Property damage liability</p>
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-px relative text-[14px]">$25,000</p>
          <p className="flex-[1_0_0] leading-[14px] max-w-[50px] min-h-px min-w-px relative text-[12px] text-right">$88</p>
        </div>
      </div>
    </div>
  );
}

function DesktopGood237MoPlanForm() {
  return (
    <div className="content-stretch flex flex-col items-start overflow-clip relative shrink-0 w-[450px]" data-name="Desktop_ Good $237.mo Plan Form">
      <AccordianGray />
      <AccordianWhite />
      <AccordianGray1 />
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
      <Frame6 />
      <DesktopGood237MoPlanForm />
    </div>
  );
}

function Frame7() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-full">
      <p className="font-['Manrope:Regular',sans-serif] leading-[28px] max-w-[450px] not-italic relative shrink-0 text-[#0078d6] text-[20px] w-[450px]">Personal coverage:</p>
    </div>
  );
}

function AccordianGray2() {
  return (
    <div className="bg-[#f5faff] relative shrink-0 w-full" data-name="<Accordian Gray>">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex font-['Open_Sans:Bold',sans-serif] items-center justify-between not-italic px-[8px] py-[12px] relative text-black w-full">
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-[248px] relative text-[14px]">Name</p>
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-px relative text-[14px]">Coverage</p>
          <p className="flex-[1_0_0] leading-[14px] max-w-[50px] min-h-px min-w-px relative text-[12px] text-right">Cost</p>
        </div>
      </div>
    </div>
  );
}

function AccordianWhite1() {
  return (
    <div className="bg-white relative shrink-0 w-full" data-name="<Accordian White>">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex font-['Open_Sans:Regular',sans-serif] gap-[4px] items-center not-italic px-[8px] py-[12px] relative text-black w-full">
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-[248px] relative text-[14px]">Personal injury protection limit</p>
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-px relative text-[14px]">$15,000</p>
          <p className="flex-[1_0_0] leading-[14px] max-w-[50px] min-h-px min-w-px relative text-[12px] text-right">$82</p>
        </div>
      </div>
    </div>
  );
}

function AccordianGray3() {
  return (
    <div className="bg-[#f8f8fa] relative shrink-0 w-full" data-name="<Accordian Gray>">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex font-['Open_Sans:Regular',sans-serif] items-center justify-between not-italic px-[8px] py-[12px] relative text-black w-full">
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-[248px] relative text-[14px]">Extra personal injury protection package option</p>
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-px relative text-[14px]">Option 1</p>
          <p className="flex-[1_0_0] leading-[14px] max-w-[50px] min-h-px min-w-px relative text-[12px] text-right">$11</p>
        </div>
      </div>
    </div>
  );
}

function AccordianWhite2() {
  return (
    <div className="bg-white relative shrink-0 w-full" data-name="<Accordian White>">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex font-['Open_Sans:Regular',sans-serif] gap-[4px] items-center not-italic px-[8px] py-[12px] relative text-black w-full">
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-[248px] relative text-[14px]">Uninsured/underinsured motorist bodily injury</p>
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-px relative text-[14px]">$35,000/70,000</p>
          <p className="flex-[1_0_0] leading-[14px] max-w-[50px] min-h-px min-w-px relative text-[12px] text-right">$77</p>
        </div>
      </div>
    </div>
  );
}

function AccordianGray4() {
  return (
    <div className="bg-[#f8f8fa] relative shrink-0 w-full" data-name="<Accordian Gray>">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex font-['Open_Sans:Regular',sans-serif] items-center justify-between not-italic px-[8px] py-[12px] relative text-black w-full">
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-[248px] relative text-[14px]">Uninsured/underinsured motorist property damage</p>
          <p className="flex-[1_0_0] leading-[22px] min-h-px min-w-px relative text-[14px]">$25,000</p>
          <p className="flex-[1_0_0] leading-[14px] max-w-[50px] min-h-px min-w-px relative text-[12px] text-right">$16</p>
        </div>
      </div>
    </div>
  );
}

function DesktopGood237MoPlanForm1() {
  return (
    <div className="content-stretch flex flex-col items-start overflow-clip relative shrink-0 w-[450px]" data-name="Desktop_ Good $237.mo Plan Form">
      <AccordianGray2 />
      <AccordianWhite1 />
      <AccordianGray3 />
      <AccordianWhite2 />
      <AccordianGray4 />
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
      <Frame7 />
      <DesktopGood237MoPlanForm1 />
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-full">
      <p className="font-['Manrope:Regular',sans-serif] leading-[28px] max-w-[450px] not-italic relative shrink-0 text-[#0078d6] text-[20px] w-[450px]">Vehicle coverage for</p>
    </div>
  );
}

function AccordianWhite3() {
  return (
    <div className="bg-white relative shrink-0 w-full" data-name="<Accordian White>">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex font-['Open_Sans:Regular',sans-serif] gap-[4px] items-center leading-[22px] not-italic px-[8px] py-[12px] relative text-[14px] text-black w-full">
          <p className="flex-[1_0_0] min-h-px min-w-[248px] relative">1984 BMW 325 E Sedan</p>
          <p className="flex-[1_0_0] min-h-px min-w-px relative text-right">None</p>
        </div>
      </div>
    </div>
  );
}

function DesktopGood237MoPlanForm2() {
  return (
    <div className="content-stretch flex flex-col items-start overflow-clip relative shrink-0 w-[450px]" data-name="Desktop_ Good $237.mo Plan Form">
      <AccordianWhite3 />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
      <Frame8 />
      <DesktopGood237MoPlanForm2 />
      <p className="font-['Open_Sans:Regular',sans-serif] leading-[14px] not-italic relative shrink-0 text-[12px] text-black whitespace-nowrap">Quote Number: MAHQ0005151311</p>
    </div>
  );
}

function LogoWithTagline() {
  return (
    <div className="h-[44.877px] relative shrink-0 w-[150.479px]" data-name="Logo with tagline">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 150.479 44.8775">
        <g clipPath="url(#clip0_2009_6264)" id="Logo with tagline">
          <path d={svgPaths.p318a8f80} fill="var(--fill-0, #0078D6)" id="Vector" />
          <path d={svgPaths.p19dd6a40} fill="var(--fill-0, #0078D6)" id="Vector_2" />
          <path d={svgPaths.p318a8f80} fill="var(--fill-0, #0078D6)" id="Vector_3" />
          <path d={svgPaths.p3e87a680} fill="var(--fill-0, #0078D6)" id="Vector_4" />
          <path d={svgPaths.pfc86a80} fill="var(--fill-0, #0078D6)" id="Vector_5" />
          <path d={svgPaths.p8f1e300} fill="var(--fill-0, #0078D6)" id="Vector_6" />
          <path d={svgPaths.p5cd6600} fill="var(--fill-0, #0078D6)" id="Vector_7" />
          <path d={svgPaths.p2dda5200} fill="var(--fill-0, #0078D6)" id="Vector_8" />
          <path d={svgPaths.p31d74600} fill="var(--fill-0, #0078D6)" id="Vector_9" />
          <path d={svgPaths.p2beae60} fill="var(--fill-0, #0078D6)" id="Vector_10" />
          <path d={svgPaths.p3d908300} fill="var(--fill-0, #0078D6)" id="Vector_11" />
          <path d={svgPaths.p10537600} fill="var(--fill-0, #0078D6)" id="Vector_12" />
          <path d={svgPaths.p19598100} fill="var(--fill-0, #0078D6)" id="Vector_13" />
          <path d={svgPaths.p89ac800} fill="var(--fill-0, #0078D6)" id="Vector_14" />
          <path d={svgPaths.p2396fb00} fill="var(--fill-0, #0078D6)" id="Vector_15" />
          <path d={svgPaths.p3fb44700} fill="var(--fill-0, #0078D6)" id="Vector_16" />
          <path d={svgPaths.p3bbd93f0} fill="var(--fill-0, #0078D6)" id="Vector_17" />
          <path d={svgPaths.p1d55e780} fill="var(--fill-0, #0078D6)" id="Vector_18" />
          <path d={svgPaths.pd9fac80} fill="var(--fill-0, #0078D6)" id="Vector_19" />
          <path d={svgPaths.p3b3fea80} fill="var(--fill-0, #0078D6)" id="Vector_20" />
          <path d={svgPaths.p19d0e680} fill="var(--fill-0, #0078D6)" id="Vector_21" />
          <path d={svgPaths.p1044ed80} fill="var(--fill-0, #0078D6)" id="Vector_22" />
          <path d={svgPaths.p37f5300} fill="var(--fill-0, #0078D6)" id="Vector_23" />
          <path d={svgPaths.p28601080} fill="var(--fill-0, #0078D6)" id="Vector_24" />
          <path d={svgPaths.p2acfda00} fill="var(--fill-0, #0078D6)" id="Vector_25" />
          <path d={svgPaths.p24faa380} fill="var(--fill-0, #0078D6)" id="Vector_26" />
          <path d={svgPaths.p274d2380} fill="var(--fill-0, #0078D6)" id="Vector_27" />
          <path d={svgPaths.p3f31f880} fill="var(--fill-0, #0078D6)" id="Vector_28" />
          <path d={svgPaths.p1b136700} fill="var(--fill-0, #0078D6)" id="Vector_29" />
          <path d={svgPaths.p1b68eb80} fill="var(--fill-0, #0078D6)" id="Vector_30" />
          <path d={svgPaths.p19a8d680} fill="var(--fill-0, #0078D6)" id="Vector_31" />
          <path d={svgPaths.p2e9b0600} fill="var(--fill-0, #0078D6)" id="Vector_32" />
          <path d={svgPaths.p185c8580} fill="var(--fill-0, #0078D6)" id="Vector_33" />
          <path d={svgPaths.pe4c3c80} fill="var(--fill-0, #0078D6)" id="Vector_34" />
          <path d={svgPaths.p6edda00} fill="var(--fill-0, #0078D6)" id="Vector_35" />
          <path d={svgPaths.p3f8bb480} fill="var(--fill-0, #0078D6)" id="Vector_36" />
          <path d={svgPaths.p3d0b2900} fill="var(--fill-0, #0078D6)" id="Vector_37" />
          <path d={svgPaths.p2839a280} fill="var(--fill-0, #0078D6)" id="Vector_38" />
          <path d={svgPaths.p36555b00} fill="var(--fill-0, #0078D6)" id="Vector_39" />
          <path d={svgPaths.p18e43080} fill="var(--fill-0, #0078D6)" id="Vector_40" />
          <path d={svgPaths.p44e3500} fill="var(--fill-0, #0078D6)" id="Vector_41" />
          <path d={svgPaths.p1b955c00} fill="var(--fill-0, #0078D6)" id="Vector_42" />
          <path d={svgPaths.p36cd6600} fill="var(--fill-0, #0078D6)" id="Vector_43" />
          <path d={svgPaths.p38a4ab00} fill="var(--fill-0, #0078D6)" id="Vector_44" />
          <path d={svgPaths.p31642e00} fill="var(--fill-0, #0078D6)" id="Vector_45" />
          <path d={svgPaths.p19934580} fill="var(--fill-0, #0078D6)" id="Vector_46" />
          <path d={svgPaths.p2dc42f00} fill="var(--fill-0, #0078D6)" id="Vector_47" />
          <path d={svgPaths.pf49fb00} fill="var(--fill-0, #0078D6)" id="Vector_48" />
        </g>
        <defs>
          <clipPath id="clip0_2009_6264">
            <rect fill="white" height="44.8775" width="150.479" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Base() {
  return (
    <div className="content-stretch flex gap-[8px] items-center justify-center relative shrink-0" data-name="Base">
      <p className="font-['Open_Sans:Regular',sans-serif] leading-[30px] not-italic relative shrink-0 text-[18px] text-white whitespace-nowrap">Continue to purchase</p>
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-between max-w-[450px] min-h-px min-w-px relative">
      <LogoWithTagline />
      <div className="bg-[#0078d6] content-stretch flex flex-col items-center justify-center overflow-clip px-[20px] py-[12px] relative rounded-[32px] shrink-0" data-name="<Button>">
        <Base />
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex items-start justify-between relative shrink-0 w-full">
      <Frame9 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col gap-[22px] items-center py-[24px] relative rounded-[30px] shrink-0 w-full">
      <div aria-hidden="true" className="absolute border-[#bec7d1] border-[1.013px] border-solid inset-0 pointer-events-none rounded-[30px]" />
      <Frame4 />
      <div className="content-stretch flex flex-col items-center overflow-clip relative shrink-0 w-full" data-name="<Tabs>">
        <Container />
      </div>
      <Frame10 />
      <Frame11 />
      <Frame12 />
      <Frame5 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full">
      <Frame />
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-col gap-[20px] items-start relative shrink-0 w-full">
      <Frame1 />
      <p className="font-['Open_Sans:Regular',sans-serif] leading-[0] not-italic relative shrink-0 text-[0px] text-[16px] text-black w-[766.096px]">
        <span className="leading-[26px]">Here is your quote, you can continue to buy your policy</span>
        <span className="leading-[26px]">{` or we can`}</span>
        <span className="leading-[26px]">{` go over any details`}</span>
        <span className="leading-[26px]">.</span>
        <span className="leading-[26px]">{` For example, you can ask me `}</span>
        <span className="font-['Open_Sans:Bold',sans-serif] leading-[26px]">What does Bodily Injury mean?</span>
        <span className="leading-[26px]">e</span>
        <span className="leading-[26px]">{` Or you can ask me`}</span>
        <span className="leading-[26px]">{` `}</span>
        <span className="font-['Open_Sans:Bold',sans-serif] leading-[26px]">{`What is the detailed coverage information? `}</span>
      </p>
    </div>
  );
}

function ChatBody() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[26px] items-center left-0 top-0 w-[782px]" data-name="Chat Body">
      <Frame2 />
      <Frame3 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-0 top-0">
      <ChatBody />
    </div>
  );
}

export default function AutoQuote() {
  return (
    <div className="bg-white relative size-full" data-name="Auto Quote 1">
      <Group />
    </div>
  );
}