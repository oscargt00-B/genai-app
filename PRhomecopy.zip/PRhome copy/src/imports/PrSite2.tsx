import svgPaths from "./svg-oxxrh33vi2";
import imgSection from "figma:asset/64e0b0a57b62813142180b07f5e18b138aaccc26.png";
import imgGoogleLogo from "figma:asset/ccc4cb9d838d770d66acfbb49291ab7964e6d3d0.png";
import imgMomAndDaughterViewingDentInBlueCar from "figma:asset/436e396f7a88e87509562a5646d24fd0058c6411.png";
import imgHappyManDrivingACar from "figma:asset/ebaafa789d8152a2592a98b92db4c12b6d3a4d85.png";
import imgAHappyFamilyThatJustLearnedHowMuchHomeownersInsuranceTheyNeed from "figma:asset/d68da8f121807ba50112ea8edb9ba25d7d6c7a83.png";
import imgPersonShovelingSnow from "figma:asset/47bb653b811563bd0bae5d4439b5e37f0cd80e6f.png";

function Container() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Font_Awesome_5_Free:Solid',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[24px] text-center text-white" role="link" tabIndex="0">
        <p className="css-ew64yg cursor-pointer leading-[24px]"></p>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="content-stretch flex items-center relative self-stretch shrink-0" data-name="Container">
      <Container />
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0" data-name="Container">
      <Container1 />
    </div>
  );
}

function LinkMainNavigationMenu() {
  return (
    <a className="bg-[#0078d6] content-stretch cursor-pointer flex items-start p-0 relative shrink-0" data-name="Link - Main Navigation Menu" href="https://www.plymouthrock.com/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjM2OTA2IiwidG9nZ2xlIjp0cnVlfQ%3D%3D">
      <Container2 />
    </a>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex flex-col items-start pb-[4px] pt-0 px-0 relative shrink-0 w-full" data-name="Container">
      <LinkMainNavigationMenu />
    </div>
  );
}

function Container4() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px pb-0 pt-[4px] px-0 relative" data-name="Container">
      <Container3 />
    </div>
  );
}

function Container5() {
  return (
    <div className="content-center flex flex-[1_0_0] flex-wrap items-center justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container4 />
    </div>
  );
}

function Container6() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px pl-[20px] pr-0 py-0 relative shrink-0 w-[51.19px]" data-name="Container">
      <Container5 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[3.89%_0.74%_6.57%_0.7%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 187.253 35.5756">
        <g id="Group">
          <path d={svgPaths.p2829fd00} fill="var(--fill-0, white)" id="Vector" />
          <g id="Group_2">
            <path d={svgPaths.p31c5ed00} fill="var(--fill-0, white)" id="Vector_2" />
            <path d={svgPaths.pa462600} fill="var(--fill-0, white)" id="Vector_3" />
            <path d={svgPaths.p2b7bbf80} fill="var(--fill-0, white)" id="Vector_4" />
            <path d={svgPaths.pe866980} fill="var(--fill-0, white)" id="Vector_5" />
            <path d={svgPaths.p28a33100} fill="var(--fill-0, white)" id="Vector_6" />
            <path d={svgPaths.pf44700} fill="var(--fill-0, white)" id="Vector_7" />
            <path d={svgPaths.p15534000} fill="var(--fill-0, white)" id="Vector_8" />
            <path d={svgPaths.p990f280} fill="var(--fill-0, white)" id="Vector_9" />
            <path d={svgPaths.p36593600} fill="var(--fill-0, white)" id="Vector_10" />
            <path d={svgPaths.p2b859500} fill="var(--fill-0, white)" id="Vector_11" />
            <path d={svgPaths.p32240a00} fill="var(--fill-0, white)" id="Vector_12" />
            <path d={svgPaths.p17aea80} fill="var(--fill-0, white)" id="Vector_13" />
          </g>
          <g id="Group_3">
            <path d={svgPaths.p324d5d80} fill="var(--fill-0, white)" id="Vector_14" />
            <path d={svgPaths.p28e61580} fill="var(--fill-0, white)" id="Vector_15" />
            <path d={svgPaths.p1251d900} fill="var(--fill-0, white)" id="Vector_16" />
            <path d={svgPaths.p7875900} fill="var(--fill-0, white)" id="Vector_17" />
            <path d={svgPaths.p281992} fill="var(--fill-0, white)" id="Vector_18" />
            <path d={svgPaths.p1b154600} fill="var(--fill-0, white)" id="Vector_19" />
            <path d={svgPaths.p20b83500} fill="var(--fill-0, white)" id="Vector_20" />
            <path d={svgPaths.p14fabe00} fill="var(--fill-0, white)" id="Vector_21" />
            <path d={svgPaths.p2c14c2d0} fill="var(--fill-0, white)" id="Vector_22" />
          </g>
          <g id="Group_4">
            <path d={svgPaths.p3fb4fc80} fill="var(--fill-0, white)" id="Vector_23" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Component() {
  return (
    <div className="h-[39.731px] overflow-clip relative shrink-0 w-[190px]" data-name="Component 1">
      <Group />
    </div>
  );
}

function PrLogoWhtSvgFill() {
  return (
    <div className="content-stretch flex flex-col h-[40px] items-center justify-center overflow-clip px-0 py-[0.135px] relative shrink-0 w-[190px]" data-name="PR-logo-wht.svg fill">
      <Component />
    </div>
  );
}

function PlymouthRockInsuranceLogo() {
  return (
    <div className="content-stretch flex h-[40px] items-start max-w-[896px] overflow-clip relative shrink-0 w-[190px]" data-name="Plymouth Rock Insurance logo">
      <PrLogoWhtSvgFill />
    </div>
  );
}

function Link() {
  return (
    <a className="content-stretch cursor-pointer flex items-start p-0 relative shrink-0" data-name="Link" href="https://www.plymouthrock.com/">
      <PlymouthRockInsuranceLogo />
    </a>
  );
}

function Container7() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex flex-col items-start pl-[10px] pr-0 py-0 relative w-full">
        <Link />
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px pb-0 pt-[6px] px-0 relative" data-name="Container">
      <Container7 />
    </div>
  );
}

function Container9() {
  return (
    <div className="content-center flex flex-[1_0_0] flex-wrap items-center justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container8 />
    </div>
  );
}

function Container10() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px relative shrink-0 w-[896px]" data-name="Container">
      <Container9 />
    </div>
  );
}

function Component9() {
  return (
    <div className="relative shrink-0 size-[21px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21 21">
        <g clipPath="url(#clip0_1_5010)" id="Component 1">
          <path d={svgPaths.p2f974b00} fill="var(--fill-0, white)" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_1_5010">
            <rect fill="white" height="21" width="21" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function SearchSvgFill() {
  return (
    <div className="content-stretch flex flex-col items-center justify-center overflow-clip relative shrink-0 size-[21px]" data-name="search.svg fill">
      <Component9 />
    </div>
  );
}

function SearchIcon() {
  return (
    <div className="content-stretch flex items-start max-w-[69.80000305175781px] overflow-clip relative shrink-0 size-[21px]" data-name="Search icon">
      <SearchSvgFill />
    </div>
  );
}

function Link1() {
  return (
    <a className="content-stretch cursor-pointer flex items-start justify-end pb-[0.78px] pt-[4.22px] px-0 relative shrink-0" data-name="Link" href="https://www.plymouthrock.com/">
      <SearchIcon />
    </a>
  );
}

function Container11() {
  return (
    <div className="content-stretch flex flex-col items-end relative shrink-0 w-full" data-name="Container">
      <Link1 />
    </div>
  );
}

function Container12() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Container">
      <Container11 />
    </div>
  );
}

function Container13() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative self-stretch" data-name="Container">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-center flex flex-wrap items-center justify-center pl-0 pr-[7px] py-0 relative size-full">
          <Container12 />
        </div>
      </div>
    </div>
  );
}

function Container14() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px relative shrink-0 w-[76.8px]" data-name="Container">
      <Container13 />
    </div>
  );
}

function Component1() {
  return (
    <div className="content-stretch flex items-start justify-end relative shrink-0 w-full" data-name="Component 2">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-right text-white">
        <p className="css-ew64yg decoration-solid leading-[26px] underline">844-242-3555</p>
      </div>
    </div>
  );
}

function Container15() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative" data-name="Container">
      <Component1 />
    </div>
  );
}

function Container16() {
  return (
    <div className="content-center flex flex-[1_0_0] flex-wrap items-center justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container15 />
    </div>
  );
}

function Container17() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px relative shrink-0 w-[115.19px]" data-name="Container">
      <Container16 />
    </div>
  );
}

function Component10() {
  return (
    <div className="h-[15.859px] relative shrink-0 w-[14px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 15.8594">
        <g id="Component 1">
          <path d={svgPaths.p3e4bbf00} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Container18() {
  return (
    <div className="content-stretch flex items-center relative self-stretch shrink-0" data-name="Container">
      <Component10 />
    </div>
  );
}

function Container19() {
  return (
    <div className="content-stretch flex flex-col items-center relative self-stretch shrink-0" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black text-center" role="link" tabIndex="0">
        <p className="css-ew64yg cursor-pointer leading-[24px]">Log in</p>
      </div>
    </div>
  );
}

function Container20() {
  return (
    <div className="content-stretch flex gap-[9px] items-start justify-center relative shrink-0" data-name="Container">
      <Container18 />
      <Container19 />
    </div>
  );
}

function Component2() {
  return (
    <a className="bg-[#ff7826] content-stretch cursor-pointer flex items-start px-[16px] py-[6px] relative rounded-[40px] shadow-[0px_4px_10px_0px_rgba(0,0,0,0.26)] shrink-0" data-name="Component 3" href="https://www.plymouthrock.com/eservice/login">
      <Container20 />
    </a>
  );
}

function Container21() {
  return (
    <div className="content-stretch flex flex-col items-end relative shrink-0 w-full" data-name="Container">
      <Component2 />
    </div>
  );
}

function Container22() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px pb-0 pt-[4px] px-0 relative" data-name="Container">
      <Container21 />
    </div>
  );
}

function Container23() {
  return (
    <div className="content-center flex flex-[1_0_0] flex-wrap items-center justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container22 />
    </div>
  );
}

function Container24() {
  return (
    <div className="content-stretch flex items-start justify-center min-h-px pl-0 pr-[20px] py-0 relative shrink-0 w-[140.42px]" data-name="Container">
      <Container23 />
    </div>
  );
}

function Container25() {
  return (
    <div className="content-stretch flex items-center max-w-[1280px] min-h-[70px] px-0 py-[12px] relative shrink-0 w-full" data-name="Container">
      <Container6 />
      <Container10 />
      <Container14 />
      <Container17 />
      <Container24 />
    </div>
  );
}

function Section() {
  return (
    <div className="bg-[#0078d6] h-[70px] relative shrink-0 w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[310px] py-0 relative size-full">
        <Container25 />
      </div>
    </div>
  );
}

function Container26() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <div className="flex-[1_0_0] h-full min-h-px min-w-px" data-name="Rectangle" />
    </div>
  );
}

function Container27() {
  return <div className="flex-[1_0_0] min-h-px min-w-px self-stretch" data-name="Container" />;
}

function Section1() {
  return (
    <div className="content-stretch flex items-start max-w-[1140px] relative shrink-0 w-[1140px]" data-name="Section">
      <Container26 />
      <Container27 />
    </div>
  );
}

function Header() {
  return (
    <div className="content-stretch flex flex-col items-center mb-[-1px] relative shrink-0 w-full" data-name="Header">
      <Section />
      <Section1 />
    </div>
  );
}

function Component3() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0" data-name="Component 4">
      <a className="css-g0mm18 flex flex-col font-['Open_Sans:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[16px] text-center text-white" href="https://ci2.plymouthrock.com/qpay/login">
        <p className="css-ew64yg cursor-pointer decoration-solid leading-[26px] underline">Quick pay</p>
      </a>
    </div>
  );
}

function Container28() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <Component3 />
    </div>
  );
}

function Container29() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[100px]" data-name="Container">
      <Container28 />
    </div>
  );
}

function Component11() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0" data-name="Component 4">
      <a className="css-g0mm18 flex flex-col font-['Open_Sans:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[0px] text-center text-white" href="https://ci2.plymouthrock.com/qpay/login">
        <p className="css-ew64yg cursor-pointer decoration-solid leading-[26px] text-[16px] underline" role="link" tabIndex="0">
          Claims center
        </p>
      </a>
    </div>
  );
}

function Container30() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <Component11 />
    </div>
  );
}

function Container31() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[165px]" data-name="Container">
      <Container30 />
    </div>
  );
}

function Component12() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0" data-name="Component 4">
      <a className="css-g0mm18 flex flex-col font-['Open_Sans:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[0px] text-center text-white" href="https://ci2.plymouthrock.com/qpay/login">
        <p className="css-ew64yg cursor-pointer decoration-solid leading-[26px] text-[16px] underline" role="link" tabIndex="0">
          Manage policy
        </p>
      </a>
    </div>
  );
}

function Container32() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <Component12 />
    </div>
  );
}

function Container33() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[140px]" data-name="Container">
      <Container32 />
    </div>
  );
}

function Container34() {
  return (
    <div className="content-center flex flex-[1_0_0] flex-wrap gap-0 items-center justify-center min-h-px min-w-px pb-[13px] pt-[10px] px-0 relative self-stretch" data-name="Container">
      <Container29 />
      <Container31 />
      <Container33 />
    </div>
  );
}

function Container35() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1075px] relative shrink-0 w-full" data-name="Container">
      <Container34 />
    </div>
  );
}

function Section2() {
  return (
    <div className="bg-[#0351aa] content-stretch flex flex-col items-start mb-[-1px] px-[412.5px] py-0 relative shrink-0 w-[1920px]" data-name="Section">
      <Container35 />
    </div>
  );
}

function Heading() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 1">
      <div className="flex flex-col font-['Manrope:Regular',sans-serif] justify-center leading-[60px] not-italic relative shrink-0 text-[48px] text-black w-full">
        <p className="css-4hzbpn mb-0">Insurance built for</p>
        <p className="css-4hzbpn">the Northeast.</p>
      </div>
    </div>
  );
}

function Container36() {
  return (
    <div className="absolute content-stretch flex flex-col inset-[0_3px_18px_-3px] items-start max-w-[550px] pb-0 pt-[37px] px-0" data-name="Container">
      <Heading />
    </div>
  );
}

function Margin() {
  return (
    <div className="h-[175px] max-w-[550px] relative shrink-0 w-[550px]" data-name="Margin">
      <Container36 />
    </div>
  );
}

function Heading1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 2">
      <div className="flex flex-col font-['Open_Sans:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[20px] text-black w-full">
        <p className="css-4hzbpn leading-[28px]">Select a product and start saving</p>
      </div>
    </div>
  );
}

function Container37() {
  return (
    <div className="absolute content-stretch flex flex-col inset-[0_0_16px_-1px] items-start px-0 py-[5px]" data-name="Container">
      <Heading1 />
    </div>
  );
}

function Margin1() {
  return (
    <div className="h-[54px] relative shrink-0 w-full" data-name="Margin">
      <Container37 />
    </div>
  );
}

function Component13() {
  return (
    <div className="relative shrink-0 size-[38px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 38 38">
        <g id="Component 1">
          <path d={svgPaths.p38ef4f00} fill="var(--fill-0, #D3E5F9)" id="Vector" stroke="var(--stroke-2, #0078D6)" strokeMiterlimit="10" strokeWidth="0.883721" />
          <path d={svgPaths.p1c957400} id="Vector_2" stroke="var(--stroke-0, #0078D6)" strokeMiterlimit="10" strokeWidth="0.883721" />
          <path d={svgPaths.p293dc280} fill="var(--fill-0, #A7CAF2)" id="Vector_3" stroke="var(--stroke-2, #0078D6)" strokeMiterlimit="10" strokeWidth="0.883721" />
          <path d={svgPaths.p1b5b3a40} fill="var(--fill-0, white)" id="Vector_4" stroke="var(--stroke-2, #0078D6)" strokeMiterlimit="10" strokeWidth="0.883721" />
          <path d={svgPaths.p1867b800} fill="var(--fill-0, white)" id="Vector_5" stroke="var(--stroke-2, #0078D6)" strokeMiterlimit="10" strokeWidth="0.883721" />
          <path d="M14.4931 24.4188H24.4111" id="Vector_6" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeMiterlimit="10" strokeWidth="0.883721" />
          <path d="M14.4931 22.0704H24.4111" id="Vector_7" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeMiterlimit="10" strokeWidth="0.883721" />
        </g>
      </svg>
    </div>
  );
}

function Container38() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative">
        <Component13 />
      </div>
    </div>
  );
}

function Container39() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative">
        <div className="css-g0mm18 flex flex-col font-['Open_Sans:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[0px] text-black text-left" role="link" tabIndex="0">
          <p className="css-ew64yg cursor-pointer leading-[19px] text-[14px]">Auto</p>
        </div>
      </div>
    </div>
  );
}

function Component4() {
  return (
    <a className="bg-white content-stretch cursor-pointer flex flex-col gap-[3px] items-center justify-center px-px py-[13px] relative rounded-[16px] shrink-0 w-full" data-name="Component 5" href="https://www.plymouthrock.com/">
      <div aria-hidden="true" className="absolute border border-[#ff7826] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container38 />
      <Container39 />
    </a>
  );
}

function Item() {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0 w-[90px]" data-name="Item">
      <Component4 />
    </div>
  );
}

function Component14() {
  return (
    <div className="relative shrink-0 size-[34px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 34">
        <g id="Component 1">
          <path d={svgPaths.p59fca00} fill="var(--fill-0, #D3E5F9)" id="Vector" stroke="var(--stroke-2, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p21edd200} fill="var(--fill-0, white)" id="Vector_2" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.pb865700} fill="var(--fill-0, white)" id="Vector_3" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p11bf180} fill="var(--fill-0, white)" id="Vector_4" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p1fb9a080} fill="var(--fill-0, #A7CAF2)" id="Vector_5" stroke="var(--stroke-2, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p21c42b00} fill="var(--fill-0, #A7CAF2)" id="Vector_6" stroke="var(--stroke-2, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
        </g>
      </svg>
    </div>
  );
}

function Container40() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative">
        <Component14 />
      </div>
    </div>
  );
}

function Container41() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative">
        <div className="css-g0mm18 flex flex-col font-['Open_Sans:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[0px] text-black text-left">
          <p className="css-ew64yg leading-[19px] text-[14px]">Home</p>
        </div>
      </div>
    </div>
  );
}

function Component15() {
  return (
    <a className="bg-white content-stretch cursor-pointer flex flex-col gap-[7px] items-center justify-center px-px py-[13px] relative rounded-[16px] shrink-0 w-full" data-name="Component 5" href="https://www.plymouthrock.com/">
      <div aria-hidden="true" className="absolute border border-[#ff7826] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container40 />
      <Container41 />
    </a>
  );
}

function Item1() {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0 w-[90px]" data-name="Item">
      <Component15 />
    </div>
  );
}

function Component16() {
  return (
    <div className="relative shrink-0 size-[34px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 34">
        <g id="Component 1">
          <path d={svgPaths.p2ccc1b80} fill="var(--fill-0, #D3E5F9)" id="Vector" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p32b89d32} fill="var(--fill-0, #D3E5F9)" id="Vector_2" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p199e7880} fill="var(--fill-0, white)" id="Vector_3" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p1995b100} fill="var(--fill-0, white)" id="Vector_4" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p31c64b00} fill="var(--fill-0, white)" id="Vector_5" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p1fb38e00} fill="var(--fill-0, #A7CAF2)" id="Vector_6" stroke="var(--stroke-2, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p18835bf0} fill="var(--fill-0, #A7CAF2)" id="Vector_7" stroke="var(--stroke-2, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p393a3f00} fill="var(--fill-0, #A7CAF2)" id="Vector_8" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p23653570} fill="var(--fill-0, #A7CAF2)" id="Vector_9" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
        </g>
      </svg>
    </div>
  );
}

function Container42() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative">
        <Component16 />
      </div>
    </div>
  );
}

function Container43() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative">
        <div className="css-g0mm18 flex flex-col font-['Open_Sans:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[0px] text-black text-left">
          <p className="css-ew64yg leading-[19px] text-[14px]">Condo</p>
        </div>
      </div>
    </div>
  );
}

function Component17() {
  return (
    <a className="bg-white content-stretch cursor-pointer flex flex-col gap-[7px] items-center justify-center px-px py-[13px] relative rounded-[16px] shrink-0 w-full" data-name="Component 5" href="https://www.plymouthrock.com/">
      <div aria-hidden="true" className="absolute border border-[#ff7826] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container42 />
      <Container43 />
    </a>
  );
}

function Item2() {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0 w-[90px]" data-name="Item">
      <Component17 />
    </div>
  );
}

function Component18() {
  return (
    <div className="relative shrink-0 size-[34px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 34 34">
        <g id="Component 1">
          <path d={svgPaths.p15170700} fill="var(--fill-0, #D3E5F9)" id="Vector" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p7963680} fill="var(--fill-0, #D3E5F9)" id="Vector_2" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p109225b0} fill="var(--fill-0, #D3E5F9)" id="Vector_3" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p3c538100} fill="var(--fill-0, white)" id="Vector_4" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p2c43c100} fill="var(--fill-0, white)" id="Vector_5" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p2abb3b00} fill="var(--fill-0, white)" id="Vector_6" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p98d1580} fill="var(--fill-0, white)" id="Vector_7" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p2267c500} fill="var(--fill-0, white)" id="Vector_8" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p183d06c0} fill="var(--fill-0, white)" id="Vector_9" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.pff6e800} fill="var(--fill-0, #A7CAF2)" id="Vector_10" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p259929f0} fill="var(--fill-0, #A7CAF2)" id="Vector_11" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p21453000} fill="var(--fill-0, white)" id="Vector_12" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p27b6e300} fill="var(--fill-0, white)" id="Vector_13" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p180ded00} fill="var(--fill-0, white)" id="Vector_14" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p8f7e000} fill="var(--fill-0, white)" id="Vector_15" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p374b3580} fill="var(--fill-0, white)" id="Vector_16" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
          <path d={svgPaths.p2e52a900} fill="var(--fill-0, white)" id="Vector_17" stroke="var(--stroke-0, #0078D6)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.68" />
        </g>
      </svg>
    </div>
  );
}

function Container44() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative">
        <Component18 />
      </div>
    </div>
  );
}

function Container45() {
  return (
    <div className="relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative">
        <div className="css-g0mm18 flex flex-col font-['Open_Sans:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[0px] text-black text-left">
          <p className="css-ew64yg leading-[19px] text-[14px]">Renters</p>
        </div>
      </div>
    </div>
  );
}

function Component19() {
  return (
    <a className="bg-white content-stretch cursor-pointer flex flex-col gap-[7px] items-center justify-center px-px py-[13px] relative rounded-[16px] shrink-0 w-full" data-name="Component 5" href="https://www.plymouthrock.com/">
      <div aria-hidden="true" className="absolute border border-[#ff7826] border-solid inset-0 pointer-events-none rounded-[16px]" />
      <Container44 />
      <Container45 />
    </a>
  );
}

function Item3() {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0 w-[90px]" data-name="Item">
      <Component19 />
    </div>
  );
}

function List() {
  return (
    <div className="content-stretch flex gap-[15px] items-start min-h-[84px] relative shrink-0 w-full" data-name="List">
      <Item />
      <Item1 />
      <Item2 />
      <Item3 />
    </div>
  );
}

function Container46() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0078d6] text-[16px] text-left" role="link" tabIndex="0">
        <p className="css-ew64yg cursor-pointer leading-[28px]">See all our insurance products</p>
      </div>
    </div>
  );
}

function Component20() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Component 1">
          <path d={svgPaths.p22fb9200} fill="var(--fill-0, #0078D6)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Component5() {
  return (
    <a className="content-stretch cursor-pointer flex gap-[6px] items-center p-0 relative shrink-0" data-name="Component 6" href="https://www.plymouthrock.com/insurance">
      <Container46 />
      <Component20 />
    </a>
  );
}

function Section3() {
  return (
    <div className="content-stretch flex flex-col gap-[25px] items-start pb-[4px] pt-0 px-0 relative shrink-0 w-full" data-name="Section">
      <List />
      <Component5 />
    </div>
  );
}

function Container47() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative w-full" data-name="Container">
      <Section3 />
    </div>
  );
}

function Margin2() {
  return (
    <div className="content-stretch flex flex-col h-[159.06px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container47 />
    </div>
  );
}

function Component21() {
  return (
    <div className="h-[21.328px] relative shrink-0 w-[22px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 21.3281">
        <g id="Component 1">
          <path d={svgPaths.p1d4ad700} fill="var(--fill-0, #0067B7)" id="Vector" stroke="var(--stroke-2, #0067B7)" strokeWidth="0.666503" />
        </g>
      </svg>
    </div>
  );
}

function Container48() {
  return (
    <div className="content-stretch flex items-center pb-[0.34px] pt-[2.33px] px-0 relative self-stretch shrink-0" data-name="Container">
      <Component21 />
    </div>
  );
}

function Container49() {
  return (
    <div className="content-stretch flex flex-col items-center relative self-stretch shrink-0" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0078d6] text-[0px] text-center">
        <p className="css-ew64yg cursor-pointer decoration-solid leading-[24px] text-[16px] underline" role="link" tabIndex="0">
          Find an Agent
        </p>
      </div>
    </div>
  );
}

function Container50() {
  return (
    <div className="content-stretch flex gap-[10px] items-start justify-center relative shrink-0" data-name="Container">
      <Container48 />
      <Container49 />
    </div>
  );
}

function Component22() {
  return (
    <a className="content-stretch cursor-pointer flex items-start pl-0 pr-[13px] py-0 relative shrink-0" data-name="Component 3" href="https://www.plymouthrock.com/find-an-agent">
      <Container50 />
    </a>
  );
}

function Container51() {
  return (
    <div className="content-stretch flex flex-col items-start max-w-[1140px] pb-[6.66px] pt-0 px-0 relative shrink-0" data-name="Container">
      <Component22 />
      <div className="absolute bg-[#0078d6] bottom-[30.04%] right-0 top-[9.98%] w-px" data-name="Vertical Divider" />
    </div>
  );
}

function Container52() {
  return (
    <div className="content-stretch flex flex-col items-center relative self-stretch shrink-0" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0078d6] text-[0px] text-center">
        <p className="css-ew64yg cursor-pointer decoration-solid leading-[24px] text-[16px] underline" role="link" tabIndex="0">
          Continue your quote
        </p>
      </div>
    </div>
  );
}

function Container53() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0" data-name="Container">
      <Container52 />
    </div>
  );
}

function Component23() {
  return (
    <a className="content-stretch cursor-pointer flex items-start pb-[7px] pl-[13px] pr-[3px] pt-0 relative shrink-0" data-name="Component 3" href="https://buy.plymouthrock.com/esales/entry/retrievequote">
      <Container53 />
    </a>
  );
}

function Container54() {
  return (
    <div className="content-stretch flex flex-col items-start max-w-[1140px] px-0 py-px relative shrink-0" data-name="Container">
      <Component23 />
    </div>
  );
}

function Container55() {
  return (
    <div className="content-center flex flex-[1_0_0] flex-wrap gap-0 items-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container51 />
      <Container54 />
    </div>
  );
}

function Container56() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-start justify-center min-h-px min-w-px relative" data-name="Container">
      <Container55 />
    </div>
  );
}

function Section4() {
  return (
    <div className="content-stretch flex items-center max-w-[1140px] relative shrink-0 w-[1140px]" data-name="Section">
      <Container56 />
    </div>
  );
}

function Container57() {
  return (
    <div className="content-stretch flex flex-col h-[113px] items-start relative shrink-0 w-full" data-name="Container">
      <Section4 />
    </div>
  );
}

function Container58() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative self-stretch shrink-0 w-[1200px]" data-name="Container">
      <div className="absolute inset-0" data-name="Gradient" style={{ backgroundImage: "linear-gradient(101deg, rgb(255, 255, 255) 52%, rgba(255, 255, 255, 0) 52%)" }} />
      <Margin />
      <Margin1 />
      <Margin2 />
      <Container57 />
    </div>
  );
}

function Container59() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1240px] min-h-px relative shrink-0 w-full" data-name="Container">
      <Container58 />
    </div>
  );
}

function Section5() {
  return (
    <div className="content-stretch flex flex-col items-start mb-[-1px] pl-[310px] pr-[350px] py-0 relative shrink-0 w-[1920px]" data-name="Section">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute h-full left-[57.81%] max-w-none top-0 w-[42.19%]" src={imgSection} />
      </div>
      <Container59 />
    </div>
  );
}

function GoogleLogo() {
  return (
    <div className="absolute h-[38.22px] left-[1149.58px] top-[10px] w-[122px]" data-name="google logo">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute h-[100.02%] left-0 max-w-none top-[-0.01%] w-full" src={imgGoogleLogo} />
      </div>
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[47.22px] relative shrink-0 w-full" data-name="Heading 2">
      <div className="absolute flex flex-col font-['Manrope:Regular',sans-serif] h-[42px] justify-center leading-[0] left-[calc(50%-127.99px)] not-italic text-[0px] text-black text-center top-[26.22px] translate-x-[-50%] translate-y-[-50%] w-[677.802px]">
        <p className="css-4hzbpn text-[32px]">
          <span className="font-['Manrope:Regular',sans-serif] leading-[42px]">{`Trusted by customers for `}</span>
          <span className="font-['Manrope:Bold',sans-serif] leading-[42px]">40+ years.</span>
          <span className="font-['Manrope:Regular',sans-serif] leading-[42px]">{` Read our `}</span>
        </p>
      </div>
      <GoogleLogo />
      <div className="absolute flex flex-col font-['Manrope:Regular',sans-serif] h-[42px] justify-center leading-[0] left-[calc(50%+403.93px)] not-italic text-[32px] text-black text-center top-[26.22px] translate-x-[-50%] translate-y-[-50%] w-[126.706px]">
        <p className="css-4hzbpn leading-[42px]">{` reviews.`}</p>
      </div>
    </div>
  );
}

function Container60() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative" data-name="Container">
      <div className="content-stretch flex flex-col items-start px-[15px] py-0 relative w-full">
        <Heading2 />
      </div>
    </div>
  );
}

function Container61() {
  return (
    <div className="content-center flex flex-[1_0_0] flex-wrap items-center justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Container60 />
    </div>
  );
}

function Container62() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0 w-full" data-name="Container">
      <Container61 />
    </div>
  );
}

function Section6() {
  return (
    <div className="bg-[#e9f2fc] content-stretch flex flex-col items-start mb-[-1px] pb-[40px] pt-[50px] px-0 relative shrink-0 w-[1920px]" data-name="Section">
      <Container62 />
    </div>
  );
}

function Component24() {
  return (
    <div className="h-[24px] relative shrink-0 w-[27px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 27 24">
        <g id="Component 1">
          <path d={svgPaths.p233e3400} fill="var(--fill-0, #0351AA)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Rating() {
  return (
    <div className="content-stretch flex items-start pb-[7px] pt-0 px-0 relative shrink-0 w-full" data-name="Rating">
      {[...Array(5).keys()].map((_, i) => (
        <Component24 key={i} />
      ))}
    </div>
  );
}

function Comment() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Comment">
      <div className="flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[24px] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn mb-0">All the coverage I need at a</p>
        <p className="css-4hzbpn">reasonable price.</p>
      </div>
    </div>
  );
}

function Container63() {
  return (
    <div className="content-stretch flex flex-col items-start pb-[5.5px] pt-[1.5px] px-0 relative shrink-0 w-full" data-name="Container">
      <div className="capitalize flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-black w-full">
        <p className="css-4hzbpn leading-[12px]">Review by: Judith P.</p>
      </div>
    </div>
  );
}

function Review() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-start pb-0 pt-[28px] px-0 relative shrink-0 w-[250px]" data-name="Review">
      <Rating />
      <Comment />
      <Container63 />
    </div>
  );
}

function Tabpanel() {
  return (
    <div className="content-stretch flex flex-col h-[150px] items-start min-h-px relative shrink-0 w-[310px]" data-name="Tabpanel">
      <Review />
    </div>
  );
}

function Component25() {
  return (
    <div className="h-[24px] relative shrink-0 w-[27px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 27 24">
        <g id="Component 1">
          <path d={svgPaths.p233e3400} fill="var(--fill-0, #0351AA)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Component26() {
  return (
    <div className="h-[24px] relative shrink-0 w-[27px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 27 24">
        <g id="Component 1">
          <path d={svgPaths.p233e3400} fill="var(--fill-0, #E0E0E0)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Rating1() {
  return (
    <div className="content-stretch flex items-start pb-[7px] pt-0 px-0 relative shrink-0 w-full" data-name="Rating">
      {[...Array(4).keys()].map((_, i) => (
        <Component25 key={i} />
      ))}
      <Component26 />
    </div>
  );
}

function Comment1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Comment">
      <div className="flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[24px] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn mb-0">Quick, easy and the right price. No</p>
        <p className="css-4hzbpn">brainer.</p>
      </div>
    </div>
  );
}

function Container64() {
  return (
    <div className="content-stretch flex flex-col items-start pb-[5.5px] pt-[1.5px] px-0 relative shrink-0 w-full" data-name="Container">
      <div className="capitalize flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-black w-full">
        <p className="css-4hzbpn leading-[12px]">Review by: Scott S.</p>
      </div>
    </div>
  );
}

function Review1() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-start pb-0 pt-[28px] px-0 relative shrink-0 w-[250px]" data-name="Review">
      <Rating1 />
      <Comment1 />
      <Container64 />
    </div>
  );
}

function Tabpanel1() {
  return (
    <div className="content-stretch flex flex-col h-[150px] items-start min-h-px relative shrink-0 w-[310px]" data-name="Tabpanel">
      <Review1 />
    </div>
  );
}

function Component27() {
  return (
    <div className="h-[24px] relative shrink-0 w-[27px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 27 24">
        <g id="Component 1">
          <path d={svgPaths.p233e3400} fill="var(--fill-0, #0351AA)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Rating2() {
  return (
    <div className="content-stretch flex items-start pb-[7px] pt-0 px-0 relative shrink-0 w-full" data-name="Rating">
      {[...Array(5).keys()].map((_, i) => (
        <Component27 key={i} />
      ))}
    </div>
  );
}

function Comment2() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Comment">
      <div className="flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[24px] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn mb-0">If you are shopping for a new</p>
        <p className="css-4hzbpn mb-0">insurance provider I highly suggest</p>
        <p className="css-4hzbpn mb-0">connecting with Amy at Plymouth</p>
        <p className="css-4hzbpn mb-0">Rock. You will not regret this</p>
        <p className="css-4hzbpn">transition/move!</p>
      </div>
    </div>
  );
}

function Container65() {
  return (
    <div className="content-stretch flex flex-col items-start pb-[5.5px] pt-[1.5px] px-0 relative shrink-0 w-full" data-name="Container">
      <div className="capitalize flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-black w-full">
        <p className="css-4hzbpn leading-[12px]">Review by: Courtney S.</p>
      </div>
    </div>
  );
}

function Review2() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-start pb-0 pt-[28px] px-0 relative shrink-0 w-[250px]" data-name="Review">
      <Rating2 />
      <Comment2 />
      <Container65 />
    </div>
  );
}

function Tabpanel2() {
  return (
    <div className="content-stretch flex flex-col items-start min-h-px relative self-stretch shrink-0 w-[310px]" data-name="Tabpanel">
      <Review2 />
    </div>
  );
}

function Component28() {
  return (
    <div className="h-[24px] relative shrink-0 w-[27px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 27 24">
        <g id="Component 1">
          <path d={svgPaths.p233e3400} fill="var(--fill-0, #0351AA)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Rating3() {
  return (
    <div className="content-stretch flex items-start pb-[7px] pt-0 px-0 relative shrink-0 w-full" data-name="Rating">
      {[...Array(5).keys()].map((_, i) => (
        <Component28 key={i} />
      ))}
    </div>
  );
}

function Comment3() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Comment">
      <div className="flex flex-col font-['Open_Sans:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[24px]">Love it no complaints</p>
      </div>
    </div>
  );
}

function Container66() {
  return (
    <div className="content-stretch flex flex-col items-start pb-[5.5px] pt-[1.5px] px-0 relative shrink-0 w-full" data-name="Container">
      <div className="capitalize flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[12px] text-black w-full">
        <p className="css-4hzbpn leading-[12px]">Review by: Hector P.</p>
      </div>
    </div>
  );
}

function Review3() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-start pb-0 pt-[28px] px-0 relative shrink-0 w-[250px]" data-name="Review">
      <Rating3 />
      <Comment3 />
      <Container66 />
    </div>
  );
}

function Tabpanel3() {
  return (
    <div className="content-stretch flex flex-col h-[126px] items-start min-h-px relative shrink-0 w-[310px]" data-name="Tabpanel">
      <Review3 />
    </div>
  );
}

function Container67() {
  return (
    <div className="content-stretch flex items-start pl-[1240px] pr-[6200px] py-0 relative shrink-0 w-[8680px]" data-name="Container">
      <Tabpanel />
      <Tabpanel1 />
      <Tabpanel2 />
      <Tabpanel3 />
    </div>
  );
}

function SingleReview() {
  return (
    <div className="relative shrink-0 w-full" data-name="Single review">
      <div className="flex flex-col items-center overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-center pl-[4960px] pr-0 py-0 relative w-full">
          <Container67 />
        </div>
      </div>
    </div>
  );
}

function Component29() {
  return (
    <div className="h-[19px] relative shrink-0 w-[13px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13 19">
        <g id="Component 1">
          <path d={svgPaths.p37cb2800} fill="var(--fill-0, #64778F)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="content-stretch flex flex-col h-[21px] items-start p-px relative rounded-[5px] shrink-0" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[5px]" />
      <Component29 />
    </div>
  );
}

function Component6() {
  return (
    <div className="h-[9px] relative w-[10px]" data-name="Component 7">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 9">
        <g id="Component 7">
          <path d={svgPaths.p30862b80} fill="var(--fill-0, #64778F)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Container68() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-0 size-[10px] top-px" data-name="Container">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none scale-y-[-100%]">
          <Component6 />
        </div>
      </div>
    </div>
  );
}

function Component7() {
  return (
    <div className="relative shrink-0 size-[10px]" data-name="Component 8">
      <Container68 />
    </div>
  );
}

function Component30() {
  return (
    <div className="h-[9px] relative w-[10px]" data-name="Component 7">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 9">
        <g id="Component 7">
          <path d={svgPaths.p30862b80} fill="var(--fill-0, #E0E0E0)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Container69() {
  return (
    <div className="absolute content-stretch flex flex-col items-start left-0 size-[10px] top-px" data-name="Container">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none scale-y-[-100%]">
          <Component30 />
        </div>
      </div>
    </div>
  );
}

function Component31() {
  return (
    <div className="relative shrink-0 size-[10px]" data-name="Component 8">
      <Container69 />
    </div>
  );
}

function Tablist() {
  return (
    <div className="content-stretch flex gap-[10px] items-start relative shrink-0 w-full" data-name="Tablist">
      <Component7 />
      {[...Array(2).keys()].map((_, i) => (
        <Component31 key={i} />
      ))}
    </div>
  );
}

function Container70() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Container">
      <Tablist />
    </div>
  );
}

function Component32() {
  return (
    <div className="h-[19px] relative shrink-0 w-[13px]" data-name="Component 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13 19">
        <g id="Component 1">
          <path d={svgPaths.p8f0800} fill="var(--fill-0, #64778F)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="content-stretch flex flex-col h-[21px] items-start p-px relative rounded-[5px] shrink-0" data-name="Button">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0)] border-solid inset-0 pointer-events-none rounded-[5px]" />
      <Component32 />
    </div>
  );
}

function Container71() {
  return (
    <div className="content-stretch flex gap-[20px] items-center justify-center relative shrink-0 w-full" data-name="Container">
      <Button />
      <Container70 />
      <Button1 />
    </div>
  );
}

function Container72() {
  return (
    <div className="content-stretch flex flex-col gap-[42px] items-start relative shrink-0 w-full" data-name="Container">
      <SingleReview />
      <Container71 />
    </div>
  );
}

function Container73() {
  return (
    <div className="content-stretch flex flex-col items-start relative self-stretch shrink-0 w-[1240px]" data-name="Container">
      <Container72 />
    </div>
  );
}

function Container74() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1280px] relative shrink-0 w-full" data-name="Container">
      <Container73 />
    </div>
  );
}

function Section7() {
  return (
    <div className="bg-[#e9f2fc] content-stretch flex flex-col items-start mb-[-1px] pb-[19px] pt-0 px-[310px] relative shrink-0 w-[1920px]" data-name="Section">
      <Container74 />
    </div>
  );
}

function Container75() {
  return (
    <div className="content-stretch flex flex-col items-end relative shrink-0 w-full" data-name="Container">
      <div className="css-g0mm18 flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[0px] text-black text-right">
        <p className="css-ew64yg text-[14px]">
          <span className="font-['Open_Sans:Bold',sans-serif] leading-[20px]">4.1 out of 5</span>
          <span className="font-['Open_Sans:Regular',sans-serif] leading-[20px]">{`, based on `}</span>
          <span className="font-['Open_Sans:Bold',sans-serif] leading-[20px]">3756</span>
        </p>
      </div>
    </div>
  );
}

function Container76() {
  return (
    <div className="content-stretch flex flex-col items-start max-w-[210px] relative shrink-0 w-[210px]" data-name="Container">
      <Container75 />
    </div>
  );
}

function GoogleLogo1() {
  return (
    <div className="h-[14.09px] max-w-[45px] relative shrink-0 w-[45px]" data-name="Google logo">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute h-[100.07%] left-0 max-w-none top-[-0.04%] w-full" src={imgGoogleLogo} />
      </div>
    </div>
  );
}

function Container77() {
  return (
    <div className="content-stretch flex flex-col items-center pb-[4.24px] pt-[7.67px] px-0 relative shrink-0 w-full" data-name="Container">
      <GoogleLogo1 />
    </div>
  );
}

function Container78() {
  return (
    <div className="content-stretch flex flex-col items-start max-w-[55px] px-[5px] py-0 relative shrink-0 w-[55px]" data-name="Container">
      <Container77 />
    </div>
  );
}

function Container79() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-col font-['Open_Sans:Bold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[14px] text-black w-full">
        <p className="css-4hzbpn leading-[20px]">reviews as of January 2026</p>
      </div>
    </div>
  );
}

function Container80() {
  return (
    <div className="content-stretch flex flex-col items-start max-w-[210px] relative shrink-0 w-[210px]" data-name="Container">
      <Container79 />
    </div>
  );
}

function Container81() {
  return (
    <div className="content-center flex flex-[1_0_0] flex-wrap gap-0 items-center justify-center min-h-px min-w-px pb-[53px] pt-0 px-0 relative self-stretch" data-name="Container">
      <Container76 />
      <Container78 />
      <Container80 />
    </div>
  );
}

function Container82() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0 w-full" data-name="Container">
      <Container81 />
    </div>
  );
}

function Section8() {
  return (
    <div className="bg-[#e9f2fc] content-stretch flex flex-col items-start mb-[-1px] relative shrink-0 w-[1920px]" data-name="Section">
      <Container82 />
    </div>
  );
}

function Heading3() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Heading 2">
      <div className="css-g0mm18 flex flex-col font-['Manrope:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[32px] text-center text-white">
        <p className="css-ew64yg leading-[42px]">Find answers to your insurance questions.</p>
      </div>
    </div>
  );
}

function Container83() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Container">
      <div className="content-stretch flex flex-col items-start px-[15px] py-0 relative size-full">
        <Heading3 />
      </div>
    </div>
  );
}

function Margin3() {
  return (
    <div className="content-stretch flex flex-col h-[78px] items-start justify-center pb-[16px] pt-0 px-0 relative shrink-0 w-full" data-name="Margin">
      <Container83 />
    </div>
  );
}

function MomAndDaughterViewingDentInBlueCar() {
  return (
    <div className="h-[140px] max-w-[270.9200134277344px] relative rounded-[16px] shrink-0 w-[270.92px]" data-name="Mom and daughter viewing dent in blue car">
      <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[16px]">
        <img alt="" className="absolute h-full left-[-1.13%] max-w-none top-0 w-[102.26%]" src={imgMomAndDaughterViewingDentInBlueCar} />
      </div>
    </div>
  );
}

function Container84() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <MomAndDaughterViewingDentInBlueCar />
    </div>
  );
}

function Container85() {
  return (
    <div className="content-stretch flex flex-col h-[150px] items-start relative shrink-0 w-full" data-name="Container">
      <Container84 />
    </div>
  );
}

function Component8() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-full" data-name="Component 9">
      <a className="flex flex-[1_0_0] flex-col font-['Manrope:Regular',sans-serif] justify-center leading-[0] min-h-px min-w-px not-italic relative text-[20px] text-black" href="https://www.plymouthrock.com/resources/auto-insurance-basics">
        <p className="css-4hzbpn cursor-pointer leading-[28px]">Auto Insurance basics</p>
      </a>
    </div>
  );
}

function Heading4() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 2">
      <Component8 />
    </div>
  );
}

function Container86() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-[85px] items-start min-h-px min-w-px overflow-clip relative" data-name="Container">
      <Heading4 />
    </div>
  );
}

function Container87() {
  return (
    <div className="content-start flex flex-[1_0_0] flex-wrap items-start justify-center min-h-px min-w-px px-0 py-[8px] relative self-stretch" data-name="Container">
      <Container86 />
    </div>
  );
}

function Container88() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0 w-full" data-name="Container">
      <Container87 />
    </div>
  );
}

function Section9() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[10px] py-0 relative size-full">
        <Container88 />
      </div>
    </div>
  );
}

function SectionMargin() {
  return (
    <div className="content-stretch flex flex-col h-[106px] items-start justify-center pb-[5px] pt-0 px-0 relative shrink-0 w-full" data-name="Section:margin">
      <Section9 />
    </div>
  );
}

function Paragraph() {
  return (
    <div className="content-stretch flex font-['Open_Sans:Regular',sans-serif] gap-[5px] items-start leading-[0] not-italic relative shrink-0 text-[#64778f] text-[14px] w-full" data-name="Paragraph">
      <div className="css-g0mm18 flex flex-col justify-center relative shrink-0">
        <p className="css-ew64yg leading-[20px]">{`5 minute read `}</p>
      </div>
      <div className="css-g0mm18 flex flex-col justify-center relative shrink-0">
        <p className="css-ew64yg leading-[20px]">•</p>
      </div>
      <div className="css-g0mm18 flex flex-col justify-center relative shrink-0">
        <p className="css-ew64yg leading-[20px]">{` December 2025`}</p>
      </div>
    </div>
  );
}

function Container89() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative self-stretch" data-name="Container">
      <Paragraph />
    </div>
  );
}

function Container90() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1140px] relative shrink-0 w-full" data-name="Container">
      <Container89 />
    </div>
  );
}

function Section10() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[10px] py-0 relative size-full">
        <Container90 />
      </div>
    </div>
  );
}

function SectionMargin1() {
  return (
    <div className="content-stretch flex flex-col h-[25px] items-start justify-center pb-[5px] pt-0 px-0 relative shrink-0 w-full" data-name="Section:margin">
      <Section10 />
    </div>
  );
}

function Container91() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative self-stretch" data-name="Container">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pb-[7px] pt-[6.5px] px-[7px] relative size-full">
          <Container85 />
          <SectionMargin />
          <SectionMargin1 />
        </div>
      </div>
    </div>
  );
}

function Container92() {
  return (
    <div className="max-w-[295px] relative shrink-0 w-[284.92px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start justify-center max-w-[inherit] relative w-full">
        <Container91 />
      </div>
    </div>
  );
}

function Section11() {
  return (
    <div className="bg-white content-stretch flex flex-[1_0_0] flex-col items-start max-w-[295px] min-h-px min-w-px p-px relative rounded-[20px] w-full" data-name="Section">
      <div aria-hidden="true" className="absolute border border-[#0078d6] border-solid inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]" />
      <Container92 />
    </div>
  );
}

function Group1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative w-[286.92px]" data-name="Group - 1 / 4">
      <Section11 />
    </div>
  );
}

function Group14Margin() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center pl-0 pr-[20px] py-0 relative self-stretch shrink-0 w-[306.92px]" data-name="Group - 1 / 4:margin">
      <Group1 />
    </div>
  );
}

function HappyManDrivingACar() {
  return (
    <div className="h-[140px] max-w-[270.9200134277344px] relative rounded-[16px] shrink-0 w-[270.92px]" data-name="Happy man driving a car.">
      <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[16px]">
        <img alt="" className="absolute h-[105.83%] left-0 max-w-none top-[-2.91%] w-full" src={imgHappyManDrivingACar} />
      </div>
    </div>
  );
}

function Container93() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <HappyManDrivingACar />
    </div>
  );
}

function Container94() {
  return (
    <div className="content-stretch flex flex-col h-[150px] items-start relative shrink-0 w-full" data-name="Container">
      <Container93 />
    </div>
  );
}

function Component33() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-full" data-name="Component 9">
      <a className="cursor-pointer flex flex-[1_0_0] flex-col font-['Manrope:Regular',sans-serif] justify-center leading-[28px] min-h-px min-w-px not-italic relative text-[0px] text-[20px] text-black" href="https://www.plymouthrock.com/resources/auto-insurance-basics">
        <p className="css-4hzbpn mb-0" role="link" tabIndex="0">
          Does paying off a car lower
        </p>
        <p className="css-4hzbpn" role="link" tabIndex="0">
          insurance?
        </p>
      </a>
    </div>
  );
}

function Heading5() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 2">
      <Component33 />
    </div>
  );
}

function Container95() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-[85px] items-start min-h-px min-w-px overflow-clip relative" data-name="Container">
      <Heading5 />
    </div>
  );
}

function Container96() {
  return (
    <div className="content-start flex flex-[1_0_0] flex-wrap items-start justify-center min-h-px min-w-px px-0 py-[8px] relative self-stretch" data-name="Container">
      <Container95 />
    </div>
  );
}

function Container97() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0 w-full" data-name="Container">
      <Container96 />
    </div>
  );
}

function Section12() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[10px] py-0 relative size-full">
        <Container97 />
      </div>
    </div>
  );
}

function SectionMargin2() {
  return (
    <div className="content-stretch flex flex-col h-[106px] items-start justify-center pb-[5px] pt-0 px-0 relative shrink-0 w-full" data-name="Section:margin">
      <Section12 />
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="content-stretch flex font-['Open_Sans:Regular',sans-serif] gap-[5px] items-start leading-[0] not-italic relative shrink-0 text-[#64778f] text-[14px] w-full" data-name="Paragraph">
      <div className="css-g0mm18 flex flex-col justify-center relative shrink-0">
        <p className="css-ew64yg leading-[20px]">{`5 minute read `}</p>
      </div>
      <div className="css-g0mm18 flex flex-col justify-center relative shrink-0">
        <p className="css-ew64yg leading-[20px]">•</p>
      </div>
      <div className="css-g0mm18 flex flex-col justify-center relative shrink-0">
        <p className="css-ew64yg leading-[20px]">{` April 2025`}</p>
      </div>
    </div>
  );
}

function Container98() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative self-stretch" data-name="Container">
      <Paragraph1 />
    </div>
  );
}

function Container99() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1140px] relative shrink-0 w-full" data-name="Container">
      <Container98 />
    </div>
  );
}

function Section13() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[10px] py-0 relative size-full">
        <Container99 />
      </div>
    </div>
  );
}

function SectionMargin3() {
  return (
    <div className="content-stretch flex flex-col h-[25px] items-start justify-center pb-[5px] pt-0 px-0 relative shrink-0 w-full" data-name="Section:margin">
      <Section13 />
    </div>
  );
}

function Container100() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative self-stretch" data-name="Container">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pb-[7px] pt-[6.5px] px-[7px] relative size-full">
          <Container94 />
          <SectionMargin2 />
          <SectionMargin3 />
        </div>
      </div>
    </div>
  );
}

function Container101() {
  return (
    <div className="max-w-[295px] relative shrink-0 w-[284.92px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start justify-center max-w-[inherit] relative w-full">
        <Container100 />
      </div>
    </div>
  );
}

function Section14() {
  return (
    <div className="bg-white content-stretch flex flex-[1_0_0] flex-col items-start max-w-[295px] min-h-px min-w-px p-px relative rounded-[20px] w-full" data-name="Section">
      <div aria-hidden="true" className="absolute border border-[#0078d6] border-solid inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]" />
      <Container101 />
    </div>
  );
}

function Group2() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative w-[286.92px]" data-name="Group - 2 / 4">
      <Section14 />
    </div>
  );
}

function Group24Margin() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center pl-0 pr-[20px] py-0 relative self-stretch shrink-0 w-[306.92px]" data-name="Group - 2 / 4:margin">
      <Group2 />
    </div>
  );
}

function AHappyFamilyThatJustLearnedHowMuchHomeownersInsuranceTheyNeed() {
  return (
    <div className="h-[140px] max-w-[270.9200134277344px] relative rounded-[16px] shrink-0 w-[270.92px]" data-name="A happy family that just learned how much homeowners insurance they need">
      <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[16px]">
        <img alt="" className="absolute h-[105.79%] left-0 max-w-none top-[-2.89%] w-full" src={imgAHappyFamilyThatJustLearnedHowMuchHomeownersInsuranceTheyNeed} />
      </div>
    </div>
  );
}

function Container102() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <AHappyFamilyThatJustLearnedHowMuchHomeownersInsuranceTheyNeed />
    </div>
  );
}

function Container103() {
  return (
    <div className="content-stretch flex flex-col h-[150px] items-start relative shrink-0 w-full" data-name="Container">
      <Container102 />
    </div>
  );
}

function Component34() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-full" data-name="Component 9">
      <a className="cursor-pointer flex flex-[1_0_0] flex-col font-['Manrope:Regular',sans-serif] justify-center leading-[28px] min-h-px min-w-px not-italic relative text-[0px] text-[20px] text-black" href="https://www.plymouthrock.com/resources/auto-insurance-basics">
        <p className="css-4hzbpn mb-0" role="link" tabIndex="0">
          How much homeowners
        </p>
        <p className="css-4hzbpn mb-0" role="link" tabIndex="0">
          insurance coverage do I
        </p>
        <p className="css-4hzbpn" role="link" tabIndex="0">
          need?
        </p>
      </a>
    </div>
  );
}

function Heading6() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 2">
      <Component34 />
    </div>
  );
}

function Container104() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-[85px] items-start min-h-px min-w-px overflow-clip relative" data-name="Container">
      <Heading6 />
    </div>
  );
}

function Container105() {
  return (
    <div className="content-start flex flex-[1_0_0] flex-wrap items-start justify-center min-h-px min-w-px px-0 py-[8px] relative self-stretch" data-name="Container">
      <Container104 />
    </div>
  );
}

function Container106() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0 w-full" data-name="Container">
      <Container105 />
    </div>
  );
}

function Section15() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[10px] py-0 relative size-full">
        <Container106 />
      </div>
    </div>
  );
}

function SectionMargin4() {
  return (
    <div className="content-stretch flex flex-col h-[106px] items-start justify-center pb-[5px] pt-0 px-0 relative shrink-0 w-full" data-name="Section:margin">
      <Section15 />
    </div>
  );
}

function Paragraph2() {
  return (
    <div className="content-stretch flex font-['Open_Sans:Regular',sans-serif] gap-[5px] items-start leading-[0] not-italic relative shrink-0 text-[#64778f] text-[14px] w-full" data-name="Paragraph">
      <div className="css-g0mm18 flex flex-col justify-center relative shrink-0">
        <p className="css-ew64yg leading-[20px]">{`6 minute read `}</p>
      </div>
      <div className="css-g0mm18 flex flex-col justify-center relative shrink-0">
        <p className="css-ew64yg leading-[20px]">•</p>
      </div>
      <div className="css-g0mm18 flex flex-col justify-center relative shrink-0">
        <p className="css-ew64yg leading-[20px]">{` September 2025`}</p>
      </div>
    </div>
  );
}

function Container107() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative self-stretch" data-name="Container">
      <Paragraph2 />
    </div>
  );
}

function Container108() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1140px] relative shrink-0 w-full" data-name="Container">
      <Container107 />
    </div>
  );
}

function Section16() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[10px] py-0 relative size-full">
        <Container108 />
      </div>
    </div>
  );
}

function SectionMargin5() {
  return (
    <div className="content-stretch flex flex-col h-[25px] items-start justify-center pb-[5px] pt-0 px-0 relative shrink-0 w-full" data-name="Section:margin">
      <Section16 />
    </div>
  );
}

function Container109() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative self-stretch" data-name="Container">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pb-[7px] pt-[6.5px] px-[7px] relative size-full">
          <Container103 />
          <SectionMargin4 />
          <SectionMargin5 />
        </div>
      </div>
    </div>
  );
}

function Container110() {
  return (
    <div className="max-w-[295px] relative shrink-0 w-[284.92px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start justify-center max-w-[inherit] relative w-full">
        <Container109 />
      </div>
    </div>
  );
}

function Section17() {
  return (
    <div className="bg-white content-stretch flex flex-[1_0_0] flex-col items-start max-w-[295px] min-h-px min-w-px p-px relative rounded-[20px] w-full" data-name="Section">
      <div aria-hidden="true" className="absolute border border-[#0078d6] border-solid inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]" />
      <Container110 />
    </div>
  );
}

function Group3() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative w-[286.92px]" data-name="Group - 3 / 4">
      <Section17 />
    </div>
  );
}

function Group34Margin() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center pl-0 pr-[20px] py-0 relative self-stretch shrink-0 w-[306.92px]" data-name="Group - 3 / 4:margin">
      <Group3 />
    </div>
  );
}

function PersonShovelingSnow() {
  return (
    <div className="h-[140px] max-w-[270.9200134277344px] relative rounded-[16px] shrink-0 w-[270.92px]" data-name="Person shoveling snow">
      <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[16px]">
        <img alt="" className="absolute h-[105.79%] left-0 max-w-none top-[-2.89%] w-full" src={imgPersonShovelingSnow} />
      </div>
    </div>
  );
}

function Container111() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Container">
      <PersonShovelingSnow />
    </div>
  );
}

function Container112() {
  return (
    <div className="content-stretch flex flex-col h-[150px] items-start relative shrink-0 w-full" data-name="Container">
      <Container111 />
    </div>
  );
}

function Component35() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-full" data-name="Component 9">
      <a className="cursor-pointer flex flex-[1_0_0] flex-col font-['Manrope:Regular',sans-serif] justify-center leading-[28px] min-h-px min-w-px not-italic relative text-[0px] text-[20px] text-black" href="https://www.plymouthrock.com/resources/auto-insurance-basics">
        <p className="css-4hzbpn mb-0" role="link" tabIndex="0">
          Winter home maintenance
        </p>
        <p className="css-4hzbpn" role="link" tabIndex="0">
          checklist
        </p>
      </a>
    </div>
  );
}

function Heading7() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Heading 2">
      <Component35 />
    </div>
  );
}

function Container113() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col h-[85px] items-start min-h-px min-w-px overflow-clip relative" data-name="Container">
      <Heading7 />
    </div>
  );
}

function Container114() {
  return (
    <div className="content-start flex flex-[1_0_0] flex-wrap items-start justify-center min-h-px min-w-px px-0 py-[8px] relative self-stretch" data-name="Container">
      <Container113 />
    </div>
  );
}

function Container115() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0 w-full" data-name="Container">
      <Container114 />
    </div>
  );
}

function Section18() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[10px] py-0 relative size-full">
        <Container115 />
      </div>
    </div>
  );
}

function SectionMargin6() {
  return (
    <div className="content-stretch flex flex-col h-[106px] items-start justify-center pb-[5px] pt-0 px-0 relative shrink-0 w-full" data-name="Section:margin">
      <Section18 />
    </div>
  );
}

function Paragraph3() {
  return (
    <div className="content-stretch flex font-['Open_Sans:Regular',sans-serif] gap-[5px] items-start leading-[0] not-italic relative shrink-0 text-[#64778f] text-[14px] w-full" data-name="Paragraph">
      <div className="css-g0mm18 flex flex-col justify-center relative shrink-0">
        <p className="css-ew64yg leading-[20px]">{`4 minute read `}</p>
      </div>
      <div className="css-g0mm18 flex flex-col justify-center relative shrink-0">
        <p className="css-ew64yg leading-[20px]">•</p>
      </div>
      <div className="css-g0mm18 flex flex-col justify-center relative shrink-0">
        <p className="css-ew64yg leading-[20px]">{` December 2025`}</p>
      </div>
    </div>
  );
}

function Container116() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start min-h-px min-w-px relative self-stretch" data-name="Container">
      <Paragraph3 />
    </div>
  );
}

function Container117() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1140px] relative shrink-0 w-full" data-name="Container">
      <Container116 />
    </div>
  );
}

function Section19() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative w-full" data-name="Section">
      <div className="content-stretch flex flex-col items-start px-[10px] py-0 relative size-full">
        <Container117 />
      </div>
    </div>
  );
}

function SectionMargin7() {
  return (
    <div className="content-stretch flex flex-col h-[25px] items-start justify-center pb-[5px] pt-0 px-0 relative shrink-0 w-full" data-name="Section:margin">
      <Section19 />
    </div>
  );
}

function Container118() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative self-stretch" data-name="Container">
      <div className="flex flex-col justify-center size-full">
        <div className="content-stretch flex flex-col items-start justify-center pb-[7px] pt-[6.5px] px-[7px] relative size-full">
          <Container112 />
          <SectionMargin6 />
          <SectionMargin7 />
        </div>
      </div>
    </div>
  );
}

function Container119() {
  return (
    <div className="max-w-[295px] relative shrink-0 w-[284.92px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start justify-center max-w-[inherit] relative w-full">
        <Container118 />
      </div>
    </div>
  );
}

function Section20() {
  return (
    <div className="bg-white content-stretch flex flex-[1_0_0] flex-col items-start max-w-[295px] min-h-px min-w-px p-px relative rounded-[20px] w-full" data-name="Section">
      <div aria-hidden="true" className="absolute border border-[#0078d6] border-solid inset-0 pointer-events-none rounded-[20px] shadow-[0px_8px_22px_0px_rgba(0,0,0,0.25)]" />
      <Container119 />
    </div>
  );
}

function Group4() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative w-[286.92px]" data-name="Group - 4 / 4">
      <Section20 />
    </div>
  );
}

function Group44Margin() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center pl-0 pr-[20px] py-0 relative self-stretch shrink-0 w-[306.92px]" data-name="Group - 4 / 4:margin">
      <Group4 />
    </div>
  );
}

function Container120() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-[1227.69px]" data-name="Container">
      <Group14Margin />
      <Group24Margin />
      <Group34Margin />
      <Group44Margin />
    </div>
  );
}

function Container121() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative" data-name="Container">
      <Container120 />
    </div>
  );
}

function Container122() {
  return (
    <div className="flex-[1_0_0] min-h-px min-w-px relative self-stretch" data-name="Container">
      <div className="flex flex-row justify-center size-full">
        <div className="content-start flex flex-wrap items-start justify-center px-[16px] py-0 relative size-full">
          <Container121 />
        </div>
      </div>
    </div>
  );
}

function Section21() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1240px] relative shrink-0 w-full" data-name="Section">
      <Container122 />
    </div>
  );
}

function Container123() {
  return (
    <div className="h-[296.5px] relative shrink-0 w-full" data-name="Container">
      <div className="content-stretch flex flex-col items-start px-[20px] py-0 relative size-full">
        <Section21 />
      </div>
    </div>
  );
}

function Container124() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-start justify-center min-h-px min-w-px relative self-stretch" data-name="Container">
      <Margin3 />
      <Container123 />
    </div>
  );
}

function Container125() {
  return (
    <div className="content-stretch flex items-start justify-center max-w-[1280px] relative shrink-0 w-full" data-name="Container">
      <Container124 />
    </div>
  );
}

function Section22() {
  return (
    <div className="content-stretch flex flex-col items-start mb-[-1px] pb-[90px] pt-[60px] px-[310px] relative shrink-0 w-[1920px]" data-name="Section" style={{ backgroundImage: "linear-gradient(145.281deg, rgb(3, 81, 170) 0%, rgb(0, 120, 214) 100%)" }}>
      <Container125 />
    </div>
  );
}

function Section23() {
  return <div className="bg-[#eff6fd] h-[140px] mb-[-1px] shrink-0 w-[1920px]" data-name="Section" />;
}

function PlymouthRockSite() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[1799px] items-start left-0 max-w-[1920px] min-w-[1920px] pb-px pt-0 px-0 right-0 top-0" data-name="PlymouthRock-site">
      <Header />
      <Section2 />
      <Section5 />
      <Section6 />
      <Section7 />
      <Section8 />
      <Section22 />
      <Section23 />
    </div>
  );
}

export default function PrSite() {
  return (
    <div className="relative size-full" data-name="PR-site 2">
      <PlymouthRockSite />
    </div>
  );
}